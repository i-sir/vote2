DROP TABLE cmf_admin_menu;

CREATE TABLE `cmf_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '菜单类型;1:有界面可访问菜单,2:无界面可访问菜单,0:只作为菜单',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;1:显示,0:不显示',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '应用名',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '操作名称',
  `param` varchar(50) NOT NULL DEFAULT '' COMMENT '额外参数',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单名称',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `controller` (`controller`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单表';

INSERT INTO cmf_admin_menu VALUES("1","0","0","1","9000","admin","Plugin","default","","插件中心","cloud","插件中心","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("2","1","1","0","1000","admin","Hook","index","","钩子管理","","钩子管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("3","2","1","0","1000","admin","Hook","plugins","","钩子插件管理","","钩子插件管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("4","2","2","0","1000","admin","Hook","pluginListOrder","","钩子插件排序","","钩子插件排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("5","2","1","0","1000","admin","Hook","sync","","同步钩子","","同步钩子","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("6","0","0","1","100","admin","Setting","default","","设置","cogs","系统设置入口","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("7","248","1","1","1000","admin","Link","index","","链接管理","","友情链接管理","1740995591","1741659517","0");
INSERT INTO cmf_admin_menu VALUES("8","7","1","0","1000","admin","Link","add","","添加友情链接","","添加友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("9","7","2","0","1000","admin","Link","addPost","","添加友情链接提交保存","","添加友情链接提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("10","7","1","0","1000","admin","Link","edit","","编辑友情链接","","编辑友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("11","7","2","0","1000","admin","Link","editPost","","编辑友情链接提交保存","","编辑友情链接提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("12","7","2","0","1000","admin","Link","delete","","删除友情链接","","删除友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("13","7","2","0","1000","admin","Link","listOrder","","友情链接排序","","友情链接排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("14","7","2","0","1000","admin","Link","toggle","","友情链接显示隐藏","","友情链接显示隐藏","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("15","6","1","1","500","admin","Mailer","index","","邮箱配置","","邮箱配置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("16","15","2","0","1000","admin","Mailer","indexPost","","邮箱配置提交保存","","邮箱配置提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("17","15","1","0","1000","admin","Mailer","template","","邮件模板","","邮件模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("18","15","2","0","1000","admin","Mailer","templatePost","","邮件模板提交","","邮件模板提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("19","15","1","0","1000","admin","Mailer","test","","邮件发送测试","","邮件发送测试","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("20","6","1","0","510","admin","Menu","index","","后台菜单","","后台菜单管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("21","20","1","0","1000","admin","Menu","lists","","所有菜单","","后台所有菜单列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("22","20","1","0","1000","admin","Menu","add","","后台菜单添加","","后台菜单添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("23","20","2","0","1000","admin","Menu","addPost","","后台菜单添加提交保存","","后台菜单添加提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("24","20","1","0","1000","admin","Menu","edit","","后台菜单编辑","","后台菜单编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("25","20","2","0","1000","admin","Menu","editPost","","后台菜单编辑提交保存","","后台菜单编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("26","20","2","0","1000","admin","Menu","delete","","后台菜单删除","","后台菜单删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("27","20","2","0","1000","admin","Menu","listOrder","","后台菜单排序","","后台菜单排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("28","20","1","0","1000","admin","Menu","getActions","","导入新后台菜单","","导入新后台菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("29","6","1","0","520","admin","Nav","index","","导航管理","","导航管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("30","29","1","0","1000","admin","Nav","add","","添加导航","","添加导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("31","29","2","0","1000","admin","Nav","addPost","","添加导航提交保存","","添加导航提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("32","29","1","0","1000","admin","Nav","edit","","编辑导航","","编辑导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("33","29","2","0","1000","admin","Nav","editPost","","编辑导航提交保存","","编辑导航提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("34","29","2","0","1000","admin","Nav","delete","","删除导航","","删除导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("35","29","1","0","1000","admin","NavMenu","index","","导航菜单","","导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("36","35","1","0","1000","admin","NavMenu","add","","添加导航菜单","","添加导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("37","35","2","0","1000","admin","NavMenu","addPost","","添加导航菜单提交保存","","添加导航菜单提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("38","35","1","0","1000","admin","NavMenu","edit","","编辑导航菜单","","编辑导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("39","35","2","0","1000","admin","NavMenu","editPost","","编辑导航菜单提交保存","","编辑导航菜单提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("40","35","2","0","1000","admin","NavMenu","delete","","删除导航菜单","","删除导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("41","35","2","0","1000","admin","NavMenu","listOrder","","导航菜单排序","","导航菜单排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("42","1","1","1","1000","admin","Plugin","index","","插件列表","","插件列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("43","42","2","0","1000","admin","Plugin","toggle","","插件启用禁用","","插件启用禁用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("44","42","1","0","1000","admin","Plugin","setting","","插件设置","","插件设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("45","42","2","0","1000","admin","Plugin","settingPost","","插件设置提交","","插件设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("46","42","2","0","1000","admin","Plugin","install","","插件安装","","插件安装","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("47","42","2","0","1000","admin","Plugin","update","","插件更新","","插件更新","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("48","42","2","0","1000","admin","Plugin","uninstall","","卸载插件","","卸载插件","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("49","0","0","1","8900","admin","User","default","","管理组","users","管理组","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("50","49","1","1","1000","admin","Rbac","index","","角色管理","","角色管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("51","50","1","0","1000","admin","Rbac","roleAdd","","添加角色","","添加角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("52","50","2","0","1000","admin","Rbac","roleAddPost","","添加角色提交","","添加角色提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("53","50","1","0","1000","admin","Rbac","roleEdit","","编辑角色","","编辑角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("54","50","2","0","1000","admin","Rbac","roleEditPost","","编辑角色提交","","编辑角色提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("55","50","2","0","1000","admin","Rbac","roleDelete","","删除角色","","删除角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("56","50","1","0","1000","admin","Rbac","authorize","","设置角色权限","","设置角色权限","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("57","50","2","0","1000","admin","Rbac","authorizePost","","角色授权提交","","角色授权提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("58","199","1","0","10000","admin","RecycleBin","index","","回收站","","回收站","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("59","58","2","0","1000","admin","RecycleBin","restore","","回收站还原","","回收站还原","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("60","58","2","0","1000","admin","RecycleBin","delete","","回收站彻底删除","","回收站彻底删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("61","6","1","0","530","admin","Route","index","","URL美化","","URL规则管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("62","61","1","0","1000","admin","Route","add","","添加路由规则","","添加路由规则","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("63","61","2","0","1000","admin","Route","addPost","","添加路由规则提交","","添加路由规则提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("64","61","1","0","1000","admin","Route","edit","","路由规则编辑","","路由规则编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("65","61","2","0","1000","admin","Route","editPost","","路由规则编辑提交","","路由规则编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("66","61","2","0","1000","admin","Route","delete","","路由规则删除","","路由规则删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("67","61","2","0","1000","admin","Route","ban","","路由规则禁用","","路由规则禁用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("68","61","2","0","1000","admin","Route","open","","路由规则启用","","路由规则启用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("69","61","2","0","1000","admin","Route","listOrder","","路由规则排序","","路由规则排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("70","61","1","0","1000","admin","Route","select","","选择URL","","选择URL","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("71","6","1","0","540","admin","Setting","site","","网站信息","","网站信息","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("72","71","2","0","1000","admin","Setting","sitePost","","网站信息设置提交","","网站信息设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("73","199","1","0","1000","admin","Setting","password","","密码修改","","密码修改","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("74","73","2","0","1000","admin","Setting","passwordPost","","密码修改提交","","密码修改提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("75","6","1","1","30","admin","Setting","upload","","上传设置","","上传设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("76","75","2","0","1000","admin","Setting","uploadPost","","上传设置提交","","上传设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("77","199","1","0","1000","admin","Setting","clearCache","","清除缓存","","清除缓存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("78","248","1","1","20","admin","Slide","index","","分类管理","","幻灯片管理","1740995591","1741659181","0");
INSERT INTO cmf_admin_menu VALUES("79","78","1","0","1000","admin","Slide","add","","添加幻灯片","","添加幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("80","78","2","0","1000","admin","Slide","addPost","","添加幻灯片提交","","添加幻灯片提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("81","78","1","0","1000","admin","Slide","edit","","编辑幻灯片","","编辑幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("82","78","2","0","1000","admin","Slide","editPost","","编辑幻灯片提交","","编辑幻灯片提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("83","78","2","0","1000","admin","Slide","delete","","删除幻灯片","","删除幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("84","78","1","0","1000","admin","SlideItem","index","","幻灯片页面列表","","幻灯片页面列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("85","84","1","0","1000","admin","SlideItem","add","","幻灯片页面添加","","幻灯片页面添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("86","84","2","0","1000","admin","SlideItem","addPost","","幻灯片页面添加提交","","幻灯片页面添加提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("87","84","1","0","1000","admin","SlideItem","edit","","幻灯片页面编辑","","幻灯片页面编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("88","84","2","0","1000","admin","SlideItem","editPost","","幻灯片页面编辑提交","","幻灯片页面编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("89","84","2","0","1000","admin","SlideItem","delete","","幻灯片页面删除","","幻灯片页面删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("90","84","2","0","1000","admin","SlideItem","ban","","幻灯片页面隐藏","","幻灯片页面隐藏","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("91","84","2","0","1000","admin","SlideItem","cancelBan","","幻灯片页面显示","","幻灯片页面显示","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("92","84","2","0","1000","admin","SlideItem","listOrder","","幻灯片页面排序","","幻灯片页面排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("93","6","1","1","40","admin","Storage","index","","文件存储","","文件存储","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("94","93","2","0","1000","admin","Storage","settingPost","","文件存储设置提交","","文件存储设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("95","6","1","0","550","admin","Theme","index","","模板管理","","模板管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("96","95","1","0","1000","admin","Theme","install","","安装模板","","安装模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("97","95","2","0","1000","admin","Theme","uninstall","","卸载模板","","卸载模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("98","95","2","0","1000","admin","Theme","installTheme","","模板安装","","模板安装","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("99","95","2","0","1000","admin","Theme","update","","模板更新","","模板更新","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("100","95","2","0","1000","admin","Theme","active","","启用模板","","启用模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("101","95","1","0","1000","admin","Theme","files","","模板文件列表","","启用模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("102","95","1","0","1000","admin","Theme","fileSetting","","模板文件设置","","模板文件设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("103","95","1","0","1000","admin","Theme","fileArrayData","","模板文件数组数据列表","","模板文件数组数据列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("104","95","2","0","1000","admin","Theme","fileArrayDataEdit","","模板文件数组数据添加编辑","","模板文件数组数据添加编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("105","95","2","0","1000","admin","Theme","fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","","模板文件数组数据添加编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("106","95","2","0","1000","admin","Theme","fileArrayDataDelete","","模板文件数组数据删除","","模板文件数组数据删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("107","95","2","0","1000","admin","Theme","settingPost","","模板文件编辑提交保存","","模板文件编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("108","95","1","0","1000","admin","Theme","dataSource","","模板文件设置数据源","","模板文件设置数据源","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("109","95","1","0","1000","admin","Theme","design","","模板设计","","模板设计","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("112","111","1","0","1000","admin","User","add","","管理员添加","","管理员添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("113","111","2","0","1000","admin","User","addPost","","管理员添加提交","","管理员添加提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("114","111","1","0","1000","admin","User","edit","","管理员编辑","","管理员编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("115","111","2","0","1000","admin","User","editPost","","管理员编辑提交","","管理员编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("116","111","1","0","1000","admin","User","userInfo","","个人信息","","管理员个人信息修改","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("117","111","2","0","1000","admin","User","userInfoPost","","管理员个人信息修改提交","","管理员个人信息修改提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("118","111","2","0","1000","admin","User","delete","","管理员删除","","管理员删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("119","111","2","0","1000","admin","User","ban","","停用管理员","","停用管理员","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("120","111","2","0","1000","admin","User","cancelBan","","启用管理员","","启用管理员","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("121","199","1","0","1000","user","AdminAsset","index","","资源管理","file","资源管理列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("122","121","2","0","1000","user","AdminAsset","delete","","删除文件","","删除文件","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("123","110","0","1","10000","user","AdminIndex","default1","","用户组","","用户组","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("124","123","1","1","10000","user","AdminIndex","index","","本站用户","","本站用户","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("125","124","2","0","10000","user","AdminIndex","ban","","本站用户拉黑","","本站用户拉黑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("126","124","2","0","10000","user","AdminIndex","cancelBan","","本站用户启用","","本站用户启用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("127","123","1","1","10000","user","AdminOauth","index","","第三方用户","","第三方用户","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("128","127","2","0","10000","user","AdminOauth","delete","","删除第三方用户绑定","","删除第三方用户绑定","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("130","129","1","0","1000","user","AdminUserAction","edit","","编辑用户操作","","编辑用户操作","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("131","129","2","0","1000","user","AdminUserAction","editPost","","编辑用户操作提交","","编辑用户操作提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("132","129","1","0","1000","user","AdminUserAction","sync","","同步用户操作","","同步用户操作","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("162","58","2","0","1000","admin","RecycleBin","clear","","清空回收站","","一键清空回收站","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("163","1","1","1","1000","plugin/Swagger","AdminIndex","index","","Swagger","","Swagger","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("164","6","1","1","10","plugin/Configs","AdminIndex","index","","系统参数设置","","系统参数设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("167","0","1","1","1000","admin","member","default","","用户管理","user-o","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("168","167","1","1","1000","admin","member","index","","用户管理","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("169","1","1","1","1000","/plugin/form","AdminIndex","setting","","生成CURD","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("179","0","1","1","8000","admin","dingdan","index","","订单管理","reorder","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("180","179","1","1","1000","admin","shop_order","index","","订单管理","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("183","182","1","0","10000","admin","Shop","edit","","编辑","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("184","182","1","0","10000","admin","Shop","add","","添加","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("185","182","1","0","10000","admin","Shop","find","","查看","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("186","182","1","0","10000","admin","Shop","delete","","删除","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("198","6","1","1","1000","plugin/weipay","admin_index","index","","小程序设置","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("199","0","2","0","9100","admin","moren","index","","子权限","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("217","49","1","1","10000","admin","AdminUser","index","","管理员","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("218","217","1","0","10000","admin","AdminUser","edit","","编辑","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("219","217","1","0","10000","admin","AdminUser","add","","添加","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("220","217","1","0","10000","admin","AdminUser","delete","","删除","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("231","0","1","1","8200","admin","asset","log_all","","资金变动记录","rmb","","1740995591","1748747904","0");
INSERT INTO cmf_admin_menu VALUES("232","0","1","1","8100","admin","withdrawal","index","","提现管理","cc","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("248","6","1","1","20","admin","Slide","de","","幻灯片管理","","","1741658856","","0");
INSERT INTO cmf_admin_menu VALUES("274","6","1","1","1100","admin","wechat_menu","index","","公众号自定义菜单","","","1743910920","","0");
INSERT INTO cmf_admin_menu VALUES("275","0","1","1","10000","admin","base_test","index","","测试模板","","","","","1747377463");
INSERT INTO cmf_admin_menu VALUES("276","275","1","0","10000","admin","base_test","edit","","编辑","","","","","0");
INSERT INTO cmf_admin_menu VALUES("277","275","1","0","10000","admin","base_test","add","","添加","","","","","0");
INSERT INTO cmf_admin_menu VALUES("278","275","1","0","10000","admin","base_test","find","","查看","","","","","0");
INSERT INTO cmf_admin_menu VALUES("279","275","1","0","10000","admin","base_test","delete","","删除","","","","","0");
INSERT INTO cmf_admin_menu VALUES("280","167","1","1","10000","admin","member","children_tree","","关系图","","","1748829750","","0");



CREATE TABLE `cmf_asset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小,单位B',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:可用,0:不可用',
  `download_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `file_key` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件惟一码',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `file_path` varchar(100) NOT NULL DEFAULT '' COMMENT '文件路径,相对于upload目录,可以为url',
  `file_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '文件md5值',
  `file_sha1` varchar(40) NOT NULL DEFAULT '',
  `suffix` varchar(10) NOT NULL DEFAULT '' COMMENT '文件后缀名,不包括点',
  `more` text COMMENT '其它详细信息,JSON格式',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资源表';

DROP TABLE cmf_auth_access;

CREATE TABLE `cmf_auth_access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT '角色',
  `rule_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类,请加应用前缀,如admin_',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `rule_name` (`rule_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COMMENT='权限授权表';

INSERT INTO cmf_auth_access VALUES("135","2","admin/member/default","admin_url");
INSERT INTO cmf_auth_access VALUES("136","2","admin/member/index","admin_url");
INSERT INTO cmf_auth_access VALUES("137","2","admin/plugin/default","admin_url");
INSERT INTO cmf_auth_access VALUES("138","2","admin/hook/index","admin_url");
INSERT INTO cmf_auth_access VALUES("139","2","admin/hook/plugins","admin_url");
INSERT INTO cmf_auth_access VALUES("140","2","admin/hook/pluginlistorder","admin_url");
INSERT INTO cmf_auth_access VALUES("141","2","admin/hook/sync","admin_url");
INSERT INTO cmf_auth_access VALUES("142","2","admin/plugin/index","admin_url");
INSERT INTO cmf_auth_access VALUES("143","2","admin/plugin/toggle","admin_url");
INSERT INTO cmf_auth_access VALUES("144","2","admin/plugin/setting","admin_url");
INSERT INTO cmf_auth_access VALUES("145","2","admin/plugin/settingpost","admin_url");
INSERT INTO cmf_auth_access VALUES("146","2","admin/plugin/install","admin_url");
INSERT INTO cmf_auth_access VALUES("147","2","admin/plugin/update","admin_url");
INSERT INTO cmf_auth_access VALUES("148","2","admin/plugin/uninstall","admin_url");
INSERT INTO cmf_auth_access VALUES("149","2","plugin/swagger/adminindex/index","admin_url");
INSERT INTO cmf_auth_access VALUES("150","2","/plugin/form/adminindex/setting","admin_url");



DROP TABLE cmf_auth_rule;

CREATE TABLE `cmf_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '规则所属app',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类，请加应用前缀,如admin_',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `param` varchar(100) NOT NULL DEFAULT '' COMMENT '额外url参数',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则描述',
  `condition` varchar(200) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `module` (`app`,`status`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8mb4 COMMENT='权限规则表';

INSERT INTO cmf_auth_rule VALUES("1","1","admin","admin_url","admin/Hook/index","","钩子管理","");
INSERT INTO cmf_auth_rule VALUES("2","1","admin","admin_url","admin/Hook/plugins","","钩子插件管理","");
INSERT INTO cmf_auth_rule VALUES("3","1","admin","admin_url","admin/Hook/pluginListOrder","","钩子插件排序","");
INSERT INTO cmf_auth_rule VALUES("4","1","admin","admin_url","admin/Hook/sync","","同步钩子","");
INSERT INTO cmf_auth_rule VALUES("5","1","admin","admin_url","admin/Link/index","","链接管理","");
INSERT INTO cmf_auth_rule VALUES("6","1","admin","admin_url","admin/Link/add","","添加友情链接","");
INSERT INTO cmf_auth_rule VALUES("7","1","admin","admin_url","admin/Link/addPost","","添加友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("8","1","admin","admin_url","admin/Link/edit","","编辑友情链接","");
INSERT INTO cmf_auth_rule VALUES("9","1","admin","admin_url","admin/Link/editPost","","编辑友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("10","1","admin","admin_url","admin/Link/delete","","删除友情链接","");
INSERT INTO cmf_auth_rule VALUES("11","1","admin","admin_url","admin/Link/listOrder","","友情链接排序","");
INSERT INTO cmf_auth_rule VALUES("12","1","admin","admin_url","admin/Link/toggle","","友情链接显示隐藏","");
INSERT INTO cmf_auth_rule VALUES("13","1","admin","admin_url","admin/Mailer/index","","邮箱配置","");
INSERT INTO cmf_auth_rule VALUES("14","1","admin","admin_url","admin/Mailer/indexPost","","邮箱配置提交保存","");
INSERT INTO cmf_auth_rule VALUES("15","1","admin","admin_url","admin/Mailer/template","","邮件模板","");
INSERT INTO cmf_auth_rule VALUES("16","1","admin","admin_url","admin/Mailer/templatePost","","邮件模板提交","");
INSERT INTO cmf_auth_rule VALUES("17","1","admin","admin_url","admin/Mailer/test","","邮件发送测试","");
INSERT INTO cmf_auth_rule VALUES("18","1","admin","admin_url","admin/Menu/index","","后台菜单","");
INSERT INTO cmf_auth_rule VALUES("19","1","admin","admin_url","admin/Menu/lists","","所有菜单","");
INSERT INTO cmf_auth_rule VALUES("20","1","admin","admin_url","admin/Menu/add","","后台菜单添加","");
INSERT INTO cmf_auth_rule VALUES("21","1","admin","admin_url","admin/Menu/addPost","","后台菜单添加提交保存","");
INSERT INTO cmf_auth_rule VALUES("22","1","admin","admin_url","admin/Menu/edit","","后台菜单编辑","");
INSERT INTO cmf_auth_rule VALUES("23","1","admin","admin_url","admin/Menu/editPost","","后台菜单编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("24","1","admin","admin_url","admin/Menu/delete","","后台菜单删除","");
INSERT INTO cmf_auth_rule VALUES("25","1","admin","admin_url","admin/Menu/listOrder","","后台菜单排序","");
INSERT INTO cmf_auth_rule VALUES("26","1","admin","admin_url","admin/Menu/getActions","","导入新后台菜单","");
INSERT INTO cmf_auth_rule VALUES("27","1","admin","admin_url","admin/Nav/index","","导航管理","");
INSERT INTO cmf_auth_rule VALUES("28","1","admin","admin_url","admin/Nav/add","","添加导航","");
INSERT INTO cmf_auth_rule VALUES("29","1","admin","admin_url","admin/Nav/addPost","","添加导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("30","1","admin","admin_url","admin/Nav/edit","","编辑导航","");
INSERT INTO cmf_auth_rule VALUES("31","1","admin","admin_url","admin/Nav/editPost","","编辑导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("32","1","admin","admin_url","admin/Nav/delete","","删除导航","");
INSERT INTO cmf_auth_rule VALUES("33","1","admin","admin_url","admin/NavMenu/index","","导航菜单","");
INSERT INTO cmf_auth_rule VALUES("34","1","admin","admin_url","admin/NavMenu/add","","添加导航菜单","");
INSERT INTO cmf_auth_rule VALUES("35","1","admin","admin_url","admin/NavMenu/addPost","","添加导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("36","1","admin","admin_url","admin/NavMenu/edit","","编辑导航菜单","");
INSERT INTO cmf_auth_rule VALUES("37","1","admin","admin_url","admin/NavMenu/editPost","","编辑导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("38","1","admin","admin_url","admin/NavMenu/delete","","删除导航菜单","");
INSERT INTO cmf_auth_rule VALUES("39","1","admin","admin_url","admin/NavMenu/listOrder","","导航菜单排序","");
INSERT INTO cmf_auth_rule VALUES("40","1","admin","admin_url","admin/Plugin/default","","插件中心","");
INSERT INTO cmf_auth_rule VALUES("41","1","admin","admin_url","admin/Plugin/index","","插件列表","");
INSERT INTO cmf_auth_rule VALUES("42","1","admin","admin_url","admin/Plugin/toggle","","插件启用禁用","");
INSERT INTO cmf_auth_rule VALUES("43","1","admin","admin_url","admin/Plugin/setting","","插件设置","");
INSERT INTO cmf_auth_rule VALUES("44","1","admin","admin_url","admin/Plugin/settingPost","","插件设置提交","");
INSERT INTO cmf_auth_rule VALUES("45","1","admin","admin_url","admin/Plugin/install","","插件安装","");
INSERT INTO cmf_auth_rule VALUES("46","1","admin","admin_url","admin/Plugin/update","","插件更新","");
INSERT INTO cmf_auth_rule VALUES("47","1","admin","admin_url","admin/Plugin/uninstall","","卸载插件","");
INSERT INTO cmf_auth_rule VALUES("48","1","admin","admin_url","admin/Rbac/index","","角色管理","");
INSERT INTO cmf_auth_rule VALUES("49","1","admin","admin_url","admin/Rbac/roleAdd","","添加角色","");
INSERT INTO cmf_auth_rule VALUES("50","1","admin","admin_url","admin/Rbac/roleAddPost","","添加角色提交","");
INSERT INTO cmf_auth_rule VALUES("51","1","admin","admin_url","admin/Rbac/roleEdit","","编辑角色","");
INSERT INTO cmf_auth_rule VALUES("52","1","admin","admin_url","admin/Rbac/roleEditPost","","编辑角色提交","");
INSERT INTO cmf_auth_rule VALUES("53","1","admin","admin_url","admin/Rbac/roleDelete","","删除角色","");
INSERT INTO cmf_auth_rule VALUES("54","1","admin","admin_url","admin/Rbac/authorize","","设置角色权限","");
INSERT INTO cmf_auth_rule VALUES("55","1","admin","admin_url","admin/Rbac/authorizePost","","角色授权提交","");
INSERT INTO cmf_auth_rule VALUES("56","1","admin","admin_url","admin/RecycleBin/index","","回收站","");
INSERT INTO cmf_auth_rule VALUES("57","1","admin","admin_url","admin/RecycleBin/restore","","回收站还原","");
INSERT INTO cmf_auth_rule VALUES("58","1","admin","admin_url","admin/RecycleBin/delete","","回收站彻底删除","");
INSERT INTO cmf_auth_rule VALUES("59","1","admin","admin_url","admin/Route/index","","URL美化","");
INSERT INTO cmf_auth_rule VALUES("60","1","admin","admin_url","admin/Route/add","","添加路由规则","");
INSERT INTO cmf_auth_rule VALUES("61","1","admin","admin_url","admin/Route/addPost","","添加路由规则提交","");
INSERT INTO cmf_auth_rule VALUES("62","1","admin","admin_url","admin/Route/edit","","路由规则编辑","");
INSERT INTO cmf_auth_rule VALUES("63","1","admin","admin_url","admin/Route/editPost","","路由规则编辑提交","");
INSERT INTO cmf_auth_rule VALUES("64","1","admin","admin_url","admin/Route/delete","","路由规则删除","");
INSERT INTO cmf_auth_rule VALUES("65","1","admin","admin_url","admin/Route/ban","","路由规则禁用","");
INSERT INTO cmf_auth_rule VALUES("66","1","admin","admin_url","admin/Route/open","","路由规则启用","");
INSERT INTO cmf_auth_rule VALUES("67","1","admin","admin_url","admin/Route/listOrder","","路由规则排序","");
INSERT INTO cmf_auth_rule VALUES("68","1","admin","admin_url","admin/Route/select","","选择URL","");
INSERT INTO cmf_auth_rule VALUES("69","1","admin","admin_url","admin/Setting/default","","设置","");
INSERT INTO cmf_auth_rule VALUES("70","1","admin","admin_url","admin/Setting/site","","网站信息","");
INSERT INTO cmf_auth_rule VALUES("71","1","admin","admin_url","admin/Setting/sitePost","","网站信息设置提交","");
INSERT INTO cmf_auth_rule VALUES("72","1","admin","admin_url","admin/Setting/password","","密码修改","");
INSERT INTO cmf_auth_rule VALUES("73","1","admin","admin_url","admin/Setting/passwordPost","","密码修改提交","");
INSERT INTO cmf_auth_rule VALUES("74","1","admin","admin_url","admin/Setting/upload","","上传设置","");
INSERT INTO cmf_auth_rule VALUES("75","1","admin","admin_url","admin/Setting/uploadPost","","上传设置提交","");
INSERT INTO cmf_auth_rule VALUES("76","1","admin","admin_url","admin/Setting/clearCache","","清除缓存","");
INSERT INTO cmf_auth_rule VALUES("77","1","admin","admin_url","admin/Slide/index","","分类管理","");
INSERT INTO cmf_auth_rule VALUES("78","1","admin","admin_url","admin/Slide/add","","添加幻灯片","");
INSERT INTO cmf_auth_rule VALUES("79","1","admin","admin_url","admin/Slide/addPost","","添加幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("80","1","admin","admin_url","admin/Slide/edit","","编辑幻灯片","");
INSERT INTO cmf_auth_rule VALUES("81","1","admin","admin_url","admin/Slide/editPost","","编辑幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("82","1","admin","admin_url","admin/Slide/delete","","删除幻灯片","");
INSERT INTO cmf_auth_rule VALUES("83","1","admin","admin_url","admin/SlideItem/index","","幻灯片页面列表","");
INSERT INTO cmf_auth_rule VALUES("84","1","admin","admin_url","admin/SlideItem/add","","幻灯片页面添加","");
INSERT INTO cmf_auth_rule VALUES("85","1","admin","admin_url","admin/SlideItem/addPost","","幻灯片页面添加提交","");
INSERT INTO cmf_auth_rule VALUES("86","1","admin","admin_url","admin/SlideItem/edit","","幻灯片页面编辑","");
INSERT INTO cmf_auth_rule VALUES("87","1","admin","admin_url","admin/SlideItem/editPost","","幻灯片页面编辑提交","");
INSERT INTO cmf_auth_rule VALUES("88","1","admin","admin_url","admin/SlideItem/delete","","幻灯片页面删除","");
INSERT INTO cmf_auth_rule VALUES("89","1","admin","admin_url","admin/SlideItem/ban","","幻灯片页面隐藏","");
INSERT INTO cmf_auth_rule VALUES("90","1","admin","admin_url","admin/SlideItem/cancelBan","","幻灯片页面显示","");
INSERT INTO cmf_auth_rule VALUES("91","1","admin","admin_url","admin/SlideItem/listOrder","","幻灯片页面排序","");
INSERT INTO cmf_auth_rule VALUES("92","1","admin","admin_url","admin/Storage/index","","文件存储","");
INSERT INTO cmf_auth_rule VALUES("93","1","admin","admin_url","admin/Storage/settingPost","","文件存储设置提交","");
INSERT INTO cmf_auth_rule VALUES("94","1","admin","admin_url","admin/Theme/index","","模板管理","");
INSERT INTO cmf_auth_rule VALUES("95","1","admin","admin_url","admin/Theme/install","","安装模板","");
INSERT INTO cmf_auth_rule VALUES("96","1","admin","admin_url","admin/Theme/uninstall","","卸载模板","");
INSERT INTO cmf_auth_rule VALUES("97","1","admin","admin_url","admin/Theme/installTheme","","模板安装","");
INSERT INTO cmf_auth_rule VALUES("98","1","admin","admin_url","admin/Theme/update","","模板更新","");
INSERT INTO cmf_auth_rule VALUES("99","1","admin","admin_url","admin/Theme/active","","启用模板","");
INSERT INTO cmf_auth_rule VALUES("100","1","admin","admin_url","admin/Theme/files","","模板文件列表","");
INSERT INTO cmf_auth_rule VALUES("101","1","admin","admin_url","admin/Theme/fileSetting","","模板文件设置","");
INSERT INTO cmf_auth_rule VALUES("102","1","admin","admin_url","admin/Theme/fileArrayData","","模板文件数组数据列表","");
INSERT INTO cmf_auth_rule VALUES("103","1","admin","admin_url","admin/Theme/fileArrayDataEdit","","模板文件数组数据添加编辑","");
INSERT INTO cmf_auth_rule VALUES("104","1","admin","admin_url","admin/Theme/fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("105","1","admin","admin_url","admin/Theme/fileArrayDataDelete","","模板文件数组数据删除","");
INSERT INTO cmf_auth_rule VALUES("106","1","admin","admin_url","admin/Theme/settingPost","","模板文件编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("107","1","admin","admin_url","admin/Theme/dataSource","","模板文件设置数据源","");
INSERT INTO cmf_auth_rule VALUES("108","1","admin","admin_url","admin/Theme/design","","模板设计","");
INSERT INTO cmf_auth_rule VALUES("109","1","admin","admin_url","admin/User/default","","管理组","");
INSERT INTO cmf_auth_rule VALUES("110","1","admin","admin_url","admin/User/index","","管理员","");
INSERT INTO cmf_auth_rule VALUES("111","1","admin","admin_url","admin/User/add","","管理员添加","");
INSERT INTO cmf_auth_rule VALUES("112","1","admin","admin_url","admin/User/addPost","","管理员添加提交","");
INSERT INTO cmf_auth_rule VALUES("113","1","admin","admin_url","admin/User/edit","","管理员编辑","");
INSERT INTO cmf_auth_rule VALUES("114","1","admin","admin_url","admin/User/editPost","","管理员编辑提交","");
INSERT INTO cmf_auth_rule VALUES("115","1","admin","admin_url","admin/User/userInfo","","个人信息","");
INSERT INTO cmf_auth_rule VALUES("116","1","admin","admin_url","admin/User/userInfoPost","","管理员个人信息修改提交","");
INSERT INTO cmf_auth_rule VALUES("117","1","admin","admin_url","admin/User/delete","","管理员删除","");
INSERT INTO cmf_auth_rule VALUES("118","1","admin","admin_url","admin/User/ban","","停用管理员","");
INSERT INTO cmf_auth_rule VALUES("119","1","admin","admin_url","admin/User/cancelBan","","启用管理员","");
INSERT INTO cmf_auth_rule VALUES("120","1","user","admin_url","user/AdminAsset/index","","资源管理","");
INSERT INTO cmf_auth_rule VALUES("121","1","user","admin_url","user/AdminAsset/delete","","删除文件","");
INSERT INTO cmf_auth_rule VALUES("122","1","user","admin_url","user/AdminIndex/default","","管理员","");
INSERT INTO cmf_auth_rule VALUES("123","1","user","admin_url","user/AdminIndex/default1","","用户组","");
INSERT INTO cmf_auth_rule VALUES("124","1","user","admin_url","user/AdminIndex/index","","本站用户","");
INSERT INTO cmf_auth_rule VALUES("125","1","user","admin_url","user/AdminIndex/ban","","本站用户拉黑","");
INSERT INTO cmf_auth_rule VALUES("126","1","user","admin_url","user/AdminIndex/cancelBan","","本站用户启用","");
INSERT INTO cmf_auth_rule VALUES("127","1","user","admin_url","user/AdminOauth/index","","第三方用户","");
INSERT INTO cmf_auth_rule VALUES("128","1","user","admin_url","user/AdminOauth/delete","","删除第三方用户绑定","");
INSERT INTO cmf_auth_rule VALUES("129","1","user","admin_url","user/AdminUserAction/index","","用户操作管理","");
INSERT INTO cmf_auth_rule VALUES("130","1","user","admin_url","user/AdminUserAction/edit","","编辑用户操作","");
INSERT INTO cmf_auth_rule VALUES("131","1","user","admin_url","user/AdminUserAction/editPost","","编辑用户操作提交","");
INSERT INTO cmf_auth_rule VALUES("132","1","user","admin_url","user/AdminUserAction/sync","","同步用户操作","");
INSERT INTO cmf_auth_rule VALUES("133","1","admin","admin_url","admin/AppInfo/index","","应用设置","");
INSERT INTO cmf_auth_rule VALUES("162","1","admin","admin_url","admin/RecycleBin/clear","","清空回收站","");
INSERT INTO cmf_auth_rule VALUES("163","1","plugin/Swagger","plugin_url","plugin/Swagger/AdminIndex/index","","Swagger","");
INSERT INTO cmf_auth_rule VALUES("164","1","plugin/Configs","plugin_url","plugin/Configs/AdminIndex/index","","系统参数设置","");
INSERT INTO cmf_auth_rule VALUES("166","1","plugin/AdminJournal","admin_url","plugin/AdminJournal/AdminIndex/index","","操作日志","");
INSERT INTO cmf_auth_rule VALUES("167","1","admin","admin_url","admin/member/default","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("168","1","admin","admin_url","admin/member/index","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("169","1","/plugin/form","admin_url","/plugin/form/AdminIndex/setting","","生成CURD","");
INSERT INTO cmf_auth_rule VALUES("177","1","admin","admin_url","admin/dingdan/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("178","1","admin","admin_url","admin/shop_order/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("179","1","admin","admin_url","admin/Shop/index","","店铺管理","");
INSERT INTO cmf_auth_rule VALUES("180","1","admin","admin_url","admin/Shop/edit","","店铺管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("181","1","admin","admin_url","admin/Shop/add","","店铺管理-添加","");
INSERT INTO cmf_auth_rule VALUES("182","1","admin","admin_url","admin/Shop/find","","店铺管理-查看","");
INSERT INTO cmf_auth_rule VALUES("183","1","admin","admin_url","admin/Shop/delete","","店铺管理-删除","");
INSERT INTO cmf_auth_rule VALUES("184","1","admin","admin_url","admin/FormTest/index","","测试生成crud","");
INSERT INTO cmf_auth_rule VALUES("185","1","admin","admin_url","admin/FormTest/edit","","测试生成crud-编辑","");
INSERT INTO cmf_auth_rule VALUES("186","1","admin","admin_url","admin/FormTest/add","","测试生成crud-添加","");
INSERT INTO cmf_auth_rule VALUES("187","1","admin","admin_url","admin/FormTest/find","","测试生成crud-查看","");
INSERT INTO cmf_auth_rule VALUES("188","1","admin","admin_url","admin/FormTest/delete","","测试生成crud-删除","");
INSERT INTO cmf_auth_rule VALUES("189","1","admin","admin_url","admin/FormTest/recommend_post","","测试生成crud-推荐","");
INSERT INTO cmf_auth_rule VALUES("190","1","admin","admin_url","admin/FormTest/list_order_post","","测试生成crud-排序","");
INSERT INTO cmf_auth_rule VALUES("191","1","admin","admin_url","admin/test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("192","1","plugin/weipay","admin_url","plugin/weipay/admin_index/index","","小程序设置","");
INSERT INTO cmf_auth_rule VALUES("193","1","admin","admin_url","admin/moren/index","","子权限","");
INSERT INTO cmf_auth_rule VALUES("194","1","admin","admin_url","admin/asset/log_all","","资金变动记录","");
INSERT INTO cmf_auth_rule VALUES("195","1","admin","admin_url","admin/withdrawal/index","","提现管理","");
INSERT INTO cmf_auth_rule VALUES("196","1","admin","admin_url","admin/base_test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("197","1","admin","admin_url","admin/BaseTest/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("198","1","admin","admin_url","admin/BaseTest/edit","","测试-编辑","");
INSERT INTO cmf_auth_rule VALUES("199","1","admin","admin_url","admin/BaseTest/add","","测试-添加","");
INSERT INTO cmf_auth_rule VALUES("200","1","admin","admin_url","admin/BaseTest/find","","测试-查看","");
INSERT INTO cmf_auth_rule VALUES("201","1","admin","admin_url","admin/BaseTest/delete","","测试-删除","");
INSERT INTO cmf_auth_rule VALUES("202","1","admin","admin_url","admin/ct/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("203","1","admin","admin_url","admin/rere/idnf","","测试","");
INSERT INTO cmf_auth_rule VALUES("204","1","a","admin_url","a/a/a","","测试","");
INSERT INTO cmf_auth_rule VALUES("205","1","a","admin_url","a/a/a1","","a","");
INSERT INTO cmf_auth_rule VALUES("206","1","admin","admin_url","admin/Slide/de","","幻灯片管理","");
INSERT INTO cmf_auth_rule VALUES("207","1","aa","admin_url","aa/aa/aa","","aa","");
INSERT INTO cmf_auth_rule VALUES("208","1","aa","admin_url","aa/aa/aac","ee","aa","");
INSERT INTO cmf_auth_rule VALUES("209","1","admin","admin_url","admin/BaseTest/list_order_post","","测试-排序","");
INSERT INTO cmf_auth_rule VALUES("210","1","admin","admin_url","admin/BaseTest/recommend_post","","测试-推荐","");
INSERT INTO cmf_auth_rule VALUES("211","1","admin","admin_url","admin/base_test/edit","","测试-编辑","");
INSERT INTO cmf_auth_rule VALUES("212","1","admin","admin_url","admin/base_test/add","","测试-添加","");
INSERT INTO cmf_auth_rule VALUES("213","1","admin","admin_url","admin/base_test/find","","测试-查看","");
INSERT INTO cmf_auth_rule VALUES("214","1","admin","admin_url","admin/base_test/delete","","测试-删除","");
INSERT INTO cmf_auth_rule VALUES("215","1","admin","admin_url","admin/wechat_menu/index","","公众号自定义菜单","");
INSERT INTO cmf_auth_rule VALUES("216","1","admin","admin_url","admin/base_test/recommend_post","","测试模板-推荐","");
INSERT INTO cmf_auth_rule VALUES("217","1","admin","admin_url","admin/base_test/list_order_post","","测试模板-排序","");
INSERT INTO cmf_auth_rule VALUES("218","1","admin","admin_url","admin/member/children_tree","","关系图","");



CREATE TABLE `cmf_base_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '1后台  2前端',
  `log` longtext COMMENT '操作地址参数',
  `admin_id` int(11) DEFAULT NULL COMMENT '登录人',
  `admin_name` varchar(200) DEFAULT NULL COMMENT '昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '登录标识',
  `ip` varchar(200) DEFAULT NULL COMMENT 'IP地址',
  `menu_name` text COMMENT '地址栏',
  `param` longtext COMMENT '参数值',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `date` varchar(200) DEFAULT NULL COMMENT '日期',
  `visit_url` text COMMENT '域名+参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COMMENT='管理员日志';

DROP TABLE cmf_base_asset_log;

CREATE TABLE `cmf_base_asset_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT '0',
  `order_num` varchar(50) DEFAULT NULL COMMENT '订单单号',
  `operate_type` varchar(50) DEFAULT 'balance' COMMENT '操作类型:balance余额,point积分',
  `identity_type` varchar(50) DEFAULT 'member' COMMENT '身份类型',
  `change_type` tinyint(6) DEFAULT NULL COMMENT '变动类型:1=收入,2=支出',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `child_id` int(11) DEFAULT NULL COMMENT '子级id',
  `describe` varchar(255) DEFAULT NULL COMMENT '操作描述',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`user_id`) USING BTREE,
  KEY `operate_type` (`operate_type`,`identity_type`,`change_type`,`order_type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='用户资产变动记录';

INSERT INTO cmf_base_asset_log VALUES("1","1","","250331139942598896","balance","member","1","100","10.00","0.00","10.00","测试","操作人[1-admin];操作说明[测试];操作类型[增加用户余额];","0","0","","1743413994","","0");
INSERT INTO cmf_base_asset_log VALUES("2","1","","250331140034522352","balance","member","2","100","2.00","10.00","8.00","测测","操作人[1-admin];操作说明[测测];操作类型[扣除用户余额];","0","0","","1743414003","","0");
INSERT INTO cmf_base_asset_log VALUES("3","1","1","250601487521262447","balance","member","1","1100","10.00","8.00","18.00","管理员添加","操作人[1-admin];操作说明[管理员添加];操作类型[增加用户余额];","0","0","","1748748752","","0");
INSERT INTO cmf_base_asset_log VALUES("4","1","1","250601488624175304","balance","member","1","1100","10.00","18.00","28.00","管理员添加","操作人[1-admin];操作说明[管理员添加];操作类型[增加用户余额];","0","0","管理员添加记录 [1000]","1748748862","","0");
INSERT INTO cmf_base_asset_log VALUES("5","1","1","250601490590160497","point","member","1","1200","80.00","0.00","80.00","管理员添加","操作人[1-admin];操作说明[管理员添加];操作类型[增加用户积分];","0","0","管理员添加记录 [1000]","1748749059","","0");
INSERT INTO cmf_base_asset_log VALUES("6","1","1","250601490691464936","point","member","1","1200","90.00","80.00","170.00","管理员添加","操作人[1-admin];操作说明[管理员添加];操作类型[增加用户积分];","0","0","管理员添加记录 [1000]","1748749069","","0");
INSERT INTO cmf_base_asset_log VALUES("7","1","1","250601493137382580","balance","member","1","1100","80.00","28.00","108.00","管理员添加","操作人[1-admin];操作说明[管理员添加];操作类型[增加用户余额];","0","0","管理员添加记录 [1000]","1748749313","","0");
INSERT INTO cmf_base_asset_log VALUES("8","1","1","250601493209171595","balance","member","2","1110","10.00","108.00","98.00","管理员扣除","操作人[1-admin];操作说明[管理员扣除];操作类型[扣除用户余额];","0","0","管理员扣除记录 [1000]","1748749320","","0");
INSERT INTO cmf_base_asset_log VALUES("9","1","1","250601493288025844","point","member","2","1210","10.00","170.00","160.00","管理员扣除","操作人[1-admin];操作说明[管理员扣除];操作类型[扣除用户积分];","0","0","管理员扣除记录 [1000]","1748749328","","0");



DROP TABLE cmf_base_comment;

CREATE TABLE `cmf_base_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(20) DEFAULT 'goods' COMMENT '类型:goods商品评价',
  `pid` int(11) DEFAULT NULL COMMENT '关联id',
  `parent_id` int(11) DEFAULT '0' COMMENT '上级id',
  `answer_user_id` int(11) DEFAULT '0' COMMENT '回答某人用户id',
  `user_id` int(11) DEFAULT NULL COMMENT '发布评论人id',
  `content` varchar(2555) DEFAULT NULL COMMENT '评论内容',
  `images` text COMMENT '图片',
  `star` varchar(255) DEFAULT '5' COMMENT '星级',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '1显示,2隐藏',
  `like_count` int(5) DEFAULT '0' COMMENT '点赞量',
  `is_top` int(11) DEFAULT '1' COMMENT '1未置顶,2已置顶',
  `image` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片',
  `ext_id` int(11) DEFAULT NULL COMMENT '扩展id',
  `send_user_id` int(11) DEFAULT NULL COMMENT '通知-发布文章者',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '软删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`,`parent_id`,`user_id`,`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论管理';




DROP TABLE cmf_base_config;

CREATE TABLE `cmf_base_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'group_id只',
  `is_menu` tinyint(4) DEFAULT '2' COMMENT '是否菜单1:线上显示,本地都显示,2所有不显示,3本地显示,线上不显示',
  `menu_name` varchar(255) DEFAULT NULL COMMENT '菜单名字',
  `key` bigint(20) DEFAULT NULL COMMENT 'group_id值',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组ID',
  `name` varchar(100) DEFAULT NULL COMMENT '参数名',
  `value` text COMMENT '参数值,序列化数据',
  `label` varchar(100) DEFAULT NULL COMMENT '参数说明',
  `uridata` varchar(100) DEFAULT NULL COMMENT '附加数据',
  `data` varchar(2555) DEFAULT NULL COMMENT '数据源',
  `type` varchar(100) DEFAULT 'text' COMMENT '设置类型 ',
  `about` varchar(100) DEFAULT NULL COMMENT '备注注释',
  `list_order` bigint(20) DEFAULT NULL COMMENT '排序',
  `status` tinyint(100) DEFAULT '1' COMMENT '0不显示',
  `scatter` varchar(100) DEFAULT NULL COMMENT '隔断,打散数据 /',
  `data_type` varchar(50) DEFAULT NULL COMMENT '数据类型',
  `is_label` tinyint(4) DEFAULT '0' COMMENT '组件数据格式:0否,1是',
  `is_edit` tinyint(4) DEFAULT '0' COMMENT '禁止编辑:0否,1是',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '显示:0否,1是',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `is_menu` (`is_menu`,`key`,`group_id`) USING BTREE,
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

INSERT INTO cmf_base_config VALUES("1","1","系统配置","100","0","system_configuration","","系统配置","","s:0:\"\";","text","","100","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("2","3","私有配置","999999","0","private_configuration","","私有配置","","s:0:\"\";","text","","999999","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("100","2","","0","100","app_logo","s:70:\"xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg\";","应用LOGO","","s:0:\"\";","img","","1","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("101","2","","0","100","app_name","s:25:\"公众号/小程序模板\";","应用名称","","s:0:\"\";","","","2","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("102","2","","0","999999","domain_name","s:26:\"https://lscs001.jscxkf.net\";","域名","","s:0:\"\";","text","","100","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("103","2","","0","999999","app_expiration_time","s:0:\"\";","应用到期时间","","s:0:\"\";","date","开发应用到期时间","300","1","","","0","0","0");
INSERT INTO cmf_base_config VALUES("104","2","","0","999999","project_name","s:19:\"公众号/小程序\";","项目名字","","s:0:\"\";","","本地项目名","300","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("105","2","","0","999999","copyright","s:0:\"\";","版权","","s:0:\"\";","","登录页版权","400","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("106","2","","0","999999","local_domain_name","s:21:\"http://lscs.ikun:9090\";","本地域名","","s:0:\"\";","","","200","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("107","2","","0","999999","log_file_days","s:2:\"10\";","日志文件保留天数","","s:0:\"\";","number","日志文件保留天数","500","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("136","2","","0","200","program_code","s:69:\"dzkf00000000001/default/20241016/ae73672e549f1ef3ceba9fe1593e5d07.jpg\";","小程序码二维码","","s:0:\"\";","img","","200","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("137","3","程序配置","200","0","program_configuration","","程序配置","","s:0:\"\";","","","999998","1","","","0","0","0");
INSERT INTO cmf_base_config VALUES("139","2","","0","200","program_information","s:22:\"***小程序-旺旺名\";","程序信息","","s:0:\"\";","","程序基础信息","100","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("141","2","","0","999999","order_automatic_cancellation_time","s:2:\"15\";","订单自动取消时","","s:0:\"\";","number","单位/分钟","600","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("142","2","","0","999999","order_auto_completion_time","s:2:\"10\";","订单发货后自动完成时间","","s:0:\"\";","number","单位/天","700","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("143","2","","0","999999","tencent_map_key","s:35:\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\";","腾讯地图key","","s:0:\"\";","","用于地图转经纬度,经纬度转地址,腾讯地图key","800","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("148","2","","0","200","trial_version_qr_image","s:71:\"xcxkf00000000001/default/20250418/46d0e3bb8e45e4ad5d6cab43a202f2ee.jpeg\";","体验版","","s:0:\"\";","img","","300","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("149","2","","0","200","qr_code_official_account_image","s:70:\"xcxkf00000000001/default/20250626/c824083a7d170de7ecab2cfd8e3386a2.jpg\";","公众号二维码","","s:0:\"\";","img","","400","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("150","2","","0","200","h5_address_code","s:70:\"xcxkf00000000001/default/20250626/abc0b2bf8d69a3e90116ad07dc78f4ad.jpg\";","h5地址码","","s:0:\"\";","img","","500","1","","","0","0","1");



DROP TABLE cmf_base_express;

CREATE TABLE `cmf_base_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL COMMENT '快递名称',
  `abbr` varchar(10) DEFAULT NULL COMMENT '微信快递code',
  `kd_hundred_code` varchar(255) DEFAULT NULL COMMENT '快递100code',
  `kd_bird_code` varchar(255) DEFAULT NULL COMMENT '快递鸟code',
  `status` tinyint(4) DEFAULT '1' COMMENT '2删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='快递表';

INSERT INTO cmf_base_express VALUES("1","安能物流","ANE","annengwuliu","ANE","1");
INSERT INTO cmf_base_express VALUES("2","百世快递","BEST","huitongkuaidi","HTKY","1");
INSERT INTO cmf_base_express VALUES("3","德邦快递","DB","debangkuaidi","DBL","1");
INSERT INTO cmf_base_express VALUES("4","中国邮政速递物流","EMS","youzhengguonei","YZPY","1");
INSERT INTO cmf_base_express VALUES("6","京东快递","JDL","jd","JD","1");
INSERT INTO cmf_base_express VALUES("7","极兔快递","JTSD","jtexpress","JTSD","1");
INSERT INTO cmf_base_express VALUES("9","顺丰速运","SF","shunfeng","SF","1");
INSERT INTO cmf_base_express VALUES("10","申通快递","STO","shentong","STO","1");
INSERT INTO cmf_base_express VALUES("12","圆通速递","YTO","yuantong","YTO","1");
INSERT INTO cmf_base_express VALUES("13","韵达快递","YUNDA","yunda","YD","1");
INSERT INTO cmf_base_express VALUES("14","中通快递","ZTO","zhongtong","ZTO","1");



DROP TABLE cmf_base_form_model;

CREATE TABLE `cmf_base_form_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json_params` text COLLATE utf8_unicode_ci,
  `type` tinyint(2) DEFAULT '1' COMMENT '1提交数据  2访问域名',
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='生成curt';

INSERT INTO cmf_base_form_model VALUES("1","a:34:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:6:\"测试\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("2","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试");
INSERT INTO cmf_base_form_model VALUES("3","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试");
INSERT INTO cmf_base_form_model VALUES("4","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:3:\"测\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:3:\"测\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("5","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:6:\"测试\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("6","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:6:\"测试\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("7","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:6:\"测试\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("8","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:6:\"测试\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("9","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试");
INSERT INTO cmf_base_form_model VALUES("10","a:28:{s:10:\"table_name\";s:11:\"wechat_menu\";s:10:\"model_name\";s:10:\"WechatMenu\";s:4:\"tags\";s:11:\"wechat_menu\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:12:{s:2:\"id\";s:4:\"null\";s:3:\"pid\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:4:\"type\";s:4:\"null\";s:3:\"key\";s:4:\"null\";s:3:\"url\";s:4:\"null\";s:8:\"media_id\";s:4:\"null\";s:5:\"appid\";s:4:\"null\";s:8:\"pagepath\";s:4:\"null\";s:10:\"article_id\";s:4:\"null\";s:5:\"thumb\";s:4:\"null\";s:13:\"reply_content\";s:4:\"null\";}s:13:\"validate_text\";a:12:{s:2:\"id\";s:0:\"\";s:3:\"pid\";s:0:\"\";s:4:\"name\";s:25:\"菜单名称不能为空!\";s:4:\"type\";s:0:\"\";s:3:\"key\";s:0:\"\";s:3:\"url\";s:0:\"\";s:8:\"media_id\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:8:\"pagepath\";s:0:\"\";s:10:\"article_id\";s:0:\"\";s:5:\"thumb\";s:0:\"\";s:13:\"reply_content\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("11","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:wechat_menu  -------  控制器(tags):wechat_menu");
INSERT INTO cmf_base_form_model VALUES("12","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:wechat_menu  -------  控制器(tags):wechat_menu");
INSERT INTO cmf_base_form_model VALUES("13","a:27:{s:10:\"table_name\";s:11:\"wechat_menu\";s:10:\"model_name\";s:10:\"WechatMenu\";s:4:\"tags\";s:15:\"微信菜单栏\";s:8:\"validate\";a:12:{s:2:\"id\";s:4:\"null\";s:3:\"pid\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:3:\"key\";s:4:\"null\";s:3:\"url\";s:4:\"null\";s:8:\"media_id\";s:4:\"null\";s:5:\"appid\";s:4:\"null\";s:8:\"pagepath\";s:4:\"null\";s:10:\"article_id\";s:4:\"null\";s:5:\"thumb\";s:4:\"null\";s:13:\"reply_content\";s:4:\"null\";}s:13:\"validate_text\";a:12:{s:2:\"id\";s:0:\"\";s:3:\"pid\";s:0:\"\";s:4:\"name\";s:0:\"\";s:4:\"type\";s:0:\"\";s:3:\"key\";s:0:\"\";s:3:\"url\";s:0:\"\";s:8:\"media_id\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:8:\"pagepath\";s:0:\"\";s:10:\"article_id\";s:0:\"\";s:5:\"thumb\";s:0:\"\";s:13:\"reply_content\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:15:\"微信菜单栏\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("14","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:wechat_menu  -------  控制器(tags):微信菜单栏");
INSERT INTO cmf_base_form_model VALUES("15","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:wechat_menu  -------  控制器(tags):微信菜单栏");
INSERT INTO cmf_base_form_model VALUES("16","a:34:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:17:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:17:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:19:\"名称不能为空!\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("17","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("18","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("19","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("20","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("21","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("22","a:35:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:17:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:17:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:19:\"名称不能为空!\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:13:\"api_checkAuth\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("23","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("24","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("25","a:34:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:18:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";s:12:\"finish_image\";s:4:\"null\";}s:13:\"validate_text\";a:18:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";s:12:\"finish_image\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:13:\"api_checkAuth\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("26","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("27","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("28","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("29","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("30","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("31","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("32","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("33","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("34","a:34:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:18:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";s:12:\"finish_image\";s:4:\"null\";}s:13:\"validate_text\";a:18:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";s:12:\"finish_image\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("35","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("36","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("37","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("38","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("39","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("40","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:8:\"validate\";a:18:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";s:12:\"finish_image\";s:4:\"null\";}s:13:\"validate_text\";a:18:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";s:12:\"finish_image\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("41","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("42","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("43","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("44","a:25:{s:10:\"table_name\";s:14:\"base_asset_log\";s:10:\"model_name\";s:12:\"BaseAssetLog\";s:4:\"tags\";s:24:\"用户资产变动记录\";s:7:\"keyword\";a:1:{s:7:\"content\";s:2:\"on\";}s:8:\"validate\";a:15:{s:2:\"id\";s:4:\"null\";s:7:\"user_id\";s:4:\"null\";s:8:\"admin_id\";s:4:\"null\";s:9:\"order_num\";s:4:\"null\";s:12:\"operate_type\";s:4:\"null\";s:13:\"identity_type\";s:4:\"null\";s:11:\"change_type\";s:4:\"null\";s:10:\"order_type\";s:4:\"null\";s:5:\"price\";s:4:\"null\";s:6:\"before\";s:4:\"null\";s:5:\"after\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"remark\";s:4:\"null\";s:8:\"order_id\";s:4:\"null\";s:8:\"child_id\";s:4:\"null\";}s:13:\"validate_text\";a:15:{s:2:\"id\";s:0:\"\";s:7:\"user_id\";s:0:\"\";s:8:\"admin_id\";s:0:\"\";s:9:\"order_num\";s:0:\"\";s:12:\"operate_type\";s:0:\"\";s:13:\"identity_type\";s:0:\"\";s:11:\"change_type\";s:0:\"\";s:10:\"order_type\";s:0:\"\";s:5:\"price\";s:0:\"\";s:6:\"before\";s:0:\"\";s:5:\"after\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:8:\"order_id\";s:0:\"\";s:8:\"child_id\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:24:\"用户资产变动记录\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("45","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_asset_log  -------  控制器(tags):用户资产变动记录");
INSERT INTO cmf_base_form_model VALUES("46","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_asset_log  -------  控制器(tags):用户资产变动记录");
INSERT INTO cmf_base_form_model VALUES("47","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:18:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";s:12:\"finish_image\";s:4:\"null\";}s:13:\"validate_text\";a:18:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";s:12:\"finish_image\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("48","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");
INSERT INTO cmf_base_form_model VALUES("49","a:33:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:12:\"测试模板\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:18:{s:2:\"id\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:8:\"class_id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";s:12:\"finish_image\";s:4:\"null\";}s:13:\"validate_text\";a:18:{s:2:\"id\";s:0:\"\";s:4:\"type\";s:0:\"\";s:8:\"class_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:7:\"content\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";s:12:\"finish_image\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"测试模板\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("50","http://lscs.ikun:9090/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):测试模板");



DROP TABLE cmf_base_leave;

CREATE TABLE `cmf_base_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `username` varchar(255) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `content` varchar(2555) DEFAULT NULL COMMENT '留言内容',
  `images` text COMMENT '图集',
  `reply_content` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1待处理,2已处理',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='投诉建议';

INSERT INTO cmf_base_leave VALUES("14","1","刘","199999","","哈哈哈哈","","","","1","1749610814","","0");
INSERT INTO cmf_base_leave VALUES("15","1","刘","199999","水电费","哈哈哈哈","","收到抚慰费","1749610833","2","1749610827","1749610833","0");



DROP TABLE cmf_base_like;

CREATE TABLE `cmf_base_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL COMMENT '类型:1论坛',
  `pid` int(11) DEFAULT NULL COMMENT '关联id',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`,`type`,`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='点赞&收藏';




DROP TABLE cmf_base_order_pay;

CREATE TABLE `cmf_base_order_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL COMMENT '关联订单id',
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `order_type` int(5) DEFAULT '1' COMMENT '订单类型:',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付',
  `order_num` varchar(255) DEFAULT NULL COMMENT '关联订单号',
  `pay_num` varchar(255) DEFAULT NULL COMMENT '发起支付单号',
  `trade_num` varchar(255) DEFAULT NULL COMMENT '第三方返回单号',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `notify` text COMMENT '回调信息',
  `status` int(2) DEFAULT '1' COMMENT '支付状态:1未支付,2已支付',
  `pay_time` bigint(20) DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='支付管理';




CREATE TABLE `cmf_base_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1普通商品,2抢购商品,3拼团商品',
  `class_id` int(11) DEFAULT NULL COMMENT '分类id',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1审核中,2已通过,3已拒绝',
  `image` varchar(255) DEFAULT NULL COMMENT '封面',
  `a_image` varchar(255) DEFAULT NULL COMMENT '介绍图',
  `images` text COMMENT '图集',
  `a_images` text COMMENT '图集222',
  `file` varchar(255) DEFAULT NULL COMMENT '文件',
  `a_file` varchar(255) DEFAULT NULL COMMENT '文件222',
  `video` varchar(255) DEFAULT NULL COMMENT '视频',
  `a_video` varchar(255) DEFAULT NULL COMMENT '视频222',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信,2余额,3支付宝',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `content` text COMMENT '内容',
  `is_index` tinyint(4) DEFAULT '1' COMMENT '首页推荐:1是,2否',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1是,2否',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '显示:1是,2否',
  `is_recommend` tinyint(4) DEFAULT '2' COMMENT '推荐:1是,2否',
  `list_order` int(11) DEFAULT '1000' COMMENT '排序',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `reply` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `finish_image` varchar(255) DEFAULT NULL COMMENT '完成图片',
  `receive_time` bigint(20) DEFAULT NULL COMMENT '领取时间',
  `finish_time` bigint(20) DEFAULT NULL COMMENT '完成时间',
  `fail_time` bigint(20) DEFAULT NULL COMMENT '失败时间',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `begin_time` bigint(20) DEFAULT NULL COMMENT '开始时间22',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `stop_time` bigint(20) DEFAULT NULL COMMENT '结束时间22',
  `closing_time` bigint(20) DEFAULT NULL COMMENT '结束时间33',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COMMENT='测试模板';

DROP TABLE cmf_base_withdrawal;

CREATE TABLE `cmf_base_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户信息',
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(2) DEFAULT '1' COMMENT '提现类型:1支付宝,2微信,3银行卡',
  `openid` varchar(120) DEFAULT NULL COMMENT 'openid',
  `wx_openid` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL COMMENT '提现金额',
  `charges` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `rmb` decimal(10,2) DEFAULT NULL COMMENT '需打款金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1待审核,2已审核,3已拒绝',
  `refuse` varchar(50) DEFAULT '' COMMENT '拒绝原因',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `ali_username` varchar(25) DEFAULT NULL,
  `ali_account` varchar(25) DEFAULT NULL,
  `wx_username` varchar(255) DEFAULT NULL,
  `wx_image` varchar(255) DEFAULT NULL,
  `opening_bank` varchar(255) DEFAULT NULL,
  `bank_username` varchar(25) DEFAULT NULL,
  `bank_account` varchar(25) DEFAULT NULL,
  `package_info` varchar(255) DEFAULT NULL,
  `transfer_bill_no` varchar(255) DEFAULT NULL,
  `pass_time` bigint(20) DEFAULT NULL COMMENT '打款时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员提现申请';




DROP TABLE cmf_comment;

CREATE TABLE `cmf_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(11) DEFAULT NULL COMMENT '文章id',
  `parent_id` int(11) DEFAULT '0' COMMENT '上级id',
  `answer_user_id` int(11) DEFAULT '0' COMMENT '回答某人用户id',
  `user_id` int(11) DEFAULT NULL COMMENT '发布评论人id',
  `content` varchar(2555) DEFAULT NULL COMMENT '评论内容',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '1显示,2隐藏',
  `send_user_id` int(11) DEFAULT NULL COMMENT '通知-发布文章者',
  `like_count` int(5) DEFAULT '0' COMMENT '点赞量',
  `is_top` int(11) DEFAULT '1' COMMENT '1未置顶,2已置顶',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1结婚墙,2寻缘墙',
  `image` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '软删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`,`parent_id`,`user_id`,`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论管理';




DROP TABLE cmf_hook;

CREATE TABLE `cmf_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '钩子类型(1:系统钩子;2:应用钩子;3:模板钩子;4:后台模板钩子)',
  `once` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否只允许一个插件运行(0:多个;1:一个)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名(只有应用钩子才用)',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子表';

INSERT INTO cmf_hook VALUES("2","1","0","应用开始","app_begin","cmf","应用开始");
INSERT INTO cmf_hook VALUES("3","1","0","模块初始化","module_init","cmf","模块初始化");
INSERT INTO cmf_hook VALUES("4","1","0","控制器开始","action_begin","cmf","控制器开始");
INSERT INTO cmf_hook VALUES("5","1","0","视图输出过滤","view_filter","cmf","视图输出过滤");
INSERT INTO cmf_hook VALUES("6","1","0","应用结束","app_end","cmf","应用结束");
INSERT INTO cmf_hook VALUES("7","1","0","日志write方法","log_write","cmf","日志write方法");
INSERT INTO cmf_hook VALUES("8","1","0","输出结束","response_end","cmf","输出结束");
INSERT INTO cmf_hook VALUES("9","1","0","后台控制器初始化","admin_init","cmf","后台控制器初始化");
INSERT INTO cmf_hook VALUES("10","1","0","前台控制器初始化","home_init","cmf","前台控制器初始化");
INSERT INTO cmf_hook VALUES("11","1","1","发送手机验证码","send_mobile_verification_code","cmf","发送手机验证码");
INSERT INTO cmf_hook VALUES("12","3","0","模板 body标签开始","body_start","","模板 body标签开始");
INSERT INTO cmf_hook VALUES("13","3","0","模板 head标签结束前","before_head_end","","模板 head标签结束前");
INSERT INTO cmf_hook VALUES("14","3","0","模板底部开始","footer_start","","模板底部开始");
INSERT INTO cmf_hook VALUES("15","3","0","模板底部开始之前","before_footer","","模板底部开始之前");
INSERT INTO cmf_hook VALUES("16","3","0","模板底部结束之前","before_footer_end","","模板底部结束之前");
INSERT INTO cmf_hook VALUES("17","3","0","模板 body 标签结束之前","before_body_end","","模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("18","3","0","模板左边栏开始","left_sidebar_start","","模板左边栏开始");
INSERT INTO cmf_hook VALUES("19","3","0","模板左边栏结束之前","before_left_sidebar_end","","模板左边栏结束之前");
INSERT INTO cmf_hook VALUES("20","3","0","模板右边栏开始","right_sidebar_start","","模板右边栏开始");
INSERT INTO cmf_hook VALUES("21","3","0","模板右边栏结束之前","before_right_sidebar_end","","模板右边栏结束之前");
INSERT INTO cmf_hook VALUES("22","3","1","评论区","comment","","评论区");
INSERT INTO cmf_hook VALUES("23","3","1","留言区","guestbook","","留言区");
INSERT INTO cmf_hook VALUES("24","2","0","后台首页仪表盘","admin_dashboard","admin","后台首页仪表盘");
INSERT INTO cmf_hook VALUES("25","4","0","后台模板 head标签结束前","admin_before_head_end","","后台模板 head标签结束前");
INSERT INTO cmf_hook VALUES("26","4","0","后台模板 body 标签结束之前","admin_before_body_end","","后台模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("27","2","0","后台登录页面","admin_login","admin","后台登录页面");
INSERT INTO cmf_hook VALUES("28","1","1","前台模板切换","switch_theme","cmf","前台模板切换");
INSERT INTO cmf_hook VALUES("29","3","0","主要内容之后","after_content","","主要内容之后");
INSERT INTO cmf_hook VALUES("32","2","1","获取上传界面","fetch_upload_view","user","获取上传界面");
INSERT INTO cmf_hook VALUES("33","3","0","主要内容之前","before_content","cmf","主要内容之前");
INSERT INTO cmf_hook VALUES("34","1","0","日志写入完成","log_write_done","cmf","日志写入完成");
INSERT INTO cmf_hook VALUES("35","1","1","后台模板切换","switch_admin_theme","cmf","后台模板切换");
INSERT INTO cmf_hook VALUES("36","1","1","验证码图片","captcha_image","cmf","验证码图片");
INSERT INTO cmf_hook VALUES("37","2","1","后台模板设计界面","admin_theme_design_view","admin","后台模板设计界面");
INSERT INTO cmf_hook VALUES("38","2","1","后台设置网站信息界面","admin_setting_site_view","admin","后台设置网站信息界面");
INSERT INTO cmf_hook VALUES("39","2","1","后台清除缓存界面","admin_setting_clear_cache_view","admin","后台清除缓存界面");
INSERT INTO cmf_hook VALUES("40","2","1","后台导航管理界面","admin_nav_index_view","admin","后台导航管理界面");
INSERT INTO cmf_hook VALUES("41","2","1","后台友情链接管理界面","admin_link_index_view","admin","后台友情链接管理界面");
INSERT INTO cmf_hook VALUES("42","2","1","后台幻灯片管理界面","admin_slide_index_view","admin","后台幻灯片管理界面");
INSERT INTO cmf_hook VALUES("43","2","1","后台管理员列表界面","admin_user_index_view","admin","后台管理员列表界面");
INSERT INTO cmf_hook VALUES("44","2","1","后台角色管理界面","admin_rbac_index_view","admin","后台角色管理界面");
INSERT INTO cmf_hook VALUES("49","2","1","用户管理本站用户列表界面","user_admin_index_view","user","用户管理本站用户列表界面");
INSERT INTO cmf_hook VALUES("50","2","1","资源管理列表界面","user_admin_asset_index_view","user","资源管理列表界面");
INSERT INTO cmf_hook VALUES("51","2","1","用户管理第三方用户列表界面","user_admin_oauth_index_view","user","用户管理第三方用户列表界面");
INSERT INTO cmf_hook VALUES("52","2","1","后台首页界面","admin_index_index_view","admin","后台首页界面");
INSERT INTO cmf_hook VALUES("53","2","1","后台回收站界面","admin_recycle_bin_index_view","admin","后台回收站界面");
INSERT INTO cmf_hook VALUES("54","2","1","后台菜单管理界面","admin_menu_index_view","admin","后台菜单管理界面");
INSERT INTO cmf_hook VALUES("55","2","1","后台自定义登录是否开启钩子","admin_custom_login_open","admin","后台自定义登录是否开启钩子");
INSERT INTO cmf_hook VALUES("64","2","1","后台幻灯片页面列表界面","admin_slide_item_index_view","admin","后台幻灯片页面列表界面");
INSERT INTO cmf_hook VALUES("65","2","1","后台幻灯片页面添加界面","admin_slide_item_add_view","admin","后台幻灯片页面添加界面");
INSERT INTO cmf_hook VALUES("66","2","1","后台幻灯片页面编辑界面","admin_slide_item_edit_view","admin","后台幻灯片页面编辑界面");
INSERT INTO cmf_hook VALUES("67","2","1","后台管理员添加界面","admin_user_add_view","admin","后台管理员添加界面");
INSERT INTO cmf_hook VALUES("68","2","1","后台管理员编辑界面","admin_user_edit_view","admin","后台管理员编辑界面");
INSERT INTO cmf_hook VALUES("69","2","1","后台角色添加界面","admin_rbac_role_add_view","admin","后台角色添加界面");
INSERT INTO cmf_hook VALUES("70","2","1","后台角色编辑界面","admin_rbac_role_edit_view","admin","后台角色编辑界面");
INSERT INTO cmf_hook VALUES("71","2","1","后台角色授权界面","admin_rbac_authorize_view","admin","后台角色授权界面");



DROP TABLE cmf_hook_plugin;

CREATE TABLE `cmf_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名',
  `plugin` varchar(50) NOT NULL DEFAULT '' COMMENT '插件',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子插件表';

INSERT INTO cmf_hook_plugin VALUES("2","10000","1","app_begin","Configs");
INSERT INTO cmf_hook_plugin VALUES("3","10000","1","fetch_upload_view","Oss");
INSERT INTO cmf_hook_plugin VALUES("4","10000","1","admin_init","AdminJournal");
INSERT INTO cmf_hook_plugin VALUES("5","10000","1","admin_login","FengiyLogin");
INSERT INTO cmf_hook_plugin VALUES("6","10000","1","send_mobile_verification_code","HuYi");



DROP TABLE cmf_link;

CREATE TABLE `cmf_link` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:显示;0:不显示',
  `rating` int(11) NOT NULL DEFAULT '0' COMMENT '友情链接评级',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接描述',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '友情链接地址',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '友情链接名称',
  `image` varchar(100) NOT NULL DEFAULT '' COMMENT '友情链接图标',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `rel` varchar(50) NOT NULL DEFAULT '' COMMENT '链接与网站的关系',
  `cate_id` int(11) DEFAULT '0' COMMENT '链接分类',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='友情链接表';

INSERT INTO cmf_link VALUES("1","0","1","200","小程序首页","/pages/index/index","首页","admin/20230218/64aab5da8de3c18e39354a90b4efa5be.png","_blank","","0");
INSERT INTO cmf_link VALUES("2","0","0","100","","/pages/user/index","个人中心","","","","0");



DROP TABLE cmf_link_category;

CREATE TABLE `cmf_link_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='链接分类';

INSERT INTO cmf_link_category VALUES("1","小程序链接","");
INSERT INTO cmf_link_category VALUES("2","其他","");



DROP TABLE cmf_member;

CREATE TABLE `cmf_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(200) DEFAULT NULL COMMENT '头像',
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `pass` varchar(100) DEFAULT NULL COMMENT '密码',
  `balance` decimal(11,2) DEFAULT '0.00' COMMENT '余额',
  `point` decimal(11,2) DEFAULT '0.00' COMMENT '积分',
  `ip` varchar(255) DEFAULT NULL COMMENT '登录ip地址',
  `login_city` varchar(255) DEFAULT NULL COMMENT '登录城市',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `pid` int(11) DEFAULT NULL COMMENT '上级',
  `mini_openid` varchar(255) DEFAULT NULL COMMENT '小程序openid',
  `official_openid` varchar(255) DEFAULT NULL COMMENT '公众openid',
  `unionid` varchar(255) DEFAULT NULL COMMENT 'unionid',
  `login_time` bigint(20) DEFAULT NULL COMMENT '最后登录时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_member VALUES("1","测试平台用户-1","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","1","1888888888","1","98.00","160.00","","","0001","0","","","","1740965414","1740965414","1740965414","0");
INSERT INTO cmf_member VALUES("2","小小怪-1","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","2","1222222222","","0.00","0.00","","","1222222222","1","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("3","小小怪-2","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","3","1333333333","","0.00","0.00","","","1333333333","2","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("4","小小怪-3","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","4","1444444444","","0.00","0.00","","","1444444444","3","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("5","小小怪-4","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","5","1555555500","","0.00","0.00","","","1555555500","4","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("6","小小怪-5","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","6","1666666666","","0.00","0.00","","","1666666666","5","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("7","小小怪-6","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","7","1777777777","","0.00","0.00","","","1777777777","6","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("8","测试平台用户-2","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","8","1588888888","","0.00","0.00","","","1588888888","0","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("9","大大怪-1","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","9","1522222222","","0.00","0.00","","","1522222222","8","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("10","大大怪-2","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","10","1533333333","","0.00","0.00","","","1533333333","9","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("11","大大怪-3","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","11","1544444444","","0.00","0.00","","","1544444444","10","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("12","大大怪-4","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","12","1555555550","","0.00","0.00","","","1555555550","11","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("13","大大怪-5","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","13","1566666666","","0.00","0.00","","","1566666666","12","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("14","小小怪-1-1","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","14","1233333333","","0.00","0.00","","","1233333333","1","","","","1740965414","1740965414","","0");
INSERT INTO cmf_member VALUES("15","小小怪-1-2","xcxkf00000000001/default/20250602/92957f701d37f4e9b9f09e77d292bc2c.jpg","15","1244444444","","0.00","0.00","","","1244444444","1","","","","1740965414","1740965414","","0");



DROP TABLE cmf_member_gzh;

CREATE TABLE `cmf_member_gzh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `unionid` varchar(255) DEFAULT NULL COMMENT 'unionId',
  `ext` text CHARACTER SET utf8 COMMENT '扩展信息',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号用户';




DROP TABLE cmf_option;

CREATE TABLE `cmf_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoload` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否自动加载;1:自动加载;0:不自动加载',
  `option_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置名',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `option_name` (`option_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='全站配置表';

INSERT INTO cmf_option VALUES("1","1","site_info","{\"site_name\":\"微巨宝定制后台模板\",\"site_seo_title\":\"微巨宝定制后台模板\",\"site_seo_keywords\":\"\",\"site_seo_description\":\"\"}");
INSERT INTO cmf_option VALUES("2","1","set_config","{\"app_name\":\"公众号\\/小程序模板\",\"app_logo\":\"xcxkf00000000001\\/default\\/20250602\\/92957f701d37f4e9b9f09e77d292bc2c.jpg\",\"user_agreement\":\"&lt;p&gt;用户协议&lt;\\/p&gt;\",\"privacy_agreement\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; background-color: rgb(255, 255, 255);&quot;&gt;隐私协议&lt;\\/span&gt;&lt;\\/p&gt;\",\"group_id\":\"999999\",\"app_logo_1\":\"https:\\/\\/oss.ausite.cn\\/dz000\\/default\\/20230217\\/2680011108c19b50228c124d86749b7d.jpg?watermark\",\"_plugin\":\"configs\",\"_controller\":\"admin_index\",\"_action\":\"index\",\"test\":\"111\",\"domain_name\":\"https:\\/\\/lscs001.jscxkf.net\",\"s\":[\"sdfwe\",\"sfwaweew\"],\"f\":[\"fawefewfawefwe\"],\"debug_mode\":\"1\",\"app_expiration_time\":\"2033-04-29 00:00\",\"listorder\":{\"100\":\"1\",\"101\":\"2\",\"108\":\"100\"},\"label\":{\"102\":\"域名\",\"106\":\"本地域名\",\"104\":\"项目名字\",\"105\":\"版权\",\"107\":\"日志文件保留天数\",\"141\":\"订单自动取消时\",\"142\":\"订单发货后自动完成时间\",\"143\":\"腾讯地图key\"},\"name\":{\"102\":\"domain_name\",\"106\":\"local_domain_name\",\"104\":\"project_name\",\"105\":\"copyright\",\"107\":\"log_file_days\",\"141\":\"order_automatic_cancellation_time\",\"142\":\"order_auto_completion_time\",\"143\":\"tencent_map_key\"},\"about\":{\"102\":\"\",\"106\":\"\",\"104\":\"本地项目名\",\"105\":\"登录页版权\",\"107\":\"日志文件保留天数\",\"141\":\"单位\\/分钟\",\"142\":\"单位\\/天\",\"143\":\"用于地图转经纬度,经纬度转地址,腾讯地图key\"},\"project_name\":\"公众号\\/小程序\",\"copyright\":\"\",\"local_domain_name\":\"http:\\/\\/lscs.ikun:9090\",\"number_of_days_for_log_files\":\"\",\"log_file_days\":\"10\",\"list_order\":{\"102\":\"100\",\"106\":\"200\",\"104\":\"300\",\"105\":\"400\",\"107\":\"500\",\"141\":\"600\",\"142\":\"700\",\"143\":\"800\"},\"video\":\"dzkf00000000001\\/default\\/20240624\\/c2dcc94117717aaad3d7d9664c2affcb.mp4\",\"file2\":\"dzkf00000000001\\/default\\/20240624\\/2cec82e71890d9b59a689e8a869c544e.docx\",\"video2\":\"dzkf00000000001\\/default\\/20240624\\/ab75196b4f0f699eb563758d59e662ca.mp4\",\"file333\":\"dzkf00000000001\\/default\\/20240624\\/9fff193bb6acaead8c8523bea7a76ad6.pdf\",\"program_code\":\"dzkf00000000001\\/default\\/20241016\\/ae73672e549f1ef3ceba9fe1593e5d07.jpg\",\"program_information\":\"***小程序-旺旺名\",\"is_show\":\"1\",\"show\":{\"app_logo\":\"on\",\"app_name\":\"on\"},\"order_automatic_cancellation_time\":\"15\",\"order_auto_completion_time\":\"10\",\"tencent_map_key\":\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\",\"cescesges\":[\"2\",\"3\",\"4\"],\"testing_and_testing\":\"额外各位各位e4545\",\"measure\":\"&lt;p&gt;冯绍峰无法&lt;\\/p&gt;\",\"is_edit\":\"1\",\"is_label\":\"1\",\"isShow\":{\"app_logo\":\"on\",\"app_name\":\"on\"},\"isEdit\":{\"app_logo\":\"on\",\"app_name\":\"on\"},\"isLabel\":{\"test1\":\"on\"},\"test1\":\"111222\",\"trial_version_qr_image\":\"xcxkf00000000001\\/default\\/20250418\\/46d0e3bb8e45e4ad5d6cab43a202f2ee.jpeg\",\"showList\":{\"102\":\"on\",\"106\":\"on\",\"104\":\"on\",\"105\":\"on\",\"107\":\"on\",\"141\":\"on\",\"142\":\"on\",\"143\":\"on\"},\"qr_code_official_account_image\":\"xcxkf00000000001\\/default\\/20250626\\/c824083a7d170de7ecab2cfd8e3386a2.jpg\",\"h5_address_code\":\"xcxkf00000000001\\/default\\/20250626\\/abc0b2bf8d69a3e90116ad07dc78f4ad.jpg\"}");
INSERT INTO cmf_option VALUES("3","1","storage","{\"storages\":{\"Oss\":{\"name\":\"阿里云OSS存储\",\"driver\":\"\\\\plugins\\\\oss\\\\lib\\\\Oss\"}},\"type\":\"Oss\"}");
INSERT INTO cmf_option VALUES("4","1","weipay","{\"wx_mp_app_id\":\"\",\"wx_mini_app_id\":\"\",\"wx_mp_app_secret\":\"\",\"wx_mini_app_secret\":\"\",\"wx_token\":\"\",\"wx_encodingaeskey\":\"\",\"wx_app_id\":\"\",\"wx_mch_id\":\"\",\"wx_v2_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_v3_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_mch_secret_cert\":\"\",\"wx_mch_public_cert_path\":\"\",\"wx_notify_url\":\"\\/api\\/wxapp\\/notify\\/wxPayNotify\",\"ali_app_id\":\"\",\"ali_app_secret_cert\":\"\",\"ali_app_public_cert_path\":\"\",\"ali_alipay_public_cert_path\":\"\",\"ali_alipay_root_cert_path\":\"\",\"ali_notify_url\":\"\",\"ali_return_url\":\"\",\"wx_system_type\":\"wx_mini\",\"wx_certificates\":\"****\",\"wx_v3_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"transfer_notify_url\":\"\\/api\\/wxapp\\/WxBase\\/notify\"}");
INSERT INTO cmf_option VALUES("5","1","upload_setting","{\"max_files\":\"20\",\"chunk_size\":\"512\",\"file_types\":{\"image\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"jpg,jpeg,png,gif,bmp4,mp3\"},\"video\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp4,avi,wmv,rm,rmvb,mkv\"},\"audio\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp3,wma,wav\"},\"file\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,pem\"}}}");
INSERT INTO cmf_option VALUES("6","1","smtp_setting","{\"from_name\":\"测试\",\"from\":\"3031000000@qq.com\",\"host\":\"smtp.qq.com\",\"smtp_secure\":\"\",\"port\":\"465\",\"username\":\"3031000000@qq.com\",\"password\":\"11111111\"}");
INSERT INTO cmf_option VALUES("7","1","email_template_verification_code","{\"subject\":\"测试\",\"template\":\"&lt;table width=&quot;100%&quot; class=&quot;x_main&quot;&gt;&lt;tbody&gt;&lt;tr class=&quot;firstRow&quot; style=&quot;box-sizing: border-box; margin: 0px;&quot;&gt;&lt;td valign=&quot;top&quot; align=&quot;center&quot; class=&quot;x_alert x_alert-warning&quot; style=&quot;padding: 20px; box-sizing: border-box; font-size: 22px; vertical-align: top; color: rgb(255, 255, 255); text-align: center; border-radius: 3px 3px 0px 0px; background-color: rgb(0, 115, 186); margin: 0px;&quot;&gt;邮箱验证码&lt;\\/td&gt;&lt;\\/tr&gt;&lt;tr style=&quot;box-sizing: border-box; margin: 0px;&quot;&gt;&lt;td valign=&quot;top&quot; class=&quot;x_content-wrap&quot; style=&quot;padding: 20px; box-sizing: border-box; vertical-align: top; margin: 0px;&quot;&gt;&lt;p&gt;KBOX&lt;\\/p&gt;&lt;p&gt;请填写以下验证码完成邮箱验证&amp;nbsp;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;&lt;p&gt;&amp;nbsp;&amp;nbsp;&lt;span style=&quot;font-size: 24px;&quot;&gt;&amp;nbsp;{$code}&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;&lt;p&gt;&lt;span style=&quot;font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; box-sizing: border-box; color: rgb(117, 117, 117); vertical-align: top; margin: 0px; padding: 0px 0px 20px; font-size: 14px;&quot;&gt;(本邮件由系统自动发出，请勿直接回复)&lt;\\/span&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;&lt;\\/td&gt;&lt;\\/tr&gt;&lt;\\/tbody&gt;&lt;\\/table&gt;&lt;p&gt;&lt;br style=&quot;text-wrap-mode: wrap;&quot;\\/&gt;&lt;\\/p&gt;&lt;p&gt;&lt;br\\/&gt;&lt;\\/p&gt;\"}");



DROP TABLE cmf_plugin;

CREATE TABLE `cmf_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型;1:网站;8:微信',
  `has_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理,0:没有;1:有',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:开启;0:禁用',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '插件安装时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件标识名,英文字母(惟一)',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `hooks` varchar(255) NOT NULL DEFAULT '' COMMENT '实现的钩子;以“,”分隔',
  `author` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '插件版本号',
  `description` varchar(255) NOT NULL COMMENT '插件描述',
  `config` text COMMENT '插件配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='插件表';

INSERT INTO cmf_plugin VALUES("1","1","1","1","1660558216","Weipay","APP信息&支付信息","","","wjb","","1.0.0","微信小程序&公众号&支付宝支付信息","[]");
INSERT INTO cmf_plugin VALUES("2","1","1","1","1660558220","Swagger","Swagger","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","1.0.0","Swagger","[]");
INSERT INTO cmf_plugin VALUES("4","1","1","1","1660723183","Configs","系统参数设置","","","lampzww","","1.0","config读取配置参数扩展","[]");
INSERT INTO cmf_plugin VALUES("6","1","0","1","1660723194","Oss","OSS上传","","","zsl","","1.0.0","OSS上传","{\"accessKey\":\"LTAI5tPQyqygfzo8Dcd56eKD\",\"secretKey\":\"cmVjiDjJ3I3ChQxzzQR3MGe46RgRF6\",\"protocol\":\"https\",\"domain\":\"oss.ausite.cn\",\"bucket\":\"twjbdzoss\",\"style_separator\":\"?\",\"dir\":\"xcxkf00000000001\"}");
INSERT INTO cmf_plugin VALUES("8","1","1","1","1660723805","Form","表单生成","http://demo.thinkcmf.com","","idcpj","http://www.thinkcmf.com","1.1","表单生成","{\"custom_config\":\"0\",\"text\":\"hello,ThinkCMF!\",\"password\":\"\",\"number\":\"1.0\",\"select\":\"1\",\"checkbox\":1,\"radio\":\"1\",\"radio2\":\"1\",\"textarea\":\"\\u8fd9\\u91cc\\u662f\\u4f60\\u8981\\u586b\\u5199\\u7684\\u5185\\u5bb9\",\"date\":\"2017-05-20\",\"datetime\":\"2017-05-20\",\"color\":\"#103633\",\"image\":\"\",\"file\":\"\",\"location\":\"\"}");
INSERT INTO cmf_plugin VALUES("9","1","1","1","1662171892","AdminJournal","操作日志","https://www.wzxaini9.cn/","","Powerless","https://www.wzxaini9.cn/","1.2.0","后台操作日志","[]");
INSERT INTO cmf_plugin VALUES("10","1","0","1","1670382358","FengiyLogin","微巨宝自定义登录页","","","Fengiy","","1.0","支持大背景/轮播图/Logo/名称自定义","{\"b_bg\":\"\",\"b_bg_illus\":\"\"}");
INSERT INTO cmf_plugin VALUES("11","1","1","1","1718330446","LoginTime","登陆状态时长控制","http://www.songzhenjiang.cn","","Tangchao","http://www.songzhenjiang.cn","1.0","登陆状态时长控制","[]");
INSERT INTO cmf_plugin VALUES("12","1","0","1","1745481075","HuYi","互亿短信","","","wjb","","1.0","互亿短信","{\"apiid\":\"C69066392\",\"apikey\":\"2f4f438100ef2bc001a69be1c2721760\",\"voice_apiid\":\"VM33201086\",\"voice_apikey\":\"ea3895f9022e4576e91ea9db6f1aa656\"}");



DROP TABLE cmf_recycle_bin;

CREATE TABLE `cmf_recycle_bin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT '0' COMMENT '删除内容 id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `table_name` varchar(60) DEFAULT '' COMMENT '删除内容所在表名',
  `name` varchar(255) DEFAULT '' COMMENT '删除内容名称',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' 回收站';




DROP TABLE cmf_region_letter;

CREATE TABLE `cmf_region_letter` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `code` bigint(12) DEFAULT NULL COMMENT '行政区划代码',
  `parent_id` bigint(11) DEFAULT NULL COMMENT '上级id',
  `level_id` varchar(32) DEFAULT NULL COMMENT '层级',
  `letter` char(4) DEFAULT NULL COMMENT '首字母',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10003790 DEFAULT CHARSET=utf8;

INSERT INTO cmf_region_letter VALUES("10000001","北京市","110000","10000000","1","B");
INSERT INTO cmf_region_letter VALUES("10000002","天津市","120000","10000000","1","T");
INSERT INTO cmf_region_letter VALUES("10000003","河北省","130000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000004","山西省","140000","10000000","1","S");
INSERT INTO cmf_region_letter VALUES("10000005","内蒙古自治区","150000","10000000","1","N");
INSERT INTO cmf_region_letter VALUES("10000006","辽宁省","210000","10000000","1","L");
INSERT INTO cmf_region_letter VALUES("10000007","吉林省","220000","10000000","1","J");
INSERT INTO cmf_region_letter VALUES("10000008","黑龙江省","230000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000009","上海市","310000","10000000","1","S");
INSERT INTO cmf_region_letter VALUES("10000010","江苏省","320000","10000000","1","J");
INSERT INTO cmf_region_letter VALUES("10000011","浙江省","330000","10000000","1","Z");
INSERT INTO cmf_region_letter VALUES("10000012","安徽省","340000","10000000","1","A");
INSERT INTO cmf_region_letter VALUES("10000013","福建省","350000","10000000","1","F");
INSERT INTO cmf_region_letter VALUES("10000014","江西省","360000","10000000","1","J");
INSERT INTO cmf_region_letter VALUES("10000015","山东省","370000","10000000","1","S");
INSERT INTO cmf_region_letter VALUES("10000016","河南省","410000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000017","湖北省","420000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000018","湖南省","430000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000019","广东省","440000","10000000","1","G");
INSERT INTO cmf_region_letter VALUES("10000020","广西壮族自治区","450000","10000000","1","G");
INSERT INTO cmf_region_letter VALUES("10000021","海南省","460000","10000000","1","H");
INSERT INTO cmf_region_letter VALUES("10000022","重庆市","500000","10000000","1","C");
INSERT INTO cmf_region_letter VALUES("10000023","四川省","510000","10000000","1","S");
INSERT INTO cmf_region_letter VALUES("10000024","贵州省","520000","10000000","1","G");
INSERT INTO cmf_region_letter VALUES("10000025","云南省","530000","10000000","1","Y");
INSERT INTO cmf_region_letter VALUES("10000026","西藏自治区","540000","10000000","1","X");
INSERT INTO cmf_region_letter VALUES("10000027","陕西省","610000","10000000","1","S");
INSERT INTO cmf_region_letter VALUES("10000028","甘肃省","620000","10000000","1","G");
INSERT INTO cmf_region_letter VALUES("10000029","青海省","630000","10000000","1","Q");
INSERT INTO cmf_region_letter VALUES("10000030","宁夏回族自治区","640000","10000000","1","N");
INSERT INTO cmf_region_letter VALUES("10000031","新疆维吾尔自治区","650000","10000000","1","X");
INSERT INTO cmf_region_letter VALUES("10000032","台湾省","710000","10000000","1","T");
INSERT INTO cmf_region_letter VALUES("10000033","香港特别行政区","810000","10000000","1","X");
INSERT INTO cmf_region_letter VALUES("10000034","澳门特别行政区","820000","10000000","1","A");
INSERT INTO cmf_region_letter VALUES("10000035","北京市","110100","10000001","2","B");
INSERT INTO cmf_region_letter VALUES("10000036","天津市","120100","10000002","2","T");
INSERT INTO cmf_region_letter VALUES("10000037","石家庄市","130100","10000003","2","S");
INSERT INTO cmf_region_letter VALUES("10000038","唐山市","130200","10000003","2","T");
INSERT INTO cmf_region_letter VALUES("10000039","秦皇岛市","130300","10000003","2","Q");
INSERT INTO cmf_region_letter VALUES("10000040","邯郸市","130400","10000003","2","H");
INSERT INTO cmf_region_letter VALUES("10000041","邢台市","130500","10000003","2","X");
INSERT INTO cmf_region_letter VALUES("10000042","保定市","130600","10000003","2","B");
INSERT INTO cmf_region_letter VALUES("10000043","张家口市","130700","10000003","2","Z");
INSERT INTO cmf_region_letter VALUES("10000044","承德市","130800","10000003","2","C");
INSERT INTO cmf_region_letter VALUES("10000045","沧州市","130900","10000003","2","C");
INSERT INTO cmf_region_letter VALUES("10000046","廊坊市","131000","10000003","2","L");
INSERT INTO cmf_region_letter VALUES("10000047","衡水市","131100","10000003","2","H");
INSERT INTO cmf_region_letter VALUES("10000048","太原市","140100","10000004","2","T");
INSERT INTO cmf_region_letter VALUES("10000049","大同市","140200","10000004","2","D");
INSERT INTO cmf_region_letter VALUES("10000050","阳泉市","140300","10000004","2","Y");
INSERT INTO cmf_region_letter VALUES("10000051","长治市","140400","10000004","2","C");
INSERT INTO cmf_region_letter VALUES("10000052","晋城市","140500","10000004","2","J");
INSERT INTO cmf_region_letter VALUES("10000053","朔州市","140600","10000004","2","S");
INSERT INTO cmf_region_letter VALUES("10000054","晋中市","140700","10000004","2","J");
INSERT INTO cmf_region_letter VALUES("10000055","运城市","140800","10000004","2","Y");
INSERT INTO cmf_region_letter VALUES("10000056","忻州市","140900","10000004","2","X");
INSERT INTO cmf_region_letter VALUES("10000057","临汾市","141000","10000004","2","L");
INSERT INTO cmf_region_letter VALUES("10000058","吕梁市","141100","10000004","2","L");
INSERT INTO cmf_region_letter VALUES("10000059","呼和浩特市","150100","10000005","2","H");
INSERT INTO cmf_region_letter VALUES("10000060","包头市","150200","10000005","2","B");
INSERT INTO cmf_region_letter VALUES("10000061","乌海市","150300","10000005","2","W");
INSERT INTO cmf_region_letter VALUES("10000062","赤峰市","150400","10000005","2","C");
INSERT INTO cmf_region_letter VALUES("10000063","通辽市","150500","10000005","2","T");
INSERT INTO cmf_region_letter VALUES("10000064","鄂尔多斯市","150600","10000005","2","E");
INSERT INTO cmf_region_letter VALUES("10000065","呼伦贝尔市","150700","10000005","2","H");
INSERT INTO cmf_region_letter VALUES("10000066","巴彦淖尔市","150800","10000005","2","B");
INSERT INTO cmf_region_letter VALUES("10000067","乌兰察布市","150900","10000005","2","W");
INSERT INTO cmf_region_letter VALUES("10000068","兴安盟","152200","10000005","2","X");
INSERT INTO cmf_region_letter VALUES("10000069","锡林郭勒盟","152500","10000005","2","X");
INSERT INTO cmf_region_letter VALUES("10000070","阿拉善盟","152900","10000005","2","A");
INSERT INTO cmf_region_letter VALUES("10000071","沈阳市","210100","10000006","2","S");
INSERT INTO cmf_region_letter VALUES("10000072","大连市","210200","10000006","2","D");
INSERT INTO cmf_region_letter VALUES("10000073","鞍山市","210300","10000006","2","A");
INSERT INTO cmf_region_letter VALUES("10000074","抚顺市","210400","10000006","2","F");
INSERT INTO cmf_region_letter VALUES("10000075","本溪市","210500","10000006","2","B");
INSERT INTO cmf_region_letter VALUES("10000076","丹东市","210600","10000006","2","D");
INSERT INTO cmf_region_letter VALUES("10000077","锦州市","210700","10000006","2","J");
INSERT INTO cmf_region_letter VALUES("10000078","营口市","210800","10000006","2","Y");
INSERT INTO cmf_region_letter VALUES("10000079","阜新市","210900","10000006","2","F");
INSERT INTO cmf_region_letter VALUES("10000080","辽阳市","211000","10000006","2","L");
INSERT INTO cmf_region_letter VALUES("10000081","盘锦市","211100","10000006","2","P");
INSERT INTO cmf_region_letter VALUES("10000082","铁岭市","211200","10000006","2","T");
INSERT INTO cmf_region_letter VALUES("10000083","朝阳市","211300","10000006","2","Z");
INSERT INTO cmf_region_letter VALUES("10000084","葫芦岛市","211400","10000006","2","H");
INSERT INTO cmf_region_letter VALUES("10000085","长春市","220100","10000007","2","C");
INSERT INTO cmf_region_letter VALUES("10000086","吉林市","220200","10000007","2","J");
INSERT INTO cmf_region_letter VALUES("10000087","四平市","220300","10000007","2","S");
INSERT INTO cmf_region_letter VALUES("10000088","辽源市","220400","10000007","2","L");
INSERT INTO cmf_region_letter VALUES("10000089","通化市","220500","10000007","2","T");
INSERT INTO cmf_region_letter VALUES("10000090","白山市","220600","10000007","2","B");
INSERT INTO cmf_region_letter VALUES("10000091","松原市","220700","10000007","2","S");
INSERT INTO cmf_region_letter VALUES("10000092","白城市","220800","10000007","2","B");
INSERT INTO cmf_region_letter VALUES("10000093","延边朝鲜族自治州","222400","10000007","2","Y");
INSERT INTO cmf_region_letter VALUES("10000094","哈尔滨市","230100","10000008","2","H");
INSERT INTO cmf_region_letter VALUES("10000095","齐齐哈尔市","230200","10000008","2","Q");
INSERT INTO cmf_region_letter VALUES("10000096","鸡西市","230300","10000008","2","J");
INSERT INTO cmf_region_letter VALUES("10000097","鹤岗市","230400","10000008","2","H");
INSERT INTO cmf_region_letter VALUES("10000098","双鸭山市","230500","10000008","2","S");
INSERT INTO cmf_region_letter VALUES("10000099","大庆市","230600","10000008","2","D");
INSERT INTO cmf_region_letter VALUES("10000100","伊春市","230700","10000008","2","Y");
INSERT INTO cmf_region_letter VALUES("10000101","佳木斯市","230800","10000008","2","J");
INSERT INTO cmf_region_letter VALUES("10000102","七台河市","230900","10000008","2","Q");
INSERT INTO cmf_region_letter VALUES("10000103","牡丹江市","231000","10000008","2","M");
INSERT INTO cmf_region_letter VALUES("10000104","黑河市","231100","10000008","2","H");
INSERT INTO cmf_region_letter VALUES("10000105","绥化市","231200","10000008","2","S");
INSERT INTO cmf_region_letter VALUES("10000106","大兴安岭地区","232700","10000008","2","D");
INSERT INTO cmf_region_letter VALUES("10000107","上海市","310100","10000009","2","S");
INSERT INTO cmf_region_letter VALUES("10000108","南京市","320100","10000010","2","N");
INSERT INTO cmf_region_letter VALUES("10000109","无锡市","320200","10000010","2","W");
INSERT INTO cmf_region_letter VALUES("10000110","徐州市","320300","10000010","2","X");
INSERT INTO cmf_region_letter VALUES("10000111","常州市","320400","10000010","2","C");
INSERT INTO cmf_region_letter VALUES("10000112","苏州市","320500","10000010","2","S");
INSERT INTO cmf_region_letter VALUES("10000113","南通市","320600","10000010","2","N");
INSERT INTO cmf_region_letter VALUES("10000114","连云港市","320700","10000010","2","L");
INSERT INTO cmf_region_letter VALUES("10000115","淮安市","320800","10000010","2","H");
INSERT INTO cmf_region_letter VALUES("10000116","盐城市","320900","10000010","2","Y");
INSERT INTO cmf_region_letter VALUES("10000117","扬州市","321000","10000010","2","Y");
INSERT INTO cmf_region_letter VALUES("10000118","镇江市","321100","10000010","2","Z");
INSERT INTO cmf_region_letter VALUES("10000119","泰州市","321200","10000010","2","T");
INSERT INTO cmf_region_letter VALUES("10000120","宿迁市","321300","10000010","2","S");
INSERT INTO cmf_region_letter VALUES("10000121","杭州市","330100","10000011","2","H");
INSERT INTO cmf_region_letter VALUES("10000122","宁波市","330200","10000011","2","N");
INSERT INTO cmf_region_letter VALUES("10000123","温州市","330300","10000011","2","W");
INSERT INTO cmf_region_letter VALUES("10000124","嘉兴市","330400","10000011","2","J");
INSERT INTO cmf_region_letter VALUES("10000125","湖州市","330500","10000011","2","H");
INSERT INTO cmf_region_letter VALUES("10000126","绍兴市","330600","10000011","2","S");
INSERT INTO cmf_region_letter VALUES("10000127","金华市","330700","10000011","2","J");
INSERT INTO cmf_region_letter VALUES("10000128","衢州市","330800","10000011","2","Q");
INSERT INTO cmf_region_letter VALUES("10000129","舟山市","330900","10000011","2","Z");
INSERT INTO cmf_region_letter VALUES("10000130","台州市","331000","10000011","2","T");
INSERT INTO cmf_region_letter VALUES("10000131","丽水市","331100","10000011","2","L");
INSERT INTO cmf_region_letter VALUES("10000132","合肥市","340100","10000012","2","H");
INSERT INTO cmf_region_letter VALUES("10000133","芜湖市","340200","10000012","2","W");
INSERT INTO cmf_region_letter VALUES("10000134","蚌埠市","340300","10000012","2","B");
INSERT INTO cmf_region_letter VALUES("10000135","淮南市","340400","10000012","2","H");
INSERT INTO cmf_region_letter VALUES("10000136","马鞍山市","340500","10000012","2","M");
INSERT INTO cmf_region_letter VALUES("10000137","淮北市","340600","10000012","2","H");
INSERT INTO cmf_region_letter VALUES("10000138","铜陵市","340700","10000012","2","T");
INSERT INTO cmf_region_letter VALUES("10000139","安庆市","340800","10000012","2","A");
INSERT INTO cmf_region_letter VALUES("10000140","黄山市","341000","10000012","2","H");
INSERT INTO cmf_region_letter VALUES("10000141","滁州市","341100","10000012","2","C");
INSERT INTO cmf_region_letter VALUES("10000142","阜阳市","341200","10000012","2","F");
INSERT INTO cmf_region_letter VALUES("10000143","宿州市","341300","10000012","2","S");
INSERT INTO cmf_region_letter VALUES("10000144","六安市","341500","10000012","2","L");
INSERT INTO cmf_region_letter VALUES("10000145","亳州市","341600","10000012","2","B");
INSERT INTO cmf_region_letter VALUES("10000146","池州市","341700","10000012","2","C");
INSERT INTO cmf_region_letter VALUES("10000147","宣城市","341800","10000012","2","X");
INSERT INTO cmf_region_letter VALUES("10000148","福州市","350100","10000013","2","F");
INSERT INTO cmf_region_letter VALUES("10000149","厦门市","350200","10000013","2","X");
INSERT INTO cmf_region_letter VALUES("10000150","莆田市","350300","10000013","2","P");
INSERT INTO cmf_region_letter VALUES("10000151","三明市","350400","10000013","2","S");
INSERT INTO cmf_region_letter VALUES("10000152","泉州市","350500","10000013","2","Q");
INSERT INTO cmf_region_letter VALUES("10000153","漳州市","350600","10000013","2","Z");
INSERT INTO cmf_region_letter VALUES("10000154","南平市","350700","10000013","2","N");
INSERT INTO cmf_region_letter VALUES("10000155","龙岩市","350800","10000013","2","L");
INSERT INTO cmf_region_letter VALUES("10000156","宁德市","350900","10000013","2","N");
INSERT INTO cmf_region_letter VALUES("10000157","南昌市","360100","10000014","2","N");
INSERT INTO cmf_region_letter VALUES("10000158","景德镇市","360200","10000014","2","J");
INSERT INTO cmf_region_letter VALUES("10000159","萍乡市","360300","10000014","2","P");
INSERT INTO cmf_region_letter VALUES("10000160","九江市","360400","10000014","2","J");
INSERT INTO cmf_region_letter VALUES("10000161","新余市","360500","10000014","2","X");
INSERT INTO cmf_region_letter VALUES("10000162","鹰潭市","360600","10000014","2","Y");
INSERT INTO cmf_region_letter VALUES("10000163","赣州市","360700","10000014","2","G");
INSERT INTO cmf_region_letter VALUES("10000164","吉安市","360800","10000014","2","J");
INSERT INTO cmf_region_letter VALUES("10000165","宜春市","360900","10000014","2","Y");
INSERT INTO cmf_region_letter VALUES("10000166","抚州市","361000","10000014","2","F");
INSERT INTO cmf_region_letter VALUES("10000167","上饶市","361100","10000014","2","S");
INSERT INTO cmf_region_letter VALUES("10000168","济南市","370100","10000015","2","J");
INSERT INTO cmf_region_letter VALUES("10000169","青岛市","370200","10000015","2","Q");
INSERT INTO cmf_region_letter VALUES("10000170","淄博市","370300","10000015","2","Z");
INSERT INTO cmf_region_letter VALUES("10000171","枣庄市","370400","10000015","2","Z");
INSERT INTO cmf_region_letter VALUES("10000172","东营市","370500","10000015","2","D");
INSERT INTO cmf_region_letter VALUES("10000173","烟台市","370600","10000015","2","Y");
INSERT INTO cmf_region_letter VALUES("10000174","潍坊市","370700","10000015","2","W");
INSERT INTO cmf_region_letter VALUES("10000175","济宁市","370800","10000015","2","J");
INSERT INTO cmf_region_letter VALUES("10000176","泰安市","370900","10000015","2","T");
INSERT INTO cmf_region_letter VALUES("10000177","威海市","371000","10000015","2","W");
INSERT INTO cmf_region_letter VALUES("10000178","日照市","371100","10000015","2","R");
INSERT INTO cmf_region_letter VALUES("10000179","临沂市","371300","10000015","2","L");
INSERT INTO cmf_region_letter VALUES("10000180","德州市","371400","10000015","2","D");
INSERT INTO cmf_region_letter VALUES("10000181","聊城市","371500","10000015","2","L");
INSERT INTO cmf_region_letter VALUES("10000182","滨州市","371600","10000015","2","B");
INSERT INTO cmf_region_letter VALUES("10000183","菏泽市","371700","10000015","2","H");
INSERT INTO cmf_region_letter VALUES("10000184","郑州市","410100","10000016","2","Z");
INSERT INTO cmf_region_letter VALUES("10000185","开封市","410200","10000016","2","K");
INSERT INTO cmf_region_letter VALUES("10000186","洛阳市","410300","10000016","2","L");
INSERT INTO cmf_region_letter VALUES("10000187","平顶山市","410400","10000016","2","P");
INSERT INTO cmf_region_letter VALUES("10000188","安阳市","410500","10000016","2","A");
INSERT INTO cmf_region_letter VALUES("10000189","鹤壁市","410600","10000016","2","H");
INSERT INTO cmf_region_letter VALUES("10000190","新乡市","410700","10000016","2","X");
INSERT INTO cmf_region_letter VALUES("10000191","焦作市","410800","10000016","2","J");
INSERT INTO cmf_region_letter VALUES("10000192","濮阳市","410900","10000016","2","P");
INSERT INTO cmf_region_letter VALUES("10000193","许昌市","411000","10000016","2","X");
INSERT INTO cmf_region_letter VALUES("10000194","漯河市","411100","10000016","2","T");
INSERT INTO cmf_region_letter VALUES("10000195","三门峡市","411200","10000016","2","S");
INSERT INTO cmf_region_letter VALUES("10000196","南阳市","411300","10000016","2","N");
INSERT INTO cmf_region_letter VALUES("10000197","商丘市","411400","10000016","2","S");
INSERT INTO cmf_region_letter VALUES("10000198","信阳市","411500","10000016","2","X");
INSERT INTO cmf_region_letter VALUES("10000199","周口市","411600","10000016","2","Z");
INSERT INTO cmf_region_letter VALUES("10000200","驻马店市","411700","10000016","2","Z");
INSERT INTO cmf_region_letter VALUES("10000201","省直辖县","419000","10000016","2","S");
INSERT INTO cmf_region_letter VALUES("10000202","武汉市","420100","10000017","2","W");
INSERT INTO cmf_region_letter VALUES("10000203","黄石市","420200","10000017","2","H");
INSERT INTO cmf_region_letter VALUES("10000204","十堰市","420300","10000017","2","S");
INSERT INTO cmf_region_letter VALUES("10000205","宜昌市","420500","10000017","2","Y");
INSERT INTO cmf_region_letter VALUES("10000206","襄阳市","420600","10000017","2","X");
INSERT INTO cmf_region_letter VALUES("10000207","鄂州市","420700","10000017","2","E");
INSERT INTO cmf_region_letter VALUES("10000208","荆门市","420800","10000017","2","J");
INSERT INTO cmf_region_letter VALUES("10000209","孝感市","420900","10000017","2","X");
INSERT INTO cmf_region_letter VALUES("10000210","荆州市","421000","10000017","2","J");
INSERT INTO cmf_region_letter VALUES("10000211","黄冈市","421100","10000017","2","H");
INSERT INTO cmf_region_letter VALUES("10000212","咸宁市","421200","10000017","2","X");
INSERT INTO cmf_region_letter VALUES("10000213","随州市","421300","10000017","2","S");
INSERT INTO cmf_region_letter VALUES("10000214","恩施土家族苗族自治州","422800","10000017","2","E");
INSERT INTO cmf_region_letter VALUES("10000215","省直辖县","429000","10000017","2","S");
INSERT INTO cmf_region_letter VALUES("10000216","长沙市","430100","10000018","2","C");
INSERT INTO cmf_region_letter VALUES("10000217","株洲市","430200","10000018","2","Z");
INSERT INTO cmf_region_letter VALUES("10000218","湘潭市","430300","10000018","2","X");
INSERT INTO cmf_region_letter VALUES("10000219","衡阳市","430400","10000018","2","H");
INSERT INTO cmf_region_letter VALUES("10000220","邵阳市","430500","10000018","2","S");
INSERT INTO cmf_region_letter VALUES("10000221","岳阳市","430600","10000018","2","Y");
INSERT INTO cmf_region_letter VALUES("10000222","常德市","430700","10000018","2","C");
INSERT INTO cmf_region_letter VALUES("10000223","张家界市","430800","10000018","2","Z");
INSERT INTO cmf_region_letter VALUES("10000224","益阳市","430900","10000018","2","Y");
INSERT INTO cmf_region_letter VALUES("10000225","郴州市","431000","10000018","2","C");
INSERT INTO cmf_region_letter VALUES("10000226","永州市","431100","10000018","2","Y");
INSERT INTO cmf_region_letter VALUES("10000227","怀化市","431200","10000018","2","H");
INSERT INTO cmf_region_letter VALUES("10000228","娄底市","431300","10000018","2","L");
INSERT INTO cmf_region_letter VALUES("10000229","湘西土家族苗族自治州","433100","10000018","2","X");
INSERT INTO cmf_region_letter VALUES("10000230","广州市","440100","10000019","2","G");
INSERT INTO cmf_region_letter VALUES("10000231","韶关市","440200","10000019","2","S");
INSERT INTO cmf_region_letter VALUES("10000232","深圳市","440300","10000019","2","S");
INSERT INTO cmf_region_letter VALUES("10000233","珠海市","440400","10000019","2","Z");
INSERT INTO cmf_region_letter VALUES("10000234","汕头市","440500","10000019","2","S");
INSERT INTO cmf_region_letter VALUES("10000235","佛山市","440600","10000019","2","F");
INSERT INTO cmf_region_letter VALUES("10000236","江门市","440700","10000019","2","J");
INSERT INTO cmf_region_letter VALUES("10000237","湛江市","440800","10000019","2","Z");
INSERT INTO cmf_region_letter VALUES("10000238","茂名市","440900","10000019","2","M");
INSERT INTO cmf_region_letter VALUES("10000239","肇庆市","441200","10000019","2","Z");
INSERT INTO cmf_region_letter VALUES("10000240","惠州市","441300","10000019","2","H");
INSERT INTO cmf_region_letter VALUES("10000241","梅州市","441400","10000019","2","M");
INSERT INTO cmf_region_letter VALUES("10000242","汕尾市","441500","10000019","2","S");
INSERT INTO cmf_region_letter VALUES("10000243","河源市","441600","10000019","2","H");
INSERT INTO cmf_region_letter VALUES("10000244","阳江市","441700","10000019","2","Y");
INSERT INTO cmf_region_letter VALUES("10000245","清远市","441800","10000019","2","Q");
INSERT INTO cmf_region_letter VALUES("10000246","东莞市","441900","10000019","2","D");
INSERT INTO cmf_region_letter VALUES("10000247","中山市","442000","10000019","2","Z");
INSERT INTO cmf_region_letter VALUES("10000248","潮州市","445100","10000019","2","C");
INSERT INTO cmf_region_letter VALUES("10000249","揭阳市","445200","10000019","2","J");
INSERT INTO cmf_region_letter VALUES("10000250","云浮市","445300","10000019","2","Y");
INSERT INTO cmf_region_letter VALUES("10000251","南宁市","450100","10000020","2","N");
INSERT INTO cmf_region_letter VALUES("10000252","柳州市","450200","10000020","2","L");
INSERT INTO cmf_region_letter VALUES("10000253","桂林市","450300","10000020","2","G");
INSERT INTO cmf_region_letter VALUES("10000254","梧州市","450400","10000020","2","W");
INSERT INTO cmf_region_letter VALUES("10000255","北海市","450500","10000020","2","B");
INSERT INTO cmf_region_letter VALUES("10000256","防城港市","450600","10000020","2","F");
INSERT INTO cmf_region_letter VALUES("10000257","钦州市","450700","10000020","2","Q");
INSERT INTO cmf_region_letter VALUES("10000258","贵港市","450800","10000020","2","G");
INSERT INTO cmf_region_letter VALUES("10000259","玉林市","450900","10000020","2","Y");
INSERT INTO cmf_region_letter VALUES("10000260","百色市","451000","10000020","2","B");
INSERT INTO cmf_region_letter VALUES("10000261","贺州市","451100","10000020","2","H");
INSERT INTO cmf_region_letter VALUES("10000262","河池市","451200","10000020","2","H");
INSERT INTO cmf_region_letter VALUES("10000263","来宾市","451300","10000020","2","L");
INSERT INTO cmf_region_letter VALUES("10000264","崇左市","451400","10000020","2","C");
INSERT INTO cmf_region_letter VALUES("10000265","海口市","460100","10000021","2","H");
INSERT INTO cmf_region_letter VALUES("10000266","三亚市","460200","10000021","2","S");
INSERT INTO cmf_region_letter VALUES("10000267","三沙市","460300","10000021","2","S");
INSERT INTO cmf_region_letter VALUES("10000268","儋州市","460400","10000021","2","D");
INSERT INTO cmf_region_letter VALUES("10000269","省直辖县","469000","10000021","2","S");
INSERT INTO cmf_region_letter VALUES("10000270","重庆市","500100","10000022","2","C");
INSERT INTO cmf_region_letter VALUES("10000271","县","500200","10000022","2","X");
INSERT INTO cmf_region_letter VALUES("10000272","成都市","510100","10000023","2","C");
INSERT INTO cmf_region_letter VALUES("10000273","自贡市","510300","10000023","2","Z");
INSERT INTO cmf_region_letter VALUES("10000274","攀枝花市","510400","10000023","2","P");
INSERT INTO cmf_region_letter VALUES("10000275","泸州市","510500","10000023","2","L");
INSERT INTO cmf_region_letter VALUES("10000276","德阳市","510600","10000023","2","D");
INSERT INTO cmf_region_letter VALUES("10000277","绵阳市","510700","10000023","2","M");
INSERT INTO cmf_region_letter VALUES("10000278","广元市","510800","10000023","2","G");
INSERT INTO cmf_region_letter VALUES("10000279","遂宁市","510900","10000023","2","S");
INSERT INTO cmf_region_letter VALUES("10000280","内江市","511000","10000023","2","N");
INSERT INTO cmf_region_letter VALUES("10000281","乐山市","511100","10000023","2","L");
INSERT INTO cmf_region_letter VALUES("10000282","南充市","511300","10000023","2","N");
INSERT INTO cmf_region_letter VALUES("10000283","眉山市","511400","10000023","2","M");
INSERT INTO cmf_region_letter VALUES("10000284","宜宾市","511500","10000023","2","Y");
INSERT INTO cmf_region_letter VALUES("10000285","广安市","511600","10000023","2","G");
INSERT INTO cmf_region_letter VALUES("10000286","达州市","511700","10000023","2","D");
INSERT INTO cmf_region_letter VALUES("10000287","雅安市","511800","10000023","2","Y");
INSERT INTO cmf_region_letter VALUES("10000288","巴中市","511900","10000023","2","B");
INSERT INTO cmf_region_letter VALUES("10000289","资阳市","512000","10000023","2","Z");
INSERT INTO cmf_region_letter VALUES("10000290","阿坝藏族羌族自治州","513200","10000023","2","A");
INSERT INTO cmf_region_letter VALUES("10000291","甘孜藏族自治州","513300","10000023","2","G");
INSERT INTO cmf_region_letter VALUES("10000292","凉山彝族自治州","513400","10000023","2","L");
INSERT INTO cmf_region_letter VALUES("10000293","贵阳市","520100","10000024","2","G");
INSERT INTO cmf_region_letter VALUES("10000294","六盘水市","520200","10000024","2","L");
INSERT INTO cmf_region_letter VALUES("10000295","遵义市","520300","10000024","2","Z");
INSERT INTO cmf_region_letter VALUES("10000296","安顺市","520400","10000024","2","A");
INSERT INTO cmf_region_letter VALUES("10000297","毕节市","520500","10000024","2","B");
INSERT INTO cmf_region_letter VALUES("10000298","铜仁市","520600","10000024","2","T");
INSERT INTO cmf_region_letter VALUES("10000299","黔西南布依族苗族自治州","522300","10000024","2","Q");
INSERT INTO cmf_region_letter VALUES("10000300","黔东南苗族侗族自治州","522600","10000024","2","Q");
INSERT INTO cmf_region_letter VALUES("10000301","黔南布依族苗族自治州","522700","10000024","2","Q");
INSERT INTO cmf_region_letter VALUES("10000302","昆明市","530100","10000025","2","K");
INSERT INTO cmf_region_letter VALUES("10000303","曲靖市","530300","10000025","2","Q");
INSERT INTO cmf_region_letter VALUES("10000304","玉溪市","530400","10000025","2","Y");
INSERT INTO cmf_region_letter VALUES("10000305","保山市","530500","10000025","2","B");
INSERT INTO cmf_region_letter VALUES("10000306","昭通市","530600","10000025","2","Z");
INSERT INTO cmf_region_letter VALUES("10000307","丽江市","530700","10000025","2","L");
INSERT INTO cmf_region_letter VALUES("10000308","普洱市","530800","10000025","2","P");
INSERT INTO cmf_region_letter VALUES("10000309","临沧市","530900","10000025","2","L");
INSERT INTO cmf_region_letter VALUES("10000310","楚雄彝族自治州","532300","10000025","2","C");
INSERT INTO cmf_region_letter VALUES("10000311","红河哈尼族彝族自治州","532500","10000025","2","H");
INSERT INTO cmf_region_letter VALUES("10000312","文山壮族苗族自治州","532600","10000025","2","W");
INSERT INTO cmf_region_letter VALUES("10000313","西双版纳傣族自治州","532800","10000025","2","X");
INSERT INTO cmf_region_letter VALUES("10000314","大理白族自治州","532900","10000025","2","D");
INSERT INTO cmf_region_letter VALUES("10000315","德宏傣族景颇族自治州","533100","10000025","2","D");
INSERT INTO cmf_region_letter VALUES("10000316","怒江傈僳族自治州","533300","10000025","2","N");
INSERT INTO cmf_region_letter VALUES("10000317","迪庆藏族自治州","533400","10000025","2","D");
INSERT INTO cmf_region_letter VALUES("10000318","拉萨市","540100","10000026","2","L");
INSERT INTO cmf_region_letter VALUES("10000319","日喀则市","540200","10000026","2","R");
INSERT INTO cmf_region_letter VALUES("10000320","昌都市","540300","10000026","2","C");
INSERT INTO cmf_region_letter VALUES("10000321","林芝市","540400","10000026","2","L");
INSERT INTO cmf_region_letter VALUES("10000322","山南市","540500","10000026","2","S");
INSERT INTO cmf_region_letter VALUES("10000323","那曲市","540600","10000026","2","N");
INSERT INTO cmf_region_letter VALUES("10000324","阿里地区","542500","10000026","2","A");
INSERT INTO cmf_region_letter VALUES("10000325","西安市","610100","10000027","2","X");
INSERT INTO cmf_region_letter VALUES("10000326","铜川市","610200","10000027","2","T");
INSERT INTO cmf_region_letter VALUES("10000327","宝鸡市","610300","10000027","2","B");
INSERT INTO cmf_region_letter VALUES("10000328","咸阳市","610400","10000027","2","X");
INSERT INTO cmf_region_letter VALUES("10000329","渭南市","610500","10000027","2","W");
INSERT INTO cmf_region_letter VALUES("10000330","延安市","610600","10000027","2","Y");
INSERT INTO cmf_region_letter VALUES("10000331","汉中市","610700","10000027","2","H");
INSERT INTO cmf_region_letter VALUES("10000332","榆林市","610800","10000027","2","Y");
INSERT INTO cmf_region_letter VALUES("10000333","安康市","610900","10000027","2","A");
INSERT INTO cmf_region_letter VALUES("10000334","商洛市","611000","10000027","2","S");
INSERT INTO cmf_region_letter VALUES("10000335","兰州市","620100","10000028","2","L");
INSERT INTO cmf_region_letter VALUES("10000336","嘉峪关市","620200","10000028","2","J");
INSERT INTO cmf_region_letter VALUES("10000337","金昌市","620300","10000028","2","J");
INSERT INTO cmf_region_letter VALUES("10000338","白银市","620400","10000028","2","B");
INSERT INTO cmf_region_letter VALUES("10000339","天水市","620500","10000028","2","T");
INSERT INTO cmf_region_letter VALUES("10000340","武威市","620600","10000028","2","W");
INSERT INTO cmf_region_letter VALUES("10000341","张掖市","620700","10000028","2","Z");
INSERT INTO cmf_region_letter VALUES("10000342","平凉市","620800","10000028","2","P");
INSERT INTO cmf_region_letter VALUES("10000343","酒泉市","620900","10000028","2","J");
INSERT INTO cmf_region_letter VALUES("10000344","庆阳市","621000","10000028","2","Q");
INSERT INTO cmf_region_letter VALUES("10000345","定西市","621100","10000028","2","D");
INSERT INTO cmf_region_letter VALUES("10000346","陇南市","621200","10000028","2","L");
INSERT INTO cmf_region_letter VALUES("10000347","临夏回族自治州","622900","10000028","2","L");
INSERT INTO cmf_region_letter VALUES("10000348","甘南藏族自治州","623000","10000028","2","G");
INSERT INTO cmf_region_letter VALUES("10000349","西宁市","630100","10000029","2","X");
INSERT INTO cmf_region_letter VALUES("10000350","海东市","630200","10000029","2","H");
INSERT INTO cmf_region_letter VALUES("10000351","海北藏族自治州","632200","10000029","2","H");
INSERT INTO cmf_region_letter VALUES("10000352","黄南藏族自治州","632300","10000029","2","H");
INSERT INTO cmf_region_letter VALUES("10000353","海南藏族自治州","632500","10000029","2","H");
INSERT INTO cmf_region_letter VALUES("10000354","果洛藏族自治州","632600","10000029","2","G");
INSERT INTO cmf_region_letter VALUES("10000355","玉树藏族自治州","632700","10000029","2","Y");
INSERT INTO cmf_region_letter VALUES("10000356","海西蒙古族藏族自治州","632800","10000029","2","H");
INSERT INTO cmf_region_letter VALUES("10000357","银川市","640100","10000030","2","Y");
INSERT INTO cmf_region_letter VALUES("10000358","石嘴山市","640200","10000030","2","S");
INSERT INTO cmf_region_letter VALUES("10000359","吴忠市","640300","10000030","2","W");
INSERT INTO cmf_region_letter VALUES("10000360","固原市","640400","10000030","2","G");
INSERT INTO cmf_region_letter VALUES("10000361","中卫市","640500","10000030","2","Z");
INSERT INTO cmf_region_letter VALUES("10000362","乌鲁木齐市","650100","10000031","2","W");
INSERT INTO cmf_region_letter VALUES("10000363","克拉玛依市","650200","10000031","2","K");
INSERT INTO cmf_region_letter VALUES("10000364","吐鲁番市","650400","10000031","2","T");
INSERT INTO cmf_region_letter VALUES("10000365","哈密市","650500","10000031","2","H");
INSERT INTO cmf_region_letter VALUES("10000366","昌吉回族自治州","652300","10000031","2","C");
INSERT INTO cmf_region_letter VALUES("10000367","博尔塔拉蒙古自治州","652700","10000031","2","B");
INSERT INTO cmf_region_letter VALUES("10000368","巴音郭楞蒙古自治州","652800","10000031","2","B");
INSERT INTO cmf_region_letter VALUES("10000369","阿克苏地区","652900","10000031","2","A");
INSERT INTO cmf_region_letter VALUES("10000370","克孜勒苏柯尔克孜自治州","653000","10000031","2","K");
INSERT INTO cmf_region_letter VALUES("10000371","喀什地区","653100","10000031","2","K");
INSERT INTO cmf_region_letter VALUES("10000372","和田地区","653200","10000031","2","H");
INSERT INTO cmf_region_letter VALUES("10000373","伊犁哈萨克自治州","654000","10000031","2","Y");
INSERT INTO cmf_region_letter VALUES("10000374","塔城地区","654200","10000031","2","T");
INSERT INTO cmf_region_letter VALUES("10000375","阿勒泰地区","654300","10000031","2","A");
INSERT INTO cmf_region_letter VALUES("10000376","自治区直辖县级行政区划","659000","10000031","2","Z");
INSERT INTO cmf_region_letter VALUES("10000377","台北市","710100","10000032","2","T");
INSERT INTO cmf_region_letter VALUES("10000378","高雄市","710200","10000032","2","G");
INSERT INTO cmf_region_letter VALUES("10000379","台南市","710300","10000032","2","T");
INSERT INTO cmf_region_letter VALUES("10000380","台中市","710400","10000032","2","T");
INSERT INTO cmf_region_letter VALUES("10000381","金门县","710500","10000032","2","J");
INSERT INTO cmf_region_letter VALUES("10000382","南投县","710600","10000032","2","N");
INSERT INTO cmf_region_letter VALUES("10000383","基隆市","710700","10000032","2","J");
INSERT INTO cmf_region_letter VALUES("10000384","新竹市","710800","10000032","2","X");
INSERT INTO cmf_region_letter VALUES("10000385","嘉义市","710900","10000032","2","J");
INSERT INTO cmf_region_letter VALUES("10000386","新北市","711100","10000032","2","X");
INSERT INTO cmf_region_letter VALUES("10000387","宜兰县","711200","10000032","2","Y");
INSERT INTO cmf_region_letter VALUES("10000388","新竹县","711300","10000032","2","X");
INSERT INTO cmf_region_letter VALUES("10000389","桃园县","711400","10000032","2","T");
INSERT INTO cmf_region_letter VALUES("10000390","苗栗县","711500","10000032","2","M");
INSERT INTO cmf_region_letter VALUES("10000391","彰化县","711700","10000032","2","Z");
INSERT INTO cmf_region_letter VALUES("10000392","嘉义县","711900","10000032","2","J");
INSERT INTO cmf_region_letter VALUES("10000393","云林县","712100","10000032","2","Y");
INSERT INTO cmf_region_letter VALUES("10000394","屏东县","712400","10000032","2","P");
INSERT INTO cmf_region_letter VALUES("10000395","台东县","712500","10000032","2","T");
INSERT INTO cmf_region_letter VALUES("10000396","花莲县","712600","10000032","2","H");
INSERT INTO cmf_region_letter VALUES("10000397","澎湖县","712700","10000032","2","P");
INSERT INTO cmf_region_letter VALUES("10000398","连江县","712800","10000032","2","L");
INSERT INTO cmf_region_letter VALUES("10000399","香港岛","810100","10000033","2","X");
INSERT INTO cmf_region_letter VALUES("10000400","九龙","810200","10000033","2","J");
INSERT INTO cmf_region_letter VALUES("10000401","新界","810300","10000033","2","X");
INSERT INTO cmf_region_letter VALUES("10000402","澳门半岛","820100","10000034","2","A");
INSERT INTO cmf_region_letter VALUES("10000403","离岛","820200","10000034","2","L");
INSERT INTO cmf_region_letter VALUES("10000404","东城区","110101","10000035","3","D");
INSERT INTO cmf_region_letter VALUES("10000405","西城区","110102","10000035","3","X");
INSERT INTO cmf_region_letter VALUES("10000406","朝阳区","110105","10000035","3","C");
INSERT INTO cmf_region_letter VALUES("10000407","丰台区","110106","10000035","3","F");
INSERT INTO cmf_region_letter VALUES("10000408","石景山区","110107","10000035","3","S");
INSERT INTO cmf_region_letter VALUES("10000409","海淀区","110108","10000035","3","H");
INSERT INTO cmf_region_letter VALUES("10000410","门头沟区","110109","10000035","3","M");
INSERT INTO cmf_region_letter VALUES("10000411","房山区","110111","10000035","3","F");
INSERT INTO cmf_region_letter VALUES("10000412","通州区","110112","10000035","3","T");
INSERT INTO cmf_region_letter VALUES("10000413","顺义区","110113","10000035","3","S");
INSERT INTO cmf_region_letter VALUES("10000414","昌平区","110114","10000035","3","C");
INSERT INTO cmf_region_letter VALUES("10000415","大兴区","110115","10000035","3","D");
INSERT INTO cmf_region_letter VALUES("10000416","怀柔区","110116","10000035","3","H");
INSERT INTO cmf_region_letter VALUES("10000417","平谷区","110117","10000035","3","P");
INSERT INTO cmf_region_letter VALUES("10000418","密云区","110118","10000035","3","M");
INSERT INTO cmf_region_letter VALUES("10000419","延庆区","110119","10000035","3","Y");
INSERT INTO cmf_region_letter VALUES("10000420","和平区","120101","10000036","3","H");
INSERT INTO cmf_region_letter VALUES("10000421","河东区","120102","10000036","3","H");
INSERT INTO cmf_region_letter VALUES("10000422","河西区","120103","10000036","3","H");
INSERT INTO cmf_region_letter VALUES("10000423","南开区","120104","10000036","3","N");
INSERT INTO cmf_region_letter VALUES("10000424","河北区","120105","10000036","3","H");
INSERT INTO cmf_region_letter VALUES("10000425","红桥区","120106","10000036","3","H");
INSERT INTO cmf_region_letter VALUES("10000426","东丽区","120110","10000036","3","D");
INSERT INTO cmf_region_letter VALUES("10000427","西青区","120111","10000036","3","X");
INSERT INTO cmf_region_letter VALUES("10000428","津南区","120112","10000036","3","J");
INSERT INTO cmf_region_letter VALUES("10000429","北辰区","120113","10000036","3","B");
INSERT INTO cmf_region_letter VALUES("10000430","武清区","120114","10000036","3","W");
INSERT INTO cmf_region_letter VALUES("10000431","宝坻区","120115","10000036","3","B");
INSERT INTO cmf_region_letter VALUES("10000432","滨海新区","120116","10000036","3","B");
INSERT INTO cmf_region_letter VALUES("10000433","宁河区","120117","10000036","3","N");
INSERT INTO cmf_region_letter VALUES("10000434","静海区","120118","10000036","3","J");
INSERT INTO cmf_region_letter VALUES("10000435","蓟州区","120119","10000036","3","J");
INSERT INTO cmf_region_letter VALUES("10000436","长安区","130102","10000037","3","C");
INSERT INTO cmf_region_letter VALUES("10000437","桥西区","130104","10000037","3","Q");
INSERT INTO cmf_region_letter VALUES("10000438","新华区","130105","10000037","3","X");
INSERT INTO cmf_region_letter VALUES("10000439","井陉矿区","130107","10000037","3","J");
INSERT INTO cmf_region_letter VALUES("10000440","裕华区","130108","10000037","3","Y");
INSERT INTO cmf_region_letter VALUES("10000441","藁城区","130109","10000037","3","G");
INSERT INTO cmf_region_letter VALUES("10000442","鹿泉区","130110","10000037","3","L");
INSERT INTO cmf_region_letter VALUES("10000443","栾城区","130111","10000037","3","L");
INSERT INTO cmf_region_letter VALUES("10000444","井陉县","130121","10000037","3","J");
INSERT INTO cmf_region_letter VALUES("10000445","正定县","130123","10000037","3","Z");
INSERT INTO cmf_region_letter VALUES("10000446","行唐县","130125","10000037","3","X");
INSERT INTO cmf_region_letter VALUES("10000447","灵寿县","130126","10000037","3","L");
INSERT INTO cmf_region_letter VALUES("10000448","高邑县","130127","10000037","3","G");
INSERT INTO cmf_region_letter VALUES("10000449","深泽县","130128","10000037","3","S");
INSERT INTO cmf_region_letter VALUES("10000450","赞皇县","130129","10000037","3","Z");
INSERT INTO cmf_region_letter VALUES("10000451","无极县","130130","10000037","3","W");
INSERT INTO cmf_region_letter VALUES("10000452","平山县","130131","10000037","3","P");
INSERT INTO cmf_region_letter VALUES("10000453","元氏县","130132","10000037","3","Y");
INSERT INTO cmf_region_letter VALUES("10000454","赵县","130133","10000037","3","Z");
INSERT INTO cmf_region_letter VALUES("10000455","辛集市","130181","10000037","3","X");
INSERT INTO cmf_region_letter VALUES("10000456","晋州市","130183","10000037","3","J");
INSERT INTO cmf_region_letter VALUES("10000457","新乐市","130184","10000037","3","X");
INSERT INTO cmf_region_letter VALUES("10000458","路南区","130202","10000038","3","L");
INSERT INTO cmf_region_letter VALUES("10000459","路北区","130203","10000038","3","L");
INSERT INTO cmf_region_letter VALUES("10000460","古冶区","130204","10000038","3","G");
INSERT INTO cmf_region_letter VALUES("10000461","开平区","130205","10000038","3","K");
INSERT INTO cmf_region_letter VALUES("10000462","丰南区","130207","10000038","3","F");
INSERT INTO cmf_region_letter VALUES("10000463","丰润区","130208","10000038","3","F");
INSERT INTO cmf_region_letter VALUES("10000464","曹妃甸区","130209","10000038","3","C");
INSERT INTO cmf_region_letter VALUES("10000465","滦南县","130224","10000038","3","L");
INSERT INTO cmf_region_letter VALUES("10000466","乐亭县","130225","10000038","3","L");
INSERT INTO cmf_region_letter VALUES("10000467","迁西县","130227","10000038","3","Q");
INSERT INTO cmf_region_letter VALUES("10000468","玉田县","130229","10000038","3","Y");
INSERT INTO cmf_region_letter VALUES("10000469","遵化市","130281","10000038","3","Z");
INSERT INTO cmf_region_letter VALUES("10000470","迁安市","130283","10000038","3","Q");
INSERT INTO cmf_region_letter VALUES("10000471","滦州市","130284","10000038","3","L");
INSERT INTO cmf_region_letter VALUES("10000472","海港区","130302","10000039","3","H");
INSERT INTO cmf_region_letter VALUES("10000473","山海关区","130303","10000039","3","S");
INSERT INTO cmf_region_letter VALUES("10000474","北戴河区","130304","10000039","3","B");
INSERT INTO cmf_region_letter VALUES("10000475","抚宁区","130306","10000039","3","F");
INSERT INTO cmf_region_letter VALUES("10000476","青龙满族自治县","130321","10000039","3","Q");
INSERT INTO cmf_region_letter VALUES("10000477","昌黎县","130322","10000039","3","C");
INSERT INTO cmf_region_letter VALUES("10000478","卢龙县","130324","10000039","3","L");
INSERT INTO cmf_region_letter VALUES("10000479","经济技术开发区","130390","10000039","3","J");
INSERT INTO cmf_region_letter VALUES("10000480","邯山区","130402","10000040","3","H");
INSERT INTO cmf_region_letter VALUES("10000481","丛台区","130403","10000040","3","C");
INSERT INTO cmf_region_letter VALUES("10000482","复兴区","130404","10000040","3","F");
INSERT INTO cmf_region_letter VALUES("10000483","峰峰矿区","130406","10000040","3","F");
INSERT INTO cmf_region_letter VALUES("10000484","肥乡区","130407","10000040","3","F");
INSERT INTO cmf_region_letter VALUES("10000485","永年区","130408","10000040","3","Y");
INSERT INTO cmf_region_letter VALUES("10000486","临漳县","130423","10000040","3","L");
INSERT INTO cmf_region_letter VALUES("10000487","成安县","130424","10000040","3","C");
INSERT INTO cmf_region_letter VALUES("10000488","大名县","130425","10000040","3","D");
INSERT INTO cmf_region_letter VALUES("10000489","涉县","130426","10000040","3","S");
INSERT INTO cmf_region_letter VALUES("10000490","磁县","130427","10000040","3","C");
INSERT INTO cmf_region_letter VALUES("10000491","邱县","130430","10000040","3","Q");
INSERT INTO cmf_region_letter VALUES("10000492","鸡泽县","130431","10000040","3","J");
INSERT INTO cmf_region_letter VALUES("10000493","广平县","130432","10000040","3","G");
INSERT INTO cmf_region_letter VALUES("10000494","馆陶县","130433","10000040","3","G");
INSERT INTO cmf_region_letter VALUES("10000495","魏县","130434","10000040","3","W");
INSERT INTO cmf_region_letter VALUES("10000496","曲周县","130435","10000040","3","Q");
INSERT INTO cmf_region_letter VALUES("10000497","武安市","130481","10000040","3","W");
INSERT INTO cmf_region_letter VALUES("10000498","桥东区","130502","10000041","3","Q");
INSERT INTO cmf_region_letter VALUES("10000499","桥西区","130503","10000041","3","Q");
INSERT INTO cmf_region_letter VALUES("10000500","邢台县","130521","10000041","3","X");
INSERT INTO cmf_region_letter VALUES("10000501","临城县","130522","10000041","3","L");
INSERT INTO cmf_region_letter VALUES("10000502","内丘县","130523","10000041","3","N");
INSERT INTO cmf_region_letter VALUES("10000503","柏乡县","130524","10000041","3","B");
INSERT INTO cmf_region_letter VALUES("10000504","隆尧县","130525","10000041","3","L");
INSERT INTO cmf_region_letter VALUES("10000505","任县","130526","10000041","3","R");
INSERT INTO cmf_region_letter VALUES("10000506","南和县","130527","10000041","3","N");
INSERT INTO cmf_region_letter VALUES("10000507","宁晋县","130528","10000041","3","N");
INSERT INTO cmf_region_letter VALUES("10000508","巨鹿县","130529","10000041","3","J");
INSERT INTO cmf_region_letter VALUES("10000509","新河县","130530","10000041","3","X");
INSERT INTO cmf_region_letter VALUES("10000510","广宗县","130531","10000041","3","G");
INSERT INTO cmf_region_letter VALUES("10000511","平乡县","130532","10000041","3","P");
INSERT INTO cmf_region_letter VALUES("10000512","威县","130533","10000041","3","W");
INSERT INTO cmf_region_letter VALUES("10000513","清河县","130534","10000041","3","Q");
INSERT INTO cmf_region_letter VALUES("10000514","临西县","130535","10000041","3","L");
INSERT INTO cmf_region_letter VALUES("10000515","南宫市","130581","10000041","3","N");
INSERT INTO cmf_region_letter VALUES("10000516","沙河市","130582","10000041","3","S");
INSERT INTO cmf_region_letter VALUES("10000517","竞秀区","130602","10000042","3","J");
INSERT INTO cmf_region_letter VALUES("10000518","莲池区","130606","10000042","3","L");
INSERT INTO cmf_region_letter VALUES("10000519","满城区","130607","10000042","3","M");
INSERT INTO cmf_region_letter VALUES("10000520","清苑区","130608","10000042","3","Q");
INSERT INTO cmf_region_letter VALUES("10000521","徐水区","130609","10000042","3","X");
INSERT INTO cmf_region_letter VALUES("10000522","涞水县","130623","10000042","3","L");
INSERT INTO cmf_region_letter VALUES("10000523","阜平县","130624","10000042","3","F");
INSERT INTO cmf_region_letter VALUES("10000524","定兴县","130626","10000042","3","D");
INSERT INTO cmf_region_letter VALUES("10000525","唐县","130627","10000042","3","T");
INSERT INTO cmf_region_letter VALUES("10000526","高阳县","130628","10000042","3","G");
INSERT INTO cmf_region_letter VALUES("10000527","容城县","130629","10000042","3","R");
INSERT INTO cmf_region_letter VALUES("10000528","涞源县","130630","10000042","3","L");
INSERT INTO cmf_region_letter VALUES("10000529","望都县","130631","10000042","3","W");
INSERT INTO cmf_region_letter VALUES("10000530","安新县","130632","10000042","3","A");
INSERT INTO cmf_region_letter VALUES("10000531","易县","130633","10000042","3","Y");
INSERT INTO cmf_region_letter VALUES("10000532","曲阳县","130634","10000042","3","Q");
INSERT INTO cmf_region_letter VALUES("10000533","蠡县","130635","10000042","3","L");
INSERT INTO cmf_region_letter VALUES("10000534","顺平县","130636","10000042","3","S");
INSERT INTO cmf_region_letter VALUES("10000535","博野县","130637","10000042","3","B");
INSERT INTO cmf_region_letter VALUES("10000536","雄县","130638","10000042","3","X");
INSERT INTO cmf_region_letter VALUES("10000537","涿州市","130681","10000042","3","Z");
INSERT INTO cmf_region_letter VALUES("10000538","定州市","130682","10000042","3","D");
INSERT INTO cmf_region_letter VALUES("10000539","安国市","130683","10000042","3","A");
INSERT INTO cmf_region_letter VALUES("10000540","高碑店市","130684","10000042","3","G");
INSERT INTO cmf_region_letter VALUES("10000541","桥东区","130702","10000043","3","Q");
INSERT INTO cmf_region_letter VALUES("10000542","桥西区","130703","10000043","3","Q");
INSERT INTO cmf_region_letter VALUES("10000543","宣化区","130705","10000043","3","X");
INSERT INTO cmf_region_letter VALUES("10000544","下花园区","130706","10000043","3","X");
INSERT INTO cmf_region_letter VALUES("10000545","万全区","130708","10000043","3","W");
INSERT INTO cmf_region_letter VALUES("10000546","崇礼区","130709","10000043","3","C");
INSERT INTO cmf_region_letter VALUES("10000547","张北县","130722","10000043","3","Z");
INSERT INTO cmf_region_letter VALUES("10000548","康保县","130723","10000043","3","K");
INSERT INTO cmf_region_letter VALUES("10000549","沽源县","130724","10000043","3","G");
INSERT INTO cmf_region_letter VALUES("10000550","尚义县","130725","10000043","3","S");
INSERT INTO cmf_region_letter VALUES("10000551","蔚县","130726","10000043","3","Y");
INSERT INTO cmf_region_letter VALUES("10000552","阳原县","130727","10000043","3","Y");
INSERT INTO cmf_region_letter VALUES("10000553","怀安县","130728","10000043","3","H");
INSERT INTO cmf_region_letter VALUES("10000554","怀来县","130730","10000043","3","H");
INSERT INTO cmf_region_letter VALUES("10000555","涿鹿县","130731","10000043","3","Z");
INSERT INTO cmf_region_letter VALUES("10000556","赤城县","130732","10000043","3","C");
INSERT INTO cmf_region_letter VALUES("10000557","双桥区","130802","10000044","3","S");
INSERT INTO cmf_region_letter VALUES("10000558","双滦区","130803","10000044","3","S");
INSERT INTO cmf_region_letter VALUES("10000559","鹰手营子矿区","130804","10000044","3","Y");
INSERT INTO cmf_region_letter VALUES("10000560","承德县","130821","10000044","3","C");
INSERT INTO cmf_region_letter VALUES("10000561","兴隆县","130822","10000044","3","X");
INSERT INTO cmf_region_letter VALUES("10000562","滦平县","130824","10000044","3","L");
INSERT INTO cmf_region_letter VALUES("10000563","隆化县","130825","10000044","3","L");
INSERT INTO cmf_region_letter VALUES("10000564","丰宁满族自治县","130826","10000044","3","F");
INSERT INTO cmf_region_letter VALUES("10000565","宽城满族自治县","130827","10000044","3","K");
INSERT INTO cmf_region_letter VALUES("10000566","围场满族蒙古族自治县","130828","10000044","3","W");
INSERT INTO cmf_region_letter VALUES("10000567","平泉市","130881","10000044","3","P");
INSERT INTO cmf_region_letter VALUES("10000568","新华区","130902","10000045","3","X");
INSERT INTO cmf_region_letter VALUES("10000569","运河区","130903","10000045","3","Y");
INSERT INTO cmf_region_letter VALUES("10000570","沧县","130921","10000045","3","C");
INSERT INTO cmf_region_letter VALUES("10000571","青县","130922","10000045","3","Q");
INSERT INTO cmf_region_letter VALUES("10000572","东光县","130923","10000045","3","D");
INSERT INTO cmf_region_letter VALUES("10000573","海兴县","130924","10000045","3","H");
INSERT INTO cmf_region_letter VALUES("10000574","盐山县","130925","10000045","3","Y");
INSERT INTO cmf_region_letter VALUES("10000575","肃宁县","130926","10000045","3","S");
INSERT INTO cmf_region_letter VALUES("10000576","南皮县","130927","10000045","3","N");
INSERT INTO cmf_region_letter VALUES("10000577","吴桥县","130928","10000045","3","W");
INSERT INTO cmf_region_letter VALUES("10000578","献县","130929","10000045","3","X");
INSERT INTO cmf_region_letter VALUES("10000579","孟村回族自治县","130930","10000045","3","M");
INSERT INTO cmf_region_letter VALUES("10000580","泊头市","130981","10000045","3","B");
INSERT INTO cmf_region_letter VALUES("10000581","任丘市","130982","10000045","3","R");
INSERT INTO cmf_region_letter VALUES("10000582","黄骅市","130983","10000045","3","H");
INSERT INTO cmf_region_letter VALUES("10000583","河间市","130984","10000045","3","H");
INSERT INTO cmf_region_letter VALUES("10000584","安次区","131002","10000046","3","A");
INSERT INTO cmf_region_letter VALUES("10000585","广阳区","131003","10000046","3","G");
INSERT INTO cmf_region_letter VALUES("10000586","固安县","131022","10000046","3","G");
INSERT INTO cmf_region_letter VALUES("10000587","永清县","131023","10000046","3","Y");
INSERT INTO cmf_region_letter VALUES("10000588","香河县","131024","10000046","3","X");
INSERT INTO cmf_region_letter VALUES("10000589","大城县","131025","10000046","3","D");
INSERT INTO cmf_region_letter VALUES("10000590","文安县","131026","10000046","3","W");
INSERT INTO cmf_region_letter VALUES("10000591","大厂回族自治县","131028","10000046","3","D");
INSERT INTO cmf_region_letter VALUES("10000592","霸州市","131081","10000046","3","B");
INSERT INTO cmf_region_letter VALUES("10000593","三河市","131082","10000046","3","S");
INSERT INTO cmf_region_letter VALUES("10000594","开发区","131090","10000046","3","K");
INSERT INTO cmf_region_letter VALUES("10000595","桃城区","131102","10000047","3","T");
INSERT INTO cmf_region_letter VALUES("10000596","冀州区","131103","10000047","3","J");
INSERT INTO cmf_region_letter VALUES("10000597","枣强县","131121","10000047","3","Z");
INSERT INTO cmf_region_letter VALUES("10000598","武邑县","131122","10000047","3","W");
INSERT INTO cmf_region_letter VALUES("10000599","武强县","131123","10000047","3","W");
INSERT INTO cmf_region_letter VALUES("10000600","饶阳县","131124","10000047","3","R");
INSERT INTO cmf_region_letter VALUES("10000601","安平县","131125","10000047","3","A");
INSERT INTO cmf_region_letter VALUES("10000602","故城县","131126","10000047","3","G");
INSERT INTO cmf_region_letter VALUES("10000603","景县","131127","10000047","3","J");
INSERT INTO cmf_region_letter VALUES("10000604","阜城县","131128","10000047","3","F");
INSERT INTO cmf_region_letter VALUES("10000605","深州市","131182","10000047","3","S");
INSERT INTO cmf_region_letter VALUES("10000606","小店区","140105","10000048","3","X");
INSERT INTO cmf_region_letter VALUES("10000607","迎泽区","140106","10000048","3","Y");
INSERT INTO cmf_region_letter VALUES("10000608","杏花岭区","140107","10000048","3","X");
INSERT INTO cmf_region_letter VALUES("10000609","尖草坪区","140108","10000048","3","J");
INSERT INTO cmf_region_letter VALUES("10000610","万柏林区","140109","10000048","3","W");
INSERT INTO cmf_region_letter VALUES("10000611","晋源区","140110","10000048","3","J");
INSERT INTO cmf_region_letter VALUES("10000612","清徐县","140121","10000048","3","Q");
INSERT INTO cmf_region_letter VALUES("10000613","阳曲县","140122","10000048","3","Y");
INSERT INTO cmf_region_letter VALUES("10000614","娄烦县","140123","10000048","3","L");
INSERT INTO cmf_region_letter VALUES("10000615","古交市","140181","10000048","3","G");
INSERT INTO cmf_region_letter VALUES("10000616","新荣区","140212","10000049","3","X");
INSERT INTO cmf_region_letter VALUES("10000617","平城区","140213","10000049","3","P");
INSERT INTO cmf_region_letter VALUES("10000618","云冈区","140214","10000049","3","Y");
INSERT INTO cmf_region_letter VALUES("10000619","云州区","140215","10000049","3","Y");
INSERT INTO cmf_region_letter VALUES("10000620","阳高县","140221","10000049","3","Y");
INSERT INTO cmf_region_letter VALUES("10000621","天镇县","140222","10000049","3","T");
INSERT INTO cmf_region_letter VALUES("10000622","广灵县","140223","10000049","3","G");
INSERT INTO cmf_region_letter VALUES("10000623","灵丘县","140224","10000049","3","L");
INSERT INTO cmf_region_letter VALUES("10000624","浑源县","140225","10000049","3","H");
INSERT INTO cmf_region_letter VALUES("10000625","左云县","140226","10000049","3","Z");
INSERT INTO cmf_region_letter VALUES("10000626","城区","140302","10000050","3","C");
INSERT INTO cmf_region_letter VALUES("10000627","矿区","140303","10000050","3","K");
INSERT INTO cmf_region_letter VALUES("10000628","郊区","140311","10000050","3","J");
INSERT INTO cmf_region_letter VALUES("10000629","平定县","140321","10000050","3","P");
INSERT INTO cmf_region_letter VALUES("10000630","盂县","140322","10000050","3","Y");
INSERT INTO cmf_region_letter VALUES("10000631","潞州区","140403","10000051","3","L");
INSERT INTO cmf_region_letter VALUES("10000632","上党区","140404","10000051","3","S");
INSERT INTO cmf_region_letter VALUES("10000633","屯留区","140405","10000051","3","T");
INSERT INTO cmf_region_letter VALUES("10000634","潞城区","140406","10000051","3","L");
INSERT INTO cmf_region_letter VALUES("10000635","襄垣县","140423","10000051","3","X");
INSERT INTO cmf_region_letter VALUES("10000636","平顺县","140425","10000051","3","P");
INSERT INTO cmf_region_letter VALUES("10000637","黎城县","140426","10000051","3","L");
INSERT INTO cmf_region_letter VALUES("10000638","壶关县","140427","10000051","3","H");
INSERT INTO cmf_region_letter VALUES("10000639","长子县","140428","10000051","3","C");
INSERT INTO cmf_region_letter VALUES("10000640","武乡县","140429","10000051","3","W");
INSERT INTO cmf_region_letter VALUES("10000641","沁县","140430","10000051","3","Q");
INSERT INTO cmf_region_letter VALUES("10000642","沁源县","140431","10000051","3","Q");
INSERT INTO cmf_region_letter VALUES("10000643","城区","140502","10000052","3","C");
INSERT INTO cmf_region_letter VALUES("10000644","沁水县","140521","10000052","3","Q");
INSERT INTO cmf_region_letter VALUES("10000645","阳城县","140522","10000052","3","Y");
INSERT INTO cmf_region_letter VALUES("10000646","陵川县","140524","10000052","3","L");
INSERT INTO cmf_region_letter VALUES("10000647","泽州县","140525","10000052","3","Z");
INSERT INTO cmf_region_letter VALUES("10000648","高平市","140581","10000052","3","G");
INSERT INTO cmf_region_letter VALUES("10000649","朔城区","140602","10000053","3","S");
INSERT INTO cmf_region_letter VALUES("10000650","平鲁区","140603","10000053","3","P");
INSERT INTO cmf_region_letter VALUES("10000651","山阴县","140621","10000053","3","S");
INSERT INTO cmf_region_letter VALUES("10000652","应县","140622","10000053","3","Y");
INSERT INTO cmf_region_letter VALUES("10000653","右玉县","140623","10000053","3","Y");
INSERT INTO cmf_region_letter VALUES("10000654","怀仁市","140681","10000053","3","H");
INSERT INTO cmf_region_letter VALUES("10000655","榆次区","140702","10000054","3","Y");
INSERT INTO cmf_region_letter VALUES("10000656","榆社县","140721","10000054","3","Y");
INSERT INTO cmf_region_letter VALUES("10000657","左权县","140722","10000054","3","Z");
INSERT INTO cmf_region_letter VALUES("10000658","和顺县","140723","10000054","3","H");
INSERT INTO cmf_region_letter VALUES("10000659","昔阳县","140724","10000054","3","X");
INSERT INTO cmf_region_letter VALUES("10000660","寿阳县","140725","10000054","3","S");
INSERT INTO cmf_region_letter VALUES("10000661","太谷县","140726","10000054","3","T");
INSERT INTO cmf_region_letter VALUES("10000662","祁县","140727","10000054","3","Q");
INSERT INTO cmf_region_letter VALUES("10000663","平遥县","140728","10000054","3","P");
INSERT INTO cmf_region_letter VALUES("10000664","灵石县","140729","10000054","3","L");
INSERT INTO cmf_region_letter VALUES("10000665","介休市","140781","10000054","3","J");
INSERT INTO cmf_region_letter VALUES("10000666","盐湖区","140802","10000055","3","Y");
INSERT INTO cmf_region_letter VALUES("10000667","临猗县","140821","10000055","3","L");
INSERT INTO cmf_region_letter VALUES("10000668","万荣县","140822","10000055","3","W");
INSERT INTO cmf_region_letter VALUES("10000669","闻喜县","140823","10000055","3","W");
INSERT INTO cmf_region_letter VALUES("10000670","稷山县","140824","10000055","3","J");
INSERT INTO cmf_region_letter VALUES("10000671","新绛县","140825","10000055","3","X");
INSERT INTO cmf_region_letter VALUES("10000672","绛县","140826","10000055","3","J");
INSERT INTO cmf_region_letter VALUES("10000673","垣曲县","140827","10000055","3","Y");
INSERT INTO cmf_region_letter VALUES("10000674","夏县","140828","10000055","3","X");
INSERT INTO cmf_region_letter VALUES("10000675","平陆县","140829","10000055","3","P");
INSERT INTO cmf_region_letter VALUES("10000676","芮城县","140830","10000055","3","R");
INSERT INTO cmf_region_letter VALUES("10000677","永济市","140881","10000055","3","Y");
INSERT INTO cmf_region_letter VALUES("10000678","河津市","140882","10000055","3","H");
INSERT INTO cmf_region_letter VALUES("10000679","忻府区","140902","10000056","3","X");
INSERT INTO cmf_region_letter VALUES("10000680","定襄县","140921","10000056","3","D");
INSERT INTO cmf_region_letter VALUES("10000681","五台县","140922","10000056","3","W");
INSERT INTO cmf_region_letter VALUES("10000682","代县","140923","10000056","3","D");
INSERT INTO cmf_region_letter VALUES("10000683","繁峙县","140924","10000056","3","F");
INSERT INTO cmf_region_letter VALUES("10000684","宁武县","140925","10000056","3","N");
INSERT INTO cmf_region_letter VALUES("10000685","静乐县","140926","10000056","3","J");
INSERT INTO cmf_region_letter VALUES("10000686","神池县","140927","10000056","3","S");
INSERT INTO cmf_region_letter VALUES("10000687","五寨县","140928","10000056","3","W");
INSERT INTO cmf_region_letter VALUES("10000688","岢岚县","140929","10000056","3","K");
INSERT INTO cmf_region_letter VALUES("10000689","河曲县","140930","10000056","3","H");
INSERT INTO cmf_region_letter VALUES("10000690","保德县","140931","10000056","3","B");
INSERT INTO cmf_region_letter VALUES("10000691","偏关县","140932","10000056","3","P");
INSERT INTO cmf_region_letter VALUES("10000692","原平市","140981","10000056","3","Y");
INSERT INTO cmf_region_letter VALUES("10000693","尧都区","141002","10000057","3","Y");
INSERT INTO cmf_region_letter VALUES("10000694","曲沃县","141021","10000057","3","Q");
INSERT INTO cmf_region_letter VALUES("10000695","翼城县","141022","10000057","3","Y");
INSERT INTO cmf_region_letter VALUES("10000696","襄汾县","141023","10000057","3","X");
INSERT INTO cmf_region_letter VALUES("10000697","洪洞县","141024","10000057","3","H");
INSERT INTO cmf_region_letter VALUES("10000698","古县","141025","10000057","3","G");
INSERT INTO cmf_region_letter VALUES("10000699","安泽县","141026","10000057","3","A");
INSERT INTO cmf_region_letter VALUES("10000700","浮山县","141027","10000057","3","F");
INSERT INTO cmf_region_letter VALUES("10000701","吉县","141028","10000057","3","J");
INSERT INTO cmf_region_letter VALUES("10000702","乡宁县","141029","10000057","3","X");
INSERT INTO cmf_region_letter VALUES("10000703","大宁县","141030","10000057","3","D");
INSERT INTO cmf_region_letter VALUES("10000704","隰县","141031","10000057","3","X");
INSERT INTO cmf_region_letter VALUES("10000705","永和县","141032","10000057","3","Y");
INSERT INTO cmf_region_letter VALUES("10000706","蒲县","141033","10000057","3","P");
INSERT INTO cmf_region_letter VALUES("10000707","汾西县","141034","10000057","3","F");
INSERT INTO cmf_region_letter VALUES("10000708","侯马市","141081","10000057","3","H");
INSERT INTO cmf_region_letter VALUES("10000709","霍州市","141082","10000057","3","H");
INSERT INTO cmf_region_letter VALUES("10000710","离石区","141102","10000058","3","L");
INSERT INTO cmf_region_letter VALUES("10000711","文水县","141121","10000058","3","W");
INSERT INTO cmf_region_letter VALUES("10000712","交城县","141122","10000058","3","J");
INSERT INTO cmf_region_letter VALUES("10000713","兴县","141123","10000058","3","X");
INSERT INTO cmf_region_letter VALUES("10000714","临县","141124","10000058","3","L");
INSERT INTO cmf_region_letter VALUES("10000715","柳林县","141125","10000058","3","L");
INSERT INTO cmf_region_letter VALUES("10000716","石楼县","141126","10000058","3","S");
INSERT INTO cmf_region_letter VALUES("10000717","岚县","141127","10000058","3","L");
INSERT INTO cmf_region_letter VALUES("10000718","方山县","141128","10000058","3","F");
INSERT INTO cmf_region_letter VALUES("10000719","中阳县","141129","10000058","3","Z");
INSERT INTO cmf_region_letter VALUES("10000720","交口县","141130","10000058","3","J");
INSERT INTO cmf_region_letter VALUES("10000721","孝义市","141181","10000058","3","X");
INSERT INTO cmf_region_letter VALUES("10000722","汾阳市","141182","10000058","3","F");
INSERT INTO cmf_region_letter VALUES("10000723","新城区","150102","10000059","3","X");
INSERT INTO cmf_region_letter VALUES("10000724","回民区","150103","10000059","3","H");
INSERT INTO cmf_region_letter VALUES("10000725","玉泉区","150104","10000059","3","Y");
INSERT INTO cmf_region_letter VALUES("10000726","赛罕区","150105","10000059","3","S");
INSERT INTO cmf_region_letter VALUES("10000727","土默特左旗","150121","10000059","3","T");
INSERT INTO cmf_region_letter VALUES("10000728","托克托县","150122","10000059","3","T");
INSERT INTO cmf_region_letter VALUES("10000729","和林格尔县","150123","10000059","3","H");
INSERT INTO cmf_region_letter VALUES("10000730","清水河县","150124","10000059","3","Q");
INSERT INTO cmf_region_letter VALUES("10000731","武川县","150125","10000059","3","W");
INSERT INTO cmf_region_letter VALUES("10000732","东河区","150202","10000060","3","D");
INSERT INTO cmf_region_letter VALUES("10000733","昆都仑区","150203","10000060","3","K");
INSERT INTO cmf_region_letter VALUES("10000734","青山区","150204","10000060","3","Q");
INSERT INTO cmf_region_letter VALUES("10000735","石拐区","150205","10000060","3","S");
INSERT INTO cmf_region_letter VALUES("10000736","白云鄂博矿区","150206","10000060","3","B");
INSERT INTO cmf_region_letter VALUES("10000737","九原区","150207","10000060","3","J");
INSERT INTO cmf_region_letter VALUES("10000738","土默特右旗","150221","10000060","3","T");
INSERT INTO cmf_region_letter VALUES("10000739","固阳县","150222","10000060","3","G");
INSERT INTO cmf_region_letter VALUES("10000740","达尔罕茂明安联合旗","150223","10000060","3","D");
INSERT INTO cmf_region_letter VALUES("10000741","海勃湾区","150302","10000061","3","H");
INSERT INTO cmf_region_letter VALUES("10000742","海南区","150303","10000061","3","H");
INSERT INTO cmf_region_letter VALUES("10000743","乌达区","150304","10000061","3","W");
INSERT INTO cmf_region_letter VALUES("10000744","红山区","150402","10000062","3","H");
INSERT INTO cmf_region_letter VALUES("10000745","元宝山区","150403","10000062","3","Y");
INSERT INTO cmf_region_letter VALUES("10000746","松山区","150404","10000062","3","S");
INSERT INTO cmf_region_letter VALUES("10000747","阿鲁科尔沁旗","150421","10000062","3","A");
INSERT INTO cmf_region_letter VALUES("10000748","巴林左旗","150422","10000062","3","B");
INSERT INTO cmf_region_letter VALUES("10000749","巴林右旗","150423","10000062","3","B");
INSERT INTO cmf_region_letter VALUES("10000750","林西县","150424","10000062","3","L");
INSERT INTO cmf_region_letter VALUES("10000751","克什克腾旗","150425","10000062","3","K");
INSERT INTO cmf_region_letter VALUES("10000752","翁牛特旗","150426","10000062","3","W");
INSERT INTO cmf_region_letter VALUES("10000753","喀喇沁旗","150428","10000062","3","K");
INSERT INTO cmf_region_letter VALUES("10000754","宁城县","150429","10000062","3","N");
INSERT INTO cmf_region_letter VALUES("10000755","敖汉旗","150430","10000062","3","A");
INSERT INTO cmf_region_letter VALUES("10000756","科尔沁区","150502","10000063","3","K");
INSERT INTO cmf_region_letter VALUES("10000757","科尔沁左翼中旗","150521","10000063","3","K");
INSERT INTO cmf_region_letter VALUES("10000758","科尔沁左翼后旗","150522","10000063","3","K");
INSERT INTO cmf_region_letter VALUES("10000759","开鲁县","150523","10000063","3","K");
INSERT INTO cmf_region_letter VALUES("10000760","库伦旗","150524","10000063","3","K");
INSERT INTO cmf_region_letter VALUES("10000761","奈曼旗","150525","10000063","3","N");
INSERT INTO cmf_region_letter VALUES("10000762","扎鲁特旗","150526","10000063","3","Z");
INSERT INTO cmf_region_letter VALUES("10000763","霍林郭勒市","150581","10000063","3","H");
INSERT INTO cmf_region_letter VALUES("10000764","东胜区","150602","10000064","3","D");
INSERT INTO cmf_region_letter VALUES("10000765","康巴什区","150603","10000064","3","K");
INSERT INTO cmf_region_letter VALUES("10000766","达拉特旗","150621","10000064","3","D");
INSERT INTO cmf_region_letter VALUES("10000767","准格尔旗","150622","10000064","3","Z");
INSERT INTO cmf_region_letter VALUES("10000768","鄂托克前旗","150623","10000064","3","E");
INSERT INTO cmf_region_letter VALUES("10000769","鄂托克旗","150624","10000064","3","E");
INSERT INTO cmf_region_letter VALUES("10000770","杭锦旗","150625","10000064","3","H");
INSERT INTO cmf_region_letter VALUES("10000771","乌审旗","150626","10000064","3","W");
INSERT INTO cmf_region_letter VALUES("10000772","伊金霍洛旗","150627","10000064","3","Y");
INSERT INTO cmf_region_letter VALUES("10000773","海拉尔区","150702","10000065","3","H");
INSERT INTO cmf_region_letter VALUES("10000774","扎赉诺尔区","150703","10000065","3","Z");
INSERT INTO cmf_region_letter VALUES("10000775","阿荣旗","150721","10000065","3","A");
INSERT INTO cmf_region_letter VALUES("10000776","莫力达瓦达斡尔族自治旗","150722","10000065","3","M");
INSERT INTO cmf_region_letter VALUES("10000777","鄂伦春自治旗","150723","10000065","3","E");
INSERT INTO cmf_region_letter VALUES("10000778","鄂温克族自治旗","150724","10000065","3","E");
INSERT INTO cmf_region_letter VALUES("10000779","陈巴尔虎旗","150725","10000065","3","C");
INSERT INTO cmf_region_letter VALUES("10000780","新巴尔虎左旗","150726","10000065","3","X");
INSERT INTO cmf_region_letter VALUES("10000781","新巴尔虎右旗","150727","10000065","3","X");
INSERT INTO cmf_region_letter VALUES("10000782","满洲里市","150781","10000065","3","M");
INSERT INTO cmf_region_letter VALUES("10000783","牙克石市","150782","10000065","3","Y");
INSERT INTO cmf_region_letter VALUES("10000784","扎兰屯市","150783","10000065","3","Z");
INSERT INTO cmf_region_letter VALUES("10000785","额尔古纳市","150784","10000065","3","E");
INSERT INTO cmf_region_letter VALUES("10000786","根河市","150785","10000065","3","G");
INSERT INTO cmf_region_letter VALUES("10000787","临河区","150802","10000066","3","L");
INSERT INTO cmf_region_letter VALUES("10000788","五原县","150821","10000066","3","W");
INSERT INTO cmf_region_letter VALUES("10000789","磴口县","150822","10000066","3","D");
INSERT INTO cmf_region_letter VALUES("10000790","乌拉特前旗","150823","10000066","3","W");
INSERT INTO cmf_region_letter VALUES("10000791","乌拉特中旗","150824","10000066","3","W");
INSERT INTO cmf_region_letter VALUES("10000792","乌拉特后旗","150825","10000066","3","W");
INSERT INTO cmf_region_letter VALUES("10000793","杭锦后旗","150826","10000066","3","H");
INSERT INTO cmf_region_letter VALUES("10000794","集宁区","150902","10000067","3","J");
INSERT INTO cmf_region_letter VALUES("10000795","卓资县","150921","10000067","3","Z");
INSERT INTO cmf_region_letter VALUES("10000796","化德县","150922","10000067","3","H");
INSERT INTO cmf_region_letter VALUES("10000797","商都县","150923","10000067","3","S");
INSERT INTO cmf_region_letter VALUES("10000798","兴和县","150924","10000067","3","X");
INSERT INTO cmf_region_letter VALUES("10000799","凉城县","150925","10000067","3","L");
INSERT INTO cmf_region_letter VALUES("10000800","察哈尔右翼前旗","150926","10000067","3","C");
INSERT INTO cmf_region_letter VALUES("10000801","察哈尔右翼中旗","150927","10000067","3","C");
INSERT INTO cmf_region_letter VALUES("10000802","察哈尔右翼后旗","150928","10000067","3","C");
INSERT INTO cmf_region_letter VALUES("10000803","四子王旗","150929","10000067","3","S");
INSERT INTO cmf_region_letter VALUES("10000804","丰镇市","150981","10000067","3","F");
INSERT INTO cmf_region_letter VALUES("10000805","乌兰浩特市","152201","10000068","3","W");
INSERT INTO cmf_region_letter VALUES("10000806","阿尔山市","152202","10000068","3","A");
INSERT INTO cmf_region_letter VALUES("10000807","科尔沁右翼前旗","152221","10000068","3","K");
INSERT INTO cmf_region_letter VALUES("10000808","科尔沁右翼中旗","152222","10000068","3","K");
INSERT INTO cmf_region_letter VALUES("10000809","扎赉特旗","152223","10000068","3","Z");
INSERT INTO cmf_region_letter VALUES("10000810","突泉县","152224","10000068","3","T");
INSERT INTO cmf_region_letter VALUES("10000811","二连浩特市","152501","10000069","3","E");
INSERT INTO cmf_region_letter VALUES("10000812","锡林浩特市","152502","10000069","3","X");
INSERT INTO cmf_region_letter VALUES("10000813","阿巴嘎旗","152522","10000069","3","A");
INSERT INTO cmf_region_letter VALUES("10000814","苏尼特左旗","152523","10000069","3","S");
INSERT INTO cmf_region_letter VALUES("10000815","苏尼特右旗","152524","10000069","3","S");
INSERT INTO cmf_region_letter VALUES("10000816","东乌珠穆沁旗","152525","10000069","3","D");
INSERT INTO cmf_region_letter VALUES("10000817","西乌珠穆沁旗","152526","10000069","3","X");
INSERT INTO cmf_region_letter VALUES("10000818","太仆寺旗","152527","10000069","3","T");
INSERT INTO cmf_region_letter VALUES("10000819","镶黄旗","152528","10000069","3","X");
INSERT INTO cmf_region_letter VALUES("10000820","正镶白旗","152529","10000069","3","Z");
INSERT INTO cmf_region_letter VALUES("10000821","正蓝旗","152530","10000069","3","Z");
INSERT INTO cmf_region_letter VALUES("10000822","多伦县","152531","10000069","3","D");
INSERT INTO cmf_region_letter VALUES("10000823","阿拉善左旗","152921","10000070","3","A");
INSERT INTO cmf_region_letter VALUES("10000824","阿拉善右旗","152922","10000070","3","A");
INSERT INTO cmf_region_letter VALUES("10000825","额济纳旗","152923","10000070","3","E");
INSERT INTO cmf_region_letter VALUES("10000826","和平区","210102","10000071","3","H");
INSERT INTO cmf_region_letter VALUES("10000827","沈河区","210103","10000071","3","S");
INSERT INTO cmf_region_letter VALUES("10000828","大东区","210104","10000071","3","D");
INSERT INTO cmf_region_letter VALUES("10000829","皇姑区","210105","10000071","3","H");
INSERT INTO cmf_region_letter VALUES("10000830","铁西区","210106","10000071","3","T");
INSERT INTO cmf_region_letter VALUES("10000831","苏家屯区","210111","10000071","3","S");
INSERT INTO cmf_region_letter VALUES("10000832","浑南区","210112","10000071","3","H");
INSERT INTO cmf_region_letter VALUES("10000833","沈北新区","210113","10000071","3","S");
INSERT INTO cmf_region_letter VALUES("10000834","于洪区","210114","10000071","3","Y");
INSERT INTO cmf_region_letter VALUES("10000835","辽中区","210115","10000071","3","L");
INSERT INTO cmf_region_letter VALUES("10000836","康平县","210123","10000071","3","K");
INSERT INTO cmf_region_letter VALUES("10000837","法库县","210124","10000071","3","F");
INSERT INTO cmf_region_letter VALUES("10000838","新民市","210181","10000071","3","X");
INSERT INTO cmf_region_letter VALUES("10000839","经济技术开发区","210190","10000071","3","J");
INSERT INTO cmf_region_letter VALUES("10000840","中山区","210202","10000072","3","Z");
INSERT INTO cmf_region_letter VALUES("10000841","西岗区","210203","10000072","3","X");
INSERT INTO cmf_region_letter VALUES("10000842","沙河口区","210204","10000072","3","S");
INSERT INTO cmf_region_letter VALUES("10000843","甘井子区","210211","10000072","3","G");
INSERT INTO cmf_region_letter VALUES("10000844","旅顺口区","210212","10000072","3","L");
INSERT INTO cmf_region_letter VALUES("10000845","金州区","210213","10000072","3","J");
INSERT INTO cmf_region_letter VALUES("10000846","普兰店区","210214","10000072","3","P");
INSERT INTO cmf_region_letter VALUES("10000847","长海县","210224","10000072","3","C");
INSERT INTO cmf_region_letter VALUES("10000848","瓦房店市","210281","10000072","3","W");
INSERT INTO cmf_region_letter VALUES("10000849","庄河市","210283","10000072","3","Z");
INSERT INTO cmf_region_letter VALUES("10000850","铁东区","210302","10000073","3","T");
INSERT INTO cmf_region_letter VALUES("10000851","铁西区","210303","10000073","3","T");
INSERT INTO cmf_region_letter VALUES("10000852","立山区","210304","10000073","3","L");
INSERT INTO cmf_region_letter VALUES("10000853","千山区","210311","10000073","3","Q");
INSERT INTO cmf_region_letter VALUES("10000854","台安县","210321","10000073","3","T");
INSERT INTO cmf_region_letter VALUES("10000855","岫岩满族自治县","210323","10000073","3","X");
INSERT INTO cmf_region_letter VALUES("10000856","海城市","210381","10000073","3","H");
INSERT INTO cmf_region_letter VALUES("10000857","高新区","210390","10000073","3","G");
INSERT INTO cmf_region_letter VALUES("10000858","新抚区","210402","10000074","3","X");
INSERT INTO cmf_region_letter VALUES("10000859","东洲区","210403","10000074","3","D");
INSERT INTO cmf_region_letter VALUES("10000860","望花区","210404","10000074","3","W");
INSERT INTO cmf_region_letter VALUES("10000861","顺城区","210411","10000074","3","S");
INSERT INTO cmf_region_letter VALUES("10000862","抚顺县","210421","10000074","3","F");
INSERT INTO cmf_region_letter VALUES("10000863","新宾满族自治县","210422","10000074","3","X");
INSERT INTO cmf_region_letter VALUES("10000864","清原满族自治县","210423","10000074","3","Q");
INSERT INTO cmf_region_letter VALUES("10000865","平山区","210502","10000075","3","P");
INSERT INTO cmf_region_letter VALUES("10000866","溪湖区","210503","10000075","3","X");
INSERT INTO cmf_region_letter VALUES("10000867","明山区","210504","10000075","3","M");
INSERT INTO cmf_region_letter VALUES("10000868","南芬区","210505","10000075","3","N");
INSERT INTO cmf_region_letter VALUES("10000869","本溪满族自治县","210521","10000075","3","B");
INSERT INTO cmf_region_letter VALUES("10000870","桓仁满族自治县","210522","10000075","3","H");
INSERT INTO cmf_region_letter VALUES("10000871","元宝区","210602","10000076","3","Y");
INSERT INTO cmf_region_letter VALUES("10000872","振兴区","210603","10000076","3","Z");
INSERT INTO cmf_region_letter VALUES("10000873","振安区","210604","10000076","3","Z");
INSERT INTO cmf_region_letter VALUES("10000874","宽甸满族自治县","210624","10000076","3","K");
INSERT INTO cmf_region_letter VALUES("10000875","东港市","210681","10000076","3","D");
INSERT INTO cmf_region_letter VALUES("10000876","凤城市","210682","10000076","3","F");
INSERT INTO cmf_region_letter VALUES("10000877","古塔区","210702","10000077","3","G");
INSERT INTO cmf_region_letter VALUES("10000878","凌河区","210703","10000077","3","L");
INSERT INTO cmf_region_letter VALUES("10000879","太和区","210711","10000077","3","T");
INSERT INTO cmf_region_letter VALUES("10000880","黑山县","210726","10000077","3","H");
INSERT INTO cmf_region_letter VALUES("10000881","义县","210727","10000077","3","Y");
INSERT INTO cmf_region_letter VALUES("10000882","凌海市","210781","10000077","3","L");
INSERT INTO cmf_region_letter VALUES("10000883","北镇市","210782","10000077","3","B");
INSERT INTO cmf_region_letter VALUES("10000884","经济技术开发区","210793","10000077","3","J");
INSERT INTO cmf_region_letter VALUES("10000885","站前区","210802","10000078","3","Z");
INSERT INTO cmf_region_letter VALUES("10000886","西市区","210803","10000078","3","X");
INSERT INTO cmf_region_letter VALUES("10000887","鲅鱼圈区","210804","10000078","3","B");
INSERT INTO cmf_region_letter VALUES("10000888","老边区","210811","10000078","3","L");
INSERT INTO cmf_region_letter VALUES("10000889","盖州市","210881","10000078","3","G");
INSERT INTO cmf_region_letter VALUES("10000890","大石桥市","210882","10000078","3","D");
INSERT INTO cmf_region_letter VALUES("10000891","海州区","210902","10000079","3","H");
INSERT INTO cmf_region_letter VALUES("10000892","新邱区","210903","10000079","3","X");
INSERT INTO cmf_region_letter VALUES("10000893","太平区","210904","10000079","3","T");
INSERT INTO cmf_region_letter VALUES("10000894","清河门区","210905","10000079","3","Q");
INSERT INTO cmf_region_letter VALUES("10000895","细河区","210911","10000079","3","X");
INSERT INTO cmf_region_letter VALUES("10000896","阜新蒙古族自治县","210921","10000079","3","F");
INSERT INTO cmf_region_letter VALUES("10000897","彰武县","210922","10000079","3","Z");
INSERT INTO cmf_region_letter VALUES("10000898","白塔区","211002","10000080","3","B");
INSERT INTO cmf_region_letter VALUES("10000899","文圣区","211003","10000080","3","W");
INSERT INTO cmf_region_letter VALUES("10000900","宏伟区","211004","10000080","3","H");
INSERT INTO cmf_region_letter VALUES("10000901","弓长岭区","211005","10000080","3","G");
INSERT INTO cmf_region_letter VALUES("10000902","太子河区","211011","10000080","3","T");
INSERT INTO cmf_region_letter VALUES("10000903","辽阳县","211021","10000080","3","L");
INSERT INTO cmf_region_letter VALUES("10000904","灯塔市","211081","10000080","3","D");
INSERT INTO cmf_region_letter VALUES("10000905","双台子区","211102","10000081","3","S");
INSERT INTO cmf_region_letter VALUES("10000906","兴隆台区","211103","10000081","3","X");
INSERT INTO cmf_region_letter VALUES("10000907","大洼区","211104","10000081","3","D");
INSERT INTO cmf_region_letter VALUES("10000908","盘山县","211122","10000081","3","P");
INSERT INTO cmf_region_letter VALUES("10000909","银州区","211202","10000082","3","Y");
INSERT INTO cmf_region_letter VALUES("10000910","清河区","211204","10000082","3","Q");
INSERT INTO cmf_region_letter VALUES("10000911","铁岭县","211221","10000082","3","T");
INSERT INTO cmf_region_letter VALUES("10000912","西丰县","211223","10000082","3","X");
INSERT INTO cmf_region_letter VALUES("10000913","昌图县","211224","10000082","3","C");
INSERT INTO cmf_region_letter VALUES("10000914","调兵山市","211281","10000082","3","D");
INSERT INTO cmf_region_letter VALUES("10000915","开原市","211282","10000082","3","K");
INSERT INTO cmf_region_letter VALUES("10000916","双塔区","211302","10000083","3","S");
INSERT INTO cmf_region_letter VALUES("10000917","龙城区","211303","10000083","3","L");
INSERT INTO cmf_region_letter VALUES("10000918","朝阳县","211321","10000083","3","Z");
INSERT INTO cmf_region_letter VALUES("10000919","建平县","211322","10000083","3","J");
INSERT INTO cmf_region_letter VALUES("10000920","喀喇沁左翼蒙古族自治县","211324","10000083","3","K");
INSERT INTO cmf_region_letter VALUES("10000921","北票市","211381","10000083","3","B");
INSERT INTO cmf_region_letter VALUES("10000922","凌源市","211382","10000083","3","L");
INSERT INTO cmf_region_letter VALUES("10000923","连山区","211402","10000084","3","L");
INSERT INTO cmf_region_letter VALUES("10000924","龙港区","211403","10000084","3","L");
INSERT INTO cmf_region_letter VALUES("10000925","南票区","211404","10000084","3","N");
INSERT INTO cmf_region_letter VALUES("10000926","绥中县","211421","10000084","3","S");
INSERT INTO cmf_region_letter VALUES("10000927","建昌县","211422","10000084","3","J");
INSERT INTO cmf_region_letter VALUES("10000928","兴城市","211481","10000084","3","X");
INSERT INTO cmf_region_letter VALUES("10000929","南关区","220102","10000085","3","N");
INSERT INTO cmf_region_letter VALUES("10000930","宽城区","220103","10000085","3","K");
INSERT INTO cmf_region_letter VALUES("10000931","朝阳区","220104","10000085","3","C");
INSERT INTO cmf_region_letter VALUES("10000932","二道区","220105","10000085","3","E");
INSERT INTO cmf_region_letter VALUES("10000933","绿园区","220106","10000085","3","L");
INSERT INTO cmf_region_letter VALUES("10000934","双阳区","220112","10000085","3","S");
INSERT INTO cmf_region_letter VALUES("10000935","九台区","220113","10000085","3","J");
INSERT INTO cmf_region_letter VALUES("10000936","农安县","220122","10000085","3","N");
INSERT INTO cmf_region_letter VALUES("10000937","榆树市","220182","10000085","3","Y");
INSERT INTO cmf_region_letter VALUES("10000938","德惠市","220183","10000085","3","D");
INSERT INTO cmf_region_letter VALUES("10000939","经济技术开发区","220192","10000085","3","J");
INSERT INTO cmf_region_letter VALUES("10000940","昌邑区","220202","10000086","3","C");
INSERT INTO cmf_region_letter VALUES("10000941","龙潭区","220203","10000086","3","L");
INSERT INTO cmf_region_letter VALUES("10000942","船营区","220204","10000086","3","C");
INSERT INTO cmf_region_letter VALUES("10000943","丰满区","220211","10000086","3","F");
INSERT INTO cmf_region_letter VALUES("10000944","永吉县","220221","10000086","3","Y");
INSERT INTO cmf_region_letter VALUES("10000945","蛟河市","220281","10000086","3","J");
INSERT INTO cmf_region_letter VALUES("10000946","桦甸市","220282","10000086","3","H");
INSERT INTO cmf_region_letter VALUES("10000947","舒兰市","220283","10000086","3","S");
INSERT INTO cmf_region_letter VALUES("10000948","磐石市","220284","10000086","3","P");
INSERT INTO cmf_region_letter VALUES("10000949","铁西区","220302","10000087","3","T");
INSERT INTO cmf_region_letter VALUES("10000950","铁东区","220303","10000087","3","T");
INSERT INTO cmf_region_letter VALUES("10000951","梨树县","220322","10000087","3","L");
INSERT INTO cmf_region_letter VALUES("10000952","伊通满族自治县","220323","10000087","3","Y");
INSERT INTO cmf_region_letter VALUES("10000953","公主岭市","220381","10000087","3","G");
INSERT INTO cmf_region_letter VALUES("10000954","双辽市","220382","10000087","3","S");
INSERT INTO cmf_region_letter VALUES("10000955","龙山区","220402","10000088","3","L");
INSERT INTO cmf_region_letter VALUES("10000956","西安区","220403","10000088","3","X");
INSERT INTO cmf_region_letter VALUES("10000957","东丰县","220421","10000088","3","D");
INSERT INTO cmf_region_letter VALUES("10000958","东辽县","220422","10000088","3","D");
INSERT INTO cmf_region_letter VALUES("10000959","东昌区","220502","10000089","3","D");
INSERT INTO cmf_region_letter VALUES("10000960","二道江区","220503","10000089","3","E");
INSERT INTO cmf_region_letter VALUES("10000961","通化县","220521","10000089","3","T");
INSERT INTO cmf_region_letter VALUES("10000962","辉南县","220523","10000089","3","H");
INSERT INTO cmf_region_letter VALUES("10000963","柳河县","220524","10000089","3","L");
INSERT INTO cmf_region_letter VALUES("10000964","梅河口市","220581","10000089","3","M");
INSERT INTO cmf_region_letter VALUES("10000965","集安市","220582","10000089","3","J");
INSERT INTO cmf_region_letter VALUES("10000966","浑江区","220602","10000090","3","H");
INSERT INTO cmf_region_letter VALUES("10000967","江源区","220605","10000090","3","J");
INSERT INTO cmf_region_letter VALUES("10000968","抚松县","220621","10000090","3","F");
INSERT INTO cmf_region_letter VALUES("10000969","靖宇县","220622","10000090","3","J");
INSERT INTO cmf_region_letter VALUES("10000970","长白朝鲜族自治县","220623","10000090","3","C");
INSERT INTO cmf_region_letter VALUES("10000971","临江市","220681","10000090","3","L");
INSERT INTO cmf_region_letter VALUES("10000972","宁江区","220702","10000091","3","N");
INSERT INTO cmf_region_letter VALUES("10000973","前郭尔罗斯蒙古族自治县","220721","10000091","3","Q");
INSERT INTO cmf_region_letter VALUES("10000974","长岭县","220722","10000091","3","C");
INSERT INTO cmf_region_letter VALUES("10000975","乾安县","220723","10000091","3","Q");
INSERT INTO cmf_region_letter VALUES("10000976","扶余市","220781","10000091","3","F");
INSERT INTO cmf_region_letter VALUES("10000977","洮北区","220802","10000092","3","T");
INSERT INTO cmf_region_letter VALUES("10000978","镇赉县","220821","10000092","3","Z");
INSERT INTO cmf_region_letter VALUES("10000979","通榆县","220822","10000092","3","T");
INSERT INTO cmf_region_letter VALUES("10000980","洮南市","220881","10000092","3","T");
INSERT INTO cmf_region_letter VALUES("10000981","大安市","220882","10000092","3","D");
INSERT INTO cmf_region_letter VALUES("10000982","延吉市","222401","10000093","3","Y");
INSERT INTO cmf_region_letter VALUES("10000983","图们市","222402","10000093","3","T");
INSERT INTO cmf_region_letter VALUES("10000984","敦化市","222403","10000093","3","D");
INSERT INTO cmf_region_letter VALUES("10000985","珲春市","222404","10000093","3","H");
INSERT INTO cmf_region_letter VALUES("10000986","龙井市","222405","10000093","3","L");
INSERT INTO cmf_region_letter VALUES("10000987","和龙市","222406","10000093","3","H");
INSERT INTO cmf_region_letter VALUES("10000988","汪清县","222424","10000093","3","W");
INSERT INTO cmf_region_letter VALUES("10000989","安图县","222426","10000093","3","A");
INSERT INTO cmf_region_letter VALUES("10000990","道里区","230102","10000094","3","D");
INSERT INTO cmf_region_letter VALUES("10000991","南岗区","230103","10000094","3","N");
INSERT INTO cmf_region_letter VALUES("10000992","道外区","230104","10000094","3","D");
INSERT INTO cmf_region_letter VALUES("10000993","平房区","230108","10000094","3","P");
INSERT INTO cmf_region_letter VALUES("10000994","松北区","230109","10000094","3","S");
INSERT INTO cmf_region_letter VALUES("10000995","香坊区","230110","10000094","3","X");
INSERT INTO cmf_region_letter VALUES("10000996","呼兰区","230111","10000094","3","H");
INSERT INTO cmf_region_letter VALUES("10000997","阿城区","230112","10000094","3","A");
INSERT INTO cmf_region_letter VALUES("10000998","双城区","230113","10000094","3","S");
INSERT INTO cmf_region_letter VALUES("10000999","依兰县","230123","10000094","3","Y");
INSERT INTO cmf_region_letter VALUES("10001000","方正县","230124","10000094","3","F");
INSERT INTO cmf_region_letter VALUES("10001001","宾县","230125","10000094","3","B");
INSERT INTO cmf_region_letter VALUES("10001002","巴彦县","230126","10000094","3","B");
INSERT INTO cmf_region_letter VALUES("10001003","木兰县","230127","10000094","3","M");
INSERT INTO cmf_region_letter VALUES("10001004","通河县","230128","10000094","3","T");
INSERT INTO cmf_region_letter VALUES("10001005","延寿县","230129","10000094","3","Y");
INSERT INTO cmf_region_letter VALUES("10001006","尚志市","230183","10000094","3","S");
INSERT INTO cmf_region_letter VALUES("10001007","五常市","230184","10000094","3","W");
INSERT INTO cmf_region_letter VALUES("10001008","龙沙区","230202","10000095","3","L");
INSERT INTO cmf_region_letter VALUES("10001009","建华区","230203","10000095","3","J");
INSERT INTO cmf_region_letter VALUES("10001010","铁锋区","230204","10000095","3","T");
INSERT INTO cmf_region_letter VALUES("10001011","昂昂溪区","230205","10000095","3","A");
INSERT INTO cmf_region_letter VALUES("10001012","富拉尔基区","230206","10000095","3","F");
INSERT INTO cmf_region_letter VALUES("10001013","碾子山区","230207","10000095","3","N");
INSERT INTO cmf_region_letter VALUES("10001014","梅里斯达斡尔族区","230208","10000095","3","M");
INSERT INTO cmf_region_letter VALUES("10001015","龙江县","230221","10000095","3","L");
INSERT INTO cmf_region_letter VALUES("10001016","依安县","230223","10000095","3","Y");
INSERT INTO cmf_region_letter VALUES("10001017","泰来县","230224","10000095","3","T");
INSERT INTO cmf_region_letter VALUES("10001018","甘南县","230225","10000095","3","G");
INSERT INTO cmf_region_letter VALUES("10001019","富裕县","230227","10000095","3","F");
INSERT INTO cmf_region_letter VALUES("10001020","克山县","230229","10000095","3","K");
INSERT INTO cmf_region_letter VALUES("10001021","克东县","230230","10000095","3","K");
INSERT INTO cmf_region_letter VALUES("10001022","拜泉县","230231","10000095","3","B");
INSERT INTO cmf_region_letter VALUES("10001023","讷河市","230281","10000095","3","N");
INSERT INTO cmf_region_letter VALUES("10001024","鸡冠区","230302","10000096","3","J");
INSERT INTO cmf_region_letter VALUES("10001025","恒山区","230303","10000096","3","H");
INSERT INTO cmf_region_letter VALUES("10001026","滴道区","230304","10000096","3","D");
INSERT INTO cmf_region_letter VALUES("10001027","梨树区","230305","10000096","3","L");
INSERT INTO cmf_region_letter VALUES("10001028","城子河区","230306","10000096","3","C");
INSERT INTO cmf_region_letter VALUES("10001029","麻山区","230307","10000096","3","M");
INSERT INTO cmf_region_letter VALUES("10001030","鸡东县","230321","10000096","3","J");
INSERT INTO cmf_region_letter VALUES("10001031","虎林市","230381","10000096","3","H");
INSERT INTO cmf_region_letter VALUES("10001032","密山市","230382","10000096","3","M");
INSERT INTO cmf_region_letter VALUES("10001033","向阳区","230402","10000097","3","X");
INSERT INTO cmf_region_letter VALUES("10001034","工农区","230403","10000097","3","G");
INSERT INTO cmf_region_letter VALUES("10001035","南山区","230404","10000097","3","N");
INSERT INTO cmf_region_letter VALUES("10001036","兴安区","230405","10000097","3","X");
INSERT INTO cmf_region_letter VALUES("10001037","东山区","230406","10000097","3","D");
INSERT INTO cmf_region_letter VALUES("10001038","兴山区","230407","10000097","3","X");
INSERT INTO cmf_region_letter VALUES("10001039","萝北县","230421","10000097","3","L");
INSERT INTO cmf_region_letter VALUES("10001040","绥滨县","230422","10000097","3","S");
INSERT INTO cmf_region_letter VALUES("10001041","尖山区","230502","10000098","3","J");
INSERT INTO cmf_region_letter VALUES("10001042","岭东区","230503","10000098","3","L");
INSERT INTO cmf_region_letter VALUES("10001043","四方台区","230505","10000098","3","S");
INSERT INTO cmf_region_letter VALUES("10001044","宝山区","230506","10000098","3","B");
INSERT INTO cmf_region_letter VALUES("10001045","集贤县","230521","10000098","3","J");
INSERT INTO cmf_region_letter VALUES("10001046","友谊县","230522","10000098","3","Y");
INSERT INTO cmf_region_letter VALUES("10001047","宝清县","230523","10000098","3","B");
INSERT INTO cmf_region_letter VALUES("10001048","饶河县","230524","10000098","3","R");
INSERT INTO cmf_region_letter VALUES("10001049","萨尔图区","230602","10000099","3","S");
INSERT INTO cmf_region_letter VALUES("10001050","龙凤区","230603","10000099","3","L");
INSERT INTO cmf_region_letter VALUES("10001051","让胡路区","230604","10000099","3","R");
INSERT INTO cmf_region_letter VALUES("10001052","红岗区","230605","10000099","3","H");
INSERT INTO cmf_region_letter VALUES("10001053","大同区","230606","10000099","3","D");
INSERT INTO cmf_region_letter VALUES("10001054","肇州县","230621","10000099","3","Z");
INSERT INTO cmf_region_letter VALUES("10001055","肇源县","230622","10000099","3","Z");
INSERT INTO cmf_region_letter VALUES("10001056","林甸县","230623","10000099","3","L");
INSERT INTO cmf_region_letter VALUES("10001057","杜尔伯特蒙古族自治县","230624","10000099","3","D");
INSERT INTO cmf_region_letter VALUES("10001058","伊春区","230702","10000100","3","Y");
INSERT INTO cmf_region_letter VALUES("10001059","南岔区","230703","10000100","3","N");
INSERT INTO cmf_region_letter VALUES("10001060","友好区","230704","10000100","3","Y");
INSERT INTO cmf_region_letter VALUES("10001061","西林区","230705","10000100","3","X");
INSERT INTO cmf_region_letter VALUES("10001062","翠峦区","230706","10000100","3","C");
INSERT INTO cmf_region_letter VALUES("10001063","新青区","230707","10000100","3","X");
INSERT INTO cmf_region_letter VALUES("10001064","美溪区","230708","10000100","3","M");
INSERT INTO cmf_region_letter VALUES("10001065","金山屯区","230709","10000100","3","J");
INSERT INTO cmf_region_letter VALUES("10001066","五营区","230710","10000100","3","W");
INSERT INTO cmf_region_letter VALUES("10001067","乌马河区","230711","10000100","3","W");
INSERT INTO cmf_region_letter VALUES("10001068","汤旺河区","230712","10000100","3","T");
INSERT INTO cmf_region_letter VALUES("10001069","带岭区","230713","10000100","3","D");
INSERT INTO cmf_region_letter VALUES("10001070","乌伊岭区","230714","10000100","3","W");
INSERT INTO cmf_region_letter VALUES("10001071","红星区","230715","10000100","3","H");
INSERT INTO cmf_region_letter VALUES("10001072","上甘岭区","230716","10000100","3","S");
INSERT INTO cmf_region_letter VALUES("10001073","嘉荫县","230722","10000100","3","J");
INSERT INTO cmf_region_letter VALUES("10001074","铁力市","230781","10000100","3","T");
INSERT INTO cmf_region_letter VALUES("10001075","向阳区","230803","10000101","3","X");
INSERT INTO cmf_region_letter VALUES("10001076","前进区","230804","10000101","3","Q");
INSERT INTO cmf_region_letter VALUES("10001077","东风区","230805","10000101","3","D");
INSERT INTO cmf_region_letter VALUES("10001078","郊区","230811","10000101","3","J");
INSERT INTO cmf_region_letter VALUES("10001079","桦南县","230822","10000101","3","H");
INSERT INTO cmf_region_letter VALUES("10001080","桦川县","230826","10000101","3","H");
INSERT INTO cmf_region_letter VALUES("10001081","汤原县","230828","10000101","3","T");
INSERT INTO cmf_region_letter VALUES("10001082","同江市","230881","10000101","3","T");
INSERT INTO cmf_region_letter VALUES("10001083","富锦市","230882","10000101","3","F");
INSERT INTO cmf_region_letter VALUES("10001084","抚远市","230883","10000101","3","F");
INSERT INTO cmf_region_letter VALUES("10001085","新兴区","230902","10000102","3","X");
INSERT INTO cmf_region_letter VALUES("10001086","桃山区","230903","10000102","3","T");
INSERT INTO cmf_region_letter VALUES("10001087","茄子河区","230904","10000102","3","Q");
INSERT INTO cmf_region_letter VALUES("10001088","勃利县","230921","10000102","3","B");
INSERT INTO cmf_region_letter VALUES("10001089","东安区","231002","10000103","3","D");
INSERT INTO cmf_region_letter VALUES("10001090","阳明区","231003","10000103","3","Y");
INSERT INTO cmf_region_letter VALUES("10001091","爱民区","231004","10000103","3","A");
INSERT INTO cmf_region_letter VALUES("10001092","西安区","231005","10000103","3","X");
INSERT INTO cmf_region_letter VALUES("10001093","林口县","231025","10000103","3","L");
INSERT INTO cmf_region_letter VALUES("10001094","绥芬河市","231081","10000103","3","S");
INSERT INTO cmf_region_letter VALUES("10001095","海林市","231083","10000103","3","H");
INSERT INTO cmf_region_letter VALUES("10001096","宁安市","231084","10000103","3","N");
INSERT INTO cmf_region_letter VALUES("10001097","穆棱市","231085","10000103","3","M");
INSERT INTO cmf_region_letter VALUES("10001098","东宁市","231086","10000103","3","D");
INSERT INTO cmf_region_letter VALUES("10001099","爱辉区","231102","10000104","3","A");
INSERT INTO cmf_region_letter VALUES("10001100","嫩江县","231121","10000104","3","N");
INSERT INTO cmf_region_letter VALUES("10001101","逊克县","231123","10000104","3","X");
INSERT INTO cmf_region_letter VALUES("10001102","孙吴县","231124","10000104","3","S");
INSERT INTO cmf_region_letter VALUES("10001103","北安市","231181","10000104","3","B");
INSERT INTO cmf_region_letter VALUES("10001104","五大连池市","231182","10000104","3","W");
INSERT INTO cmf_region_letter VALUES("10001105","北林区","231202","10000105","3","B");
INSERT INTO cmf_region_letter VALUES("10001106","望奎县","231221","10000105","3","W");
INSERT INTO cmf_region_letter VALUES("10001107","兰西县","231222","10000105","3","L");
INSERT INTO cmf_region_letter VALUES("10001108","青冈县","231223","10000105","3","Q");
INSERT INTO cmf_region_letter VALUES("10001109","庆安县","231224","10000105","3","Q");
INSERT INTO cmf_region_letter VALUES("10001110","明水县","231225","10000105","3","M");
INSERT INTO cmf_region_letter VALUES("10001111","绥棱县","231226","10000105","3","S");
INSERT INTO cmf_region_letter VALUES("10001112","安达市","231281","10000105","3","A");
INSERT INTO cmf_region_letter VALUES("10001113","肇东市","231282","10000105","3","Z");
INSERT INTO cmf_region_letter VALUES("10001114","海伦市","231283","10000105","3","H");
INSERT INTO cmf_region_letter VALUES("10001115","漠河市","232701","10000106","3","M");
INSERT INTO cmf_region_letter VALUES("10001116","呼玛县","232721","10000106","3","H");
INSERT INTO cmf_region_letter VALUES("10001117","塔河县","232722","10000106","3","T");
INSERT INTO cmf_region_letter VALUES("10001118","松岭区","232790","10000106","3","S");
INSERT INTO cmf_region_letter VALUES("10001119","呼中区","232791","10000106","3","H");
INSERT INTO cmf_region_letter VALUES("10001120","加格达奇区","232792","10000106","3","J");
INSERT INTO cmf_region_letter VALUES("10001121","新林区","232793","10000106","3","X");
INSERT INTO cmf_region_letter VALUES("10001122","黄浦区","310101","10000107","3","H");
INSERT INTO cmf_region_letter VALUES("10001123","徐汇区","310104","10000107","3","X");
INSERT INTO cmf_region_letter VALUES("10001124","长宁区","310105","10000107","3","C");
INSERT INTO cmf_region_letter VALUES("10001125","静安区","310106","10000107","3","J");
INSERT INTO cmf_region_letter VALUES("10001126","普陀区","310107","10000107","3","P");
INSERT INTO cmf_region_letter VALUES("10001127","虹口区","310109","10000107","3","H");
INSERT INTO cmf_region_letter VALUES("10001128","杨浦区","310110","10000107","3","Y");
INSERT INTO cmf_region_letter VALUES("10001129","闵行区","310112","10000107","3","M");
INSERT INTO cmf_region_letter VALUES("10001130","宝山区","310113","10000107","3","B");
INSERT INTO cmf_region_letter VALUES("10001131","嘉定区","310114","10000107","3","J");
INSERT INTO cmf_region_letter VALUES("10001132","浦东新区","310115","10000107","3","P");
INSERT INTO cmf_region_letter VALUES("10001133","金山区","310116","10000107","3","J");
INSERT INTO cmf_region_letter VALUES("10001134","松江区","310117","10000107","3","S");
INSERT INTO cmf_region_letter VALUES("10001135","青浦区","310118","10000107","3","Q");
INSERT INTO cmf_region_letter VALUES("10001136","奉贤区","310120","10000107","3","F");
INSERT INTO cmf_region_letter VALUES("10001137","崇明区","310151","10000107","3","C");
INSERT INTO cmf_region_letter VALUES("10001138","玄武区","320102","10000108","3","X");
INSERT INTO cmf_region_letter VALUES("10001139","秦淮区","320104","10000108","3","Q");
INSERT INTO cmf_region_letter VALUES("10001140","建邺区","320105","10000108","3","J");
INSERT INTO cmf_region_letter VALUES("10001141","鼓楼区","320106","10000108","3","G");
INSERT INTO cmf_region_letter VALUES("10001142","浦口区","320111","10000108","3","P");
INSERT INTO cmf_region_letter VALUES("10001143","栖霞区","320113","10000108","3","Q");
INSERT INTO cmf_region_letter VALUES("10001144","雨花台区","320114","10000108","3","Y");
INSERT INTO cmf_region_letter VALUES("10001145","江宁区","320115","10000108","3","J");
INSERT INTO cmf_region_letter VALUES("10001146","六合区","320116","10000108","3","L");
INSERT INTO cmf_region_letter VALUES("10001147","溧水区","320117","10000108","3","L");
INSERT INTO cmf_region_letter VALUES("10001148","高淳区","320118","10000108","3","G");
INSERT INTO cmf_region_letter VALUES("10001149","锡山区","320205","10000109","3","X");
INSERT INTO cmf_region_letter VALUES("10001150","惠山区","320206","10000109","3","H");
INSERT INTO cmf_region_letter VALUES("10001151","滨湖区","320211","10000109","3","B");
INSERT INTO cmf_region_letter VALUES("10001152","梁溪区","320213","10000109","3","L");
INSERT INTO cmf_region_letter VALUES("10001153","新吴区","320214","10000109","3","X");
INSERT INTO cmf_region_letter VALUES("10001154","江阴市","320281","10000109","3","J");
INSERT INTO cmf_region_letter VALUES("10001155","宜兴市","320282","10000109","3","Y");
INSERT INTO cmf_region_letter VALUES("10001156","鼓楼区","320302","10000110","3","G");
INSERT INTO cmf_region_letter VALUES("10001157","云龙区","320303","10000110","3","Y");
INSERT INTO cmf_region_letter VALUES("10001158","贾汪区","320305","10000110","3","J");
INSERT INTO cmf_region_letter VALUES("10001159","泉山区","320311","10000110","3","Q");
INSERT INTO cmf_region_letter VALUES("10001160","铜山区","320312","10000110","3","T");
INSERT INTO cmf_region_letter VALUES("10001161","丰县","320321","10000110","3","F");
INSERT INTO cmf_region_letter VALUES("10001162","沛县","320322","10000110","3","P");
INSERT INTO cmf_region_letter VALUES("10001163","睢宁县","320324","10000110","3","S");
INSERT INTO cmf_region_letter VALUES("10001164","新沂市","320381","10000110","3","X");
INSERT INTO cmf_region_letter VALUES("10001165","邳州市","320382","10000110","3","P");
INSERT INTO cmf_region_letter VALUES("10001166","工业园区","320391","10000110","3","G");
INSERT INTO cmf_region_letter VALUES("10001167","天宁区","320402","10000111","3","T");
INSERT INTO cmf_region_letter VALUES("10001168","钟楼区","320404","10000111","3","Z");
INSERT INTO cmf_region_letter VALUES("10001169","新北区","320411","10000111","3","X");
INSERT INTO cmf_region_letter VALUES("10001170","武进区","320412","10000111","3","W");
INSERT INTO cmf_region_letter VALUES("10001171","金坛区","320413","10000111","3","J");
INSERT INTO cmf_region_letter VALUES("10001172","溧阳市","320481","10000111","3","L");
INSERT INTO cmf_region_letter VALUES("10001173","虎丘区","320505","10000112","3","H");
INSERT INTO cmf_region_letter VALUES("10001174","吴中区","320506","10000112","3","W");
INSERT INTO cmf_region_letter VALUES("10001175","相城区","320507","10000112","3","X");
INSERT INTO cmf_region_letter VALUES("10001176","姑苏区","320508","10000112","3","G");
INSERT INTO cmf_region_letter VALUES("10001177","吴江区","320509","10000112","3","W");
INSERT INTO cmf_region_letter VALUES("10001178","常熟市","320581","10000112","3","C");
INSERT INTO cmf_region_letter VALUES("10001179","张家港市","320582","10000112","3","Z");
INSERT INTO cmf_region_letter VALUES("10001180","昆山市","320583","10000112","3","K");
INSERT INTO cmf_region_letter VALUES("10001181","太仓市","320585","10000112","3","T");
INSERT INTO cmf_region_letter VALUES("10001182","工业园区","320590","10000112","3","G");
INSERT INTO cmf_region_letter VALUES("10001183","高新区","320591","10000112","3","G");
INSERT INTO cmf_region_letter VALUES("10001184","崇川区","320602","10000113","3","C");
INSERT INTO cmf_region_letter VALUES("10001185","港闸区","320611","10000113","3","G");
INSERT INTO cmf_region_letter VALUES("10001186","通州区","320612","10000113","3","T");
INSERT INTO cmf_region_letter VALUES("10001187","如东县","320623","10000113","3","R");
INSERT INTO cmf_region_letter VALUES("10001188","启东市","320681","10000113","3","Q");
INSERT INTO cmf_region_letter VALUES("10001189","如皋市","320682","10000113","3","R");
INSERT INTO cmf_region_letter VALUES("10001190","海门市","320684","10000113","3","H");
INSERT INTO cmf_region_letter VALUES("10001191","海安市","320685","10000113","3","H");
INSERT INTO cmf_region_letter VALUES("10001192","高新区","320691","10000113","3","G");
INSERT INTO cmf_region_letter VALUES("10001193","连云区","320703","10000114","3","L");
INSERT INTO cmf_region_letter VALUES("10001194","海州区","320706","10000114","3","H");
INSERT INTO cmf_region_letter VALUES("10001195","赣榆区","320707","10000114","3","G");
INSERT INTO cmf_region_letter VALUES("10001196","东海县","320722","10000114","3","D");
INSERT INTO cmf_region_letter VALUES("10001197","灌云县","320723","10000114","3","G");
INSERT INTO cmf_region_letter VALUES("10001198","灌南县","320724","10000114","3","G");
INSERT INTO cmf_region_letter VALUES("10001199","淮安区","320803","10000115","3","H");
INSERT INTO cmf_region_letter VALUES("10001200","淮阴区","320804","10000115","3","H");
INSERT INTO cmf_region_letter VALUES("10001201","清江浦区","320812","10000115","3","Q");
INSERT INTO cmf_region_letter VALUES("10001202","洪泽区","320813","10000115","3","H");
INSERT INTO cmf_region_letter VALUES("10001203","涟水县","320826","10000115","3","L");
INSERT INTO cmf_region_letter VALUES("10001204","盱眙县","320830","10000115","3","X");
INSERT INTO cmf_region_letter VALUES("10001205","金湖县","320831","10000115","3","J");
INSERT INTO cmf_region_letter VALUES("10001206","经济开发区","320890","10000115","3","J");
INSERT INTO cmf_region_letter VALUES("10001207","亭湖区","320902","10000116","3","T");
INSERT INTO cmf_region_letter VALUES("10001208","盐都区","320903","10000116","3","Y");
INSERT INTO cmf_region_letter VALUES("10001209","大丰区","320904","10000116","3","D");
INSERT INTO cmf_region_letter VALUES("10001210","响水县","320921","10000116","3","X");
INSERT INTO cmf_region_letter VALUES("10001211","滨海县","320922","10000116","3","B");
INSERT INTO cmf_region_letter VALUES("10001212","阜宁县","320923","10000116","3","F");
INSERT INTO cmf_region_letter VALUES("10001213","射阳县","320924","10000116","3","S");
INSERT INTO cmf_region_letter VALUES("10001214","建湖县","320925","10000116","3","J");
INSERT INTO cmf_region_letter VALUES("10001215","东台市","320981","10000116","3","D");
INSERT INTO cmf_region_letter VALUES("10001216","广陵区","321002","10000117","3","G");
INSERT INTO cmf_region_letter VALUES("10001217","邗江区","321003","10000117","3","H");
INSERT INTO cmf_region_letter VALUES("10001218","江都区","321012","10000117","3","J");
INSERT INTO cmf_region_letter VALUES("10001219","宝应县","321023","10000117","3","B");
INSERT INTO cmf_region_letter VALUES("10001220","仪征市","321081","10000117","3","Y");
INSERT INTO cmf_region_letter VALUES("10001221","高邮市","321084","10000117","3","G");
INSERT INTO cmf_region_letter VALUES("10001222","经济开发区","321090","10000117","3","J");
INSERT INTO cmf_region_letter VALUES("10001223","京口区","321102","10000118","3","J");
INSERT INTO cmf_region_letter VALUES("10001224","润州区","321111","10000118","3","R");
INSERT INTO cmf_region_letter VALUES("10001225","丹徒区","321112","10000118","3","D");
INSERT INTO cmf_region_letter VALUES("10001226","丹阳市","321181","10000118","3","D");
INSERT INTO cmf_region_letter VALUES("10001227","扬中市","321182","10000118","3","Y");
INSERT INTO cmf_region_letter VALUES("10001228","句容市","321183","10000118","3","J");
INSERT INTO cmf_region_letter VALUES("10001229","海陵区","321202","10000119","3","H");
INSERT INTO cmf_region_letter VALUES("10001230","高港区","321203","10000119","3","G");
INSERT INTO cmf_region_letter VALUES("10001231","姜堰区","321204","10000119","3","J");
INSERT INTO cmf_region_letter VALUES("10001232","兴化市","321281","10000119","3","X");
INSERT INTO cmf_region_letter VALUES("10001233","靖江市","321282","10000119","3","J");
INSERT INTO cmf_region_letter VALUES("10001234","泰兴市","321283","10000119","3","T");
INSERT INTO cmf_region_letter VALUES("10001235","宿城区","321302","10000120","3","S");
INSERT INTO cmf_region_letter VALUES("10001236","宿豫区","321311","10000120","3","S");
INSERT INTO cmf_region_letter VALUES("10001237","沭阳县","321322","10000120","3","S");
INSERT INTO cmf_region_letter VALUES("10001238","泗阳县","321323","10000120","3","S");
INSERT INTO cmf_region_letter VALUES("10001239","泗洪县","321324","10000120","3","S");
INSERT INTO cmf_region_letter VALUES("10001240","上城区","330102","10000121","3","S");
INSERT INTO cmf_region_letter VALUES("10001241","下城区","330103","10000121","3","X");
INSERT INTO cmf_region_letter VALUES("10001242","江干区","330104","10000121","3","J");
INSERT INTO cmf_region_letter VALUES("10001243","拱墅区","330105","10000121","3","G");
INSERT INTO cmf_region_letter VALUES("10001244","西湖区","330106","10000121","3","X");
INSERT INTO cmf_region_letter VALUES("10001245","滨江区","330108","10000121","3","B");
INSERT INTO cmf_region_letter VALUES("10001246","萧山区","330109","10000121","3","X");
INSERT INTO cmf_region_letter VALUES("10001247","余杭区","330110","10000121","3","Y");
INSERT INTO cmf_region_letter VALUES("10001248","富阳区","330111","10000121","3","F");
INSERT INTO cmf_region_letter VALUES("10001249","临安区","330112","10000121","3","L");
INSERT INTO cmf_region_letter VALUES("10001250","桐庐县","330122","10000121","3","T");
INSERT INTO cmf_region_letter VALUES("10001251","淳安县","330127","10000121","3","C");
INSERT INTO cmf_region_letter VALUES("10001252","建德市","330182","10000121","3","J");
INSERT INTO cmf_region_letter VALUES("10001253","海曙区","330203","10000122","3","H");
INSERT INTO cmf_region_letter VALUES("10001254","江北区","330205","10000122","3","J");
INSERT INTO cmf_region_letter VALUES("10001255","北仑区","330206","10000122","3","B");
INSERT INTO cmf_region_letter VALUES("10001256","镇海区","330211","10000122","3","Z");
INSERT INTO cmf_region_letter VALUES("10001257","鄞州区","330212","10000122","3","Y");
INSERT INTO cmf_region_letter VALUES("10001258","奉化区","330213","10000122","3","F");
INSERT INTO cmf_region_letter VALUES("10001259","象山县","330225","10000122","3","X");
INSERT INTO cmf_region_letter VALUES("10001260","宁海县","330226","10000122","3","N");
INSERT INTO cmf_region_letter VALUES("10001261","余姚市","330281","10000122","3","Y");
INSERT INTO cmf_region_letter VALUES("10001262","慈溪市","330282","10000122","3","C");
INSERT INTO cmf_region_letter VALUES("10001263","鹿城区","330302","10000123","3","L");
INSERT INTO cmf_region_letter VALUES("10001264","龙湾区","330303","10000123","3","L");
INSERT INTO cmf_region_letter VALUES("10001265","瓯海区","330304","10000123","3","O");
INSERT INTO cmf_region_letter VALUES("10001266","洞头区","330305","10000123","3","D");
INSERT INTO cmf_region_letter VALUES("10001267","永嘉县","330324","10000123","3","Y");
INSERT INTO cmf_region_letter VALUES("10001268","平阳县","330326","10000123","3","P");
INSERT INTO cmf_region_letter VALUES("10001269","苍南县","330327","10000123","3","C");
INSERT INTO cmf_region_letter VALUES("10001270","文成县","330328","10000123","3","W");
INSERT INTO cmf_region_letter VALUES("10001271","泰顺县","330329","10000123","3","T");
INSERT INTO cmf_region_letter VALUES("10001272","瑞安市","330381","10000123","3","R");
INSERT INTO cmf_region_letter VALUES("10001273","乐清市","330382","10000123","3","Y");
INSERT INTO cmf_region_letter VALUES("10001274","南湖区","330402","10000124","3","N");
INSERT INTO cmf_region_letter VALUES("10001275","秀洲区","330411","10000124","3","X");
INSERT INTO cmf_region_letter VALUES("10001276","嘉善县","330421","10000124","3","J");
INSERT INTO cmf_region_letter VALUES("10001277","海盐县","330424","10000124","3","H");
INSERT INTO cmf_region_letter VALUES("10001278","海宁市","330481","10000124","3","H");
INSERT INTO cmf_region_letter VALUES("10001279","平湖市","330482","10000124","3","P");
INSERT INTO cmf_region_letter VALUES("10001280","桐乡市","330483","10000124","3","T");
INSERT INTO cmf_region_letter VALUES("10001281","吴兴区","330502","10000125","3","W");
INSERT INTO cmf_region_letter VALUES("10001282","南浔区","330503","10000125","3","N");
INSERT INTO cmf_region_letter VALUES("10001283","德清县","330521","10000125","3","D");
INSERT INTO cmf_region_letter VALUES("10001284","长兴县","330522","10000125","3","C");
INSERT INTO cmf_region_letter VALUES("10001285","安吉县","330523","10000125","3","A");
INSERT INTO cmf_region_letter VALUES("10001286","越城区","330602","10000126","3","Y");
INSERT INTO cmf_region_letter VALUES("10001287","柯桥区","330603","10000126","3","K");
INSERT INTO cmf_region_letter VALUES("10001288","上虞区","330604","10000126","3","S");
INSERT INTO cmf_region_letter VALUES("10001289","新昌县","330624","10000126","3","X");
INSERT INTO cmf_region_letter VALUES("10001290","诸暨市","330681","10000126","3","Z");
INSERT INTO cmf_region_letter VALUES("10001291","嵊州市","330683","10000126","3","S");
INSERT INTO cmf_region_letter VALUES("10001292","婺城区","330702","10000127","3","W");
INSERT INTO cmf_region_letter VALUES("10001293","金东区","330703","10000127","3","J");
INSERT INTO cmf_region_letter VALUES("10001294","武义县","330723","10000127","3","W");
INSERT INTO cmf_region_letter VALUES("10001295","浦江县","330726","10000127","3","P");
INSERT INTO cmf_region_letter VALUES("10001296","磐安县","330727","10000127","3","P");
INSERT INTO cmf_region_letter VALUES("10001297","兰溪市","330781","10000127","3","L");
INSERT INTO cmf_region_letter VALUES("10001298","义乌市","330782","10000127","3","Y");
INSERT INTO cmf_region_letter VALUES("10001299","东阳市","330783","10000127","3","D");
INSERT INTO cmf_region_letter VALUES("10001300","永康市","330784","10000127","3","Y");
INSERT INTO cmf_region_letter VALUES("10001301","柯城区","330802","10000128","3","K");
INSERT INTO cmf_region_letter VALUES("10001302","衢江区","330803","10000128","3","Q");
INSERT INTO cmf_region_letter VALUES("10001303","常山县","330822","10000128","3","C");
INSERT INTO cmf_region_letter VALUES("10001304","开化县","330824","10000128","3","K");
INSERT INTO cmf_region_letter VALUES("10001305","龙游县","330825","10000128","3","L");
INSERT INTO cmf_region_letter VALUES("10001306","江山市","330881","10000128","3","J");
INSERT INTO cmf_region_letter VALUES("10001307","定海区","330902","10000129","3","D");
INSERT INTO cmf_region_letter VALUES("10001308","普陀区","330903","10000129","3","P");
INSERT INTO cmf_region_letter VALUES("10001309","岱山县","330921","10000129","3","D");
INSERT INTO cmf_region_letter VALUES("10001310","嵊泗县","330922","10000129","3","S");
INSERT INTO cmf_region_letter VALUES("10001311","椒江区","331002","10000130","3","J");
INSERT INTO cmf_region_letter VALUES("10001312","黄岩区","331003","10000130","3","H");
INSERT INTO cmf_region_letter VALUES("10001313","路桥区","331004","10000130","3","L");
INSERT INTO cmf_region_letter VALUES("10001314","三门县","331022","10000130","3","S");
INSERT INTO cmf_region_letter VALUES("10001315","天台县","331023","10000130","3","T");
INSERT INTO cmf_region_letter VALUES("10001316","仙居县","331024","10000130","3","X");
INSERT INTO cmf_region_letter VALUES("10001317","温岭市","331081","10000130","3","W");
INSERT INTO cmf_region_letter VALUES("10001318","临海市","331082","10000130","3","L");
INSERT INTO cmf_region_letter VALUES("10001319","玉环市","331083","10000130","3","Y");
INSERT INTO cmf_region_letter VALUES("10001320","莲都区","331102","10000131","3","L");
INSERT INTO cmf_region_letter VALUES("10001321","青田县","331121","10000131","3","Q");
INSERT INTO cmf_region_letter VALUES("10001322","缙云县","331122","10000131","3","J");
INSERT INTO cmf_region_letter VALUES("10001323","遂昌县","331123","10000131","3","S");
INSERT INTO cmf_region_letter VALUES("10001324","松阳县","331124","10000131","3","S");
INSERT INTO cmf_region_letter VALUES("10001325","云和县","331125","10000131","3","Y");
INSERT INTO cmf_region_letter VALUES("10001326","庆元县","331126","10000131","3","Q");
INSERT INTO cmf_region_letter VALUES("10001327","景宁畲族自治县","331127","10000131","3","J");
INSERT INTO cmf_region_letter VALUES("10001328","龙泉市","331181","10000131","3","L");
INSERT INTO cmf_region_letter VALUES("10001329","瑶海区","340102","10000132","3","Y");
INSERT INTO cmf_region_letter VALUES("10001330","庐阳区","340103","10000132","3","L");
INSERT INTO cmf_region_letter VALUES("10001331","蜀山区","340104","10000132","3","S");
INSERT INTO cmf_region_letter VALUES("10001332","包河区","340111","10000132","3","B");
INSERT INTO cmf_region_letter VALUES("10001333","长丰县","340121","10000132","3","C");
INSERT INTO cmf_region_letter VALUES("10001334","肥东县","340122","10000132","3","F");
INSERT INTO cmf_region_letter VALUES("10001335","肥西县","340123","10000132","3","F");
INSERT INTO cmf_region_letter VALUES("10001336","庐江县","340124","10000132","3","L");
INSERT INTO cmf_region_letter VALUES("10001337","巢湖市","340181","10000132","3","C");
INSERT INTO cmf_region_letter VALUES("10001338","高新技术开发区","340190","10000132","3","G");
INSERT INTO cmf_region_letter VALUES("10001339","经济技术开发区","340191","10000132","3","J");
INSERT INTO cmf_region_letter VALUES("10001340","镜湖区","340202","10000133","3","J");
INSERT INTO cmf_region_letter VALUES("10001341","弋江区","340203","10000133","3","Y");
INSERT INTO cmf_region_letter VALUES("10001342","鸠江区","340207","10000133","3","J");
INSERT INTO cmf_region_letter VALUES("10001343","三山区","340208","10000133","3","S");
INSERT INTO cmf_region_letter VALUES("10001344","芜湖县","340221","10000133","3","W");
INSERT INTO cmf_region_letter VALUES("10001345","繁昌县","340222","10000133","3","F");
INSERT INTO cmf_region_letter VALUES("10001346","南陵县","340223","10000133","3","N");
INSERT INTO cmf_region_letter VALUES("10001347","无为县","340225","10000133","3","W");
INSERT INTO cmf_region_letter VALUES("10001348","龙子湖区","340302","10000134","3","L");
INSERT INTO cmf_region_letter VALUES("10001349","蚌山区","340303","10000134","3","B");
INSERT INTO cmf_region_letter VALUES("10001350","禹会区","340304","10000134","3","Y");
INSERT INTO cmf_region_letter VALUES("10001351","淮上区","340311","10000134","3","H");
INSERT INTO cmf_region_letter VALUES("10001352","怀远县","340321","10000134","3","H");
INSERT INTO cmf_region_letter VALUES("10001353","五河县","340322","10000134","3","W");
INSERT INTO cmf_region_letter VALUES("10001354","固镇县","340323","10000134","3","G");
INSERT INTO cmf_region_letter VALUES("10001355","大通区","340402","10000135","3","D");
INSERT INTO cmf_region_letter VALUES("10001356","田家庵区","340403","10000135","3","T");
INSERT INTO cmf_region_letter VALUES("10001357","谢家集区","340404","10000135","3","X");
INSERT INTO cmf_region_letter VALUES("10001358","八公山区","340405","10000135","3","B");
INSERT INTO cmf_region_letter VALUES("10001359","潘集区","340406","10000135","3","P");
INSERT INTO cmf_region_letter VALUES("10001360","凤台县","340421","10000135","3","F");
INSERT INTO cmf_region_letter VALUES("10001361","寿县","340422","10000135","3","S");
INSERT INTO cmf_region_letter VALUES("10001362","花山区","340503","10000136","3","H");
INSERT INTO cmf_region_letter VALUES("10001363","雨山区","340504","10000136","3","Y");
INSERT INTO cmf_region_letter VALUES("10001364","博望区","340506","10000136","3","B");
INSERT INTO cmf_region_letter VALUES("10001365","当涂县","340521","10000136","3","D");
INSERT INTO cmf_region_letter VALUES("10001366","含山县","340522","10000136","3","H");
INSERT INTO cmf_region_letter VALUES("10001367","和县","340523","10000136","3","H");
INSERT INTO cmf_region_letter VALUES("10001368","杜集区","340602","10000137","3","D");
INSERT INTO cmf_region_letter VALUES("10001369","相山区","340603","10000137","3","X");
INSERT INTO cmf_region_letter VALUES("10001370","烈山区","340604","10000137","3","L");
INSERT INTO cmf_region_letter VALUES("10001371","濉溪县","340621","10000137","3","S");
INSERT INTO cmf_region_letter VALUES("10001372","铜官区","340705","10000138","3","T");
INSERT INTO cmf_region_letter VALUES("10001373","义安区","340706","10000138","3","Y");
INSERT INTO cmf_region_letter VALUES("10001374","郊区","340711","10000138","3","J");
INSERT INTO cmf_region_letter VALUES("10001375","枞阳县","340722","10000138","3","Z");
INSERT INTO cmf_region_letter VALUES("10001376","迎江区","340802","10000139","3","Y");
INSERT INTO cmf_region_letter VALUES("10001377","大观区","340803","10000139","3","D");
INSERT INTO cmf_region_letter VALUES("10001378","宜秀区","340811","10000139","3","Y");
INSERT INTO cmf_region_letter VALUES("10001379","怀宁县","340822","10000139","3","H");
INSERT INTO cmf_region_letter VALUES("10001380","潜山县","340824","10000139","3","Q");
INSERT INTO cmf_region_letter VALUES("10001381","太湖县","340825","10000139","3","T");
INSERT INTO cmf_region_letter VALUES("10001382","宿松县","340826","10000139","3","S");
INSERT INTO cmf_region_letter VALUES("10001383","望江县","340827","10000139","3","W");
INSERT INTO cmf_region_letter VALUES("10001384","岳西县","340828","10000139","3","Y");
INSERT INTO cmf_region_letter VALUES("10001385","桐城市","340881","10000139","3","T");
INSERT INTO cmf_region_letter VALUES("10001386","屯溪区","341002","10000140","3","T");
INSERT INTO cmf_region_letter VALUES("10001387","黄山区","341003","10000140","3","H");
INSERT INTO cmf_region_letter VALUES("10001388","徽州区","341004","10000140","3","H");
INSERT INTO cmf_region_letter VALUES("10001389","歙县","341021","10000140","3","S");
INSERT INTO cmf_region_letter VALUES("10001390","休宁县","341022","10000140","3","X");
INSERT INTO cmf_region_letter VALUES("10001391","黟县","341023","10000140","3","Y");
INSERT INTO cmf_region_letter VALUES("10001392","祁门县","341024","10000140","3","Q");
INSERT INTO cmf_region_letter VALUES("10001393","琅琊区","341102","10000141","3","L");
INSERT INTO cmf_region_letter VALUES("10001394","南谯区","341103","10000141","3","N");
INSERT INTO cmf_region_letter VALUES("10001395","来安县","341122","10000141","3","L");
INSERT INTO cmf_region_letter VALUES("10001396","全椒县","341124","10000141","3","Q");
INSERT INTO cmf_region_letter VALUES("10001397","定远县","341125","10000141","3","D");
INSERT INTO cmf_region_letter VALUES("10001398","凤阳县","341126","10000141","3","F");
INSERT INTO cmf_region_letter VALUES("10001399","天长市","341181","10000141","3","T");
INSERT INTO cmf_region_letter VALUES("10001400","明光市","341182","10000141","3","M");
INSERT INTO cmf_region_letter VALUES("10001401","颍州区","341202","10000142","3","Y");
INSERT INTO cmf_region_letter VALUES("10001402","颍东区","341203","10000142","3","Y");
INSERT INTO cmf_region_letter VALUES("10001403","颍泉区","341204","10000142","3","Y");
INSERT INTO cmf_region_letter VALUES("10001404","临泉县","341221","10000142","3","L");
INSERT INTO cmf_region_letter VALUES("10001405","太和县","341222","10000142","3","T");
INSERT INTO cmf_region_letter VALUES("10001406","阜南县","341225","10000142","3","F");
INSERT INTO cmf_region_letter VALUES("10001407","颍上县","341226","10000142","3","Y");
INSERT INTO cmf_region_letter VALUES("10001408","界首市","341282","10000142","3","J");
INSERT INTO cmf_region_letter VALUES("10001409","埇桥区","341302","10000143","3","Y");
INSERT INTO cmf_region_letter VALUES("10001410","砀山县","341321","10000143","3","D");
INSERT INTO cmf_region_letter VALUES("10001411","萧县","341322","10000143","3","X");
INSERT INTO cmf_region_letter VALUES("10001412","灵璧县","341323","10000143","3","L");
INSERT INTO cmf_region_letter VALUES("10001413","泗县","341324","10000143","3","S");
INSERT INTO cmf_region_letter VALUES("10001414","经济开发区","341390","10000143","3","J");
INSERT INTO cmf_region_letter VALUES("10001415","金安区","341502","10000144","3","J");
INSERT INTO cmf_region_letter VALUES("10001416","裕安区","341503","10000144","3","Y");
INSERT INTO cmf_region_letter VALUES("10001417","叶集区","341504","10000144","3","Y");
INSERT INTO cmf_region_letter VALUES("10001418","霍邱县","341522","10000144","3","H");
INSERT INTO cmf_region_letter VALUES("10001419","舒城县","341523","10000144","3","S");
INSERT INTO cmf_region_letter VALUES("10001420","金寨县","341524","10000144","3","J");
INSERT INTO cmf_region_letter VALUES("10001421","霍山县","341525","10000144","3","H");
INSERT INTO cmf_region_letter VALUES("10001422","谯城区","341602","10000145","3","Q");
INSERT INTO cmf_region_letter VALUES("10001423","涡阳县","341621","10000145","3","G");
INSERT INTO cmf_region_letter VALUES("10001424","蒙城县","341622","10000145","3","M");
INSERT INTO cmf_region_letter VALUES("10001425","利辛县","341623","10000145","3","L");
INSERT INTO cmf_region_letter VALUES("10001426","贵池区","341702","10000146","3","G");
INSERT INTO cmf_region_letter VALUES("10001427","东至县","341721","10000146","3","D");
INSERT INTO cmf_region_letter VALUES("10001428","石台县","341722","10000146","3","S");
INSERT INTO cmf_region_letter VALUES("10001429","青阳县","341723","10000146","3","Q");
INSERT INTO cmf_region_letter VALUES("10001430","宣州区","341802","10000147","3","X");
INSERT INTO cmf_region_letter VALUES("10001431","郎溪县","341821","10000147","3","L");
INSERT INTO cmf_region_letter VALUES("10001432","广德县","341822","10000147","3","G");
INSERT INTO cmf_region_letter VALUES("10001433","泾县","341823","10000147","3","J");
INSERT INTO cmf_region_letter VALUES("10001434","绩溪县","341824","10000147","3","J");
INSERT INTO cmf_region_letter VALUES("10001435","旌德县","341825","10000147","3","J");
INSERT INTO cmf_region_letter VALUES("10001436","宁国市","341881","10000147","3","N");
INSERT INTO cmf_region_letter VALUES("10001437","鼓楼区","350102","10000148","3","G");
INSERT INTO cmf_region_letter VALUES("10001438","台江区","350103","10000148","3","T");
INSERT INTO cmf_region_letter VALUES("10001439","仓山区","350104","10000148","3","C");
INSERT INTO cmf_region_letter VALUES("10001440","马尾区","350105","10000148","3","M");
INSERT INTO cmf_region_letter VALUES("10001441","晋安区","350111","10000148","3","J");
INSERT INTO cmf_region_letter VALUES("10001442","长乐区","350112","10000148","3","C");
INSERT INTO cmf_region_letter VALUES("10001443","闽侯县","350121","10000148","3","M");
INSERT INTO cmf_region_letter VALUES("10001444","连江县","350122","10000148","3","L");
INSERT INTO cmf_region_letter VALUES("10001445","罗源县","350123","10000148","3","L");
INSERT INTO cmf_region_letter VALUES("10001446","闽清县","350124","10000148","3","M");
INSERT INTO cmf_region_letter VALUES("10001447","永泰县","350125","10000148","3","Y");
INSERT INTO cmf_region_letter VALUES("10001448","平潭县","350128","10000148","3","P");
INSERT INTO cmf_region_letter VALUES("10001449","福清市","350181","10000148","3","F");
INSERT INTO cmf_region_letter VALUES("10001450","思明区","350203","10000149","3","S");
INSERT INTO cmf_region_letter VALUES("10001451","海沧区","350205","10000149","3","H");
INSERT INTO cmf_region_letter VALUES("10001452","湖里区","350206","10000149","3","H");
INSERT INTO cmf_region_letter VALUES("10001453","集美区","350211","10000149","3","J");
INSERT INTO cmf_region_letter VALUES("10001454","同安区","350212","10000149","3","T");
INSERT INTO cmf_region_letter VALUES("10001455","翔安区","350213","10000149","3","X");
INSERT INTO cmf_region_letter VALUES("10001456","城厢区","350302","10000150","3","C");
INSERT INTO cmf_region_letter VALUES("10001457","涵江区","350303","10000150","3","H");
INSERT INTO cmf_region_letter VALUES("10001458","荔城区","350304","10000150","3","L");
INSERT INTO cmf_region_letter VALUES("10001459","秀屿区","350305","10000150","3","X");
INSERT INTO cmf_region_letter VALUES("10001460","仙游县","350322","10000150","3","X");
INSERT INTO cmf_region_letter VALUES("10001461","梅列区","350402","10000151","3","M");
INSERT INTO cmf_region_letter VALUES("10001462","三元区","350403","10000151","3","S");
INSERT INTO cmf_region_letter VALUES("10001463","明溪县","350421","10000151","3","M");
INSERT INTO cmf_region_letter VALUES("10001464","清流县","350423","10000151","3","Q");
INSERT INTO cmf_region_letter VALUES("10001465","宁化县","350424","10000151","3","N");
INSERT INTO cmf_region_letter VALUES("10001466","大田县","350425","10000151","3","D");
INSERT INTO cmf_region_letter VALUES("10001467","尤溪县","350426","10000151","3","Y");
INSERT INTO cmf_region_letter VALUES("10001468","沙县","350427","10000151","3","S");
INSERT INTO cmf_region_letter VALUES("10001469","将乐县","350428","10000151","3","J");
INSERT INTO cmf_region_letter VALUES("10001470","泰宁县","350429","10000151","3","T");
INSERT INTO cmf_region_letter VALUES("10001471","建宁县","350430","10000151","3","J");
INSERT INTO cmf_region_letter VALUES("10001472","永安市","350481","10000151","3","Y");
INSERT INTO cmf_region_letter VALUES("10001473","鲤城区","350502","10000152","3","L");
INSERT INTO cmf_region_letter VALUES("10001474","丰泽区","350503","10000152","3","F");
INSERT INTO cmf_region_letter VALUES("10001475","洛江区","350504","10000152","3","L");
INSERT INTO cmf_region_letter VALUES("10001476","泉港区","350505","10000152","3","Q");
INSERT INTO cmf_region_letter VALUES("10001477","惠安县","350521","10000152","3","H");
INSERT INTO cmf_region_letter VALUES("10001478","安溪县","350524","10000152","3","A");
INSERT INTO cmf_region_letter VALUES("10001479","永春县","350525","10000152","3","Y");
INSERT INTO cmf_region_letter VALUES("10001480","德化县","350526","10000152","3","D");
INSERT INTO cmf_region_letter VALUES("10001481","金门县","350527","10000152","3","J");
INSERT INTO cmf_region_letter VALUES("10001482","石狮市","350581","10000152","3","S");
INSERT INTO cmf_region_letter VALUES("10001483","晋江市","350582","10000152","3","J");
INSERT INTO cmf_region_letter VALUES("10001484","南安市","350583","10000152","3","N");
INSERT INTO cmf_region_letter VALUES("10001485","芗城区","350602","10000153","3","X");
INSERT INTO cmf_region_letter VALUES("10001486","龙文区","350603","10000153","3","L");
INSERT INTO cmf_region_letter VALUES("10001487","云霄县","350622","10000153","3","Y");
INSERT INTO cmf_region_letter VALUES("10001488","漳浦县","350623","10000153","3","Z");
INSERT INTO cmf_region_letter VALUES("10001489","诏安县","350624","10000153","3","Z");
INSERT INTO cmf_region_letter VALUES("10001490","长泰县","350625","10000153","3","C");
INSERT INTO cmf_region_letter VALUES("10001491","东山县","350626","10000153","3","D");
INSERT INTO cmf_region_letter VALUES("10001492","南靖县","350627","10000153","3","N");
INSERT INTO cmf_region_letter VALUES("10001493","平和县","350628","10000153","3","P");
INSERT INTO cmf_region_letter VALUES("10001494","华安县","350629","10000153","3","H");
INSERT INTO cmf_region_letter VALUES("10001495","龙海市","350681","10000153","3","L");
INSERT INTO cmf_region_letter VALUES("10001496","延平区","350702","10000154","3","Y");
INSERT INTO cmf_region_letter VALUES("10001497","建阳区","350703","10000154","3","J");
INSERT INTO cmf_region_letter VALUES("10001498","顺昌县","350721","10000154","3","S");
INSERT INTO cmf_region_letter VALUES("10001499","浦城县","350722","10000154","3","P");
INSERT INTO cmf_region_letter VALUES("10001500","光泽县","350723","10000154","3","G");
INSERT INTO cmf_region_letter VALUES("10001501","松溪县","350724","10000154","3","S");
INSERT INTO cmf_region_letter VALUES("10001502","政和县","350725","10000154","3","Z");
INSERT INTO cmf_region_letter VALUES("10001503","邵武市","350781","10000154","3","S");
INSERT INTO cmf_region_letter VALUES("10001504","武夷山市","350782","10000154","3","W");
INSERT INTO cmf_region_letter VALUES("10001505","建瓯市","350783","10000154","3","J");
INSERT INTO cmf_region_letter VALUES("10001506","新罗区","350802","10000155","3","X");
INSERT INTO cmf_region_letter VALUES("10001507","永定区","350803","10000155","3","Y");
INSERT INTO cmf_region_letter VALUES("10001508","长汀县","350821","10000155","3","C");
INSERT INTO cmf_region_letter VALUES("10001509","上杭县","350823","10000155","3","S");
INSERT INTO cmf_region_letter VALUES("10001510","武平县","350824","10000155","3","W");
INSERT INTO cmf_region_letter VALUES("10001511","连城县","350825","10000155","3","L");
INSERT INTO cmf_region_letter VALUES("10001512","漳平市","350881","10000155","3","Z");
INSERT INTO cmf_region_letter VALUES("10001513","蕉城区","350902","10000156","3","J");
INSERT INTO cmf_region_letter VALUES("10001514","霞浦县","350921","10000156","3","X");
INSERT INTO cmf_region_letter VALUES("10001515","古田县","350922","10000156","3","G");
INSERT INTO cmf_region_letter VALUES("10001516","屏南县","350923","10000156","3","P");
INSERT INTO cmf_region_letter VALUES("10001517","寿宁县","350924","10000156","3","S");
INSERT INTO cmf_region_letter VALUES("10001518","周宁县","350925","10000156","3","Z");
INSERT INTO cmf_region_letter VALUES("10001519","柘荣县","350926","10000156","3","Z");
INSERT INTO cmf_region_letter VALUES("10001520","福安市","350981","10000156","3","F");
INSERT INTO cmf_region_letter VALUES("10001521","福鼎市","350982","10000156","3","F");
INSERT INTO cmf_region_letter VALUES("10001522","东湖区","360102","10000157","3","D");
INSERT INTO cmf_region_letter VALUES("10001523","西湖区","360103","10000157","3","X");
INSERT INTO cmf_region_letter VALUES("10001524","青云谱区","360104","10000157","3","Q");
INSERT INTO cmf_region_letter VALUES("10001525","湾里区","360105","10000157","3","W");
INSERT INTO cmf_region_letter VALUES("10001526","青山湖区","360111","10000157","3","Q");
INSERT INTO cmf_region_letter VALUES("10001527","新建区","360112","10000157","3","X");
INSERT INTO cmf_region_letter VALUES("10001528","南昌县","360121","10000157","3","N");
INSERT INTO cmf_region_letter VALUES("10001529","安义县","360123","10000157","3","A");
INSERT INTO cmf_region_letter VALUES("10001530","进贤县","360124","10000157","3","J");
INSERT INTO cmf_region_letter VALUES("10001531","经济技术开发区","360190","10000157","3","J");
INSERT INTO cmf_region_letter VALUES("10001532","高新区","360192","10000157","3","G");
INSERT INTO cmf_region_letter VALUES("10001533","昌江区","360202","10000158","3","C");
INSERT INTO cmf_region_letter VALUES("10001534","珠山区","360203","10000158","3","Z");
INSERT INTO cmf_region_letter VALUES("10001535","浮梁县","360222","10000158","3","F");
INSERT INTO cmf_region_letter VALUES("10001536","乐平市","360281","10000158","3","L");
INSERT INTO cmf_region_letter VALUES("10001537","安源区","360302","10000159","3","A");
INSERT INTO cmf_region_letter VALUES("10001538","湘东区","360313","10000159","3","X");
INSERT INTO cmf_region_letter VALUES("10001539","莲花县","360321","10000159","3","L");
INSERT INTO cmf_region_letter VALUES("10001540","上栗县","360322","10000159","3","S");
INSERT INTO cmf_region_letter VALUES("10001541","芦溪县","360323","10000159","3","L");
INSERT INTO cmf_region_letter VALUES("10001542","濂溪区","360402","10000160","3","L");
INSERT INTO cmf_region_letter VALUES("10001543","浔阳区","360403","10000160","3","X");
INSERT INTO cmf_region_letter VALUES("10001544","柴桑区","360404","10000160","3","C");
INSERT INTO cmf_region_letter VALUES("10001545","武宁县","360423","10000160","3","W");
INSERT INTO cmf_region_letter VALUES("10001546","修水县","360424","10000160","3","X");
INSERT INTO cmf_region_letter VALUES("10001547","永修县","360425","10000160","3","Y");
INSERT INTO cmf_region_letter VALUES("10001548","德安县","360426","10000160","3","D");
INSERT INTO cmf_region_letter VALUES("10001549","都昌县","360428","10000160","3","D");
INSERT INTO cmf_region_letter VALUES("10001550","湖口县","360429","10000160","3","H");
INSERT INTO cmf_region_letter VALUES("10001551","彭泽县","360430","10000160","3","P");
INSERT INTO cmf_region_letter VALUES("10001552","瑞昌市","360481","10000160","3","R");
INSERT INTO cmf_region_letter VALUES("10001553","共青城市","360482","10000160","3","G");
INSERT INTO cmf_region_letter VALUES("10001554","庐山市","360483","10000160","3","L");
INSERT INTO cmf_region_letter VALUES("10001555","经济技术开发区","360490","10000160","3","J");
INSERT INTO cmf_region_letter VALUES("10001556","渝水区","360502","10000161","3","Y");
INSERT INTO cmf_region_letter VALUES("10001557","分宜县","360521","10000161","3","F");
INSERT INTO cmf_region_letter VALUES("10001558","月湖区","360602","10000162","3","Y");
INSERT INTO cmf_region_letter VALUES("10001559","余江区","360603","10000162","3","Y");
INSERT INTO cmf_region_letter VALUES("10001560","贵溪市","360681","10000162","3","G");
INSERT INTO cmf_region_letter VALUES("10001561","章贡区","360702","10000163","3","Z");
INSERT INTO cmf_region_letter VALUES("10001562","南康区","360703","10000163","3","N");
INSERT INTO cmf_region_letter VALUES("10001563","赣县区","360704","10000163","3","G");
INSERT INTO cmf_region_letter VALUES("10001564","信丰县","360722","10000163","3","X");
INSERT INTO cmf_region_letter VALUES("10001565","大余县","360723","10000163","3","D");
INSERT INTO cmf_region_letter VALUES("10001566","上犹县","360724","10000163","3","S");
INSERT INTO cmf_region_letter VALUES("10001567","崇义县","360725","10000163","3","C");
INSERT INTO cmf_region_letter VALUES("10001568","安远县","360726","10000163","3","A");
INSERT INTO cmf_region_letter VALUES("10001569","龙南县","360727","10000163","3","L");
INSERT INTO cmf_region_letter VALUES("10001570","定南县","360728","10000163","3","D");
INSERT INTO cmf_region_letter VALUES("10001571","全南县","360729","10000163","3","Q");
INSERT INTO cmf_region_letter VALUES("10001572","宁都县","360730","10000163","3","N");
INSERT INTO cmf_region_letter VALUES("10001573","于都县","360731","10000163","3","Y");
INSERT INTO cmf_region_letter VALUES("10001574","兴国县","360732","10000163","3","X");
INSERT INTO cmf_region_letter VALUES("10001575","会昌县","360733","10000163","3","H");
INSERT INTO cmf_region_letter VALUES("10001576","寻乌县","360734","10000163","3","X");
INSERT INTO cmf_region_letter VALUES("10001577","石城县","360735","10000163","3","S");
INSERT INTO cmf_region_letter VALUES("10001578","瑞金市","360781","10000163","3","R");
INSERT INTO cmf_region_letter VALUES("10001579","吉州区","360802","10000164","3","J");
INSERT INTO cmf_region_letter VALUES("10001580","青原区","360803","10000164","3","Q");
INSERT INTO cmf_region_letter VALUES("10001581","吉安县","360821","10000164","3","J");
INSERT INTO cmf_region_letter VALUES("10001582","吉水县","360822","10000164","3","J");
INSERT INTO cmf_region_letter VALUES("10001583","峡江县","360823","10000164","3","X");
INSERT INTO cmf_region_letter VALUES("10001584","新干县","360824","10000164","3","X");
INSERT INTO cmf_region_letter VALUES("10001585","永丰县","360825","10000164","3","Y");
INSERT INTO cmf_region_letter VALUES("10001586","泰和县","360826","10000164","3","T");
INSERT INTO cmf_region_letter VALUES("10001587","遂川县","360827","10000164","3","S");
INSERT INTO cmf_region_letter VALUES("10001588","万安县","360828","10000164","3","W");
INSERT INTO cmf_region_letter VALUES("10001589","安福县","360829","10000164","3","A");
INSERT INTO cmf_region_letter VALUES("10001590","永新县","360830","10000164","3","Y");
INSERT INTO cmf_region_letter VALUES("10001591","井冈山市","360881","10000164","3","J");
INSERT INTO cmf_region_letter VALUES("10001592","袁州区","360902","10000165","3","Y");
INSERT INTO cmf_region_letter VALUES("10001593","奉新县","360921","10000165","3","F");
INSERT INTO cmf_region_letter VALUES("10001594","万载县","360922","10000165","3","W");
INSERT INTO cmf_region_letter VALUES("10001595","上高县","360923","10000165","3","S");
INSERT INTO cmf_region_letter VALUES("10001596","宜丰县","360924","10000165","3","Y");
INSERT INTO cmf_region_letter VALUES("10001597","靖安县","360925","10000165","3","J");
INSERT INTO cmf_region_letter VALUES("10001598","铜鼓县","360926","10000165","3","T");
INSERT INTO cmf_region_letter VALUES("10001599","丰城市","360981","10000165","3","F");
INSERT INTO cmf_region_letter VALUES("10001600","樟树市","360982","10000165","3","Z");
INSERT INTO cmf_region_letter VALUES("10001601","高安市","360983","10000165","3","G");
INSERT INTO cmf_region_letter VALUES("10001602","临川区","361002","10000166","3","L");
INSERT INTO cmf_region_letter VALUES("10001603","东乡区","361003","10000166","3","D");
INSERT INTO cmf_region_letter VALUES("10001604","南城县","361021","10000166","3","N");
INSERT INTO cmf_region_letter VALUES("10001605","黎川县","361022","10000166","3","L");
INSERT INTO cmf_region_letter VALUES("10001606","南丰县","361023","10000166","3","N");
INSERT INTO cmf_region_letter VALUES("10001607","崇仁县","361024","10000166","3","C");
INSERT INTO cmf_region_letter VALUES("10001608","乐安县","361025","10000166","3","L");
INSERT INTO cmf_region_letter VALUES("10001609","宜黄县","361026","10000166","3","Y");
INSERT INTO cmf_region_letter VALUES("10001610","金溪县","361027","10000166","3","J");
INSERT INTO cmf_region_letter VALUES("10001611","资溪县","361028","10000166","3","Z");
INSERT INTO cmf_region_letter VALUES("10001612","广昌县","361030","10000166","3","G");
INSERT INTO cmf_region_letter VALUES("10001613","信州区","361102","10000167","3","X");
INSERT INTO cmf_region_letter VALUES("10001614","广丰区","361103","10000167","3","G");
INSERT INTO cmf_region_letter VALUES("10001615","上饶县","361121","10000167","3","S");
INSERT INTO cmf_region_letter VALUES("10001616","玉山县","361123","10000167","3","Y");
INSERT INTO cmf_region_letter VALUES("10001617","铅山县","361124","10000167","3","Y");
INSERT INTO cmf_region_letter VALUES("10001618","横峰县","361125","10000167","3","H");
INSERT INTO cmf_region_letter VALUES("10001619","弋阳县","361126","10000167","3","Y");
INSERT INTO cmf_region_letter VALUES("10001620","余干县","361127","10000167","3","Y");
INSERT INTO cmf_region_letter VALUES("10001621","鄱阳县","361128","10000167","3","P");
INSERT INTO cmf_region_letter VALUES("10001622","万年县","361129","10000167","3","W");
INSERT INTO cmf_region_letter VALUES("10001623","婺源县","361130","10000167","3","W");
INSERT INTO cmf_region_letter VALUES("10001624","德兴市","361181","10000167","3","D");
INSERT INTO cmf_region_letter VALUES("10001625","历下区","370102","10000168","3","L");
INSERT INTO cmf_region_letter VALUES("10001626","市中区","370103","10000168","3","S");
INSERT INTO cmf_region_letter VALUES("10001627","槐荫区","370104","10000168","3","H");
INSERT INTO cmf_region_letter VALUES("10001628","天桥区","370105","10000168","3","T");
INSERT INTO cmf_region_letter VALUES("10001629","历城区","370112","10000168","3","L");
INSERT INTO cmf_region_letter VALUES("10001630","长清区","370113","10000168","3","C");
INSERT INTO cmf_region_letter VALUES("10001631","章丘区","370114","10000168","3","Z");
INSERT INTO cmf_region_letter VALUES("10001632","济阳区","370115","10000168","3","J");
INSERT INTO cmf_region_letter VALUES("10001633","莱芜区","370116","10000168","3","L");
INSERT INTO cmf_region_letter VALUES("10001634","钢城区","370117","10000168","3","G");
INSERT INTO cmf_region_letter VALUES("10001635","平阴县","370124","10000168","3","P");
INSERT INTO cmf_region_letter VALUES("10001636","商河县","370126","10000168","3","S");
INSERT INTO cmf_region_letter VALUES("10001637","高新区","370190","10000168","3","G");
INSERT INTO cmf_region_letter VALUES("10001638","市南区","370202","10000169","3","S");
INSERT INTO cmf_region_letter VALUES("10001639","市北区","370203","10000169","3","S");
INSERT INTO cmf_region_letter VALUES("10001640","黄岛区","370211","10000169","3","H");
INSERT INTO cmf_region_letter VALUES("10001641","崂山区","370212","10000169","3","L");
INSERT INTO cmf_region_letter VALUES("10001642","李沧区","370213","10000169","3","L");
INSERT INTO cmf_region_letter VALUES("10001643","城阳区","370214","10000169","3","C");
INSERT INTO cmf_region_letter VALUES("10001644","即墨区","370215","10000169","3","J");
INSERT INTO cmf_region_letter VALUES("10001645","胶州市","370281","10000169","3","J");
INSERT INTO cmf_region_letter VALUES("10001646","平度市","370283","10000169","3","P");
INSERT INTO cmf_region_letter VALUES("10001647","莱西市","370285","10000169","3","L");
INSERT INTO cmf_region_letter VALUES("10001648","开发区","370290","10000169","3","K");
INSERT INTO cmf_region_letter VALUES("10001649","淄川区","370302","10000170","3","Z");
INSERT INTO cmf_region_letter VALUES("10001650","张店区","370303","10000170","3","Z");
INSERT INTO cmf_region_letter VALUES("10001651","博山区","370304","10000170","3","B");
INSERT INTO cmf_region_letter VALUES("10001652","临淄区","370305","10000170","3","L");
INSERT INTO cmf_region_letter VALUES("10001653","周村区","370306","10000170","3","Z");
INSERT INTO cmf_region_letter VALUES("10001654","桓台县","370321","10000170","3","H");
INSERT INTO cmf_region_letter VALUES("10001655","高青县","370322","10000170","3","G");
INSERT INTO cmf_region_letter VALUES("10001656","沂源县","370323","10000170","3","Y");
INSERT INTO cmf_region_letter VALUES("10001657","市中区","370402","10000171","3","S");
INSERT INTO cmf_region_letter VALUES("10001658","薛城区","370403","10000171","3","X");
INSERT INTO cmf_region_letter VALUES("10001659","峄城区","370404","10000171","3","Y");
INSERT INTO cmf_region_letter VALUES("10001660","台儿庄区","370405","10000171","3","T");
INSERT INTO cmf_region_letter VALUES("10001661","山亭区","370406","10000171","3","S");
INSERT INTO cmf_region_letter VALUES("10001662","滕州市","370481","10000171","3","T");
INSERT INTO cmf_region_letter VALUES("10001663","东营区","370502","10000172","3","D");
INSERT INTO cmf_region_letter VALUES("10001664","河口区","370503","10000172","3","H");
INSERT INTO cmf_region_letter VALUES("10001665","垦利区","370505","10000172","3","K");
INSERT INTO cmf_region_letter VALUES("10001666","利津县","370522","10000172","3","L");
INSERT INTO cmf_region_letter VALUES("10001667","广饶县","370523","10000172","3","G");
INSERT INTO cmf_region_letter VALUES("10001668","芝罘区","370602","10000173","3","Z");
INSERT INTO cmf_region_letter VALUES("10001669","福山区","370611","10000173","3","F");
INSERT INTO cmf_region_letter VALUES("10001670","牟平区","370612","10000173","3","M");
INSERT INTO cmf_region_letter VALUES("10001671","莱山区","370613","10000173","3","L");
INSERT INTO cmf_region_letter VALUES("10001672","长岛县","370634","10000173","3","C");
INSERT INTO cmf_region_letter VALUES("10001673","龙口市","370681","10000173","3","L");
INSERT INTO cmf_region_letter VALUES("10001674","莱阳市","370682","10000173","3","L");
INSERT INTO cmf_region_letter VALUES("10001675","莱州市","370683","10000173","3","L");
INSERT INTO cmf_region_letter VALUES("10001676","蓬莱市","370684","10000173","3","P");
INSERT INTO cmf_region_letter VALUES("10001677","招远市","370685","10000173","3","Z");
INSERT INTO cmf_region_letter VALUES("10001678","栖霞市","370686","10000173","3","X");
INSERT INTO cmf_region_letter VALUES("10001679","海阳市","370687","10000173","3","H");
INSERT INTO cmf_region_letter VALUES("10001680","开发区","370690","10000173","3","K");
INSERT INTO cmf_region_letter VALUES("10001681","潍城区","370702","10000174","3","W");
INSERT INTO cmf_region_letter VALUES("10001682","寒亭区","370703","10000174","3","H");
INSERT INTO cmf_region_letter VALUES("10001683","坊子区","370704","10000174","3","F");
INSERT INTO cmf_region_letter VALUES("10001684","奎文区","370705","10000174","3","K");
INSERT INTO cmf_region_letter VALUES("10001685","临朐县","370724","10000174","3","L");
INSERT INTO cmf_region_letter VALUES("10001686","昌乐县","370725","10000174","3","C");
INSERT INTO cmf_region_letter VALUES("10001687","青州市","370781","10000174","3","Q");
INSERT INTO cmf_region_letter VALUES("10001688","诸城市","370782","10000174","3","Z");
INSERT INTO cmf_region_letter VALUES("10001689","寿光市","370783","10000174","3","S");
INSERT INTO cmf_region_letter VALUES("10001690","安丘市","370784","10000174","3","A");
INSERT INTO cmf_region_letter VALUES("10001691","高密市","370785","10000174","3","G");
INSERT INTO cmf_region_letter VALUES("10001692","昌邑市","370786","10000174","3","C");
INSERT INTO cmf_region_letter VALUES("10001693","开发区","370790","10000174","3","K");
INSERT INTO cmf_region_letter VALUES("10001694","高新区","370791","10000174","3","G");
INSERT INTO cmf_region_letter VALUES("10001695","任城区","370811","10000175","3","R");
INSERT INTO cmf_region_letter VALUES("10001696","兖州区","370812","10000175","3","Y");
INSERT INTO cmf_region_letter VALUES("10001697","微山县","370826","10000175","3","W");
INSERT INTO cmf_region_letter VALUES("10001698","鱼台县","370827","10000175","3","Y");
INSERT INTO cmf_region_letter VALUES("10001699","金乡县","370828","10000175","3","J");
INSERT INTO cmf_region_letter VALUES("10001700","嘉祥县","370829","10000175","3","J");
INSERT INTO cmf_region_letter VALUES("10001701","汶上县","370830","10000175","3","W");
INSERT INTO cmf_region_letter VALUES("10001702","泗水县","370831","10000175","3","S");
INSERT INTO cmf_region_letter VALUES("10001703","梁山县","370832","10000175","3","L");
INSERT INTO cmf_region_letter VALUES("10001704","曲阜市","370881","10000175","3","Q");
INSERT INTO cmf_region_letter VALUES("10001705","邹城市","370883","10000175","3","Z");
INSERT INTO cmf_region_letter VALUES("10001706","高新区","370890","10000175","3","G");
INSERT INTO cmf_region_letter VALUES("10001707","泰山区","370902","10000176","3","T");
INSERT INTO cmf_region_letter VALUES("10001708","岱岳区","370911","10000176","3","D");
INSERT INTO cmf_region_letter VALUES("10001709","宁阳县","370921","10000176","3","N");
INSERT INTO cmf_region_letter VALUES("10001710","东平县","370923","10000176","3","D");
INSERT INTO cmf_region_letter VALUES("10001711","新泰市","370982","10000176","3","X");
INSERT INTO cmf_region_letter VALUES("10001712","肥城市","370983","10000176","3","F");
INSERT INTO cmf_region_letter VALUES("10001713","环翠区","371002","10000177","3","H");
INSERT INTO cmf_region_letter VALUES("10001714","文登区","371003","10000177","3","W");
INSERT INTO cmf_region_letter VALUES("10001715","荣成市","371082","10000177","3","R");
INSERT INTO cmf_region_letter VALUES("10001716","乳山市","371083","10000177","3","R");
INSERT INTO cmf_region_letter VALUES("10001717","经济技术开发区","371091","10000177","3","J");
INSERT INTO cmf_region_letter VALUES("10001718","东港区","371102","10000178","3","D");
INSERT INTO cmf_region_letter VALUES("10001719","岚山区","371103","10000178","3","L");
INSERT INTO cmf_region_letter VALUES("10001720","五莲县","371121","10000178","3","W");
INSERT INTO cmf_region_letter VALUES("10001721","莒县","371122","10000178","3","J");
INSERT INTO cmf_region_letter VALUES("10001722","兰山区","371302","10000179","3","L");
INSERT INTO cmf_region_letter VALUES("10001723","罗庄区","371311","10000179","3","L");
INSERT INTO cmf_region_letter VALUES("10001724","河东区","371312","10000179","3","H");
INSERT INTO cmf_region_letter VALUES("10001725","沂南县","371321","10000179","3","Y");
INSERT INTO cmf_region_letter VALUES("10001726","郯城县","371322","10000179","3","T");
INSERT INTO cmf_region_letter VALUES("10001727","沂水县","371323","10000179","3","Y");
INSERT INTO cmf_region_letter VALUES("10001728","兰陵县","371324","10000179","3","L");
INSERT INTO cmf_region_letter VALUES("10001729","费县","371325","10000179","3","F");
INSERT INTO cmf_region_letter VALUES("10001730","平邑县","371326","10000179","3","P");
INSERT INTO cmf_region_letter VALUES("10001731","莒南县","371327","10000179","3","J");
INSERT INTO cmf_region_letter VALUES("10001732","蒙阴县","371328","10000179","3","M");
INSERT INTO cmf_region_letter VALUES("10001733","临沭县","371329","10000179","3","L");
INSERT INTO cmf_region_letter VALUES("10001734","德城区","371402","10000180","3","D");
INSERT INTO cmf_region_letter VALUES("10001735","陵城区","371403","10000180","3","L");
INSERT INTO cmf_region_letter VALUES("10001736","宁津县","371422","10000180","3","N");
INSERT INTO cmf_region_letter VALUES("10001737","庆云县","371423","10000180","3","Q");
INSERT INTO cmf_region_letter VALUES("10001738","临邑县","371424","10000180","3","L");
INSERT INTO cmf_region_letter VALUES("10001739","齐河县","371425","10000180","3","Q");
INSERT INTO cmf_region_letter VALUES("10001740","平原县","371426","10000180","3","P");
INSERT INTO cmf_region_letter VALUES("10001741","夏津县","371427","10000180","3","X");
INSERT INTO cmf_region_letter VALUES("10001742","武城县","371428","10000180","3","W");
INSERT INTO cmf_region_letter VALUES("10001743","乐陵市","371481","10000180","3","L");
INSERT INTO cmf_region_letter VALUES("10001744","禹城市","371482","10000180","3","Y");
INSERT INTO cmf_region_letter VALUES("10001745","东昌府区","371502","10000181","3","D");
INSERT INTO cmf_region_letter VALUES("10001746","阳谷县","371521","10000181","3","Y");
INSERT INTO cmf_region_letter VALUES("10001747","莘县","371522","10000181","3","S");
INSERT INTO cmf_region_letter VALUES("10001748","茌平县","371523","10000181","3","C");
INSERT INTO cmf_region_letter VALUES("10001749","东阿县","371524","10000181","3","D");
INSERT INTO cmf_region_letter VALUES("10001750","冠县","371525","10000181","3","G");
INSERT INTO cmf_region_letter VALUES("10001751","高唐县","371526","10000181","3","G");
INSERT INTO cmf_region_letter VALUES("10001752","临清市","371581","10000181","3","L");
INSERT INTO cmf_region_letter VALUES("10001753","滨城区","371602","10000182","3","B");
INSERT INTO cmf_region_letter VALUES("10001754","沾化区","371603","10000182","3","Z");
INSERT INTO cmf_region_letter VALUES("10001755","惠民县","371621","10000182","3","H");
INSERT INTO cmf_region_letter VALUES("10001756","阳信县","371622","10000182","3","Y");
INSERT INTO cmf_region_letter VALUES("10001757","无棣县","371623","10000182","3","W");
INSERT INTO cmf_region_letter VALUES("10001758","博兴县","371625","10000182","3","B");
INSERT INTO cmf_region_letter VALUES("10001759","邹平市","371681","10000182","3","Z");
INSERT INTO cmf_region_letter VALUES("10001760","牡丹区","371702","10000183","3","M");
INSERT INTO cmf_region_letter VALUES("10001761","定陶区","371703","10000183","3","D");
INSERT INTO cmf_region_letter VALUES("10001762","曹县","371721","10000183","3","C");
INSERT INTO cmf_region_letter VALUES("10001763","单县","371722","10000183","3","S");
INSERT INTO cmf_region_letter VALUES("10001764","成武县","371723","10000183","3","C");
INSERT INTO cmf_region_letter VALUES("10001765","巨野县","371724","10000183","3","J");
INSERT INTO cmf_region_letter VALUES("10001766","郓城县","371725","10000183","3","Y");
INSERT INTO cmf_region_letter VALUES("10001767","鄄城县","371726","10000183","3","J");
INSERT INTO cmf_region_letter VALUES("10001768","东明县","371728","10000183","3","D");
INSERT INTO cmf_region_letter VALUES("10001769","中原区","410102","10000184","3","Z");
INSERT INTO cmf_region_letter VALUES("10001770","二七区","410103","10000184","3","E");
INSERT INTO cmf_region_letter VALUES("10001771","管城回族区","410104","10000184","3","G");
INSERT INTO cmf_region_letter VALUES("10001772","金水区","410105","10000184","3","J");
INSERT INTO cmf_region_letter VALUES("10001773","上街区","410106","10000184","3","S");
INSERT INTO cmf_region_letter VALUES("10001774","惠济区","410108","10000184","3","H");
INSERT INTO cmf_region_letter VALUES("10001775","中牟县","410122","10000184","3","Z");
INSERT INTO cmf_region_letter VALUES("10001776","巩义市","410181","10000184","3","G");
INSERT INTO cmf_region_letter VALUES("10001777","荥阳市","410182","10000184","3","X");
INSERT INTO cmf_region_letter VALUES("10001778","新密市","410183","10000184","3","X");
INSERT INTO cmf_region_letter VALUES("10001779","新郑市","410184","10000184","3","X");
INSERT INTO cmf_region_letter VALUES("10001780","登封市","410185","10000184","3","D");
INSERT INTO cmf_region_letter VALUES("10001781","高新技术开发区","410190","10000184","3","G");
INSERT INTO cmf_region_letter VALUES("10001782","经济技术开发区","410191","10000184","3","J");
INSERT INTO cmf_region_letter VALUES("10001783","龙亭区","410202","10000185","3","L");
INSERT INTO cmf_region_letter VALUES("10001784","顺河回族区","410203","10000185","3","S");
INSERT INTO cmf_region_letter VALUES("10001785","鼓楼区","410204","10000185","3","G");
INSERT INTO cmf_region_letter VALUES("10001786","禹王台区","410205","10000185","3","Y");
INSERT INTO cmf_region_letter VALUES("10001787","祥符区","410212","10000185","3","X");
INSERT INTO cmf_region_letter VALUES("10001788","杞县","410221","10000185","3","Q");
INSERT INTO cmf_region_letter VALUES("10001789","通许县","410222","10000185","3","T");
INSERT INTO cmf_region_letter VALUES("10001790","尉氏县","410223","10000185","3","W");
INSERT INTO cmf_region_letter VALUES("10001791","兰考县","410225","10000185","3","L");
INSERT INTO cmf_region_letter VALUES("10001792","老城区","410302","10000186","3","L");
INSERT INTO cmf_region_letter VALUES("10001793","西工区","410303","10000186","3","X");
INSERT INTO cmf_region_letter VALUES("10001794","瀍河回族区","410304","10000186","3","C");
INSERT INTO cmf_region_letter VALUES("10001795","涧西区","410305","10000186","3","J");
INSERT INTO cmf_region_letter VALUES("10001796","吉利区","410306","10000186","3","J");
INSERT INTO cmf_region_letter VALUES("10001797","洛龙区","410311","10000186","3","L");
INSERT INTO cmf_region_letter VALUES("10001798","孟津县","410322","10000186","3","M");
INSERT INTO cmf_region_letter VALUES("10001799","新安县","410323","10000186","3","X");
INSERT INTO cmf_region_letter VALUES("10001800","栾川县","410324","10000186","3","L");
INSERT INTO cmf_region_letter VALUES("10001801","嵩县","410325","10000186","3","S");
INSERT INTO cmf_region_letter VALUES("10001802","汝阳县","410326","10000186","3","R");
INSERT INTO cmf_region_letter VALUES("10001803","宜阳县","410327","10000186","3","Y");
INSERT INTO cmf_region_letter VALUES("10001804","洛宁县","410328","10000186","3","L");
INSERT INTO cmf_region_letter VALUES("10001805","伊川县","410329","10000186","3","Y");
INSERT INTO cmf_region_letter VALUES("10001806","偃师市","410381","10000186","3","Y");
INSERT INTO cmf_region_letter VALUES("10001807","新华区","410402","10000187","3","X");
INSERT INTO cmf_region_letter VALUES("10001808","卫东区","410403","10000187","3","W");
INSERT INTO cmf_region_letter VALUES("10001809","石龙区","410404","10000187","3","S");
INSERT INTO cmf_region_letter VALUES("10001810","湛河区","410411","10000187","3","Z");
INSERT INTO cmf_region_letter VALUES("10001811","宝丰县","410421","10000187","3","B");
INSERT INTO cmf_region_letter VALUES("10001812","叶县","410422","10000187","3","Y");
INSERT INTO cmf_region_letter VALUES("10001813","鲁山县","410423","10000187","3","L");
INSERT INTO cmf_region_letter VALUES("10001814","郏县","410425","10000187","3","J");
INSERT INTO cmf_region_letter VALUES("10001815","舞钢市","410481","10000187","3","W");
INSERT INTO cmf_region_letter VALUES("10001816","汝州市","410482","10000187","3","R");
INSERT INTO cmf_region_letter VALUES("10001817","文峰区","410502","10000188","3","W");
INSERT INTO cmf_region_letter VALUES("10001818","北关区","410503","10000188","3","B");
INSERT INTO cmf_region_letter VALUES("10001819","殷都区","410505","10000188","3","Y");
INSERT INTO cmf_region_letter VALUES("10001820","龙安区","410506","10000188","3","L");
INSERT INTO cmf_region_letter VALUES("10001821","安阳县","410522","10000188","3","A");
INSERT INTO cmf_region_letter VALUES("10001822","汤阴县","410523","10000188","3","T");
INSERT INTO cmf_region_letter VALUES("10001823","滑县","410526","10000188","3","H");
INSERT INTO cmf_region_letter VALUES("10001824","内黄县","410527","10000188","3","N");
INSERT INTO cmf_region_letter VALUES("10001825","林州市","410581","10000188","3","L");
INSERT INTO cmf_region_letter VALUES("10001826","开发区","410590","10000188","3","K");
INSERT INTO cmf_region_letter VALUES("10001827","鹤山区","410602","10000189","3","H");
INSERT INTO cmf_region_letter VALUES("10001828","山城区","410603","10000189","3","S");
INSERT INTO cmf_region_letter VALUES("10001829","淇滨区","410611","10000189","3","Q");
INSERT INTO cmf_region_letter VALUES("10001830","浚县","410621","10000189","3","J");
INSERT INTO cmf_region_letter VALUES("10001831","淇县","410622","10000189","3","Q");
INSERT INTO cmf_region_letter VALUES("10001832","红旗区","410702","10000190","3","H");
INSERT INTO cmf_region_letter VALUES("10001833","卫滨区","410703","10000190","3","W");
INSERT INTO cmf_region_letter VALUES("10001834","凤泉区","410704","10000190","3","F");
INSERT INTO cmf_region_letter VALUES("10001835","牧野区","410711","10000190","3","M");
INSERT INTO cmf_region_letter VALUES("10001836","新乡县","410721","10000190","3","X");
INSERT INTO cmf_region_letter VALUES("10001837","获嘉县","410724","10000190","3","H");
INSERT INTO cmf_region_letter VALUES("10001838","原阳县","410725","10000190","3","Y");
INSERT INTO cmf_region_letter VALUES("10001839","延津县","410726","10000190","3","Y");
INSERT INTO cmf_region_letter VALUES("10001840","封丘县","410727","10000190","3","F");
INSERT INTO cmf_region_letter VALUES("10001841","长垣县","410728","10000190","3","C");
INSERT INTO cmf_region_letter VALUES("10001842","卫辉市","410781","10000190","3","W");
INSERT INTO cmf_region_letter VALUES("10001843","辉县市","410782","10000190","3","H");
INSERT INTO cmf_region_letter VALUES("10001844","解放区","410802","10000191","3","J");
INSERT INTO cmf_region_letter VALUES("10001845","中站区","410803","10000191","3","Z");
INSERT INTO cmf_region_letter VALUES("10001846","马村区","410804","10000191","3","M");
INSERT INTO cmf_region_letter VALUES("10001847","山阳区","410811","10000191","3","S");
INSERT INTO cmf_region_letter VALUES("10001848","修武县","410821","10000191","3","X");
INSERT INTO cmf_region_letter VALUES("10001849","博爱县","410822","10000191","3","B");
INSERT INTO cmf_region_letter VALUES("10001850","武陟县","410823","10000191","3","W");
INSERT INTO cmf_region_letter VALUES("10001851","温县","410825","10000191","3","W");
INSERT INTO cmf_region_letter VALUES("10001852","沁阳市","410882","10000191","3","Q");
INSERT INTO cmf_region_letter VALUES("10001853","孟州市","410883","10000191","3","M");
INSERT INTO cmf_region_letter VALUES("10001854","华龙区","410902","10000192","3","H");
INSERT INTO cmf_region_letter VALUES("10001855","清丰县","410922","10000192","3","Q");
INSERT INTO cmf_region_letter VALUES("10001856","南乐县","410923","10000192","3","N");
INSERT INTO cmf_region_letter VALUES("10001857","范县","410926","10000192","3","F");
INSERT INTO cmf_region_letter VALUES("10001858","台前县","410927","10000192","3","T");
INSERT INTO cmf_region_letter VALUES("10001859","濮阳县","410928","10000192","3","P");
INSERT INTO cmf_region_letter VALUES("10001860","魏都区","411002","10000193","3","W");
INSERT INTO cmf_region_letter VALUES("10001861","建安区","411003","10000193","3","J");
INSERT INTO cmf_region_letter VALUES("10001862","鄢陵县","411024","10000193","3","Y");
INSERT INTO cmf_region_letter VALUES("10001863","襄城县","411025","10000193","3","X");
INSERT INTO cmf_region_letter VALUES("10001864","禹州市","411081","10000193","3","Y");
INSERT INTO cmf_region_letter VALUES("10001865","长葛市","411082","10000193","3","C");
INSERT INTO cmf_region_letter VALUES("10001866","源汇区","411102","10000194","3","Y");
INSERT INTO cmf_region_letter VALUES("10001867","郾城区","411103","10000194","3","Y");
INSERT INTO cmf_region_letter VALUES("10001868","召陵区","411104","10000194","3","S");
INSERT INTO cmf_region_letter VALUES("10001869","舞阳县","411121","10000194","3","W");
INSERT INTO cmf_region_letter VALUES("10001870","临颍县","411122","10000194","3","L");
INSERT INTO cmf_region_letter VALUES("10001871","湖滨区","411202","10000195","3","H");
INSERT INTO cmf_region_letter VALUES("10001872","陕州区","411203","10000195","3","S");
INSERT INTO cmf_region_letter VALUES("10001873","渑池县","411221","10000195","3","M");
INSERT INTO cmf_region_letter VALUES("10001874","卢氏县","411224","10000195","3","L");
INSERT INTO cmf_region_letter VALUES("10001875","义马市","411281","10000195","3","Y");
INSERT INTO cmf_region_letter VALUES("10001876","灵宝市","411282","10000195","3","L");
INSERT INTO cmf_region_letter VALUES("10001877","宛城区","411302","10000196","3","W");
INSERT INTO cmf_region_letter VALUES("10001878","卧龙区","411303","10000196","3","W");
INSERT INTO cmf_region_letter VALUES("10001879","南召县","411321","10000196","3","N");
INSERT INTO cmf_region_letter VALUES("10001880","方城县","411322","10000196","3","F");
INSERT INTO cmf_region_letter VALUES("10001881","西峡县","411323","10000196","3","X");
INSERT INTO cmf_region_letter VALUES("10001882","镇平县","411324","10000196","3","Z");
INSERT INTO cmf_region_letter VALUES("10001883","内乡县","411325","10000196","3","N");
INSERT INTO cmf_region_letter VALUES("10001884","淅川县","411326","10000196","3","X");
INSERT INTO cmf_region_letter VALUES("10001885","社旗县","411327","10000196","3","S");
INSERT INTO cmf_region_letter VALUES("10001886","唐河县","411328","10000196","3","T");
INSERT INTO cmf_region_letter VALUES("10001887","新野县","411329","10000196","3","X");
INSERT INTO cmf_region_letter VALUES("10001888","桐柏县","411330","10000196","3","T");
INSERT INTO cmf_region_letter VALUES("10001889","邓州市","411381","10000196","3","D");
INSERT INTO cmf_region_letter VALUES("10001890","梁园区","411402","10000197","3","L");
INSERT INTO cmf_region_letter VALUES("10001891","睢阳区","411403","10000197","3","S");
INSERT INTO cmf_region_letter VALUES("10001892","民权县","411421","10000197","3","M");
INSERT INTO cmf_region_letter VALUES("10001893","睢县","411422","10000197","3","S");
INSERT INTO cmf_region_letter VALUES("10001894","宁陵县","411423","10000197","3","N");
INSERT INTO cmf_region_letter VALUES("10001895","柘城县","411424","10000197","3","Z");
INSERT INTO cmf_region_letter VALUES("10001896","虞城县","411425","10000197","3","Y");
INSERT INTO cmf_region_letter VALUES("10001897","夏邑县","411426","10000197","3","X");
INSERT INTO cmf_region_letter VALUES("10001898","永城市","411481","10000197","3","Y");
INSERT INTO cmf_region_letter VALUES("10001899","浉河区","411502","10000198","3","S");
INSERT INTO cmf_region_letter VALUES("10001900","平桥区","411503","10000198","3","P");
INSERT INTO cmf_region_letter VALUES("10001901","罗山县","411521","10000198","3","L");
INSERT INTO cmf_region_letter VALUES("10001902","光山县","411522","10000198","3","G");
INSERT INTO cmf_region_letter VALUES("10001903","新县","411523","10000198","3","X");
INSERT INTO cmf_region_letter VALUES("10001904","商城县","411524","10000198","3","S");
INSERT INTO cmf_region_letter VALUES("10001905","固始县","411525","10000198","3","G");
INSERT INTO cmf_region_letter VALUES("10001906","潢川县","411526","10000198","3","H");
INSERT INTO cmf_region_letter VALUES("10001907","淮滨县","411527","10000198","3","H");
INSERT INTO cmf_region_letter VALUES("10001908","息县","411528","10000198","3","X");
INSERT INTO cmf_region_letter VALUES("10001909","川汇区","411602","10000199","3","C");
INSERT INTO cmf_region_letter VALUES("10001910","扶沟县","411621","10000199","3","F");
INSERT INTO cmf_region_letter VALUES("10001911","西华县","411622","10000199","3","X");
INSERT INTO cmf_region_letter VALUES("10001912","商水县","411623","10000199","3","S");
INSERT INTO cmf_region_letter VALUES("10001913","沈丘县","411624","10000199","3","S");
INSERT INTO cmf_region_letter VALUES("10001914","郸城县","411625","10000199","3","D");
INSERT INTO cmf_region_letter VALUES("10001915","淮阳县","411626","10000199","3","H");
INSERT INTO cmf_region_letter VALUES("10001916","太康县","411627","10000199","3","T");
INSERT INTO cmf_region_letter VALUES("10001917","鹿邑县","411628","10000199","3","L");
INSERT INTO cmf_region_letter VALUES("10001918","项城市","411681","10000199","3","X");
INSERT INTO cmf_region_letter VALUES("10001919","经济开发区","411690","10000199","3","J");
INSERT INTO cmf_region_letter VALUES("10001920","驿城区","411702","10000200","3","Y");
INSERT INTO cmf_region_letter VALUES("10001921","西平县","411721","10000200","3","X");
INSERT INTO cmf_region_letter VALUES("10001922","上蔡县","411722","10000200","3","S");
INSERT INTO cmf_region_letter VALUES("10001923","平舆县","411723","10000200","3","P");
INSERT INTO cmf_region_letter VALUES("10001924","正阳县","411724","10000200","3","Z");
INSERT INTO cmf_region_letter VALUES("10001925","确山县","411725","10000200","3","Q");
INSERT INTO cmf_region_letter VALUES("10001926","泌阳县","411726","10000200","3","B");
INSERT INTO cmf_region_letter VALUES("10001927","汝南县","411727","10000200","3","R");
INSERT INTO cmf_region_letter VALUES("10001928","遂平县","411728","10000200","3","S");
INSERT INTO cmf_region_letter VALUES("10001929","新蔡县","411729","10000200","3","X");
INSERT INTO cmf_region_letter VALUES("10001930","济源市","419001","10000201","3","J");
INSERT INTO cmf_region_letter VALUES("10001931","江岸区","420102","10000202","3","J");
INSERT INTO cmf_region_letter VALUES("10001932","江汉区","420103","10000202","3","J");
INSERT INTO cmf_region_letter VALUES("10001933","硚口区","420104","10000202","3","Q");
INSERT INTO cmf_region_letter VALUES("10001934","汉阳区","420105","10000202","3","H");
INSERT INTO cmf_region_letter VALUES("10001935","武昌区","420106","10000202","3","W");
INSERT INTO cmf_region_letter VALUES("10001936","青山区","420107","10000202","3","Q");
INSERT INTO cmf_region_letter VALUES("10001937","洪山区","420111","10000202","3","H");
INSERT INTO cmf_region_letter VALUES("10001938","东西湖区","420112","10000202","3","D");
INSERT INTO cmf_region_letter VALUES("10001939","汉南区","420113","10000202","3","H");
INSERT INTO cmf_region_letter VALUES("10001940","蔡甸区","420114","10000202","3","C");
INSERT INTO cmf_region_letter VALUES("10001941","江夏区","420115","10000202","3","J");
INSERT INTO cmf_region_letter VALUES("10001942","黄陂区","420116","10000202","3","H");
INSERT INTO cmf_region_letter VALUES("10001943","新洲区","420117","10000202","3","X");
INSERT INTO cmf_region_letter VALUES("10001944","黄石港区","420202","10000203","3","H");
INSERT INTO cmf_region_letter VALUES("10001945","西塞山区","420203","10000203","3","X");
INSERT INTO cmf_region_letter VALUES("10001946","下陆区","420204","10000203","3","X");
INSERT INTO cmf_region_letter VALUES("10001947","铁山区","420205","10000203","3","T");
INSERT INTO cmf_region_letter VALUES("10001948","阳新县","420222","10000203","3","Y");
INSERT INTO cmf_region_letter VALUES("10001949","大冶市","420281","10000203","3","D");
INSERT INTO cmf_region_letter VALUES("10001950","茅箭区","420302","10000204","3","M");
INSERT INTO cmf_region_letter VALUES("10001951","张湾区","420303","10000204","3","Z");
INSERT INTO cmf_region_letter VALUES("10001952","郧阳区","420304","10000204","3","Y");
INSERT INTO cmf_region_letter VALUES("10001953","郧西县","420322","10000204","3","Y");
INSERT INTO cmf_region_letter VALUES("10001954","竹山县","420323","10000204","3","Z");
INSERT INTO cmf_region_letter VALUES("10001955","竹溪县","420324","10000204","3","Z");
INSERT INTO cmf_region_letter VALUES("10001956","房县","420325","10000204","3","F");
INSERT INTO cmf_region_letter VALUES("10001957","丹江口市","420381","10000204","3","D");
INSERT INTO cmf_region_letter VALUES("10001958","西陵区","420502","10000205","3","X");
INSERT INTO cmf_region_letter VALUES("10001959","伍家岗区","420503","10000205","3","W");
INSERT INTO cmf_region_letter VALUES("10001960","点军区","420504","10000205","3","D");
INSERT INTO cmf_region_letter VALUES("10001961","猇亭区","420505","10000205","3","X");
INSERT INTO cmf_region_letter VALUES("10001962","夷陵区","420506","10000205","3","Y");
INSERT INTO cmf_region_letter VALUES("10001963","远安县","420525","10000205","3","Y");
INSERT INTO cmf_region_letter VALUES("10001964","兴山县","420526","10000205","3","X");
INSERT INTO cmf_region_letter VALUES("10001965","秭归县","420527","10000205","3","Z");
INSERT INTO cmf_region_letter VALUES("10001966","长阳土家族自治县","420528","10000205","3","C");
INSERT INTO cmf_region_letter VALUES("10001967","五峰土家族自治县","420529","10000205","3","W");
INSERT INTO cmf_region_letter VALUES("10001968","宜都市","420581","10000205","3","Y");
INSERT INTO cmf_region_letter VALUES("10001969","当阳市","420582","10000205","3","D");
INSERT INTO cmf_region_letter VALUES("10001970","枝江市","420583","10000205","3","Z");
INSERT INTO cmf_region_letter VALUES("10001971","经济开发区","420590","10000205","3","J");
INSERT INTO cmf_region_letter VALUES("10001972","襄城区","420602","10000206","3","X");
INSERT INTO cmf_region_letter VALUES("10001973","樊城区","420606","10000206","3","F");
INSERT INTO cmf_region_letter VALUES("10001974","襄州区","420607","10000206","3","X");
INSERT INTO cmf_region_letter VALUES("10001975","南漳县","420624","10000206","3","N");
INSERT INTO cmf_region_letter VALUES("10001976","谷城县","420625","10000206","3","G");
INSERT INTO cmf_region_letter VALUES("10001977","保康县","420626","10000206","3","B");
INSERT INTO cmf_region_letter VALUES("10001978","老河口市","420682","10000206","3","L");
INSERT INTO cmf_region_letter VALUES("10001979","枣阳市","420683","10000206","3","Z");
INSERT INTO cmf_region_letter VALUES("10001980","宜城市","420684","10000206","3","Y");
INSERT INTO cmf_region_letter VALUES("10001981","梁子湖区","420702","10000207","3","L");
INSERT INTO cmf_region_letter VALUES("10001982","华容区","420703","10000207","3","H");
INSERT INTO cmf_region_letter VALUES("10001983","鄂城区","420704","10000207","3","E");
INSERT INTO cmf_region_letter VALUES("10001984","东宝区","420802","10000208","3","D");
INSERT INTO cmf_region_letter VALUES("10001985","掇刀区","420804","10000208","3","D");
INSERT INTO cmf_region_letter VALUES("10001986","沙洋县","420822","10000208","3","S");
INSERT INTO cmf_region_letter VALUES("10001987","钟祥市","420881","10000208","3","Z");
INSERT INTO cmf_region_letter VALUES("10001988","京山市","420882","10000208","3","J");
INSERT INTO cmf_region_letter VALUES("10001989","孝南区","420902","10000209","3","X");
INSERT INTO cmf_region_letter VALUES("10001990","孝昌县","420921","10000209","3","X");
INSERT INTO cmf_region_letter VALUES("10001991","大悟县","420922","10000209","3","D");
INSERT INTO cmf_region_letter VALUES("10001992","云梦县","420923","10000209","3","Y");
INSERT INTO cmf_region_letter VALUES("10001993","应城市","420981","10000209","3","Y");
INSERT INTO cmf_region_letter VALUES("10001994","安陆市","420982","10000209","3","A");
INSERT INTO cmf_region_letter VALUES("10001995","汉川市","420984","10000209","3","H");
INSERT INTO cmf_region_letter VALUES("10001996","沙市区","421002","10000210","3","S");
INSERT INTO cmf_region_letter VALUES("10001997","荆州区","421003","10000210","3","J");
INSERT INTO cmf_region_letter VALUES("10001998","公安县","421022","10000210","3","G");
INSERT INTO cmf_region_letter VALUES("10001999","监利县","421023","10000210","3","J");
INSERT INTO cmf_region_letter VALUES("10002000","江陵县","421024","10000210","3","J");
INSERT INTO cmf_region_letter VALUES("10002001","石首市","421081","10000210","3","S");
INSERT INTO cmf_region_letter VALUES("10002002","洪湖市","421083","10000210","3","H");
INSERT INTO cmf_region_letter VALUES("10002003","松滋市","421087","10000210","3","S");
INSERT INTO cmf_region_letter VALUES("10002004","黄州区","421102","10000211","3","H");
INSERT INTO cmf_region_letter VALUES("10002005","团风县","421121","10000211","3","T");
INSERT INTO cmf_region_letter VALUES("10002006","红安县","421122","10000211","3","H");
INSERT INTO cmf_region_letter VALUES("10002007","罗田县","421123","10000211","3","L");
INSERT INTO cmf_region_letter VALUES("10002008","英山县","421124","10000211","3","Y");
INSERT INTO cmf_region_letter VALUES("10002009","浠水县","421125","10000211","3","X");
INSERT INTO cmf_region_letter VALUES("10002010","蕲春县","421126","10000211","3","Q");
INSERT INTO cmf_region_letter VALUES("10002011","黄梅县","421127","10000211","3","H");
INSERT INTO cmf_region_letter VALUES("10002012","麻城市","421181","10000211","3","M");
INSERT INTO cmf_region_letter VALUES("10002013","武穴市","421182","10000211","3","W");
INSERT INTO cmf_region_letter VALUES("10002014","咸安区","421202","10000212","3","X");
INSERT INTO cmf_region_letter VALUES("10002015","嘉鱼县","421221","10000212","3","J");
INSERT INTO cmf_region_letter VALUES("10002016","通城县","421222","10000212","3","T");
INSERT INTO cmf_region_letter VALUES("10002017","崇阳县","421223","10000212","3","C");
INSERT INTO cmf_region_letter VALUES("10002018","通山县","421224","10000212","3","T");
INSERT INTO cmf_region_letter VALUES("10002019","赤壁市","421281","10000212","3","C");
INSERT INTO cmf_region_letter VALUES("10002020","曾都区","421303","10000213","3","Z");
INSERT INTO cmf_region_letter VALUES("10002021","随县","421321","10000213","3","S");
INSERT INTO cmf_region_letter VALUES("10002022","广水市","421381","10000213","3","G");
INSERT INTO cmf_region_letter VALUES("10002023","恩施市","422801","10000214","3","E");
INSERT INTO cmf_region_letter VALUES("10002024","利川市","422802","10000214","3","L");
INSERT INTO cmf_region_letter VALUES("10002025","建始县","422822","10000214","3","J");
INSERT INTO cmf_region_letter VALUES("10002026","巴东县","422823","10000214","3","B");
INSERT INTO cmf_region_letter VALUES("10002027","宣恩县","422825","10000214","3","X");
INSERT INTO cmf_region_letter VALUES("10002028","咸丰县","422826","10000214","3","X");
INSERT INTO cmf_region_letter VALUES("10002029","来凤县","422827","10000214","3","L");
INSERT INTO cmf_region_letter VALUES("10002030","鹤峰县","422828","10000214","3","H");
INSERT INTO cmf_region_letter VALUES("10002031","仙桃市","429004","10000215","3","X");
INSERT INTO cmf_region_letter VALUES("10002032","潜江市","429005","10000215","3","Q");
INSERT INTO cmf_region_letter VALUES("10002033","天门市","429006","10000215","3","T");
INSERT INTO cmf_region_letter VALUES("10002034","神农架林区","429021","10000215","3","S");
INSERT INTO cmf_region_letter VALUES("10002035","芙蓉区","430102","10000216","3","F");
INSERT INTO cmf_region_letter VALUES("10002036","天心区","430103","10000216","3","T");
INSERT INTO cmf_region_letter VALUES("10002037","岳麓区","430104","10000216","3","Y");
INSERT INTO cmf_region_letter VALUES("10002038","开福区","430105","10000216","3","K");
INSERT INTO cmf_region_letter VALUES("10002039","雨花区","430111","10000216","3","Y");
INSERT INTO cmf_region_letter VALUES("10002040","望城区","430112","10000216","3","W");
INSERT INTO cmf_region_letter VALUES("10002041","长沙县","430121","10000216","3","C");
INSERT INTO cmf_region_letter VALUES("10002042","浏阳市","430181","10000216","3","L");
INSERT INTO cmf_region_letter VALUES("10002043","宁乡市","430182","10000216","3","N");
INSERT INTO cmf_region_letter VALUES("10002044","荷塘区","430202","10000217","3","H");
INSERT INTO cmf_region_letter VALUES("10002045","芦淞区","430203","10000217","3","L");
INSERT INTO cmf_region_letter VALUES("10002046","石峰区","430204","10000217","3","S");
INSERT INTO cmf_region_letter VALUES("10002047","天元区","430211","10000217","3","T");
INSERT INTO cmf_region_letter VALUES("10002048","渌口区","430212","10000217","3","L");
INSERT INTO cmf_region_letter VALUES("10002049","攸县","430223","10000217","3","Y");
INSERT INTO cmf_region_letter VALUES("10002050","茶陵县","430224","10000217","3","C");
INSERT INTO cmf_region_letter VALUES("10002051","炎陵县","430225","10000217","3","Y");
INSERT INTO cmf_region_letter VALUES("10002052","醴陵市","430281","10000217","3","L");
INSERT INTO cmf_region_letter VALUES("10002053","雨湖区","430302","10000218","3","Y");
INSERT INTO cmf_region_letter VALUES("10002054","岳塘区","430304","10000218","3","Y");
INSERT INTO cmf_region_letter VALUES("10002055","湘潭县","430321","10000218","3","X");
INSERT INTO cmf_region_letter VALUES("10002056","湘乡市","430381","10000218","3","X");
INSERT INTO cmf_region_letter VALUES("10002057","韶山市","430382","10000218","3","S");
INSERT INTO cmf_region_letter VALUES("10002058","珠晖区","430405","10000219","3","Z");
INSERT INTO cmf_region_letter VALUES("10002059","雁峰区","430406","10000219","3","Y");
INSERT INTO cmf_region_letter VALUES("10002060","石鼓区","430407","10000219","3","D");
INSERT INTO cmf_region_letter VALUES("10002061","蒸湘区","430408","10000219","3","Z");
INSERT INTO cmf_region_letter VALUES("10002062","南岳区","430412","10000219","3","N");
INSERT INTO cmf_region_letter VALUES("10002063","衡阳县","430421","10000219","3","H");
INSERT INTO cmf_region_letter VALUES("10002064","衡南县","430422","10000219","3","H");
INSERT INTO cmf_region_letter VALUES("10002065","衡山县","430423","10000219","3","H");
INSERT INTO cmf_region_letter VALUES("10002066","衡东县","430424","10000219","3","H");
INSERT INTO cmf_region_letter VALUES("10002067","祁东县","430426","10000219","3","Q");
INSERT INTO cmf_region_letter VALUES("10002068","耒阳市","430481","10000219","3","L");
INSERT INTO cmf_region_letter VALUES("10002069","常宁市","430482","10000219","3","C");
INSERT INTO cmf_region_letter VALUES("10002070","双清区","430502","10000220","3","S");
INSERT INTO cmf_region_letter VALUES("10002071","大祥区","430503","10000220","3","D");
INSERT INTO cmf_region_letter VALUES("10002072","北塔区","430511","10000220","3","B");
INSERT INTO cmf_region_letter VALUES("10002073","邵东县","430521","10000220","3","S");
INSERT INTO cmf_region_letter VALUES("10002074","新邵县","430522","10000220","3","X");
INSERT INTO cmf_region_letter VALUES("10002075","邵阳县","430523","10000220","3","S");
INSERT INTO cmf_region_letter VALUES("10002076","隆回县","430524","10000220","3","L");
INSERT INTO cmf_region_letter VALUES("10002077","洞口县","430525","10000220","3","D");
INSERT INTO cmf_region_letter VALUES("10002078","绥宁县","430527","10000220","3","S");
INSERT INTO cmf_region_letter VALUES("10002079","新宁县","430528","10000220","3","X");
INSERT INTO cmf_region_letter VALUES("10002080","城步苗族自治县","430529","10000220","3","C");
INSERT INTO cmf_region_letter VALUES("10002081","武冈市","430581","10000220","3","W");
INSERT INTO cmf_region_letter VALUES("10002082","岳阳楼区","430602","10000221","3","Y");
INSERT INTO cmf_region_letter VALUES("10002083","云溪区","430603","10000221","3","Y");
INSERT INTO cmf_region_letter VALUES("10002084","君山区","430611","10000221","3","J");
INSERT INTO cmf_region_letter VALUES("10002085","岳阳县","430621","10000221","3","Y");
INSERT INTO cmf_region_letter VALUES("10002086","华容县","430623","10000221","3","H");
INSERT INTO cmf_region_letter VALUES("10002087","湘阴县","430624","10000221","3","X");
INSERT INTO cmf_region_letter VALUES("10002088","平江县","430626","10000221","3","P");
INSERT INTO cmf_region_letter VALUES("10002089","汨罗市","430681","10000221","3","M");
INSERT INTO cmf_region_letter VALUES("10002090","临湘市","430682","10000221","3","L");
INSERT INTO cmf_region_letter VALUES("10002091","武陵区","430702","10000222","3","W");
INSERT INTO cmf_region_letter VALUES("10002092","鼎城区","430703","10000222","3","D");
INSERT INTO cmf_region_letter VALUES("10002093","安乡县","430721","10000222","3","A");
INSERT INTO cmf_region_letter VALUES("10002094","汉寿县","430722","10000222","3","H");
INSERT INTO cmf_region_letter VALUES("10002095","澧县","430723","10000222","3","L");
INSERT INTO cmf_region_letter VALUES("10002096","临澧县","430724","10000222","3","L");
INSERT INTO cmf_region_letter VALUES("10002097","桃源县","430725","10000222","3","T");
INSERT INTO cmf_region_letter VALUES("10002098","石门县","430726","10000222","3","S");
INSERT INTO cmf_region_letter VALUES("10002099","津市市","430781","10000222","3","J");
INSERT INTO cmf_region_letter VALUES("10002100","永定区","430802","10000223","3","Y");
INSERT INTO cmf_region_letter VALUES("10002101","武陵源区","430811","10000223","3","W");
INSERT INTO cmf_region_letter VALUES("10002102","慈利县","430821","10000223","3","C");
INSERT INTO cmf_region_letter VALUES("10002103","桑植县","430822","10000223","3","S");
INSERT INTO cmf_region_letter VALUES("10002104","资阳区","430902","10000224","3","Z");
INSERT INTO cmf_region_letter VALUES("10002105","赫山区","430903","10000224","3","H");
INSERT INTO cmf_region_letter VALUES("10002106","南县","430921","10000224","3","N");
INSERT INTO cmf_region_letter VALUES("10002107","桃江县","430922","10000224","3","T");
INSERT INTO cmf_region_letter VALUES("10002108","安化县","430923","10000224","3","A");
INSERT INTO cmf_region_letter VALUES("10002109","沅江市","430981","10000224","3","Y");
INSERT INTO cmf_region_letter VALUES("10002110","北湖区","431002","10000225","3","B");
INSERT INTO cmf_region_letter VALUES("10002111","苏仙区","431003","10000225","3","S");
INSERT INTO cmf_region_letter VALUES("10002112","桂阳县","431021","10000225","3","G");
INSERT INTO cmf_region_letter VALUES("10002113","宜章县","431022","10000225","3","Y");
INSERT INTO cmf_region_letter VALUES("10002114","永兴县","431023","10000225","3","Y");
INSERT INTO cmf_region_letter VALUES("10002115","嘉禾县","431024","10000225","3","J");
INSERT INTO cmf_region_letter VALUES("10002116","临武县","431025","10000225","3","L");
INSERT INTO cmf_region_letter VALUES("10002117","汝城县","431026","10000225","3","R");
INSERT INTO cmf_region_letter VALUES("10002118","桂东县","431027","10000225","3","G");
INSERT INTO cmf_region_letter VALUES("10002119","安仁县","431028","10000225","3","A");
INSERT INTO cmf_region_letter VALUES("10002120","资兴市","431081","10000225","3","Z");
INSERT INTO cmf_region_letter VALUES("10002121","零陵区","431102","10000226","3","L");
INSERT INTO cmf_region_letter VALUES("10002122","冷水滩区","431103","10000226","3","L");
INSERT INTO cmf_region_letter VALUES("10002123","祁阳县","431121","10000226","3","Q");
INSERT INTO cmf_region_letter VALUES("10002124","东安县","431122","10000226","3","D");
INSERT INTO cmf_region_letter VALUES("10002125","双牌县","431123","10000226","3","S");
INSERT INTO cmf_region_letter VALUES("10002126","道县","431124","10000226","3","D");
INSERT INTO cmf_region_letter VALUES("10002127","江永县","431125","10000226","3","J");
INSERT INTO cmf_region_letter VALUES("10002128","宁远县","431126","10000226","3","N");
INSERT INTO cmf_region_letter VALUES("10002129","蓝山县","431127","10000226","3","L");
INSERT INTO cmf_region_letter VALUES("10002130","新田县","431128","10000226","3","X");
INSERT INTO cmf_region_letter VALUES("10002131","江华瑶族自治县","431129","10000226","3","J");
INSERT INTO cmf_region_letter VALUES("10002132","鹤城区","431202","10000227","3","H");
INSERT INTO cmf_region_letter VALUES("10002133","中方县","431221","10000227","3","Z");
INSERT INTO cmf_region_letter VALUES("10002134","沅陵县","431222","10000227","3","Y");
INSERT INTO cmf_region_letter VALUES("10002135","辰溪县","431223","10000227","3","C");
INSERT INTO cmf_region_letter VALUES("10002136","溆浦县","431224","10000227","3","X");
INSERT INTO cmf_region_letter VALUES("10002137","会同县","431225","10000227","3","H");
INSERT INTO cmf_region_letter VALUES("10002138","麻阳苗族自治县","431226","10000227","3","M");
INSERT INTO cmf_region_letter VALUES("10002139","新晃侗族自治县","431227","10000227","3","X");
INSERT INTO cmf_region_letter VALUES("10002140","芷江侗族自治县","431228","10000227","3","Z");
INSERT INTO cmf_region_letter VALUES("10002141","靖州苗族侗族自治县","431229","10000227","3","J");
INSERT INTO cmf_region_letter VALUES("10002142","通道侗族自治县","431230","10000227","3","T");
INSERT INTO cmf_region_letter VALUES("10002143","洪江市","431281","10000227","3","H");
INSERT INTO cmf_region_letter VALUES("10002144","娄星区","431302","10000228","3","L");
INSERT INTO cmf_region_letter VALUES("10002145","双峰县","431321","10000228","3","S");
INSERT INTO cmf_region_letter VALUES("10002146","新化县","431322","10000228","3","X");
INSERT INTO cmf_region_letter VALUES("10002147","冷水江市","431381","10000228","3","L");
INSERT INTO cmf_region_letter VALUES("10002148","涟源市","431382","10000228","3","L");
INSERT INTO cmf_region_letter VALUES("10002149","吉首市","433101","10000229","3","J");
INSERT INTO cmf_region_letter VALUES("10002150","泸溪县","433122","10000229","3","L");
INSERT INTO cmf_region_letter VALUES("10002151","凤凰县","433123","10000229","3","F");
INSERT INTO cmf_region_letter VALUES("10002152","花垣县","433124","10000229","3","H");
INSERT INTO cmf_region_letter VALUES("10002153","保靖县","433125","10000229","3","B");
INSERT INTO cmf_region_letter VALUES("10002154","古丈县","433126","10000229","3","G");
INSERT INTO cmf_region_letter VALUES("10002155","永顺县","433127","10000229","3","Y");
INSERT INTO cmf_region_letter VALUES("10002156","龙山县","433130","10000229","3","L");
INSERT INTO cmf_region_letter VALUES("10002157","荔湾区","440103","10000230","3","L");
INSERT INTO cmf_region_letter VALUES("10002158","越秀区","440104","10000230","3","Y");
INSERT INTO cmf_region_letter VALUES("10002159","海珠区","440105","10000230","3","H");
INSERT INTO cmf_region_letter VALUES("10002160","天河区","440106","10000230","3","T");
INSERT INTO cmf_region_letter VALUES("10002161","白云区","440111","10000230","3","B");
INSERT INTO cmf_region_letter VALUES("10002162","黄埔区","440112","10000230","3","H");
INSERT INTO cmf_region_letter VALUES("10002163","番禺区","440113","10000230","3","P");
INSERT INTO cmf_region_letter VALUES("10002164","花都区","440114","10000230","3","H");
INSERT INTO cmf_region_letter VALUES("10002165","南沙区","440115","10000230","3","N");
INSERT INTO cmf_region_letter VALUES("10002166","从化区","440117","10000230","3","C");
INSERT INTO cmf_region_letter VALUES("10002167","增城区","440118","10000230","3","Z");
INSERT INTO cmf_region_letter VALUES("10002168","武江区","440203","10000231","3","W");
INSERT INTO cmf_region_letter VALUES("10002169","浈江区","440204","10000231","3","Z");
INSERT INTO cmf_region_letter VALUES("10002170","曲江区","440205","10000231","3","Q");
INSERT INTO cmf_region_letter VALUES("10002171","始兴县","440222","10000231","3","S");
INSERT INTO cmf_region_letter VALUES("10002172","仁化县","440224","10000231","3","R");
INSERT INTO cmf_region_letter VALUES("10002173","翁源县","440229","10000231","3","W");
INSERT INTO cmf_region_letter VALUES("10002174","乳源瑶族自治县","440232","10000231","3","R");
INSERT INTO cmf_region_letter VALUES("10002175","新丰县","440233","10000231","3","X");
INSERT INTO cmf_region_letter VALUES("10002176","乐昌市","440281","10000231","3","L");
INSERT INTO cmf_region_letter VALUES("10002177","南雄市","440282","10000231","3","N");
INSERT INTO cmf_region_letter VALUES("10002178","罗湖区","440303","10000232","3","L");
INSERT INTO cmf_region_letter VALUES("10002179","福田区","440304","10000232","3","F");
INSERT INTO cmf_region_letter VALUES("10002180","南山区","440305","10000232","3","N");
INSERT INTO cmf_region_letter VALUES("10002181","宝安区","440306","10000232","3","B");
INSERT INTO cmf_region_letter VALUES("10002182","龙岗区","440307","10000232","3","L");
INSERT INTO cmf_region_letter VALUES("10002183","盐田区","440308","10000232","3","Y");
INSERT INTO cmf_region_letter VALUES("10002184","龙华区","440309","10000232","3","L");
INSERT INTO cmf_region_letter VALUES("10002185","坪山区","440310","10000232","3","P");
INSERT INTO cmf_region_letter VALUES("10002186","光明区","440311","10000232","3","G");
INSERT INTO cmf_region_letter VALUES("10002187","香洲区","440402","10000233","3","X");
INSERT INTO cmf_region_letter VALUES("10002188","斗门区","440403","10000233","3","D");
INSERT INTO cmf_region_letter VALUES("10002189","金湾区","440404","10000233","3","J");
INSERT INTO cmf_region_letter VALUES("10002190","龙湖区","440507","10000234","3","L");
INSERT INTO cmf_region_letter VALUES("10002191","金平区","440511","10000234","3","J");
INSERT INTO cmf_region_letter VALUES("10002192","濠江区","440512","10000234","3","H");
INSERT INTO cmf_region_letter VALUES("10002193","潮阳区","440513","10000234","3","C");
INSERT INTO cmf_region_letter VALUES("10002194","潮南区","440514","10000234","3","C");
INSERT INTO cmf_region_letter VALUES("10002195","澄海区","440515","10000234","3","C");
INSERT INTO cmf_region_letter VALUES("10002196","南澳县","440523","10000234","3","N");
INSERT INTO cmf_region_letter VALUES("10002197","禅城区","440604","10000235","3","C");
INSERT INTO cmf_region_letter VALUES("10002198","南海区","440605","10000235","3","N");
INSERT INTO cmf_region_letter VALUES("10002199","顺德区","440606","10000235","3","S");
INSERT INTO cmf_region_letter VALUES("10002200","三水区","440607","10000235","3","S");
INSERT INTO cmf_region_letter VALUES("10002201","高明区","440608","10000235","3","G");
INSERT INTO cmf_region_letter VALUES("10002202","蓬江区","440703","10000236","3","P");
INSERT INTO cmf_region_letter VALUES("10002203","江海区","440704","10000236","3","J");
INSERT INTO cmf_region_letter VALUES("10002204","新会区","440705","10000236","3","X");
INSERT INTO cmf_region_letter VALUES("10002205","台山市","440781","10000236","3","T");
INSERT INTO cmf_region_letter VALUES("10002206","开平市","440783","10000236","3","K");
INSERT INTO cmf_region_letter VALUES("10002207","鹤山市","440784","10000236","3","H");
INSERT INTO cmf_region_letter VALUES("10002208","恩平市","440785","10000236","3","E");
INSERT INTO cmf_region_letter VALUES("10002209","赤坎区","440802","10000237","3","C");
INSERT INTO cmf_region_letter VALUES("10002210","霞山区","440803","10000237","3","X");
INSERT INTO cmf_region_letter VALUES("10002211","坡头区","440804","10000237","3","P");
INSERT INTO cmf_region_letter VALUES("10002212","麻章区","440811","10000237","3","M");
INSERT INTO cmf_region_letter VALUES("10002213","遂溪县","440823","10000237","3","S");
INSERT INTO cmf_region_letter VALUES("10002214","徐闻县","440825","10000237","3","X");
INSERT INTO cmf_region_letter VALUES("10002215","廉江市","440881","10000237","3","L");
INSERT INTO cmf_region_letter VALUES("10002216","雷州市","440882","10000237","3","L");
INSERT INTO cmf_region_letter VALUES("10002217","吴川市","440883","10000237","3","W");
INSERT INTO cmf_region_letter VALUES("10002218","经济技术开发区","440890","10000237","3","J");
INSERT INTO cmf_region_letter VALUES("10002219","茂南区","440902","10000238","3","M");
INSERT INTO cmf_region_letter VALUES("10002220","电白区","440904","10000238","3","D");
INSERT INTO cmf_region_letter VALUES("10002221","高州市","440981","10000238","3","G");
INSERT INTO cmf_region_letter VALUES("10002222","化州市","440982","10000238","3","H");
INSERT INTO cmf_region_letter VALUES("10002223","信宜市","440983","10000238","3","X");
INSERT INTO cmf_region_letter VALUES("10002224","端州区","441202","10000239","3","D");
INSERT INTO cmf_region_letter VALUES("10002225","鼎湖区","441203","10000239","3","D");
INSERT INTO cmf_region_letter VALUES("10002226","高要区","441204","10000239","3","G");
INSERT INTO cmf_region_letter VALUES("10002227","广宁县","441223","10000239","3","G");
INSERT INTO cmf_region_letter VALUES("10002228","怀集县","441224","10000239","3","H");
INSERT INTO cmf_region_letter VALUES("10002229","封开县","441225","10000239","3","F");
INSERT INTO cmf_region_letter VALUES("10002230","德庆县","441226","10000239","3","D");
INSERT INTO cmf_region_letter VALUES("10002231","四会市","441284","10000239","3","S");
INSERT INTO cmf_region_letter VALUES("10002232","惠城区","441302","10000240","3","H");
INSERT INTO cmf_region_letter VALUES("10002233","惠阳区","441303","10000240","3","H");
INSERT INTO cmf_region_letter VALUES("10002234","博罗县","441322","10000240","3","B");
INSERT INTO cmf_region_letter VALUES("10002235","惠东县","441323","10000240","3","H");
INSERT INTO cmf_region_letter VALUES("10002236","龙门县","441324","10000240","3","L");
INSERT INTO cmf_region_letter VALUES("10002237","梅江区","441402","10000241","3","M");
INSERT INTO cmf_region_letter VALUES("10002238","梅县区","441403","10000241","3","M");
INSERT INTO cmf_region_letter VALUES("10002239","大埔县","441422","10000241","3","D");
INSERT INTO cmf_region_letter VALUES("10002240","丰顺县","441423","10000241","3","F");
INSERT INTO cmf_region_letter VALUES("10002241","五华县","441424","10000241","3","W");
INSERT INTO cmf_region_letter VALUES("10002242","平远县","441426","10000241","3","P");
INSERT INTO cmf_region_letter VALUES("10002243","蕉岭县","441427","10000241","3","J");
INSERT INTO cmf_region_letter VALUES("10002244","兴宁市","441481","10000241","3","X");
INSERT INTO cmf_region_letter VALUES("10002245","城区","441502","10000242","3","C");
INSERT INTO cmf_region_letter VALUES("10002246","海丰县","441521","10000242","3","H");
INSERT INTO cmf_region_letter VALUES("10002247","陆河县","441523","10000242","3","L");
INSERT INTO cmf_region_letter VALUES("10002248","陆丰市","441581","10000242","3","L");
INSERT INTO cmf_region_letter VALUES("10002249","源城区","441602","10000243","3","Y");
INSERT INTO cmf_region_letter VALUES("10002250","紫金县","441621","10000243","3","Z");
INSERT INTO cmf_region_letter VALUES("10002251","龙川县","441622","10000243","3","L");
INSERT INTO cmf_region_letter VALUES("10002252","连平县","441623","10000243","3","L");
INSERT INTO cmf_region_letter VALUES("10002253","和平县","441624","10000243","3","H");
INSERT INTO cmf_region_letter VALUES("10002254","东源县","441625","10000243","3","D");
INSERT INTO cmf_region_letter VALUES("10002255","江城区","441702","10000244","3","J");
INSERT INTO cmf_region_letter VALUES("10002256","阳东区","441704","10000244","3","Y");
INSERT INTO cmf_region_letter VALUES("10002257","阳西县","441721","10000244","3","Y");
INSERT INTO cmf_region_letter VALUES("10002258","阳春市","441781","10000244","3","Y");
INSERT INTO cmf_region_letter VALUES("10002259","清城区","441802","10000245","3","Q");
INSERT INTO cmf_region_letter VALUES("10002260","清新区","441803","10000245","3","Q");
INSERT INTO cmf_region_letter VALUES("10002261","佛冈县","441821","10000245","3","F");
INSERT INTO cmf_region_letter VALUES("10002262","阳山县","441823","10000245","3","Y");
INSERT INTO cmf_region_letter VALUES("10002263","连山壮族瑶族自治县","441825","10000245","3","L");
INSERT INTO cmf_region_letter VALUES("10002264","连南瑶族自治县","441826","10000245","3","L");
INSERT INTO cmf_region_letter VALUES("10002265","英德市","441881","10000245","3","Y");
INSERT INTO cmf_region_letter VALUES("10002266","连州市","441882","10000245","3","L");
INSERT INTO cmf_region_letter VALUES("10002267","中堂镇","441901","10000246","3","Z");
INSERT INTO cmf_region_letter VALUES("10002268","南城街道办事处","441903","10000246","3","N");
INSERT INTO cmf_region_letter VALUES("10002269","长安镇","441904","10000246","3","C");
INSERT INTO cmf_region_letter VALUES("10002270","东坑镇","441905","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002271","樟木头镇","441906","10000246","3","Z");
INSERT INTO cmf_region_letter VALUES("10002272","莞城街道办事处","441907","10000246","3","G");
INSERT INTO cmf_region_letter VALUES("10002273","石龙镇","441908","10000246","3","S");
INSERT INTO cmf_region_letter VALUES("10002274","桥头镇","441909","10000246","3","Q");
INSERT INTO cmf_region_letter VALUES("10002275","万江街道办事处","441910","10000246","3","W");
INSERT INTO cmf_region_letter VALUES("10002276","麻涌镇","441911","10000246","3","M");
INSERT INTO cmf_region_letter VALUES("10002277","虎门镇","441912","10000246","3","H");
INSERT INTO cmf_region_letter VALUES("10002278","谢岗镇","441913","10000246","3","X");
INSERT INTO cmf_region_letter VALUES("10002279","石碣镇","441914","10000246","3","S");
INSERT INTO cmf_region_letter VALUES("10002280","茶山镇","441915","10000246","3","C");
INSERT INTO cmf_region_letter VALUES("10002281","东城街道办事处","441916","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002282","洪梅镇","441917","10000246","3","H");
INSERT INTO cmf_region_letter VALUES("10002283","道滘镇","441918","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002284","高埗镇","441919","10000246","3","G");
INSERT INTO cmf_region_letter VALUES("10002285","企石镇","441920","10000246","3","Q");
INSERT INTO cmf_region_letter VALUES("10002286","凤岗镇","441921","10000246","3","F");
INSERT INTO cmf_region_letter VALUES("10002287","大岭山镇","441922","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002288","松山湖管委会","441923","10000246","3","S");
INSERT INTO cmf_region_letter VALUES("10002289","清溪镇","441924","10000246","3","Q");
INSERT INTO cmf_region_letter VALUES("10002290","望牛墩镇","441925","10000246","3","W");
INSERT INTO cmf_region_letter VALUES("10002291","厚街镇","441926","10000246","3","H");
INSERT INTO cmf_region_letter VALUES("10002292","常平镇","441927","10000246","3","C");
INSERT INTO cmf_region_letter VALUES("10002293","寮步镇","441928","10000246","3","L");
INSERT INTO cmf_region_letter VALUES("10002294","石排镇","441929","10000246","3","S");
INSERT INTO cmf_region_letter VALUES("10002295","横沥镇","441930","10000246","3","H");
INSERT INTO cmf_region_letter VALUES("10002296","塘厦镇","441931","10000246","3","T");
INSERT INTO cmf_region_letter VALUES("10002297","黄江镇","441932","10000246","3","H");
INSERT INTO cmf_region_letter VALUES("10002298","大朗镇","441933","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002299","东莞港","441934","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002300","东莞生态园","441935","10000246","3","D");
INSERT INTO cmf_region_letter VALUES("10002301","沙田镇","441990","10000246","3","S");
INSERT INTO cmf_region_letter VALUES("10002302","南头镇","442001","10000247","3","N");
INSERT INTO cmf_region_letter VALUES("10002303","神湾镇","442002","10000247","3","S");
INSERT INTO cmf_region_letter VALUES("10002304","东凤镇","442003","10000247","3","D");
INSERT INTO cmf_region_letter VALUES("10002305","五桂山街道办事处","442004","10000247","3","W");
INSERT INTO cmf_region_letter VALUES("10002306","黄圃镇","442005","10000247","3","H");
INSERT INTO cmf_region_letter VALUES("10002307","小榄镇","442006","10000247","3","X");
INSERT INTO cmf_region_letter VALUES("10002308","石岐区街道办事处","442007","10000247","3","S");
INSERT INTO cmf_region_letter VALUES("10002309","横栏镇","442008","10000247","3","H");
INSERT INTO cmf_region_letter VALUES("10002310","三角镇","442009","10000247","3","S");
INSERT INTO cmf_region_letter VALUES("10002311","三乡镇","442010","10000247","3","S");
INSERT INTO cmf_region_letter VALUES("10002312","港口镇","442011","10000247","3","G");
INSERT INTO cmf_region_letter VALUES("10002313","沙溪镇","442012","10000247","3","S");
INSERT INTO cmf_region_letter VALUES("10002314","板芙镇","442013","10000247","3","B");
INSERT INTO cmf_region_letter VALUES("10002315","东升镇","442015","10000247","3","D");
INSERT INTO cmf_region_letter VALUES("10002316","阜沙镇","442016","10000247","3","F");
INSERT INTO cmf_region_letter VALUES("10002317","民众镇","442017","10000247","3","M");
INSERT INTO cmf_region_letter VALUES("10002318","东区街道办事处","442018","10000247","3","D");
INSERT INTO cmf_region_letter VALUES("10002319","火炬开发区街道办事处","442019","10000247","3","H");
INSERT INTO cmf_region_letter VALUES("10002320","西区街道办事处","442020","10000247","3","X");
INSERT INTO cmf_region_letter VALUES("10002321","南区街道办事处","442021","10000247","3","N");
INSERT INTO cmf_region_letter VALUES("10002322","古镇镇","442022","10000247","3","G");
INSERT INTO cmf_region_letter VALUES("10002323","坦洲镇","442023","10000247","3","T");
INSERT INTO cmf_region_letter VALUES("10002324","大涌镇","442024","10000247","3","D");
INSERT INTO cmf_region_letter VALUES("10002325","南朗镇","442025","10000247","3","N");
INSERT INTO cmf_region_letter VALUES("10002326","湘桥区","445102","10000248","3","X");
INSERT INTO cmf_region_letter VALUES("10002327","潮安区","445103","10000248","3","C");
INSERT INTO cmf_region_letter VALUES("10002328","饶平县","445122","10000248","3","R");
INSERT INTO cmf_region_letter VALUES("10002329","榕城区","445202","10000249","3","R");
INSERT INTO cmf_region_letter VALUES("10002330","揭东区","445203","10000249","3","J");
INSERT INTO cmf_region_letter VALUES("10002331","揭西县","445222","10000249","3","J");
INSERT INTO cmf_region_letter VALUES("10002332","惠来县","445224","10000249","3","H");
INSERT INTO cmf_region_letter VALUES("10002333","普宁市","445281","10000249","3","P");
INSERT INTO cmf_region_letter VALUES("10002334","云城区","445302","10000250","3","Y");
INSERT INTO cmf_region_letter VALUES("10002335","云安区","445303","10000250","3","Y");
INSERT INTO cmf_region_letter VALUES("10002336","新兴县","445321","10000250","3","X");
INSERT INTO cmf_region_letter VALUES("10002337","郁南县","445322","10000250","3","Y");
INSERT INTO cmf_region_letter VALUES("10002338","罗定市","445381","10000250","3","L");
INSERT INTO cmf_region_letter VALUES("10002339","兴宁区","450102","10000251","3","X");
INSERT INTO cmf_region_letter VALUES("10002340","青秀区","450103","10000251","3","Q");
INSERT INTO cmf_region_letter VALUES("10002341","江南区","450105","10000251","3","J");
INSERT INTO cmf_region_letter VALUES("10002342","西乡塘区","450107","10000251","3","X");
INSERT INTO cmf_region_letter VALUES("10002343","良庆区","450108","10000251","3","L");
INSERT INTO cmf_region_letter VALUES("10002344","邕宁区","450109","10000251","3","Y");
INSERT INTO cmf_region_letter VALUES("10002345","武鸣区","450110","10000251","3","W");
INSERT INTO cmf_region_letter VALUES("10002346","隆安县","450123","10000251","3","L");
INSERT INTO cmf_region_letter VALUES("10002347","马山县","450124","10000251","3","M");
INSERT INTO cmf_region_letter VALUES("10002348","上林县","450125","10000251","3","S");
INSERT INTO cmf_region_letter VALUES("10002349","宾阳县","450126","10000251","3","B");
INSERT INTO cmf_region_letter VALUES("10002350","横县","450127","10000251","3","H");
INSERT INTO cmf_region_letter VALUES("10002351","城中区","450202","10000252","3","C");
INSERT INTO cmf_region_letter VALUES("10002352","鱼峰区","450203","10000252","3","Y");
INSERT INTO cmf_region_letter VALUES("10002353","柳南区","450204","10000252","3","L");
INSERT INTO cmf_region_letter VALUES("10002354","柳北区","450205","10000252","3","L");
INSERT INTO cmf_region_letter VALUES("10002355","柳江区","450206","10000252","3","L");
INSERT INTO cmf_region_letter VALUES("10002356","柳城县","450222","10000252","3","L");
INSERT INTO cmf_region_letter VALUES("10002357","鹿寨县","450223","10000252","3","L");
INSERT INTO cmf_region_letter VALUES("10002358","融安县","450224","10000252","3","R");
INSERT INTO cmf_region_letter VALUES("10002359","融水苗族自治县","450225","10000252","3","R");
INSERT INTO cmf_region_letter VALUES("10002360","三江侗族自治县","450226","10000252","3","S");
INSERT INTO cmf_region_letter VALUES("10002361","秀峰区","450302","10000253","3","X");
INSERT INTO cmf_region_letter VALUES("10002362","叠彩区","450303","10000253","3","D");
INSERT INTO cmf_region_letter VALUES("10002363","象山区","450304","10000253","3","X");
INSERT INTO cmf_region_letter VALUES("10002364","七星区","450305","10000253","3","Q");
INSERT INTO cmf_region_letter VALUES("10002365","雁山区","450311","10000253","3","Y");
INSERT INTO cmf_region_letter VALUES("10002366","临桂区","450312","10000253","3","L");
INSERT INTO cmf_region_letter VALUES("10002367","阳朔县","450321","10000253","3","Y");
INSERT INTO cmf_region_letter VALUES("10002368","灵川县","450323","10000253","3","L");
INSERT INTO cmf_region_letter VALUES("10002369","全州县","450324","10000253","3","Q");
INSERT INTO cmf_region_letter VALUES("10002370","兴安县","450325","10000253","3","X");
INSERT INTO cmf_region_letter VALUES("10002371","永福县","450326","10000253","3","Y");
INSERT INTO cmf_region_letter VALUES("10002372","灌阳县","450327","10000253","3","G");
INSERT INTO cmf_region_letter VALUES("10002373","龙胜各族自治县","450328","10000253","3","L");
INSERT INTO cmf_region_letter VALUES("10002374","资源县","450329","10000253","3","Z");
INSERT INTO cmf_region_letter VALUES("10002375","平乐县","450330","10000253","3","P");
INSERT INTO cmf_region_letter VALUES("10002376","恭城瑶族自治县","450332","10000253","3","G");
INSERT INTO cmf_region_letter VALUES("10002377","荔浦市","450381","10000253","3","L");
INSERT INTO cmf_region_letter VALUES("10002378","万秀区","450403","10000254","3","W");
INSERT INTO cmf_region_letter VALUES("10002379","长洲区","450405","10000254","3","C");
INSERT INTO cmf_region_letter VALUES("10002380","龙圩区","450406","10000254","3","L");
INSERT INTO cmf_region_letter VALUES("10002381","苍梧县","450421","10000254","3","C");
INSERT INTO cmf_region_letter VALUES("10002382","藤县","450422","10000254","3","T");
INSERT INTO cmf_region_letter VALUES("10002383","蒙山县","450423","10000254","3","M");
INSERT INTO cmf_region_letter VALUES("10002384","岑溪市","450481","10000254","3","C");
INSERT INTO cmf_region_letter VALUES("10002385","海城区","450502","10000255","3","H");
INSERT INTO cmf_region_letter VALUES("10002386","银海区","450503","10000255","3","Y");
INSERT INTO cmf_region_letter VALUES("10002387","铁山港区","450512","10000255","3","T");
INSERT INTO cmf_region_letter VALUES("10002388","合浦县","450521","10000255","3","H");
INSERT INTO cmf_region_letter VALUES("10002389","港口区","450602","10000256","3","G");
INSERT INTO cmf_region_letter VALUES("10002390","防城区","450603","10000256","3","F");
INSERT INTO cmf_region_letter VALUES("10002391","上思县","450621","10000256","3","S");
INSERT INTO cmf_region_letter VALUES("10002392","东兴市","450681","10000256","3","D");
INSERT INTO cmf_region_letter VALUES("10002393","钦南区","450702","10000257","3","Q");
INSERT INTO cmf_region_letter VALUES("10002394","钦北区","450703","10000257","3","Q");
INSERT INTO cmf_region_letter VALUES("10002395","灵山县","450721","10000257","3","L");
INSERT INTO cmf_region_letter VALUES("10002396","浦北县","450722","10000257","3","P");
INSERT INTO cmf_region_letter VALUES("10002397","港北区","450802","10000258","3","G");
INSERT INTO cmf_region_letter VALUES("10002398","港南区","450803","10000258","3","G");
INSERT INTO cmf_region_letter VALUES("10002399","覃塘区","450804","10000258","3","T");
INSERT INTO cmf_region_letter VALUES("10002400","平南县","450821","10000258","3","P");
INSERT INTO cmf_region_letter VALUES("10002401","桂平市","450881","10000258","3","G");
INSERT INTO cmf_region_letter VALUES("10002402","玉州区","450902","10000259","3","Y");
INSERT INTO cmf_region_letter VALUES("10002403","福绵区","450903","10000259","3","F");
INSERT INTO cmf_region_letter VALUES("10002404","容县","450921","10000259","3","R");
INSERT INTO cmf_region_letter VALUES("10002405","陆川县","450922","10000259","3","L");
INSERT INTO cmf_region_letter VALUES("10002406","博白县","450923","10000259","3","B");
INSERT INTO cmf_region_letter VALUES("10002407","兴业县","450924","10000259","3","X");
INSERT INTO cmf_region_letter VALUES("10002408","北流市","450981","10000259","3","B");
INSERT INTO cmf_region_letter VALUES("10002409","右江区","451002","10000260","3","Y");
INSERT INTO cmf_region_letter VALUES("10002410","田阳县","451021","10000260","3","T");
INSERT INTO cmf_region_letter VALUES("10002411","田东县","451022","10000260","3","T");
INSERT INTO cmf_region_letter VALUES("10002412","平果县","451023","10000260","3","P");
INSERT INTO cmf_region_letter VALUES("10002413","德保县","451024","10000260","3","D");
INSERT INTO cmf_region_letter VALUES("10002414","那坡县","451026","10000260","3","N");
INSERT INTO cmf_region_letter VALUES("10002415","凌云县","451027","10000260","3","L");
INSERT INTO cmf_region_letter VALUES("10002416","乐业县","451028","10000260","3","L");
INSERT INTO cmf_region_letter VALUES("10002417","田林县","451029","10000260","3","T");
INSERT INTO cmf_region_letter VALUES("10002418","西林县","451030","10000260","3","X");
INSERT INTO cmf_region_letter VALUES("10002419","隆林各族自治县","451031","10000260","3","L");
INSERT INTO cmf_region_letter VALUES("10002420","靖西市","451081","10000260","3","J");
INSERT INTO cmf_region_letter VALUES("10002421","八步区","451102","10000261","3","B");
INSERT INTO cmf_region_letter VALUES("10002422","平桂区","451103","10000261","3","P");
INSERT INTO cmf_region_letter VALUES("10002423","昭平县","451121","10000261","3","Z");
INSERT INTO cmf_region_letter VALUES("10002424","钟山县","451122","10000261","3","Z");
INSERT INTO cmf_region_letter VALUES("10002425","富川瑶族自治县","451123","10000261","3","F");
INSERT INTO cmf_region_letter VALUES("10002426","金城江区","451202","10000262","3","J");
INSERT INTO cmf_region_letter VALUES("10002427","宜州区","451203","10000262","3","Y");
INSERT INTO cmf_region_letter VALUES("10002428","南丹县","451221","10000262","3","N");
INSERT INTO cmf_region_letter VALUES("10002429","天峨县","451222","10000262","3","T");
INSERT INTO cmf_region_letter VALUES("10002430","凤山县","451223","10000262","3","F");
INSERT INTO cmf_region_letter VALUES("10002431","东兰县","451224","10000262","3","D");
INSERT INTO cmf_region_letter VALUES("10002432","罗城仫佬族自治县","451225","10000262","3","L");
INSERT INTO cmf_region_letter VALUES("10002433","环江毛南族自治县","451226","10000262","3","H");
INSERT INTO cmf_region_letter VALUES("10002434","巴马瑶族自治县","451227","10000262","3","B");
INSERT INTO cmf_region_letter VALUES("10002435","都安瑶族自治县","451228","10000262","3","D");
INSERT INTO cmf_region_letter VALUES("10002436","大化瑶族自治县","451229","10000262","3","D");
INSERT INTO cmf_region_letter VALUES("10002437","兴宾区","451302","10000263","3","X");
INSERT INTO cmf_region_letter VALUES("10002438","忻城县","451321","10000263","3","X");
INSERT INTO cmf_region_letter VALUES("10002439","象州县","451322","10000263","3","X");
INSERT INTO cmf_region_letter VALUES("10002440","武宣县","451323","10000263","3","W");
INSERT INTO cmf_region_letter VALUES("10002441","金秀瑶族自治县","451324","10000263","3","J");
INSERT INTO cmf_region_letter VALUES("10002442","合山市","451381","10000263","3","H");
INSERT INTO cmf_region_letter VALUES("10002443","江州区","451402","10000264","3","J");
INSERT INTO cmf_region_letter VALUES("10002444","扶绥县","451421","10000264","3","F");
INSERT INTO cmf_region_letter VALUES("10002445","宁明县","451422","10000264","3","N");
INSERT INTO cmf_region_letter VALUES("10002446","龙州县","451423","10000264","3","L");
INSERT INTO cmf_region_letter VALUES("10002447","大新县","451424","10000264","3","D");
INSERT INTO cmf_region_letter VALUES("10002448","天等县","451425","10000264","3","T");
INSERT INTO cmf_region_letter VALUES("10002449","凭祥市","451481","10000264","3","P");
INSERT INTO cmf_region_letter VALUES("10002450","秀英区","460105","10000265","3","X");
INSERT INTO cmf_region_letter VALUES("10002451","龙华区","460106","10000265","3","L");
INSERT INTO cmf_region_letter VALUES("10002452","琼山区","460107","10000265","3","Q");
INSERT INTO cmf_region_letter VALUES("10002453","美兰区","460108","10000265","3","M");
INSERT INTO cmf_region_letter VALUES("10002454","海棠区","460202","10000266","3","H");
INSERT INTO cmf_region_letter VALUES("10002455","吉阳区","460203","10000266","3","J");
INSERT INTO cmf_region_letter VALUES("10002456","天涯区","460204","10000266","3","T");
INSERT INTO cmf_region_letter VALUES("10002457","崖州区","460205","10000266","3","Y");
INSERT INTO cmf_region_letter VALUES("10002458","西沙群岛","460321","10000267","3","X");
INSERT INTO cmf_region_letter VALUES("10002459","南沙群岛","460322","10000267","3","N");
INSERT INTO cmf_region_letter VALUES("10002460","中沙群岛的岛礁及其海域","460323","10000267","3","Z");
INSERT INTO cmf_region_letter VALUES("10002461","那大镇","460401","10000268","3","N");
INSERT INTO cmf_region_letter VALUES("10002462","和庆镇","460402","10000268","3","H");
INSERT INTO cmf_region_letter VALUES("10002463","南丰镇","460403","10000268","3","N");
INSERT INTO cmf_region_letter VALUES("10002464","大成镇","460404","10000268","3","D");
INSERT INTO cmf_region_letter VALUES("10002465","雅星镇","460405","10000268","3","Y");
INSERT INTO cmf_region_letter VALUES("10002466","兰洋镇","460406","10000268","3","L");
INSERT INTO cmf_region_letter VALUES("10002467","光村镇","460407","10000268","3","G");
INSERT INTO cmf_region_letter VALUES("10002468","木棠镇","460408","10000268","3","M");
INSERT INTO cmf_region_letter VALUES("10002469","海头镇","460409","10000268","3","H");
INSERT INTO cmf_region_letter VALUES("10002470","峨蔓镇","460410","10000268","3","E");
INSERT INTO cmf_region_letter VALUES("10002471","王五镇","460411","10000268","3","W");
INSERT INTO cmf_region_letter VALUES("10002472","白马井镇","460412","10000268","3","B");
INSERT INTO cmf_region_letter VALUES("10002473","中和镇","460413","10000268","3","Z");
INSERT INTO cmf_region_letter VALUES("10002474","排浦镇","460414","10000268","3","P");
INSERT INTO cmf_region_letter VALUES("10002475","东成镇","460415","10000268","3","D");
INSERT INTO cmf_region_letter VALUES("10002476","新州镇","460416","10000268","3","X");
INSERT INTO cmf_region_letter VALUES("10002477","洋浦经济开发区","460417","10000268","3","Y");
INSERT INTO cmf_region_letter VALUES("10002478","华南热作学院","460418","10000268","3","H");
INSERT INTO cmf_region_letter VALUES("10002479","五指山市","469001","10000269","3","W");
INSERT INTO cmf_region_letter VALUES("10002480","琼海市","469002","10000269","3","Q");
INSERT INTO cmf_region_letter VALUES("10002481","文昌市","469005","10000269","3","W");
INSERT INTO cmf_region_letter VALUES("10002482","万宁市","469006","10000269","3","W");
INSERT INTO cmf_region_letter VALUES("10002483","东方市","469007","10000269","3","D");
INSERT INTO cmf_region_letter VALUES("10002484","定安县","469021","10000269","3","D");
INSERT INTO cmf_region_letter VALUES("10002485","屯昌县","469022","10000269","3","T");
INSERT INTO cmf_region_letter VALUES("10002486","澄迈县","469023","10000269","3","C");
INSERT INTO cmf_region_letter VALUES("10002487","临高县","469024","10000269","3","L");
INSERT INTO cmf_region_letter VALUES("10002488","白沙黎族自治县","469025","10000269","3","B");
INSERT INTO cmf_region_letter VALUES("10002489","昌江黎族自治县","469026","10000269","3","C");
INSERT INTO cmf_region_letter VALUES("10002490","乐东黎族自治县","469027","10000269","3","L");
INSERT INTO cmf_region_letter VALUES("10002491","陵水黎族自治县","469028","10000269","3","L");
INSERT INTO cmf_region_letter VALUES("10002492","保亭黎族苗族自治县","469029","10000269","3","B");
INSERT INTO cmf_region_letter VALUES("10002493","琼中黎族苗族自治县","469030","10000269","3","Q");
INSERT INTO cmf_region_letter VALUES("10002494","万州区","500101","10000270","3","W");
INSERT INTO cmf_region_letter VALUES("10002495","涪陵区","500102","10000270","3","F");
INSERT INTO cmf_region_letter VALUES("10002496","渝中区","500103","10000270","3","Y");
INSERT INTO cmf_region_letter VALUES("10002497","大渡口区","500104","10000270","3","D");
INSERT INTO cmf_region_letter VALUES("10002498","江北区","500105","10000270","3","J");
INSERT INTO cmf_region_letter VALUES("10002499","沙坪坝区","500106","10000270","3","S");
INSERT INTO cmf_region_letter VALUES("10002500","九龙坡区","500107","10000270","3","J");
INSERT INTO cmf_region_letter VALUES("10002501","南岸区","500108","10000270","3","N");
INSERT INTO cmf_region_letter VALUES("10002502","北碚区","500109","10000270","3","B");
INSERT INTO cmf_region_letter VALUES("10002503","綦江区","500110","10000270","3","Q");
INSERT INTO cmf_region_letter VALUES("10002504","大足区","500111","10000270","3","D");
INSERT INTO cmf_region_letter VALUES("10002505","渝北区","500112","10000270","3","Y");
INSERT INTO cmf_region_letter VALUES("10002506","巴南区","500113","10000270","3","B");
INSERT INTO cmf_region_letter VALUES("10002507","黔江区","500114","10000270","3","Q");
INSERT INTO cmf_region_letter VALUES("10002508","长寿区","500115","10000270","3","C");
INSERT INTO cmf_region_letter VALUES("10002509","江津区","500116","10000270","3","J");
INSERT INTO cmf_region_letter VALUES("10002510","合川区","500117","10000270","3","H");
INSERT INTO cmf_region_letter VALUES("10002511","永川区","500118","10000270","3","Y");
INSERT INTO cmf_region_letter VALUES("10002512","南川区","500119","10000270","3","N");
INSERT INTO cmf_region_letter VALUES("10002513","璧山区","500120","10000270","3","B");
INSERT INTO cmf_region_letter VALUES("10002514","铜梁区","500151","10000270","3","T");
INSERT INTO cmf_region_letter VALUES("10002515","潼南区","500152","10000270","3","T");
INSERT INTO cmf_region_letter VALUES("10002516","荣昌区","500153","10000270","3","R");
INSERT INTO cmf_region_letter VALUES("10002517","开州区","500154","10000270","3","K");
INSERT INTO cmf_region_letter VALUES("10002518","梁平区","500155","10000270","3","L");
INSERT INTO cmf_region_letter VALUES("10002519","武隆区","500156","10000270","3","W");
INSERT INTO cmf_region_letter VALUES("10002520","城口县","500229","10000271","3","C");
INSERT INTO cmf_region_letter VALUES("10002521","丰都县","500230","10000271","3","F");
INSERT INTO cmf_region_letter VALUES("10002522","垫江县","500231","10000271","3","D");
INSERT INTO cmf_region_letter VALUES("10002523","忠县","500233","10000271","3","Z");
INSERT INTO cmf_region_letter VALUES("10002524","云阳县","500235","10000271","3","Y");
INSERT INTO cmf_region_letter VALUES("10002525","奉节县","500236","10000271","3","F");
INSERT INTO cmf_region_letter VALUES("10002526","巫山县","500237","10000271","3","W");
INSERT INTO cmf_region_letter VALUES("10002527","巫溪县","500238","10000271","3","W");
INSERT INTO cmf_region_letter VALUES("10002528","石柱土家族自治县","500240","10000271","3","S");
INSERT INTO cmf_region_letter VALUES("10002529","秀山土家族苗族自治县","500241","10000271","3","X");
INSERT INTO cmf_region_letter VALUES("10002530","酉阳土家族苗族自治县","500242","10000271","3","Y");
INSERT INTO cmf_region_letter VALUES("10002531","彭水苗族土家族自治县","500243","10000271","3","P");
INSERT INTO cmf_region_letter VALUES("10002532","锦江区","510104","10000272","3","J");
INSERT INTO cmf_region_letter VALUES("10002533","青羊区","510105","10000272","3","Q");
INSERT INTO cmf_region_letter VALUES("10002534","金牛区","510106","10000272","3","J");
INSERT INTO cmf_region_letter VALUES("10002535","武侯区","510107","10000272","3","W");
INSERT INTO cmf_region_letter VALUES("10002536","成华区","510108","10000272","3","C");
INSERT INTO cmf_region_letter VALUES("10002537","龙泉驿区","510112","10000272","3","L");
INSERT INTO cmf_region_letter VALUES("10002538","青白江区","510113","10000272","3","Q");
INSERT INTO cmf_region_letter VALUES("10002539","新都区","510114","10000272","3","X");
INSERT INTO cmf_region_letter VALUES("10002540","温江区","510115","10000272","3","W");
INSERT INTO cmf_region_letter VALUES("10002541","双流区","510116","10000272","3","S");
INSERT INTO cmf_region_letter VALUES("10002542","郫都区","510117","10000272","3","P");
INSERT INTO cmf_region_letter VALUES("10002543","金堂县","510121","10000272","3","J");
INSERT INTO cmf_region_letter VALUES("10002544","大邑县","510129","10000272","3","D");
INSERT INTO cmf_region_letter VALUES("10002545","蒲江县","510131","10000272","3","P");
INSERT INTO cmf_region_letter VALUES("10002546","新津县","510132","10000272","3","X");
INSERT INTO cmf_region_letter VALUES("10002547","都江堰市","510181","10000272","3","D");
INSERT INTO cmf_region_letter VALUES("10002548","彭州市","510182","10000272","3","P");
INSERT INTO cmf_region_letter VALUES("10002549","邛崃市","510183","10000272","3","Q");
INSERT INTO cmf_region_letter VALUES("10002550","崇州市","510184","10000272","3","C");
INSERT INTO cmf_region_letter VALUES("10002551","简阳市","510185","10000272","3","J");
INSERT INTO cmf_region_letter VALUES("10002552","高新区","510191","10000272","3","G");
INSERT INTO cmf_region_letter VALUES("10002553","自流井区","510302","10000273","3","Z");
INSERT INTO cmf_region_letter VALUES("10002554","贡井区","510303","10000273","3","G");
INSERT INTO cmf_region_letter VALUES("10002555","大安区","510304","10000273","3","D");
INSERT INTO cmf_region_letter VALUES("10002556","沿滩区","510311","10000273","3","Y");
INSERT INTO cmf_region_letter VALUES("10002557","荣县","510321","10000273","3","R");
INSERT INTO cmf_region_letter VALUES("10002558","富顺县","510322","10000273","3","F");
INSERT INTO cmf_region_letter VALUES("10002559","东区","510402","10000274","3","D");
INSERT INTO cmf_region_letter VALUES("10002560","西区","510403","10000274","3","X");
INSERT INTO cmf_region_letter VALUES("10002561","仁和区","510411","10000274","3","R");
INSERT INTO cmf_region_letter VALUES("10002562","米易县","510421","10000274","3","M");
INSERT INTO cmf_region_letter VALUES("10002563","盐边县","510422","10000274","3","Y");
INSERT INTO cmf_region_letter VALUES("10002564","江阳区","510502","10000275","3","J");
INSERT INTO cmf_region_letter VALUES("10002565","纳溪区","510503","10000275","3","N");
INSERT INTO cmf_region_letter VALUES("10002566","龙马潭区","510504","10000275","3","L");
INSERT INTO cmf_region_letter VALUES("10002567","泸县","510521","10000275","3","L");
INSERT INTO cmf_region_letter VALUES("10002568","合江县","510522","10000275","3","H");
INSERT INTO cmf_region_letter VALUES("10002569","叙永县","510524","10000275","3","X");
INSERT INTO cmf_region_letter VALUES("10002570","古蔺县","510525","10000275","3","G");
INSERT INTO cmf_region_letter VALUES("10002571","旌阳区","510603","10000276","3","J");
INSERT INTO cmf_region_letter VALUES("10002572","罗江区","510604","10000276","3","L");
INSERT INTO cmf_region_letter VALUES("10002573","中江县","510623","10000276","3","Z");
INSERT INTO cmf_region_letter VALUES("10002574","广汉市","510681","10000276","3","G");
INSERT INTO cmf_region_letter VALUES("10002575","什邡市","510682","10000276","3","S");
INSERT INTO cmf_region_letter VALUES("10002576","绵竹市","510683","10000276","3","M");
INSERT INTO cmf_region_letter VALUES("10002577","涪城区","510703","10000277","3","F");
INSERT INTO cmf_region_letter VALUES("10002578","游仙区","510704","10000277","3","Y");
INSERT INTO cmf_region_letter VALUES("10002579","安州区","510705","10000277","3","A");
INSERT INTO cmf_region_letter VALUES("10002580","三台县","510722","10000277","3","S");
INSERT INTO cmf_region_letter VALUES("10002581","盐亭县","510723","10000277","3","Y");
INSERT INTO cmf_region_letter VALUES("10002582","梓潼县","510725","10000277","3","Z");
INSERT INTO cmf_region_letter VALUES("10002583","北川羌族自治县","510726","10000277","3","B");
INSERT INTO cmf_region_letter VALUES("10002584","平武县","510727","10000277","3","P");
INSERT INTO cmf_region_letter VALUES("10002585","江油市","510781","10000277","3","J");
INSERT INTO cmf_region_letter VALUES("10002586","高新区","510791","10000277","3","G");
INSERT INTO cmf_region_letter VALUES("10002587","利州区","510802","10000278","3","L");
INSERT INTO cmf_region_letter VALUES("10002588","昭化区","510811","10000278","3","Z");
INSERT INTO cmf_region_letter VALUES("10002589","朝天区","510812","10000278","3","C");
INSERT INTO cmf_region_letter VALUES("10002590","旺苍县","510821","10000278","3","W");
INSERT INTO cmf_region_letter VALUES("10002591","青川县","510822","10000278","3","Q");
INSERT INTO cmf_region_letter VALUES("10002592","剑阁县","510823","10000278","3","J");
INSERT INTO cmf_region_letter VALUES("10002593","苍溪县","510824","10000278","3","C");
INSERT INTO cmf_region_letter VALUES("10002594","船山区","510903","10000279","3","C");
INSERT INTO cmf_region_letter VALUES("10002595","安居区","510904","10000279","3","A");
INSERT INTO cmf_region_letter VALUES("10002596","蓬溪县","510921","10000279","3","P");
INSERT INTO cmf_region_letter VALUES("10002597","射洪县","510922","10000279","3","S");
INSERT INTO cmf_region_letter VALUES("10002598","大英县","510923","10000279","3","D");
INSERT INTO cmf_region_letter VALUES("10002599","市中区","511002","10000280","3","S");
INSERT INTO cmf_region_letter VALUES("10002600","东兴区","511011","10000280","3","D");
INSERT INTO cmf_region_letter VALUES("10002601","威远县","511024","10000280","3","W");
INSERT INTO cmf_region_letter VALUES("10002602","资中县","511025","10000280","3","Z");
INSERT INTO cmf_region_letter VALUES("10002603","隆昌市","511083","10000280","3","L");
INSERT INTO cmf_region_letter VALUES("10002604","市中区","511102","10000281","3","S");
INSERT INTO cmf_region_letter VALUES("10002605","沙湾区","511111","10000281","3","S");
INSERT INTO cmf_region_letter VALUES("10002606","五通桥区","511112","10000281","3","W");
INSERT INTO cmf_region_letter VALUES("10002607","金口河区","511113","10000281","3","J");
INSERT INTO cmf_region_letter VALUES("10002608","犍为县","511123","10000281","3","Q");
INSERT INTO cmf_region_letter VALUES("10002609","井研县","511124","10000281","3","J");
INSERT INTO cmf_region_letter VALUES("10002610","夹江县","511126","10000281","3","J");
INSERT INTO cmf_region_letter VALUES("10002611","沐川县","511129","10000281","3","M");
INSERT INTO cmf_region_letter VALUES("10002612","峨边彝族自治县","511132","10000281","3","E");
INSERT INTO cmf_region_letter VALUES("10002613","马边彝族自治县","511133","10000281","3","M");
INSERT INTO cmf_region_letter VALUES("10002614","峨眉山市","511181","10000281","3","E");
INSERT INTO cmf_region_letter VALUES("10002615","顺庆区","511302","10000282","3","S");
INSERT INTO cmf_region_letter VALUES("10002616","高坪区","511303","10000282","3","G");
INSERT INTO cmf_region_letter VALUES("10002617","嘉陵区","511304","10000282","3","J");
INSERT INTO cmf_region_letter VALUES("10002618","南部县","511321","10000282","3","N");
INSERT INTO cmf_region_letter VALUES("10002619","营山县","511322","10000282","3","Y");
INSERT INTO cmf_region_letter VALUES("10002620","蓬安县","511323","10000282","3","P");
INSERT INTO cmf_region_letter VALUES("10002621","仪陇县","511324","10000282","3","Y");
INSERT INTO cmf_region_letter VALUES("10002622","西充县","511325","10000282","3","X");
INSERT INTO cmf_region_letter VALUES("10002623","阆中市","511381","10000282","3","L");
INSERT INTO cmf_region_letter VALUES("10002624","东坡区","511402","10000283","3","D");
INSERT INTO cmf_region_letter VALUES("10002625","彭山区","511403","10000283","3","P");
INSERT INTO cmf_region_letter VALUES("10002626","仁寿县","511421","10000283","3","R");
INSERT INTO cmf_region_letter VALUES("10002627","洪雅县","511423","10000283","3","H");
INSERT INTO cmf_region_letter VALUES("10002628","丹棱县","511424","10000283","3","D");
INSERT INTO cmf_region_letter VALUES("10002629","青神县","511425","10000283","3","Q");
INSERT INTO cmf_region_letter VALUES("10002630","翠屏区","511502","10000284","3","C");
INSERT INTO cmf_region_letter VALUES("10002631","南溪区","511503","10000284","3","N");
INSERT INTO cmf_region_letter VALUES("10002632","叙州区","511504","10000284","3","X");
INSERT INTO cmf_region_letter VALUES("10002633","江安县","511523","10000284","3","J");
INSERT INTO cmf_region_letter VALUES("10002634","长宁县","511524","10000284","3","C");
INSERT INTO cmf_region_letter VALUES("10002635","高县","511525","10000284","3","G");
INSERT INTO cmf_region_letter VALUES("10002636","珙县","511526","10000284","3","G");
INSERT INTO cmf_region_letter VALUES("10002637","筠连县","511527","10000284","3","J");
INSERT INTO cmf_region_letter VALUES("10002638","兴文县","511528","10000284","3","X");
INSERT INTO cmf_region_letter VALUES("10002639","屏山县","511529","10000284","3","P");
INSERT INTO cmf_region_letter VALUES("10002640","广安区","511602","10000285","3","G");
INSERT INTO cmf_region_letter VALUES("10002641","前锋区","511603","10000285","3","Q");
INSERT INTO cmf_region_letter VALUES("10002642","岳池县","511621","10000285","3","Y");
INSERT INTO cmf_region_letter VALUES("10002643","武胜县","511622","10000285","3","W");
INSERT INTO cmf_region_letter VALUES("10002644","邻水县","511623","10000285","3","L");
INSERT INTO cmf_region_letter VALUES("10002645","华蓥市","511681","10000285","3","H");
INSERT INTO cmf_region_letter VALUES("10002646","通川区","511702","10000286","3","T");
INSERT INTO cmf_region_letter VALUES("10002647","达川区","511703","10000286","3","D");
INSERT INTO cmf_region_letter VALUES("10002648","宣汉县","511722","10000286","3","X");
INSERT INTO cmf_region_letter VALUES("10002649","开江县","511723","10000286","3","K");
INSERT INTO cmf_region_letter VALUES("10002650","大竹县","511724","10000286","3","D");
INSERT INTO cmf_region_letter VALUES("10002651","渠县","511725","10000286","3","Q");
INSERT INTO cmf_region_letter VALUES("10002652","万源市","511781","10000286","3","W");
INSERT INTO cmf_region_letter VALUES("10002653","雨城区","511802","10000287","3","Y");
INSERT INTO cmf_region_letter VALUES("10002654","名山区","511803","10000287","3","M");
INSERT INTO cmf_region_letter VALUES("10002655","荥经县","511822","10000287","3","Y");
INSERT INTO cmf_region_letter VALUES("10002656","汉源县","511823","10000287","3","H");
INSERT INTO cmf_region_letter VALUES("10002657","石棉县","511824","10000287","3","S");
INSERT INTO cmf_region_letter VALUES("10002658","天全县","511825","10000287","3","T");
INSERT INTO cmf_region_letter VALUES("10002659","芦山县","511826","10000287","3","L");
INSERT INTO cmf_region_letter VALUES("10002660","宝兴县","511827","10000287","3","B");
INSERT INTO cmf_region_letter VALUES("10002661","巴州区","511902","10000288","3","B");
INSERT INTO cmf_region_letter VALUES("10002662","恩阳区","511903","10000288","3","E");
INSERT INTO cmf_region_letter VALUES("10002663","通江县","511921","10000288","3","T");
INSERT INTO cmf_region_letter VALUES("10002664","南江县","511922","10000288","3","N");
INSERT INTO cmf_region_letter VALUES("10002665","平昌县","511923","10000288","3","P");
INSERT INTO cmf_region_letter VALUES("10002666","雁江区","512002","10000289","3","Y");
INSERT INTO cmf_region_letter VALUES("10002667","安岳县","512021","10000289","3","A");
INSERT INTO cmf_region_letter VALUES("10002668","乐至县","512022","10000289","3","L");
INSERT INTO cmf_region_letter VALUES("10002669","马尔康市","513201","10000290","3","M");
INSERT INTO cmf_region_letter VALUES("10002670","汶川县","513221","10000290","3","W");
INSERT INTO cmf_region_letter VALUES("10002671","理县","513222","10000290","3","L");
INSERT INTO cmf_region_letter VALUES("10002672","茂县","513223","10000290","3","M");
INSERT INTO cmf_region_letter VALUES("10002673","松潘县","513224","10000290","3","S");
INSERT INTO cmf_region_letter VALUES("10002674","九寨沟县","513225","10000290","3","J");
INSERT INTO cmf_region_letter VALUES("10002675","金川县","513226","10000290","3","J");
INSERT INTO cmf_region_letter VALUES("10002676","小金县","513227","10000290","3","X");
INSERT INTO cmf_region_letter VALUES("10002677","黑水县","513228","10000290","3","H");
INSERT INTO cmf_region_letter VALUES("10002678","壤塘县","513230","10000290","3","R");
INSERT INTO cmf_region_letter VALUES("10002679","阿坝县","513231","10000290","3","A");
INSERT INTO cmf_region_letter VALUES("10002680","若尔盖县","513232","10000290","3","R");
INSERT INTO cmf_region_letter VALUES("10002681","红原县","513233","10000290","3","H");
INSERT INTO cmf_region_letter VALUES("10002682","康定市","513301","10000291","3","K");
INSERT INTO cmf_region_letter VALUES("10002683","泸定县","513322","10000291","3","L");
INSERT INTO cmf_region_letter VALUES("10002684","丹巴县","513323","10000291","3","D");
INSERT INTO cmf_region_letter VALUES("10002685","九龙县","513324","10000291","3","J");
INSERT INTO cmf_region_letter VALUES("10002686","雅江县","513325","10000291","3","Y");
INSERT INTO cmf_region_letter VALUES("10002687","道孚县","513326","10000291","3","D");
INSERT INTO cmf_region_letter VALUES("10002688","炉霍县","513327","10000291","3","L");
INSERT INTO cmf_region_letter VALUES("10002689","甘孜县","513328","10000291","3","G");
INSERT INTO cmf_region_letter VALUES("10002690","新龙县","513329","10000291","3","X");
INSERT INTO cmf_region_letter VALUES("10002691","德格县","513330","10000291","3","D");
INSERT INTO cmf_region_letter VALUES("10002692","白玉县","513331","10000291","3","B");
INSERT INTO cmf_region_letter VALUES("10002693","石渠县","513332","10000291","3","S");
INSERT INTO cmf_region_letter VALUES("10002694","色达县","513333","10000291","3","S");
INSERT INTO cmf_region_letter VALUES("10002695","理塘县","513334","10000291","3","L");
INSERT INTO cmf_region_letter VALUES("10002696","巴塘县","513335","10000291","3","B");
INSERT INTO cmf_region_letter VALUES("10002697","乡城县","513336","10000291","3","X");
INSERT INTO cmf_region_letter VALUES("10002698","稻城县","513337","10000291","3","D");
INSERT INTO cmf_region_letter VALUES("10002699","得荣县","513338","10000291","3","D");
INSERT INTO cmf_region_letter VALUES("10002700","西昌市","513401","10000292","3","X");
INSERT INTO cmf_region_letter VALUES("10002701","木里藏族自治县","513422","10000292","3","M");
INSERT INTO cmf_region_letter VALUES("10002702","盐源县","513423","10000292","3","Y");
INSERT INTO cmf_region_letter VALUES("10002703","德昌县","513424","10000292","3","D");
INSERT INTO cmf_region_letter VALUES("10002704","会理县","513425","10000292","3","H");
INSERT INTO cmf_region_letter VALUES("10002705","会东县","513426","10000292","3","H");
INSERT INTO cmf_region_letter VALUES("10002706","宁南县","513427","10000292","3","N");
INSERT INTO cmf_region_letter VALUES("10002707","普格县","513428","10000292","3","P");
INSERT INTO cmf_region_letter VALUES("10002708","布拖县","513429","10000292","3","B");
INSERT INTO cmf_region_letter VALUES("10002709","金阳县","513430","10000292","3","J");
INSERT INTO cmf_region_letter VALUES("10002710","昭觉县","513431","10000292","3","Z");
INSERT INTO cmf_region_letter VALUES("10002711","喜德县","513432","10000292","3","X");
INSERT INTO cmf_region_letter VALUES("10002712","冕宁县","513433","10000292","3","M");
INSERT INTO cmf_region_letter VALUES("10002713","越西县","513434","10000292","3","Y");
INSERT INTO cmf_region_letter VALUES("10002714","甘洛县","513435","10000292","3","G");
INSERT INTO cmf_region_letter VALUES("10002715","美姑县","513436","10000292","3","M");
INSERT INTO cmf_region_letter VALUES("10002716","雷波县","513437","10000292","3","L");
INSERT INTO cmf_region_letter VALUES("10002717","南明区","520102","10000293","3","N");
INSERT INTO cmf_region_letter VALUES("10002718","云岩区","520103","10000293","3","Y");
INSERT INTO cmf_region_letter VALUES("10002719","花溪区","520111","10000293","3","H");
INSERT INTO cmf_region_letter VALUES("10002720","乌当区","520112","10000293","3","W");
INSERT INTO cmf_region_letter VALUES("10002721","白云区","520113","10000293","3","B");
INSERT INTO cmf_region_letter VALUES("10002722","观山湖区","520115","10000293","3","G");
INSERT INTO cmf_region_letter VALUES("10002723","开阳县","520121","10000293","3","K");
INSERT INTO cmf_region_letter VALUES("10002724","息烽县","520122","10000293","3","X");
INSERT INTO cmf_region_letter VALUES("10002725","修文县","520123","10000293","3","X");
INSERT INTO cmf_region_letter VALUES("10002726","清镇市","520181","10000293","3","Q");
INSERT INTO cmf_region_letter VALUES("10002727","钟山区","520201","10000294","3","Z");
INSERT INTO cmf_region_letter VALUES("10002728","六枝特区","520203","10000294","3","L");
INSERT INTO cmf_region_letter VALUES("10002729","水城县","520221","10000294","3","S");
INSERT INTO cmf_region_letter VALUES("10002730","盘州市","520281","10000294","3","P");
INSERT INTO cmf_region_letter VALUES("10002731","红花岗区","520302","10000295","3","H");
INSERT INTO cmf_region_letter VALUES("10002732","汇川区","520303","10000295","3","H");
INSERT INTO cmf_region_letter VALUES("10002733","播州区","520304","10000295","3","B");
INSERT INTO cmf_region_letter VALUES("10002734","桐梓县","520322","10000295","3","T");
INSERT INTO cmf_region_letter VALUES("10002735","绥阳县","520323","10000295","3","S");
INSERT INTO cmf_region_letter VALUES("10002736","正安县","520324","10000295","3","Z");
INSERT INTO cmf_region_letter VALUES("10002737","道真仡佬族苗族自治县","520325","10000295","3","D");
INSERT INTO cmf_region_letter VALUES("10002738","务川仡佬族苗族自治县","520326","10000295","3","W");
INSERT INTO cmf_region_letter VALUES("10002739","凤冈县","520327","10000295","3","F");
INSERT INTO cmf_region_letter VALUES("10002740","湄潭县","520328","10000295","3","M");
INSERT INTO cmf_region_letter VALUES("10002741","余庆县","520329","10000295","3","Y");
INSERT INTO cmf_region_letter VALUES("10002742","习水县","520330","10000295","3","X");
INSERT INTO cmf_region_letter VALUES("10002743","赤水市","520381","10000295","3","C");
INSERT INTO cmf_region_letter VALUES("10002744","仁怀市","520382","10000295","3","R");
INSERT INTO cmf_region_letter VALUES("10002745","西秀区","520402","10000296","3","X");
INSERT INTO cmf_region_letter VALUES("10002746","平坝区","520403","10000296","3","P");
INSERT INTO cmf_region_letter VALUES("10002747","普定县","520422","10000296","3","P");
INSERT INTO cmf_region_letter VALUES("10002748","镇宁布依族苗族自治县","520423","10000296","3","Z");
INSERT INTO cmf_region_letter VALUES("10002749","关岭布依族苗族自治县","520424","10000296","3","G");
INSERT INTO cmf_region_letter VALUES("10002750","紫云苗族布依族自治县","520425","10000296","3","Z");
INSERT INTO cmf_region_letter VALUES("10002751","七星关区","520502","10000297","3","Q");
INSERT INTO cmf_region_letter VALUES("10002752","大方县","520521","10000297","3","D");
INSERT INTO cmf_region_letter VALUES("10002753","黔西县","520522","10000297","3","Q");
INSERT INTO cmf_region_letter VALUES("10002754","金沙县","520523","10000297","3","J");
INSERT INTO cmf_region_letter VALUES("10002755","织金县","520524","10000297","3","Z");
INSERT INTO cmf_region_letter VALUES("10002756","纳雍县","520525","10000297","3","N");
INSERT INTO cmf_region_letter VALUES("10002757","威宁彝族回族苗族自治县","520526","10000297","3","W");
INSERT INTO cmf_region_letter VALUES("10002758","赫章县","520527","10000297","3","H");
INSERT INTO cmf_region_letter VALUES("10002759","碧江区","520602","10000298","3","B");
INSERT INTO cmf_region_letter VALUES("10002760","万山区","520603","10000298","3","W");
INSERT INTO cmf_region_letter VALUES("10002761","江口县","520621","10000298","3","J");
INSERT INTO cmf_region_letter VALUES("10002762","玉屏侗族自治县","520622","10000298","3","Y");
INSERT INTO cmf_region_letter VALUES("10002763","石阡县","520623","10000298","3","S");
INSERT INTO cmf_region_letter VALUES("10002764","思南县","520624","10000298","3","S");
INSERT INTO cmf_region_letter VALUES("10002765","印江土家族苗族自治县","520625","10000298","3","Y");
INSERT INTO cmf_region_letter VALUES("10002766","德江县","520626","10000298","3","D");
INSERT INTO cmf_region_letter VALUES("10002767","沿河土家族自治县","520627","10000298","3","Y");
INSERT INTO cmf_region_letter VALUES("10002768","松桃苗族自治县","520628","10000298","3","S");
INSERT INTO cmf_region_letter VALUES("10002769","兴义市","522301","10000299","3","X");
INSERT INTO cmf_region_letter VALUES("10002770","兴仁市","522302","10000299","3","X");
INSERT INTO cmf_region_letter VALUES("10002771","普安县","522323","10000299","3","P");
INSERT INTO cmf_region_letter VALUES("10002772","晴隆县","522324","10000299","3","Q");
INSERT INTO cmf_region_letter VALUES("10002773","贞丰县","522325","10000299","3","Z");
INSERT INTO cmf_region_letter VALUES("10002774","望谟县","522326","10000299","3","W");
INSERT INTO cmf_region_letter VALUES("10002775","册亨县","522327","10000299","3","C");
INSERT INTO cmf_region_letter VALUES("10002776","安龙县","522328","10000299","3","A");
INSERT INTO cmf_region_letter VALUES("10002777","凯里市","522601","10000300","3","K");
INSERT INTO cmf_region_letter VALUES("10002778","黄平县","522622","10000300","3","H");
INSERT INTO cmf_region_letter VALUES("10002779","施秉县","522623","10000300","3","S");
INSERT INTO cmf_region_letter VALUES("10002780","三穗县","522624","10000300","3","S");
INSERT INTO cmf_region_letter VALUES("10002781","镇远县","522625","10000300","3","Z");
INSERT INTO cmf_region_letter VALUES("10002782","岑巩县","522626","10000300","3","C");
INSERT INTO cmf_region_letter VALUES("10002783","天柱县","522627","10000300","3","T");
INSERT INTO cmf_region_letter VALUES("10002784","锦屏县","522628","10000300","3","J");
INSERT INTO cmf_region_letter VALUES("10002785","剑河县","522629","10000300","3","J");
INSERT INTO cmf_region_letter VALUES("10002786","台江县","522630","10000300","3","T");
INSERT INTO cmf_region_letter VALUES("10002787","黎平县","522631","10000300","3","L");
INSERT INTO cmf_region_letter VALUES("10002788","榕江县","522632","10000300","3","R");
INSERT INTO cmf_region_letter VALUES("10002789","从江县","522633","10000300","3","C");
INSERT INTO cmf_region_letter VALUES("10002790","雷山县","522634","10000300","3","L");
INSERT INTO cmf_region_letter VALUES("10002791","麻江县","522635","10000300","3","M");
INSERT INTO cmf_region_letter VALUES("10002792","丹寨县","522636","10000300","3","D");
INSERT INTO cmf_region_letter VALUES("10002793","都匀市","522701","10000301","3","D");
INSERT INTO cmf_region_letter VALUES("10002794","福泉市","522702","10000301","3","F");
INSERT INTO cmf_region_letter VALUES("10002795","荔波县","522722","10000301","3","L");
INSERT INTO cmf_region_letter VALUES("10002796","贵定县","522723","10000301","3","G");
INSERT INTO cmf_region_letter VALUES("10002797","瓮安县","522725","10000301","3","W");
INSERT INTO cmf_region_letter VALUES("10002798","独山县","522726","10000301","3","D");
INSERT INTO cmf_region_letter VALUES("10002799","平塘县","522727","10000301","3","P");
INSERT INTO cmf_region_letter VALUES("10002800","罗甸县","522728","10000301","3","L");
INSERT INTO cmf_region_letter VALUES("10002801","长顺县","522729","10000301","3","C");
INSERT INTO cmf_region_letter VALUES("10002802","龙里县","522730","10000301","3","L");
INSERT INTO cmf_region_letter VALUES("10002803","惠水县","522731","10000301","3","H");
INSERT INTO cmf_region_letter VALUES("10002804","三都水族自治县","522732","10000301","3","S");
INSERT INTO cmf_region_letter VALUES("10002805","五华区","530102","10000302","3","W");
INSERT INTO cmf_region_letter VALUES("10002806","盘龙区","530103","10000302","3","P");
INSERT INTO cmf_region_letter VALUES("10002807","官渡区","530111","10000302","3","G");
INSERT INTO cmf_region_letter VALUES("10002808","西山区","530112","10000302","3","X");
INSERT INTO cmf_region_letter VALUES("10002809","东川区","530113","10000302","3","D");
INSERT INTO cmf_region_letter VALUES("10002810","呈贡区","530114","10000302","3","C");
INSERT INTO cmf_region_letter VALUES("10002811","晋宁区","530115","10000302","3","J");
INSERT INTO cmf_region_letter VALUES("10002812","富民县","530124","10000302","3","F");
INSERT INTO cmf_region_letter VALUES("10002813","宜良县","530125","10000302","3","Y");
INSERT INTO cmf_region_letter VALUES("10002814","石林彝族自治县","530126","10000302","3","S");
INSERT INTO cmf_region_letter VALUES("10002815","嵩明县","530127","10000302","3","S");
INSERT INTO cmf_region_letter VALUES("10002816","禄劝彝族苗族自治县","530128","10000302","3","L");
INSERT INTO cmf_region_letter VALUES("10002817","寻甸回族彝族自治县","530129","10000302","3","X");
INSERT INTO cmf_region_letter VALUES("10002818","安宁市","530181","10000302","3","A");
INSERT INTO cmf_region_letter VALUES("10002819","麒麟区","530302","10000303","3","Q");
INSERT INTO cmf_region_letter VALUES("10002820","沾益区","530303","10000303","3","Z");
INSERT INTO cmf_region_letter VALUES("10002821","马龙区","530304","10000303","3","M");
INSERT INTO cmf_region_letter VALUES("10002822","陆良县","530322","10000303","3","L");
INSERT INTO cmf_region_letter VALUES("10002823","师宗县","530323","10000303","3","S");
INSERT INTO cmf_region_letter VALUES("10002824","罗平县","530324","10000303","3","L");
INSERT INTO cmf_region_letter VALUES("10002825","富源县","530325","10000303","3","F");
INSERT INTO cmf_region_letter VALUES("10002826","会泽县","530326","10000303","3","H");
INSERT INTO cmf_region_letter VALUES("10002827","宣威市","530381","10000303","3","X");
INSERT INTO cmf_region_letter VALUES("10002828","红塔区","530402","10000304","3","H");
INSERT INTO cmf_region_letter VALUES("10002829","江川区","530403","10000304","3","J");
INSERT INTO cmf_region_letter VALUES("10002830","澄江县","530422","10000304","3","C");
INSERT INTO cmf_region_letter VALUES("10002831","通海县","530423","10000304","3","T");
INSERT INTO cmf_region_letter VALUES("10002832","华宁县","530424","10000304","3","H");
INSERT INTO cmf_region_letter VALUES("10002833","易门县","530425","10000304","3","Y");
INSERT INTO cmf_region_letter VALUES("10002834","峨山彝族自治县","530426","10000304","3","E");
INSERT INTO cmf_region_letter VALUES("10002835","新平彝族傣族自治县","530427","10000304","3","X");
INSERT INTO cmf_region_letter VALUES("10002836","元江哈尼族彝族傣族自治县","530428","10000304","3","Y");
INSERT INTO cmf_region_letter VALUES("10002837","隆阳区","530502","10000305","3","L");
INSERT INTO cmf_region_letter VALUES("10002838","施甸县","530521","10000305","3","S");
INSERT INTO cmf_region_letter VALUES("10002839","龙陵县","530523","10000305","3","L");
INSERT INTO cmf_region_letter VALUES("10002840","昌宁县","530524","10000305","3","C");
INSERT INTO cmf_region_letter VALUES("10002841","腾冲市","530581","10000305","3","T");
INSERT INTO cmf_region_letter VALUES("10002842","昭阳区","530602","10000306","3","Z");
INSERT INTO cmf_region_letter VALUES("10002843","鲁甸县","530621","10000306","3","L");
INSERT INTO cmf_region_letter VALUES("10002844","巧家县","530622","10000306","3","Q");
INSERT INTO cmf_region_letter VALUES("10002845","盐津县","530623","10000306","3","Y");
INSERT INTO cmf_region_letter VALUES("10002846","大关县","530624","10000306","3","D");
INSERT INTO cmf_region_letter VALUES("10002847","永善县","530625","10000306","3","Y");
INSERT INTO cmf_region_letter VALUES("10002848","绥江县","530626","10000306","3","S");
INSERT INTO cmf_region_letter VALUES("10002849","镇雄县","530627","10000306","3","Z");
INSERT INTO cmf_region_letter VALUES("10002850","彝良县","530628","10000306","3","Y");
INSERT INTO cmf_region_letter VALUES("10002851","威信县","530629","10000306","3","W");
INSERT INTO cmf_region_letter VALUES("10002852","水富市","530681","10000306","3","S");
INSERT INTO cmf_region_letter VALUES("10002853","古城区","530702","10000307","3","G");
INSERT INTO cmf_region_letter VALUES("10002854","玉龙纳西族自治县","530721","10000307","3","Y");
INSERT INTO cmf_region_letter VALUES("10002855","永胜县","530722","10000307","3","Y");
INSERT INTO cmf_region_letter VALUES("10002856","华坪县","530723","10000307","3","H");
INSERT INTO cmf_region_letter VALUES("10002857","宁蒗彝族自治县","530724","10000307","3","N");
INSERT INTO cmf_region_letter VALUES("10002858","思茅区","530802","10000308","3","S");
INSERT INTO cmf_region_letter VALUES("10002859","宁洱哈尼族彝族自治县","530821","10000308","3","N");
INSERT INTO cmf_region_letter VALUES("10002860","墨江哈尼族自治县","530822","10000308","3","M");
INSERT INTO cmf_region_letter VALUES("10002861","景东彝族自治县","530823","10000308","3","J");
INSERT INTO cmf_region_letter VALUES("10002862","景谷傣族彝族自治县","530824","10000308","3","J");
INSERT INTO cmf_region_letter VALUES("10002863","镇沅彝族哈尼族拉祜族自治县","530825","10000308","3","Z");
INSERT INTO cmf_region_letter VALUES("10002864","江城哈尼族彝族自治县","530826","10000308","3","J");
INSERT INTO cmf_region_letter VALUES("10002865","孟连傣族拉祜族佤族自治县","530827","10000308","3","M");
INSERT INTO cmf_region_letter VALUES("10002866","澜沧拉祜族自治县","530828","10000308","3","L");
INSERT INTO cmf_region_letter VALUES("10002867","西盟佤族自治县","530829","10000308","3","X");
INSERT INTO cmf_region_letter VALUES("10002868","临翔区","530902","10000309","3","L");
INSERT INTO cmf_region_letter VALUES("10002869","凤庆县","530921","10000309","3","F");
INSERT INTO cmf_region_letter VALUES("10002870","云县","530922","10000309","3","Y");
INSERT INTO cmf_region_letter VALUES("10002871","永德县","530923","10000309","3","Y");
INSERT INTO cmf_region_letter VALUES("10002872","镇康县","530924","10000309","3","Z");
INSERT INTO cmf_region_letter VALUES("10002873","双江拉祜族佤族布朗族傣族自治县","530925","10000309","3","S");
INSERT INTO cmf_region_letter VALUES("10002874","耿马傣族佤族自治县","530926","10000309","3","G");
INSERT INTO cmf_region_letter VALUES("10002875","沧源佤族自治县","530927","10000309","3","C");
INSERT INTO cmf_region_letter VALUES("10002876","楚雄市","532301","10000310","3","C");
INSERT INTO cmf_region_letter VALUES("10002877","双柏县","532322","10000310","3","S");
INSERT INTO cmf_region_letter VALUES("10002878","牟定县","532323","10000310","3","M");
INSERT INTO cmf_region_letter VALUES("10002879","南华县","532324","10000310","3","N");
INSERT INTO cmf_region_letter VALUES("10002880","姚安县","532325","10000310","3","Y");
INSERT INTO cmf_region_letter VALUES("10002881","大姚县","532326","10000310","3","D");
INSERT INTO cmf_region_letter VALUES("10002882","永仁县","532327","10000310","3","Y");
INSERT INTO cmf_region_letter VALUES("10002883","元谋县","532328","10000310","3","Y");
INSERT INTO cmf_region_letter VALUES("10002884","武定县","532329","10000310","3","W");
INSERT INTO cmf_region_letter VALUES("10002885","禄丰县","532331","10000310","3","L");
INSERT INTO cmf_region_letter VALUES("10002886","个旧市","532501","10000311","3","G");
INSERT INTO cmf_region_letter VALUES("10002887","开远市","532502","10000311","3","K");
INSERT INTO cmf_region_letter VALUES("10002888","蒙自市","532503","10000311","3","M");
INSERT INTO cmf_region_letter VALUES("10002889","弥勒市","532504","10000311","3","M");
INSERT INTO cmf_region_letter VALUES("10002890","屏边苗族自治县","532523","10000311","3","P");
INSERT INTO cmf_region_letter VALUES("10002891","建水县","532524","10000311","3","J");
INSERT INTO cmf_region_letter VALUES("10002892","石屏县","532525","10000311","3","S");
INSERT INTO cmf_region_letter VALUES("10002893","泸西县","532527","10000311","3","L");
INSERT INTO cmf_region_letter VALUES("10002894","元阳县","532528","10000311","3","Y");
INSERT INTO cmf_region_letter VALUES("10002895","红河县","532529","10000311","3","H");
INSERT INTO cmf_region_letter VALUES("10002896","金平苗族瑶族傣族自治县","532530","10000311","3","J");
INSERT INTO cmf_region_letter VALUES("10002897","绿春县","532531","10000311","3","L");
INSERT INTO cmf_region_letter VALUES("10002898","河口瑶族自治县","532532","10000311","3","H");
INSERT INTO cmf_region_letter VALUES("10002899","文山市","532601","10000312","3","W");
INSERT INTO cmf_region_letter VALUES("10002900","砚山县","532622","10000312","3","Y");
INSERT INTO cmf_region_letter VALUES("10002901","西畴县","532623","10000312","3","X");
INSERT INTO cmf_region_letter VALUES("10002902","麻栗坡县","532624","10000312","3","M");
INSERT INTO cmf_region_letter VALUES("10002903","马关县","532625","10000312","3","M");
INSERT INTO cmf_region_letter VALUES("10002904","丘北县","532626","10000312","3","Q");
INSERT INTO cmf_region_letter VALUES("10002905","广南县","532627","10000312","3","G");
INSERT INTO cmf_region_letter VALUES("10002906","富宁县","532628","10000312","3","F");
INSERT INTO cmf_region_letter VALUES("10002907","景洪市","532801","10000313","3","J");
INSERT INTO cmf_region_letter VALUES("10002908","勐海县","532822","10000313","3","M");
INSERT INTO cmf_region_letter VALUES("10002909","勐腊县","532823","10000313","3","M");
INSERT INTO cmf_region_letter VALUES("10002910","大理市","532901","10000314","3","D");
INSERT INTO cmf_region_letter VALUES("10002911","漾濞彝族自治县","532922","10000314","3","Y");
INSERT INTO cmf_region_letter VALUES("10002912","祥云县","532923","10000314","3","X");
INSERT INTO cmf_region_letter VALUES("10002913","宾川县","532924","10000314","3","B");
INSERT INTO cmf_region_letter VALUES("10002914","弥渡县","532925","10000314","3","M");
INSERT INTO cmf_region_letter VALUES("10002915","南涧彝族自治县","532926","10000314","3","N");
INSERT INTO cmf_region_letter VALUES("10002916","巍山彝族回族自治县","532927","10000314","3","W");
INSERT INTO cmf_region_letter VALUES("10002917","永平县","532928","10000314","3","Y");
INSERT INTO cmf_region_letter VALUES("10002918","云龙县","532929","10000314","3","Y");
INSERT INTO cmf_region_letter VALUES("10002919","洱源县","532930","10000314","3","E");
INSERT INTO cmf_region_letter VALUES("10002920","剑川县","532931","10000314","3","J");
INSERT INTO cmf_region_letter VALUES("10002921","鹤庆县","532932","10000314","3","H");
INSERT INTO cmf_region_letter VALUES("10002922","瑞丽市","533102","10000315","3","R");
INSERT INTO cmf_region_letter VALUES("10002923","芒市","533103","10000315","3","M");
INSERT INTO cmf_region_letter VALUES("10002924","梁河县","533122","10000315","3","L");
INSERT INTO cmf_region_letter VALUES("10002925","盈江县","533123","10000315","3","Y");
INSERT INTO cmf_region_letter VALUES("10002926","陇川县","533124","10000315","3","L");
INSERT INTO cmf_region_letter VALUES("10002927","泸水市","533301","10000316","3","L");
INSERT INTO cmf_region_letter VALUES("10002928","福贡县","533323","10000316","3","F");
INSERT INTO cmf_region_letter VALUES("10002929","贡山独龙族怒族自治县","533324","10000316","3","G");
INSERT INTO cmf_region_letter VALUES("10002930","兰坪白族普米族自治县","533325","10000316","3","L");
INSERT INTO cmf_region_letter VALUES("10002931","香格里拉市","533401","10000317","3","X");
INSERT INTO cmf_region_letter VALUES("10002932","德钦县","533422","10000317","3","D");
INSERT INTO cmf_region_letter VALUES("10002933","维西傈僳族自治县","533423","10000317","3","W");
INSERT INTO cmf_region_letter VALUES("10002934","城关区","540102","10000318","3","C");
INSERT INTO cmf_region_letter VALUES("10002935","堆龙德庆区","540103","10000318","3","D");
INSERT INTO cmf_region_letter VALUES("10002936","达孜区","540104","10000318","3","D");
INSERT INTO cmf_region_letter VALUES("10002937","林周县","540121","10000318","3","L");
INSERT INTO cmf_region_letter VALUES("10002938","当雄县","540122","10000318","3","D");
INSERT INTO cmf_region_letter VALUES("10002939","尼木县","540123","10000318","3","N");
INSERT INTO cmf_region_letter VALUES("10002940","曲水县","540124","10000318","3","Q");
INSERT INTO cmf_region_letter VALUES("10002941","墨竹工卡县","540127","10000318","3","M");
INSERT INTO cmf_region_letter VALUES("10002942","桑珠孜区","540202","10000319","3","S");
INSERT INTO cmf_region_letter VALUES("10002943","南木林县","540221","10000319","3","N");
INSERT INTO cmf_region_letter VALUES("10002944","江孜县","540222","10000319","3","J");
INSERT INTO cmf_region_letter VALUES("10002945","定日县","540223","10000319","3","D");
INSERT INTO cmf_region_letter VALUES("10002946","萨迦县","540224","10000319","3","S");
INSERT INTO cmf_region_letter VALUES("10002947","拉孜县","540225","10000319","3","L");
INSERT INTO cmf_region_letter VALUES("10002948","昂仁县","540226","10000319","3","A");
INSERT INTO cmf_region_letter VALUES("10002949","谢通门县","540227","10000319","3","X");
INSERT INTO cmf_region_letter VALUES("10002950","白朗县","540228","10000319","3","B");
INSERT INTO cmf_region_letter VALUES("10002951","仁布县","540229","10000319","3","R");
INSERT INTO cmf_region_letter VALUES("10002952","康马县","540230","10000319","3","K");
INSERT INTO cmf_region_letter VALUES("10002953","定结县","540231","10000319","3","D");
INSERT INTO cmf_region_letter VALUES("10002954","仲巴县","540232","10000319","3","Z");
INSERT INTO cmf_region_letter VALUES("10002955","亚东县","540233","10000319","3","Y");
INSERT INTO cmf_region_letter VALUES("10002956","吉隆县","540234","10000319","3","J");
INSERT INTO cmf_region_letter VALUES("10002957","聂拉木县","540235","10000319","3","N");
INSERT INTO cmf_region_letter VALUES("10002958","萨嘎县","540236","10000319","3","S");
INSERT INTO cmf_region_letter VALUES("10002959","岗巴县","540237","10000319","3","G");
INSERT INTO cmf_region_letter VALUES("10002960","卡若区","540302","10000320","3","K");
INSERT INTO cmf_region_letter VALUES("10002961","江达县","540321","10000320","3","J");
INSERT INTO cmf_region_letter VALUES("10002962","贡觉县","540322","10000320","3","G");
INSERT INTO cmf_region_letter VALUES("10002963","类乌齐县","540323","10000320","3","L");
INSERT INTO cmf_region_letter VALUES("10002964","丁青县","540324","10000320","3","D");
INSERT INTO cmf_region_letter VALUES("10002965","察雅县","540325","10000320","3","C");
INSERT INTO cmf_region_letter VALUES("10002966","八宿县","540326","10000320","3","B");
INSERT INTO cmf_region_letter VALUES("10002967","左贡县","540327","10000320","3","Z");
INSERT INTO cmf_region_letter VALUES("10002968","芒康县","540328","10000320","3","M");
INSERT INTO cmf_region_letter VALUES("10002969","洛隆县","540329","10000320","3","L");
INSERT INTO cmf_region_letter VALUES("10002970","边坝县","540330","10000320","3","B");
INSERT INTO cmf_region_letter VALUES("10002971","巴宜区","540402","10000321","3","B");
INSERT INTO cmf_region_letter VALUES("10002972","工布江达县","540421","10000321","3","G");
INSERT INTO cmf_region_letter VALUES("10002973","米林县","540422","10000321","3","M");
INSERT INTO cmf_region_letter VALUES("10002974","墨脱县","540423","10000321","3","M");
INSERT INTO cmf_region_letter VALUES("10002975","波密县","540424","10000321","3","B");
INSERT INTO cmf_region_letter VALUES("10002976","察隅县","540425","10000321","3","C");
INSERT INTO cmf_region_letter VALUES("10002977","朗县","540426","10000321","3","L");
INSERT INTO cmf_region_letter VALUES("10002978","乃东区","540502","10000322","3","N");
INSERT INTO cmf_region_letter VALUES("10002979","扎囊县","540521","10000322","3","Z");
INSERT INTO cmf_region_letter VALUES("10002980","贡嘎县","540522","10000322","3","G");
INSERT INTO cmf_region_letter VALUES("10002981","桑日县","540523","10000322","3","S");
INSERT INTO cmf_region_letter VALUES("10002982","琼结县","540524","10000322","3","Q");
INSERT INTO cmf_region_letter VALUES("10002983","曲松县","540525","10000322","3","Q");
INSERT INTO cmf_region_letter VALUES("10002984","措美县","540526","10000322","3","C");
INSERT INTO cmf_region_letter VALUES("10002985","洛扎县","540527","10000322","3","L");
INSERT INTO cmf_region_letter VALUES("10002986","加查县","540528","10000322","3","J");
INSERT INTO cmf_region_letter VALUES("10002987","隆子县","540529","10000322","3","L");
INSERT INTO cmf_region_letter VALUES("10002988","错那县","540530","10000322","3","C");
INSERT INTO cmf_region_letter VALUES("10002989","浪卡子县","540531","10000322","3","L");
INSERT INTO cmf_region_letter VALUES("10002990","色尼区","540602","10000323","3","S");
INSERT INTO cmf_region_letter VALUES("10002991","嘉黎县","540621","10000323","3","J");
INSERT INTO cmf_region_letter VALUES("10002992","比如县","540622","10000323","3","B");
INSERT INTO cmf_region_letter VALUES("10002993","聂荣县","540623","10000323","3","N");
INSERT INTO cmf_region_letter VALUES("10002994","安多县","540624","10000323","3","A");
INSERT INTO cmf_region_letter VALUES("10002995","申扎县","540625","10000323","3","S");
INSERT INTO cmf_region_letter VALUES("10002996","索县","540626","10000323","3","S");
INSERT INTO cmf_region_letter VALUES("10002997","班戈县","540627","10000323","3","B");
INSERT INTO cmf_region_letter VALUES("10002998","巴青县","540628","10000323","3","B");
INSERT INTO cmf_region_letter VALUES("10002999","尼玛县","540629","10000323","3","N");
INSERT INTO cmf_region_letter VALUES("10003000","双湖县","540630","10000323","3","S");
INSERT INTO cmf_region_letter VALUES("10003001","普兰县","542521","10000324","3","P");
INSERT INTO cmf_region_letter VALUES("10003002","札达县","542522","10000324","3","Z");
INSERT INTO cmf_region_letter VALUES("10003003","噶尔县","542523","10000324","3","G");
INSERT INTO cmf_region_letter VALUES("10003004","日土县","542524","10000324","3","R");
INSERT INTO cmf_region_letter VALUES("10003005","革吉县","542525","10000324","3","G");
INSERT INTO cmf_region_letter VALUES("10003006","改则县","542526","10000324","3","G");
INSERT INTO cmf_region_letter VALUES("10003007","措勤县","542527","10000324","3","C");
INSERT INTO cmf_region_letter VALUES("10003008","新城区","610102","10000325","3","X");
INSERT INTO cmf_region_letter VALUES("10003009","碑林区","610103","10000325","3","B");
INSERT INTO cmf_region_letter VALUES("10003010","莲湖区","610104","10000325","3","L");
INSERT INTO cmf_region_letter VALUES("10003011","灞桥区","610111","10000325","3","B");
INSERT INTO cmf_region_letter VALUES("10003012","未央区","610112","10000325","3","W");
INSERT INTO cmf_region_letter VALUES("10003013","雁塔区","610113","10000325","3","Y");
INSERT INTO cmf_region_letter VALUES("10003014","阎良区","610114","10000325","3","Y");
INSERT INTO cmf_region_letter VALUES("10003015","临潼区","610115","10000325","3","L");
INSERT INTO cmf_region_letter VALUES("10003016","长安区","610116","10000325","3","C");
INSERT INTO cmf_region_letter VALUES("10003017","高陵区","610117","10000325","3","G");
INSERT INTO cmf_region_letter VALUES("10003018","鄠邑区","610118","10000325","3","H");
INSERT INTO cmf_region_letter VALUES("10003019","蓝田县","610122","10000325","3","L");
INSERT INTO cmf_region_letter VALUES("10003020","周至县","610124","10000325","3","Z");
INSERT INTO cmf_region_letter VALUES("10003021","王益区","610202","10000326","3","W");
INSERT INTO cmf_region_letter VALUES("10003022","印台区","610203","10000326","3","Y");
INSERT INTO cmf_region_letter VALUES("10003023","耀州区","610204","10000326","3","Y");
INSERT INTO cmf_region_letter VALUES("10003024","宜君县","610222","10000326","3","Y");
INSERT INTO cmf_region_letter VALUES("10003025","渭滨区","610302","10000327","3","W");
INSERT INTO cmf_region_letter VALUES("10003026","金台区","610303","10000327","3","J");
INSERT INTO cmf_region_letter VALUES("10003027","陈仓区","610304","10000327","3","C");
INSERT INTO cmf_region_letter VALUES("10003028","凤翔县","610322","10000327","3","F");
INSERT INTO cmf_region_letter VALUES("10003029","岐山县","610323","10000327","3","Q");
INSERT INTO cmf_region_letter VALUES("10003030","扶风县","610324","10000327","3","F");
INSERT INTO cmf_region_letter VALUES("10003031","眉县","610326","10000327","3","M");
INSERT INTO cmf_region_letter VALUES("10003032","陇县","610327","10000327","3","L");
INSERT INTO cmf_region_letter VALUES("10003033","千阳县","610328","10000327","3","Q");
INSERT INTO cmf_region_letter VALUES("10003034","麟游县","610329","10000327","3","L");
INSERT INTO cmf_region_letter VALUES("10003035","凤县","610330","10000327","3","F");
INSERT INTO cmf_region_letter VALUES("10003036","太白县","610331","10000327","3","T");
INSERT INTO cmf_region_letter VALUES("10003037","秦都区","610402","10000328","3","Q");
INSERT INTO cmf_region_letter VALUES("10003038","杨陵区","610403","10000328","3","Y");
INSERT INTO cmf_region_letter VALUES("10003039","渭城区","610404","10000328","3","W");
INSERT INTO cmf_region_letter VALUES("10003040","三原县","610422","10000328","3","S");
INSERT INTO cmf_region_letter VALUES("10003041","泾阳县","610423","10000328","3","J");
INSERT INTO cmf_region_letter VALUES("10003042","乾县","610424","10000328","3","Q");
INSERT INTO cmf_region_letter VALUES("10003043","礼泉县","610425","10000328","3","L");
INSERT INTO cmf_region_letter VALUES("10003044","永寿县","610426","10000328","3","Y");
INSERT INTO cmf_region_letter VALUES("10003045","长武县","610428","10000328","3","C");
INSERT INTO cmf_region_letter VALUES("10003046","旬邑县","610429","10000328","3","X");
INSERT INTO cmf_region_letter VALUES("10003047","淳化县","610430","10000328","3","C");
INSERT INTO cmf_region_letter VALUES("10003048","武功县","610431","10000328","3","W");
INSERT INTO cmf_region_letter VALUES("10003049","兴平市","610481","10000328","3","X");
INSERT INTO cmf_region_letter VALUES("10003050","彬州市","610482","10000328","3","B");
INSERT INTO cmf_region_letter VALUES("10003051","临渭区","610502","10000329","3","L");
INSERT INTO cmf_region_letter VALUES("10003052","华州区","610503","10000329","3","H");
INSERT INTO cmf_region_letter VALUES("10003053","潼关县","610522","10000329","3","T");
INSERT INTO cmf_region_letter VALUES("10003054","大荔县","610523","10000329","3","D");
INSERT INTO cmf_region_letter VALUES("10003055","合阳县","610524","10000329","3","H");
INSERT INTO cmf_region_letter VALUES("10003056","澄城县","610525","10000329","3","C");
INSERT INTO cmf_region_letter VALUES("10003057","蒲城县","610526","10000329","3","P");
INSERT INTO cmf_region_letter VALUES("10003058","白水县","610527","10000329","3","B");
INSERT INTO cmf_region_letter VALUES("10003059","富平县","610528","10000329","3","F");
INSERT INTO cmf_region_letter VALUES("10003060","韩城市","610581","10000329","3","H");
INSERT INTO cmf_region_letter VALUES("10003061","华阴市","610582","10000329","3","H");
INSERT INTO cmf_region_letter VALUES("10003062","宝塔区","610602","10000330","3","B");
INSERT INTO cmf_region_letter VALUES("10003063","安塞区","610603","10000330","3","A");
INSERT INTO cmf_region_letter VALUES("10003064","延长县","610621","10000330","3","Y");
INSERT INTO cmf_region_letter VALUES("10003065","延川县","610622","10000330","3","Y");
INSERT INTO cmf_region_letter VALUES("10003066","子长县","610623","10000330","3","Z");
INSERT INTO cmf_region_letter VALUES("10003067","志丹县","610625","10000330","3","Z");
INSERT INTO cmf_region_letter VALUES("10003068","吴起县","610626","10000330","3","W");
INSERT INTO cmf_region_letter VALUES("10003069","甘泉县","610627","10000330","3","G");
INSERT INTO cmf_region_letter VALUES("10003070","富县","610628","10000330","3","F");
INSERT INTO cmf_region_letter VALUES("10003071","洛川县","610629","10000330","3","L");
INSERT INTO cmf_region_letter VALUES("10003072","宜川县","610630","10000330","3","Y");
INSERT INTO cmf_region_letter VALUES("10003073","黄龙县","610631","10000330","3","H");
INSERT INTO cmf_region_letter VALUES("10003074","黄陵县","610632","10000330","3","H");
INSERT INTO cmf_region_letter VALUES("10003075","汉台区","610702","10000331","3","H");
INSERT INTO cmf_region_letter VALUES("10003076","南郑区","610703","10000331","3","N");
INSERT INTO cmf_region_letter VALUES("10003077","城固县","610722","10000331","3","C");
INSERT INTO cmf_region_letter VALUES("10003078","洋县","610723","10000331","3","Y");
INSERT INTO cmf_region_letter VALUES("10003079","西乡县","610724","10000331","3","X");
INSERT INTO cmf_region_letter VALUES("10003080","勉县","610725","10000331","3","M");
INSERT INTO cmf_region_letter VALUES("10003081","宁强县","610726","10000331","3","N");
INSERT INTO cmf_region_letter VALUES("10003082","略阳县","610727","10000331","3","L");
INSERT INTO cmf_region_letter VALUES("10003083","镇巴县","610728","10000331","3","Z");
INSERT INTO cmf_region_letter VALUES("10003084","留坝县","610729","10000331","3","L");
INSERT INTO cmf_region_letter VALUES("10003085","佛坪县","610730","10000331","3","F");
INSERT INTO cmf_region_letter VALUES("10003086","榆阳区","610802","10000332","3","Y");
INSERT INTO cmf_region_letter VALUES("10003087","横山区","610803","10000332","3","H");
INSERT INTO cmf_region_letter VALUES("10003088","府谷县","610822","10000332","3","F");
INSERT INTO cmf_region_letter VALUES("10003089","靖边县","610824","10000332","3","J");
INSERT INTO cmf_region_letter VALUES("10003090","定边县","610825","10000332","3","D");
INSERT INTO cmf_region_letter VALUES("10003091","绥德县","610826","10000332","3","S");
INSERT INTO cmf_region_letter VALUES("10003092","米脂县","610827","10000332","3","M");
INSERT INTO cmf_region_letter VALUES("10003093","佳县","610828","10000332","3","J");
INSERT INTO cmf_region_letter VALUES("10003094","吴堡县","610829","10000332","3","W");
INSERT INTO cmf_region_letter VALUES("10003095","清涧县","610830","10000332","3","Q");
INSERT INTO cmf_region_letter VALUES("10003096","子洲县","610831","10000332","3","Z");
INSERT INTO cmf_region_letter VALUES("10003097","神木市","610881","10000332","3","S");
INSERT INTO cmf_region_letter VALUES("10003098","汉滨区","610902","10000333","3","H");
INSERT INTO cmf_region_letter VALUES("10003099","汉阴县","610921","10000333","3","H");
INSERT INTO cmf_region_letter VALUES("10003100","石泉县","610922","10000333","3","S");
INSERT INTO cmf_region_letter VALUES("10003101","宁陕县","610923","10000333","3","N");
INSERT INTO cmf_region_letter VALUES("10003102","紫阳县","610924","10000333","3","Z");
INSERT INTO cmf_region_letter VALUES("10003103","岚皋县","610925","10000333","3","L");
INSERT INTO cmf_region_letter VALUES("10003104","平利县","610926","10000333","3","P");
INSERT INTO cmf_region_letter VALUES("10003105","镇坪县","610927","10000333","3","Z");
INSERT INTO cmf_region_letter VALUES("10003106","旬阳县","610928","10000333","3","X");
INSERT INTO cmf_region_letter VALUES("10003107","白河县","610929","10000333","3","B");
INSERT INTO cmf_region_letter VALUES("10003108","商州区","611002","10000334","3","S");
INSERT INTO cmf_region_letter VALUES("10003109","洛南县","611021","10000334","3","L");
INSERT INTO cmf_region_letter VALUES("10003110","丹凤县","611022","10000334","3","D");
INSERT INTO cmf_region_letter VALUES("10003111","商南县","611023","10000334","3","S");
INSERT INTO cmf_region_letter VALUES("10003112","山阳县","611024","10000334","3","S");
INSERT INTO cmf_region_letter VALUES("10003113","镇安县","611025","10000334","3","Z");
INSERT INTO cmf_region_letter VALUES("10003114","柞水县","611026","10000334","3","Z");
INSERT INTO cmf_region_letter VALUES("10003115","城关区","620102","10000335","3","C");
INSERT INTO cmf_region_letter VALUES("10003116","七里河区","620103","10000335","3","Q");
INSERT INTO cmf_region_letter VALUES("10003117","西固区","620104","10000335","3","X");
INSERT INTO cmf_region_letter VALUES("10003118","安宁区","620105","10000335","3","A");
INSERT INTO cmf_region_letter VALUES("10003119","红古区","620111","10000335","3","H");
INSERT INTO cmf_region_letter VALUES("10003120","永登县","620121","10000335","3","Y");
INSERT INTO cmf_region_letter VALUES("10003121","皋兰县","620122","10000335","3","G");
INSERT INTO cmf_region_letter VALUES("10003122","榆中县","620123","10000335","3","Y");
INSERT INTO cmf_region_letter VALUES("10003123","市辖区","620201","10000336","3","S");
INSERT INTO cmf_region_letter VALUES("10003124","雄关区","620290","10000336","3","X");
INSERT INTO cmf_region_letter VALUES("10003125","长城区","620291","10000336","3","C");
INSERT INTO cmf_region_letter VALUES("10003126","镜铁区","620292","10000336","3","J");
INSERT INTO cmf_region_letter VALUES("10003127","新城镇","620293","10000336","3","X");
INSERT INTO cmf_region_letter VALUES("10003128","峪泉镇","620294","10000336","3","Y");
INSERT INTO cmf_region_letter VALUES("10003129","文殊镇","620295","10000336","3","W");
INSERT INTO cmf_region_letter VALUES("10003130","金川区","620302","10000337","3","J");
INSERT INTO cmf_region_letter VALUES("10003131","永昌县","620321","10000337","3","Y");
INSERT INTO cmf_region_letter VALUES("10003132","白银区","620402","10000338","3","B");
INSERT INTO cmf_region_letter VALUES("10003133","平川区","620403","10000338","3","P");
INSERT INTO cmf_region_letter VALUES("10003134","靖远县","620421","10000338","3","J");
INSERT INTO cmf_region_letter VALUES("10003135","会宁县","620422","10000338","3","H");
INSERT INTO cmf_region_letter VALUES("10003136","景泰县","620423","10000338","3","J");
INSERT INTO cmf_region_letter VALUES("10003137","秦州区","620502","10000339","3","Q");
INSERT INTO cmf_region_letter VALUES("10003138","麦积区","620503","10000339","3","M");
INSERT INTO cmf_region_letter VALUES("10003139","清水县","620521","10000339","3","Q");
INSERT INTO cmf_region_letter VALUES("10003140","秦安县","620522","10000339","3","Q");
INSERT INTO cmf_region_letter VALUES("10003141","甘谷县","620523","10000339","3","G");
INSERT INTO cmf_region_letter VALUES("10003142","武山县","620524","10000339","3","W");
INSERT INTO cmf_region_letter VALUES("10003143","张家川回族自治县","620525","10000339","3","Z");
INSERT INTO cmf_region_letter VALUES("10003144","凉州区","620602","10000340","3","L");
INSERT INTO cmf_region_letter VALUES("10003145","民勤县","620621","10000340","3","M");
INSERT INTO cmf_region_letter VALUES("10003146","古浪县","620622","10000340","3","G");
INSERT INTO cmf_region_letter VALUES("10003147","天祝藏族自治县","620623","10000340","3","T");
INSERT INTO cmf_region_letter VALUES("10003148","甘州区","620702","10000341","3","G");
INSERT INTO cmf_region_letter VALUES("10003149","肃南裕固族自治县","620721","10000341","3","S");
INSERT INTO cmf_region_letter VALUES("10003150","民乐县","620722","10000341","3","M");
INSERT INTO cmf_region_letter VALUES("10003151","临泽县","620723","10000341","3","L");
INSERT INTO cmf_region_letter VALUES("10003152","高台县","620724","10000341","3","G");
INSERT INTO cmf_region_letter VALUES("10003153","山丹县","620725","10000341","3","S");
INSERT INTO cmf_region_letter VALUES("10003154","崆峒区","620802","10000342","3","K");
INSERT INTO cmf_region_letter VALUES("10003155","泾川县","620821","10000342","3","J");
INSERT INTO cmf_region_letter VALUES("10003156","灵台县","620822","10000342","3","L");
INSERT INTO cmf_region_letter VALUES("10003157","崇信县","620823","10000342","3","C");
INSERT INTO cmf_region_letter VALUES("10003158","庄浪县","620825","10000342","3","Z");
INSERT INTO cmf_region_letter VALUES("10003159","静宁县","620826","10000342","3","J");
INSERT INTO cmf_region_letter VALUES("10003160","华亭市","620881","10000342","3","H");
INSERT INTO cmf_region_letter VALUES("10003161","肃州区","620902","10000343","3","S");
INSERT INTO cmf_region_letter VALUES("10003162","金塔县","620921","10000343","3","J");
INSERT INTO cmf_region_letter VALUES("10003163","瓜州县","620922","10000343","3","G");
INSERT INTO cmf_region_letter VALUES("10003164","肃北蒙古族自治县","620923","10000343","3","S");
INSERT INTO cmf_region_letter VALUES("10003165","阿克塞哈萨克族自治县","620924","10000343","3","A");
INSERT INTO cmf_region_letter VALUES("10003166","玉门市","620981","10000343","3","Y");
INSERT INTO cmf_region_letter VALUES("10003167","敦煌市","620982","10000343","3","D");
INSERT INTO cmf_region_letter VALUES("10003168","西峰区","621002","10000344","3","X");
INSERT INTO cmf_region_letter VALUES("10003169","庆城县","621021","10000344","3","Q");
INSERT INTO cmf_region_letter VALUES("10003170","环县","621022","10000344","3","H");
INSERT INTO cmf_region_letter VALUES("10003171","华池县","621023","10000344","3","H");
INSERT INTO cmf_region_letter VALUES("10003172","合水县","621024","10000344","3","H");
INSERT INTO cmf_region_letter VALUES("10003173","正宁县","621025","10000344","3","Z");
INSERT INTO cmf_region_letter VALUES("10003174","宁县","621026","10000344","3","N");
INSERT INTO cmf_region_letter VALUES("10003175","镇原县","621027","10000344","3","Z");
INSERT INTO cmf_region_letter VALUES("10003176","安定区","621102","10000345","3","A");
INSERT INTO cmf_region_letter VALUES("10003177","通渭县","621121","10000345","3","T");
INSERT INTO cmf_region_letter VALUES("10003178","陇西县","621122","10000345","3","L");
INSERT INTO cmf_region_letter VALUES("10003179","渭源县","621123","10000345","3","W");
INSERT INTO cmf_region_letter VALUES("10003180","临洮县","621124","10000345","3","L");
INSERT INTO cmf_region_letter VALUES("10003181","漳县","621125","10000345","3","Z");
INSERT INTO cmf_region_letter VALUES("10003182","岷县","621126","10000345","3","M");
INSERT INTO cmf_region_letter VALUES("10003183","武都区","621202","10000346","3","W");
INSERT INTO cmf_region_letter VALUES("10003184","成县","621221","10000346","3","C");
INSERT INTO cmf_region_letter VALUES("10003185","文县","621222","10000346","3","W");
INSERT INTO cmf_region_letter VALUES("10003186","宕昌县","621223","10000346","3","D");
INSERT INTO cmf_region_letter VALUES("10003187","康县","621224","10000346","3","K");
INSERT INTO cmf_region_letter VALUES("10003188","西和县","621225","10000346","3","X");
INSERT INTO cmf_region_letter VALUES("10003189","礼县","621226","10000346","3","L");
INSERT INTO cmf_region_letter VALUES("10003190","徽县","621227","10000346","3","H");
INSERT INTO cmf_region_letter VALUES("10003191","两当县","621228","10000346","3","L");
INSERT INTO cmf_region_letter VALUES("10003192","临夏市","622901","10000347","3","L");
INSERT INTO cmf_region_letter VALUES("10003193","临夏县","622921","10000347","3","L");
INSERT INTO cmf_region_letter VALUES("10003194","康乐县","622922","10000347","3","K");
INSERT INTO cmf_region_letter VALUES("10003195","永靖县","622923","10000347","3","Y");
INSERT INTO cmf_region_letter VALUES("10003196","广河县","622924","10000347","3","G");
INSERT INTO cmf_region_letter VALUES("10003197","和政县","622925","10000347","3","H");
INSERT INTO cmf_region_letter VALUES("10003198","东乡族自治县","622926","10000347","3","D");
INSERT INTO cmf_region_letter VALUES("10003199","积石山保安族东乡族撒拉族自治县","622927","10000347","3","J");
INSERT INTO cmf_region_letter VALUES("10003200","合作市","623001","10000348","3","H");
INSERT INTO cmf_region_letter VALUES("10003201","临潭县","623021","10000348","3","L");
INSERT INTO cmf_region_letter VALUES("10003202","卓尼县","623022","10000348","3","Z");
INSERT INTO cmf_region_letter VALUES("10003203","舟曲县","623023","10000348","3","Z");
INSERT INTO cmf_region_letter VALUES("10003204","迭部县","623024","10000348","3","D");
INSERT INTO cmf_region_letter VALUES("10003205","玛曲县","623025","10000348","3","M");
INSERT INTO cmf_region_letter VALUES("10003206","碌曲县","623026","10000348","3","L");
INSERT INTO cmf_region_letter VALUES("10003207","夏河县","623027","10000348","3","X");
INSERT INTO cmf_region_letter VALUES("10003208","城东区","630102","10000349","3","C");
INSERT INTO cmf_region_letter VALUES("10003209","城中区","630103","10000349","3","C");
INSERT INTO cmf_region_letter VALUES("10003210","城西区","630104","10000349","3","C");
INSERT INTO cmf_region_letter VALUES("10003211","城北区","630105","10000349","3","C");
INSERT INTO cmf_region_letter VALUES("10003212","大通回族土族自治县","630121","10000349","3","D");
INSERT INTO cmf_region_letter VALUES("10003213","湟中县","630122","10000349","3","H");
INSERT INTO cmf_region_letter VALUES("10003214","湟源县","630123","10000349","3","H");
INSERT INTO cmf_region_letter VALUES("10003215","乐都区","630202","10000350","3","L");
INSERT INTO cmf_region_letter VALUES("10003216","平安区","630203","10000350","3","P");
INSERT INTO cmf_region_letter VALUES("10003217","民和回族土族自治县","630222","10000350","3","M");
INSERT INTO cmf_region_letter VALUES("10003218","互助土族自治县","630223","10000350","3","H");
INSERT INTO cmf_region_letter VALUES("10003219","化隆回族自治县","630224","10000350","3","H");
INSERT INTO cmf_region_letter VALUES("10003220","循化撒拉族自治县","630225","10000350","3","X");
INSERT INTO cmf_region_letter VALUES("10003221","门源回族自治县","632221","10000351","3","M");
INSERT INTO cmf_region_letter VALUES("10003222","祁连县","632222","10000351","3","Q");
INSERT INTO cmf_region_letter VALUES("10003223","海晏县","632223","10000351","3","H");
INSERT INTO cmf_region_letter VALUES("10003224","刚察县","632224","10000351","3","G");
INSERT INTO cmf_region_letter VALUES("10003225","同仁县","632321","10000352","3","T");
INSERT INTO cmf_region_letter VALUES("10003226","尖扎县","632322","10000352","3","J");
INSERT INTO cmf_region_letter VALUES("10003227","泽库县","632323","10000352","3","Z");
INSERT INTO cmf_region_letter VALUES("10003228","河南蒙古族自治县","632324","10000352","3","H");
INSERT INTO cmf_region_letter VALUES("10003229","共和县","632521","10000353","3","G");
INSERT INTO cmf_region_letter VALUES("10003230","同德县","632522","10000353","3","T");
INSERT INTO cmf_region_letter VALUES("10003231","贵德县","632523","10000353","3","G");
INSERT INTO cmf_region_letter VALUES("10003232","兴海县","632524","10000353","3","X");
INSERT INTO cmf_region_letter VALUES("10003233","贵南县","632525","10000353","3","G");
INSERT INTO cmf_region_letter VALUES("10003234","玛沁县","632621","10000354","3","M");
INSERT INTO cmf_region_letter VALUES("10003235","班玛县","632622","10000354","3","B");
INSERT INTO cmf_region_letter VALUES("10003236","甘德县","632623","10000354","3","G");
INSERT INTO cmf_region_letter VALUES("10003237","达日县","632624","10000354","3","D");
INSERT INTO cmf_region_letter VALUES("10003238","久治县","632625","10000354","3","J");
INSERT INTO cmf_region_letter VALUES("10003239","玛多县","632626","10000354","3","M");
INSERT INTO cmf_region_letter VALUES("10003240","玉树市","632701","10000355","3","Y");
INSERT INTO cmf_region_letter VALUES("10003241","杂多县","632722","10000355","3","Z");
INSERT INTO cmf_region_letter VALUES("10003242","称多县","632723","10000355","3","C");
INSERT INTO cmf_region_letter VALUES("10003243","治多县","632724","10000355","3","Z");
INSERT INTO cmf_region_letter VALUES("10003244","囊谦县","632725","10000355","3","N");
INSERT INTO cmf_region_letter VALUES("10003245","曲麻莱县","632726","10000355","3","Q");
INSERT INTO cmf_region_letter VALUES("10003246","格尔木市","632801","10000356","3","G");
INSERT INTO cmf_region_letter VALUES("10003247","德令哈市","632802","10000356","3","D");
INSERT INTO cmf_region_letter VALUES("10003248","茫崖市","632803","10000356","3","M");
INSERT INTO cmf_region_letter VALUES("10003249","乌兰县","632821","10000356","3","W");
INSERT INTO cmf_region_letter VALUES("10003250","都兰县","632822","10000356","3","D");
INSERT INTO cmf_region_letter VALUES("10003251","天峻县","632823","10000356","3","T");
INSERT INTO cmf_region_letter VALUES("10003252","兴庆区","640104","10000357","3","X");
INSERT INTO cmf_region_letter VALUES("10003253","西夏区","640105","10000357","3","X");
INSERT INTO cmf_region_letter VALUES("10003254","金凤区","640106","10000357","3","J");
INSERT INTO cmf_region_letter VALUES("10003255","永宁县","640121","10000357","3","Y");
INSERT INTO cmf_region_letter VALUES("10003256","贺兰县","640122","10000357","3","H");
INSERT INTO cmf_region_letter VALUES("10003257","灵武市","640181","10000357","3","L");
INSERT INTO cmf_region_letter VALUES("10003258","大武口区","640202","10000358","3","D");
INSERT INTO cmf_region_letter VALUES("10003259","惠农区","640205","10000358","3","H");
INSERT INTO cmf_region_letter VALUES("10003260","平罗县","640221","10000358","3","P");
INSERT INTO cmf_region_letter VALUES("10003261","利通区","640302","10000359","3","L");
INSERT INTO cmf_region_letter VALUES("10003262","红寺堡区","640303","10000359","3","H");
INSERT INTO cmf_region_letter VALUES("10003263","盐池县","640323","10000359","3","Y");
INSERT INTO cmf_region_letter VALUES("10003264","同心县","640324","10000359","3","T");
INSERT INTO cmf_region_letter VALUES("10003265","青铜峡市","640381","10000359","3","Q");
INSERT INTO cmf_region_letter VALUES("10003266","原州区","640402","10000360","3","Y");
INSERT INTO cmf_region_letter VALUES("10003267","西吉县","640422","10000360","3","X");
INSERT INTO cmf_region_letter VALUES("10003268","隆德县","640423","10000360","3","L");
INSERT INTO cmf_region_letter VALUES("10003269","泾源县","640424","10000360","3","J");
INSERT INTO cmf_region_letter VALUES("10003270","彭阳县","640425","10000360","3","P");
INSERT INTO cmf_region_letter VALUES("10003271","沙坡头区","640502","10000361","3","S");
INSERT INTO cmf_region_letter VALUES("10003272","中宁县","640521","10000361","3","Z");
INSERT INTO cmf_region_letter VALUES("10003273","海原县","640522","10000361","3","H");
INSERT INTO cmf_region_letter VALUES("10003274","天山区","650102","10000362","3","T");
INSERT INTO cmf_region_letter VALUES("10003275","沙依巴克区","650103","10000362","3","S");
INSERT INTO cmf_region_letter VALUES("10003276","新市区","650104","10000362","3","X");
INSERT INTO cmf_region_letter VALUES("10003277","水磨沟区","650105","10000362","3","S");
INSERT INTO cmf_region_letter VALUES("10003278","头屯河区","650106","10000362","3","T");
INSERT INTO cmf_region_letter VALUES("10003279","达坂城区","650107","10000362","3","D");
INSERT INTO cmf_region_letter VALUES("10003280","米东区","650109","10000362","3","M");
INSERT INTO cmf_region_letter VALUES("10003281","乌鲁木齐县","650121","10000362","3","W");
INSERT INTO cmf_region_letter VALUES("10003282","独山子区","650202","10000363","3","D");
INSERT INTO cmf_region_letter VALUES("10003283","克拉玛依区","650203","10000363","3","K");
INSERT INTO cmf_region_letter VALUES("10003284","白碱滩区","650204","10000363","3","B");
INSERT INTO cmf_region_letter VALUES("10003285","乌尔禾区","650205","10000363","3","W");
INSERT INTO cmf_region_letter VALUES("10003286","高昌区","650402","10000364","3","G");
INSERT INTO cmf_region_letter VALUES("10003287","鄯善县","650421","10000364","3","S");
INSERT INTO cmf_region_letter VALUES("10003288","托克逊县","650422","10000364","3","T");
INSERT INTO cmf_region_letter VALUES("10003289","伊州区","650502","10000365","3","Y");
INSERT INTO cmf_region_letter VALUES("10003290","巴里坤哈萨克自治县","650521","10000365","3","B");
INSERT INTO cmf_region_letter VALUES("10003291","伊吾县","650522","10000365","3","Y");
INSERT INTO cmf_region_letter VALUES("10003292","昌吉市","652301","10000366","3","C");
INSERT INTO cmf_region_letter VALUES("10003293","阜康市","652302","10000366","3","F");
INSERT INTO cmf_region_letter VALUES("10003294","呼图壁县","652323","10000366","3","H");
INSERT INTO cmf_region_letter VALUES("10003295","玛纳斯县","652324","10000366","3","M");
INSERT INTO cmf_region_letter VALUES("10003296","奇台县","652325","10000366","3","Q");
INSERT INTO cmf_region_letter VALUES("10003297","吉木萨尔县","652327","10000366","3","J");
INSERT INTO cmf_region_letter VALUES("10003298","木垒哈萨克自治县","652328","10000366","3","M");
INSERT INTO cmf_region_letter VALUES("10003299","博乐市","652701","10000367","3","B");
INSERT INTO cmf_region_letter VALUES("10003300","阿拉山口市","652702","10000367","3","A");
INSERT INTO cmf_region_letter VALUES("10003301","精河县","652722","10000367","3","J");
INSERT INTO cmf_region_letter VALUES("10003302","温泉县","652723","10000367","3","W");
INSERT INTO cmf_region_letter VALUES("10003303","库尔勒市","652801","10000368","3","K");
INSERT INTO cmf_region_letter VALUES("10003304","轮台县","652822","10000368","3","L");
INSERT INTO cmf_region_letter VALUES("10003305","尉犁县","652823","10000368","3","Y");
INSERT INTO cmf_region_letter VALUES("10003306","若羌县","652824","10000368","3","R");
INSERT INTO cmf_region_letter VALUES("10003307","且末县","652825","10000368","3","Q");
INSERT INTO cmf_region_letter VALUES("10003308","焉耆回族自治县","652826","10000368","3","Y");
INSERT INTO cmf_region_letter VALUES("10003309","和静县","652827","10000368","3","H");
INSERT INTO cmf_region_letter VALUES("10003310","和硕县","652828","10000368","3","H");
INSERT INTO cmf_region_letter VALUES("10003311","博湖县","652829","10000368","3","B");
INSERT INTO cmf_region_letter VALUES("10003312","阿克苏市","652901","10000369","3","A");
INSERT INTO cmf_region_letter VALUES("10003313","温宿县","652922","10000369","3","W");
INSERT INTO cmf_region_letter VALUES("10003314","库车县","652923","10000369","3","K");
INSERT INTO cmf_region_letter VALUES("10003315","沙雅县","652924","10000369","3","S");
INSERT INTO cmf_region_letter VALUES("10003316","新和县","652925","10000369","3","X");
INSERT INTO cmf_region_letter VALUES("10003317","拜城县","652926","10000369","3","B");
INSERT INTO cmf_region_letter VALUES("10003318","乌什县","652927","10000369","3","W");
INSERT INTO cmf_region_letter VALUES("10003319","阿瓦提县","652928","10000369","3","A");
INSERT INTO cmf_region_letter VALUES("10003320","柯坪县","652929","10000369","3","K");
INSERT INTO cmf_region_letter VALUES("10003321","阿图什市","653001","10000370","3","A");
INSERT INTO cmf_region_letter VALUES("10003322","阿克陶县","653022","10000370","3","A");
INSERT INTO cmf_region_letter VALUES("10003323","阿合奇县","653023","10000370","3","A");
INSERT INTO cmf_region_letter VALUES("10003324","乌恰县","653024","10000370","3","W");
INSERT INTO cmf_region_letter VALUES("10003325","喀什市","653101","10000371","3","K");
INSERT INTO cmf_region_letter VALUES("10003326","疏附县","653121","10000371","3","S");
INSERT INTO cmf_region_letter VALUES("10003327","疏勒县","653122","10000371","3","S");
INSERT INTO cmf_region_letter VALUES("10003328","英吉沙县","653123","10000371","3","Y");
INSERT INTO cmf_region_letter VALUES("10003329","泽普县","653124","10000371","3","Z");
INSERT INTO cmf_region_letter VALUES("10003330","莎车县","653125","10000371","3","S");
INSERT INTO cmf_region_letter VALUES("10003331","叶城县","653126","10000371","3","Y");
INSERT INTO cmf_region_letter VALUES("10003332","麦盖提县","653127","10000371","3","M");
INSERT INTO cmf_region_letter VALUES("10003333","岳普湖县","653128","10000371","3","Y");
INSERT INTO cmf_region_letter VALUES("10003334","伽师县","653129","10000371","3","J");
INSERT INTO cmf_region_letter VALUES("10003335","巴楚县","653130","10000371","3","B");
INSERT INTO cmf_region_letter VALUES("10003336","塔什库尔干塔吉克自治县","653131","10000371","3","T");
INSERT INTO cmf_region_letter VALUES("10003337","和田市","653201","10000372","3","H");
INSERT INTO cmf_region_letter VALUES("10003338","和田县","653221","10000372","3","H");
INSERT INTO cmf_region_letter VALUES("10003339","墨玉县","653222","10000372","3","M");
INSERT INTO cmf_region_letter VALUES("10003340","皮山县","653223","10000372","3","P");
INSERT INTO cmf_region_letter VALUES("10003341","洛浦县","653224","10000372","3","L");
INSERT INTO cmf_region_letter VALUES("10003342","策勒县","653225","10000372","3","C");
INSERT INTO cmf_region_letter VALUES("10003343","于田县","653226","10000372","3","Y");
INSERT INTO cmf_region_letter VALUES("10003344","民丰县","653227","10000372","3","M");
INSERT INTO cmf_region_letter VALUES("10003345","伊宁市","654002","10000373","3","Y");
INSERT INTO cmf_region_letter VALUES("10003346","奎屯市","654003","10000373","3","K");
INSERT INTO cmf_region_letter VALUES("10003347","霍尔果斯市","654004","10000373","3","H");
INSERT INTO cmf_region_letter VALUES("10003348","伊宁县","654021","10000373","3","Y");
INSERT INTO cmf_region_letter VALUES("10003349","察布查尔锡伯自治县","654022","10000373","3","C");
INSERT INTO cmf_region_letter VALUES("10003350","霍城县","654023","10000373","3","H");
INSERT INTO cmf_region_letter VALUES("10003351","巩留县","654024","10000373","3","G");
INSERT INTO cmf_region_letter VALUES("10003352","新源县","654025","10000373","3","X");
INSERT INTO cmf_region_letter VALUES("10003353","昭苏县","654026","10000373","3","Z");
INSERT INTO cmf_region_letter VALUES("10003354","特克斯县","654027","10000373","3","T");
INSERT INTO cmf_region_letter VALUES("10003355","尼勒克县","654028","10000373","3","N");
INSERT INTO cmf_region_letter VALUES("10003356","塔城市","654201","10000374","3","T");
INSERT INTO cmf_region_letter VALUES("10003357","乌苏市","654202","10000374","3","W");
INSERT INTO cmf_region_letter VALUES("10003358","额敏县","654221","10000374","3","E");
INSERT INTO cmf_region_letter VALUES("10003359","沙湾县","654223","10000374","3","S");
INSERT INTO cmf_region_letter VALUES("10003360","托里县","654224","10000374","3","T");
INSERT INTO cmf_region_letter VALUES("10003361","裕民县","654225","10000374","3","Y");
INSERT INTO cmf_region_letter VALUES("10003362","和布克赛尔蒙古自治县","654226","10000374","3","H");
INSERT INTO cmf_region_letter VALUES("10003363","阿勒泰市","654301","10000375","3","A");
INSERT INTO cmf_region_letter VALUES("10003364","布尔津县","654321","10000375","3","B");
INSERT INTO cmf_region_letter VALUES("10003365","富蕴县","654322","10000375","3","F");
INSERT INTO cmf_region_letter VALUES("10003366","福海县","654323","10000375","3","F");
INSERT INTO cmf_region_letter VALUES("10003367","哈巴河县","654324","10000375","3","H");
INSERT INTO cmf_region_letter VALUES("10003368","青河县","654325","10000375","3","Q");
INSERT INTO cmf_region_letter VALUES("10003369","吉木乃县","654326","10000375","3","J");
INSERT INTO cmf_region_letter VALUES("10003370","石河子市","659001","10000376","3","S");
INSERT INTO cmf_region_letter VALUES("10003371","阿拉尔市","659002","10000376","3","A");
INSERT INTO cmf_region_letter VALUES("10003372","图木舒克市","659003","10000376","3","T");
INSERT INTO cmf_region_letter VALUES("10003373","五家渠市","659004","10000376","3","W");
INSERT INTO cmf_region_letter VALUES("10003374","北屯市","659005","10000376","3","B");
INSERT INTO cmf_region_letter VALUES("10003375","铁门关市","659006","10000376","3","T");
INSERT INTO cmf_region_letter VALUES("10003376","双河市","659007","10000376","3","S");
INSERT INTO cmf_region_letter VALUES("10003377","可克达拉市","659008","10000376","3","K");
INSERT INTO cmf_region_letter VALUES("10003378","昆玉市","659009","10000376","3","K");
INSERT INTO cmf_region_letter VALUES("10003379","中正区","710101","10000377","3","Z");
INSERT INTO cmf_region_letter VALUES("10003380","大同区","710102","10000377","3","D");
INSERT INTO cmf_region_letter VALUES("10003381","中山区","710103","10000377","3","Z");
INSERT INTO cmf_region_letter VALUES("10003382","松山区","710104","10000377","3","S");
INSERT INTO cmf_region_letter VALUES("10003383","大安区","710105","10000377","3","D");
INSERT INTO cmf_region_letter VALUES("10003384","万华区","710106","10000377","3","W");
INSERT INTO cmf_region_letter VALUES("10003385","信义区","710107","10000377","3","X");
INSERT INTO cmf_region_letter VALUES("10003386","士林区","710108","10000377","3","S");
INSERT INTO cmf_region_letter VALUES("10003387","北投区","710109","10000377","3","B");
INSERT INTO cmf_region_letter VALUES("10003388","内湖区","710110","10000377","3","N");
INSERT INTO cmf_region_letter VALUES("10003389","南港区","710111","10000377","3","N");
INSERT INTO cmf_region_letter VALUES("10003390","文山区","710112","10000377","3","W");
INSERT INTO cmf_region_letter VALUES("10003391","其它区","710199","10000377","3","Q");
INSERT INTO cmf_region_letter VALUES("10003392","新兴区","710201","10000378","3","X");
INSERT INTO cmf_region_letter VALUES("10003393","前金区","710202","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003394","芩雅区","710203","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003395","盐埕区","710204","10000378","3","Y");
INSERT INTO cmf_region_letter VALUES("10003396","鼓山区","710205","10000378","3","G");
INSERT INTO cmf_region_letter VALUES("10003397","旗津区","710206","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003398","前镇区","710207","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003399","三民区","710208","10000378","3","S");
INSERT INTO cmf_region_letter VALUES("10003400","左营区","710209","10000378","3","Z");
INSERT INTO cmf_region_letter VALUES("10003401","楠梓区","710210","10000378","3","N");
INSERT INTO cmf_region_letter VALUES("10003402","小港区","710211","10000378","3","X");
INSERT INTO cmf_region_letter VALUES("10003403","苓雅区","710241","10000378","3","L");
INSERT INTO cmf_region_letter VALUES("10003404","仁武区","710242","10000378","3","R");
INSERT INTO cmf_region_letter VALUES("10003405","大社区","710243","10000378","3","D");
INSERT INTO cmf_region_letter VALUES("10003406","冈山区","710244","10000378","3","G");
INSERT INTO cmf_region_letter VALUES("10003407","路竹区","710245","10000378","3","L");
INSERT INTO cmf_region_letter VALUES("10003408","阿莲区","710246","10000378","3","A");
INSERT INTO cmf_region_letter VALUES("10003409","田寮区","710247","10000378","3","T");
INSERT INTO cmf_region_letter VALUES("10003410","燕巢区","710248","10000378","3","Y");
INSERT INTO cmf_region_letter VALUES("10003411","桥头区","710249","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003412","梓官区","710250","10000378","3","Z");
INSERT INTO cmf_region_letter VALUES("10003413","弥陀区","710251","10000378","3","M");
INSERT INTO cmf_region_letter VALUES("10003414","永安区","710252","10000378","3","Y");
INSERT INTO cmf_region_letter VALUES("10003415","湖内区","710253","10000378","3","H");
INSERT INTO cmf_region_letter VALUES("10003416","凤山区","710254","10000378","3","F");
INSERT INTO cmf_region_letter VALUES("10003417","大寮区","710255","10000378","3","D");
INSERT INTO cmf_region_letter VALUES("10003418","林园区","710256","10000378","3","L");
INSERT INTO cmf_region_letter VALUES("10003419","鸟松区","710257","10000378","3","N");
INSERT INTO cmf_region_letter VALUES("10003420","大树区","710258","10000378","3","D");
INSERT INTO cmf_region_letter VALUES("10003421","旗山区","710259","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003422","美浓区","710260","10000378","3","M");
INSERT INTO cmf_region_letter VALUES("10003423","六龟区","710261","10000378","3","L");
INSERT INTO cmf_region_letter VALUES("10003424","内门区","710262","10000378","3","N");
INSERT INTO cmf_region_letter VALUES("10003425","杉林区","710263","10000378","3","S");
INSERT INTO cmf_region_letter VALUES("10003426","甲仙区","710264","10000378","3","J");
INSERT INTO cmf_region_letter VALUES("10003427","桃源区","710265","10000378","3","T");
INSERT INTO cmf_region_letter VALUES("10003428","那玛夏区","710266","10000378","3","N");
INSERT INTO cmf_region_letter VALUES("10003429","茂林区","710267","10000378","3","M");
INSERT INTO cmf_region_letter VALUES("10003430","茄萣区","710268","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003431","其它区","710299","10000378","3","Q");
INSERT INTO cmf_region_letter VALUES("10003432","中西区","710301","10000379","3","Z");
INSERT INTO cmf_region_letter VALUES("10003433","东区","710302","10000379","3","D");
INSERT INTO cmf_region_letter VALUES("10003434","南区","710303","10000379","3","N");
INSERT INTO cmf_region_letter VALUES("10003435","北区","710304","10000379","3","B");
INSERT INTO cmf_region_letter VALUES("10003436","安平区","710305","10000379","3","A");
INSERT INTO cmf_region_letter VALUES("10003437","安南区","710306","10000379","3","A");
INSERT INTO cmf_region_letter VALUES("10003438","永康区","710339","10000379","3","Y");
INSERT INTO cmf_region_letter VALUES("10003439","归仁区","710340","10000379","3","G");
INSERT INTO cmf_region_letter VALUES("10003440","新化区","710341","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003441","左镇区","710342","10000379","3","Z");
INSERT INTO cmf_region_letter VALUES("10003442","玉井区","710343","10000379","3","Y");
INSERT INTO cmf_region_letter VALUES("10003443","楠西区","710344","10000379","3","N");
INSERT INTO cmf_region_letter VALUES("10003444","南化区","710345","10000379","3","N");
INSERT INTO cmf_region_letter VALUES("10003445","仁德区","710346","10000379","3","R");
INSERT INTO cmf_region_letter VALUES("10003446","关庙区","710347","10000379","3","G");
INSERT INTO cmf_region_letter VALUES("10003447","龙崎区","710348","10000379","3","L");
INSERT INTO cmf_region_letter VALUES("10003448","官田区","710349","10000379","3","G");
INSERT INTO cmf_region_letter VALUES("10003449","麻豆区","710350","10000379","3","M");
INSERT INTO cmf_region_letter VALUES("10003450","佳里区","710351","10000379","3","J");
INSERT INTO cmf_region_letter VALUES("10003451","西港区","710352","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003452","七股区","710353","10000379","3","Q");
INSERT INTO cmf_region_letter VALUES("10003453","将军区","710354","10000379","3","J");
INSERT INTO cmf_region_letter VALUES("10003454","学甲区","710355","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003455","北门区","710356","10000379","3","B");
INSERT INTO cmf_region_letter VALUES("10003456","新营区","710357","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003457","后壁区","710358","10000379","3","H");
INSERT INTO cmf_region_letter VALUES("10003458","白河区","710359","10000379","3","B");
INSERT INTO cmf_region_letter VALUES("10003459","东山区","710360","10000379","3","D");
INSERT INTO cmf_region_letter VALUES("10003460","六甲区","710361","10000379","3","L");
INSERT INTO cmf_region_letter VALUES("10003461","下营区","710362","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003462","柳营区","710363","10000379","3","L");
INSERT INTO cmf_region_letter VALUES("10003463","盐水区","710364","10000379","3","Y");
INSERT INTO cmf_region_letter VALUES("10003464","善化区","710365","10000379","3","S");
INSERT INTO cmf_region_letter VALUES("10003465","大内区","710366","10000379","3","D");
INSERT INTO cmf_region_letter VALUES("10003466","山上区","710367","10000379","3","S");
INSERT INTO cmf_region_letter VALUES("10003467","新市区","710368","10000379","3","X");
INSERT INTO cmf_region_letter VALUES("10003468","安定区","710369","10000379","3","A");
INSERT INTO cmf_region_letter VALUES("10003469","其它区","710399","10000379","3","Q");
INSERT INTO cmf_region_letter VALUES("10003470","中区","710401","10000380","3","Z");
INSERT INTO cmf_region_letter VALUES("10003471","东区","710402","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003472","南区","710403","10000380","3","N");
INSERT INTO cmf_region_letter VALUES("10003473","西区","710404","10000380","3","X");
INSERT INTO cmf_region_letter VALUES("10003474","北区","710405","10000380","3","B");
INSERT INTO cmf_region_letter VALUES("10003475","北屯区","710406","10000380","3","B");
INSERT INTO cmf_region_letter VALUES("10003476","西屯区","710407","10000380","3","X");
INSERT INTO cmf_region_letter VALUES("10003477","南屯区","710408","10000380","3","N");
INSERT INTO cmf_region_letter VALUES("10003478","太平区","710431","10000380","3","T");
INSERT INTO cmf_region_letter VALUES("10003479","大里区","710432","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003480","雾峰区","710433","10000380","3","W");
INSERT INTO cmf_region_letter VALUES("10003481","乌日区","710434","10000380","3","W");
INSERT INTO cmf_region_letter VALUES("10003482","丰原区","710435","10000380","3","F");
INSERT INTO cmf_region_letter VALUES("10003483","后里区","710436","10000380","3","H");
INSERT INTO cmf_region_letter VALUES("10003484","石冈区","710437","10000380","3","S");
INSERT INTO cmf_region_letter VALUES("10003485","东势区","710438","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003486","和平区","710439","10000380","3","H");
INSERT INTO cmf_region_letter VALUES("10003487","新社区","710440","10000380","3","X");
INSERT INTO cmf_region_letter VALUES("10003488","潭子区","710441","10000380","3","T");
INSERT INTO cmf_region_letter VALUES("10003489","大雅区","710442","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003490","神冈区","710443","10000380","3","S");
INSERT INTO cmf_region_letter VALUES("10003491","大肚区","710444","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003492","沙鹿区","710445","10000380","3","S");
INSERT INTO cmf_region_letter VALUES("10003493","龙井区","710446","10000380","3","L");
INSERT INTO cmf_region_letter VALUES("10003494","梧栖区","710447","10000380","3","W");
INSERT INTO cmf_region_letter VALUES("10003495","清水区","710448","10000380","3","Q");
INSERT INTO cmf_region_letter VALUES("10003496","大甲区","710449","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003497","外埔区","710450","10000380","3","W");
INSERT INTO cmf_region_letter VALUES("10003498","大安区","710451","10000380","3","D");
INSERT INTO cmf_region_letter VALUES("10003499","其它区","710499","10000380","3","Q");
INSERT INTO cmf_region_letter VALUES("10003500","金沙镇","710507","10000381","3","J");
INSERT INTO cmf_region_letter VALUES("10003501","金湖镇","710508","10000381","3","J");
INSERT INTO cmf_region_letter VALUES("10003502","金宁乡","710509","10000381","3","J");
INSERT INTO cmf_region_letter VALUES("10003503","金城镇","710510","10000381","3","J");
INSERT INTO cmf_region_letter VALUES("10003504","烈屿乡","710511","10000381","3","L");
INSERT INTO cmf_region_letter VALUES("10003505","乌坵乡","710512","10000381","3","W");
INSERT INTO cmf_region_letter VALUES("10003506","南投市","710614","10000382","3","N");
INSERT INTO cmf_region_letter VALUES("10003507","中寮乡","710615","10000382","3","Z");
INSERT INTO cmf_region_letter VALUES("10003508","草屯镇","710616","10000382","3","C");
INSERT INTO cmf_region_letter VALUES("10003509","国姓乡","710617","10000382","3","G");
INSERT INTO cmf_region_letter VALUES("10003510","埔里镇","710618","10000382","3","B");
INSERT INTO cmf_region_letter VALUES("10003511","仁爱乡","710619","10000382","3","R");
INSERT INTO cmf_region_letter VALUES("10003512","名间乡","710620","10000382","3","M");
INSERT INTO cmf_region_letter VALUES("10003513","集集镇","710621","10000382","3","J");
INSERT INTO cmf_region_letter VALUES("10003514","水里乡","710622","10000382","3","S");
INSERT INTO cmf_region_letter VALUES("10003515","鱼池乡","710623","10000382","3","Y");
INSERT INTO cmf_region_letter VALUES("10003516","信义乡","710624","10000382","3","X");
INSERT INTO cmf_region_letter VALUES("10003517","竹山镇","710625","10000382","3","Z");
INSERT INTO cmf_region_letter VALUES("10003518","鹿谷乡","710626","10000382","3","L");
INSERT INTO cmf_region_letter VALUES("10003519","仁爱区","710701","10000383","3","R");
INSERT INTO cmf_region_letter VALUES("10003520","信义区","710702","10000383","3","X");
INSERT INTO cmf_region_letter VALUES("10003521","中正区","710703","10000383","3","Z");
INSERT INTO cmf_region_letter VALUES("10003522","中山区","710704","10000383","3","Z");
INSERT INTO cmf_region_letter VALUES("10003523","安乐区","710705","10000383","3","A");
INSERT INTO cmf_region_letter VALUES("10003524","暖暖区","710706","10000383","3","N");
INSERT INTO cmf_region_letter VALUES("10003525","七堵区","710707","10000383","3","Q");
INSERT INTO cmf_region_letter VALUES("10003526","其它区","710799","10000383","3","Q");
INSERT INTO cmf_region_letter VALUES("10003527","东区","710801","10000384","3","D");
INSERT INTO cmf_region_letter VALUES("10003528","北区","710802","10000384","3","B");
INSERT INTO cmf_region_letter VALUES("10003529","香山区","710803","10000384","3","X");
INSERT INTO cmf_region_letter VALUES("10003530","其它区","710899","10000384","3","Q");
INSERT INTO cmf_region_letter VALUES("10003531","东区","710901","10000385","3","D");
INSERT INTO cmf_region_letter VALUES("10003532","西区","710902","10000385","3","X");
INSERT INTO cmf_region_letter VALUES("10003533","其它区","710999","10000385","3","Q");
INSERT INTO cmf_region_letter VALUES("10003534","万里区","711130","10000386","3","W");
INSERT INTO cmf_region_letter VALUES("10003535","板桥区","711132","10000386","3","B");
INSERT INTO cmf_region_letter VALUES("10003536","汐止区","711133","10000386","3","X");
INSERT INTO cmf_region_letter VALUES("10003537","深坑区","711134","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003538","石碇区","711135","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003539","瑞芳区","711136","10000386","3","R");
INSERT INTO cmf_region_letter VALUES("10003540","平溪区","711137","10000386","3","P");
INSERT INTO cmf_region_letter VALUES("10003541","双溪区","711138","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003542","贡寮区","711139","10000386","3","G");
INSERT INTO cmf_region_letter VALUES("10003543","新店区","711140","10000386","3","X");
INSERT INTO cmf_region_letter VALUES("10003544","坪林区","711141","10000386","3","P");
INSERT INTO cmf_region_letter VALUES("10003545","乌来区","711142","10000386","3","W");
INSERT INTO cmf_region_letter VALUES("10003546","永和区","711143","10000386","3","Y");
INSERT INTO cmf_region_letter VALUES("10003547","中和区","711144","10000386","3","Z");
INSERT INTO cmf_region_letter VALUES("10003548","土城区","711145","10000386","3","T");
INSERT INTO cmf_region_letter VALUES("10003549","三峡区","711146","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003550","树林区","711147","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003551","莺歌区","711148","10000386","3","Y");
INSERT INTO cmf_region_letter VALUES("10003552","三重区","711149","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003553","新庄区","711150","10000386","3","X");
INSERT INTO cmf_region_letter VALUES("10003554","泰山区","711151","10000386","3","T");
INSERT INTO cmf_region_letter VALUES("10003555","林口区","711152","10000386","3","L");
INSERT INTO cmf_region_letter VALUES("10003556","芦洲区","711153","10000386","3","L");
INSERT INTO cmf_region_letter VALUES("10003557","五股区","711154","10000386","3","W");
INSERT INTO cmf_region_letter VALUES("10003558","八里区","711155","10000386","3","B");
INSERT INTO cmf_region_letter VALUES("10003559","淡水区","711156","10000386","3","D");
INSERT INTO cmf_region_letter VALUES("10003560","三芝区","711157","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003561","石门区","711158","10000386","3","S");
INSERT INTO cmf_region_letter VALUES("10003562","宜兰市","711287","10000387","3","Y");
INSERT INTO cmf_region_letter VALUES("10003563","头城镇","711288","10000387","3","T");
INSERT INTO cmf_region_letter VALUES("10003564","礁溪乡","711289","10000387","3","J");
INSERT INTO cmf_region_letter VALUES("10003565","壮围乡","711290","10000387","3","Z");
INSERT INTO cmf_region_letter VALUES("10003566","员山乡","711291","10000387","3","Y");
INSERT INTO cmf_region_letter VALUES("10003567","罗东镇","711292","10000387","3","L");
INSERT INTO cmf_region_letter VALUES("10003568","三星乡","711293","10000387","3","S");
INSERT INTO cmf_region_letter VALUES("10003569","大同乡","711294","10000387","3","D");
INSERT INTO cmf_region_letter VALUES("10003570","五结乡","711295","10000387","3","W");
INSERT INTO cmf_region_letter VALUES("10003571","冬山乡","711296","10000387","3","D");
INSERT INTO cmf_region_letter VALUES("10003572","苏澳镇","711297","10000387","3","S");
INSERT INTO cmf_region_letter VALUES("10003573","南澳乡","711298","10000387","3","N");
INSERT INTO cmf_region_letter VALUES("10003574","钓鱼台","711299","10000387","3","D");
INSERT INTO cmf_region_letter VALUES("10003575","竹北市","711387","10000388","3","Z");
INSERT INTO cmf_region_letter VALUES("10003576","湖口乡","711388","10000388","3","H");
INSERT INTO cmf_region_letter VALUES("10003577","新丰乡","711389","10000388","3","X");
INSERT INTO cmf_region_letter VALUES("10003578","新埔镇","711390","10000388","3","X");
INSERT INTO cmf_region_letter VALUES("10003579","关西镇","711391","10000388","3","G");
INSERT INTO cmf_region_letter VALUES("10003580","芎林乡","711392","10000388","3","Q");
INSERT INTO cmf_region_letter VALUES("10003581","宝山乡","711393","10000388","3","B");
INSERT INTO cmf_region_letter VALUES("10003582","竹东镇","711394","10000388","3","Z");
INSERT INTO cmf_region_letter VALUES("10003583","五峰乡","711395","10000388","3","W");
INSERT INTO cmf_region_letter VALUES("10003584","横山乡","711396","10000388","3","H");
INSERT INTO cmf_region_letter VALUES("10003585","尖石乡","711397","10000388","3","J");
INSERT INTO cmf_region_letter VALUES("10003586","北埔乡","711398","10000388","3","B");
INSERT INTO cmf_region_letter VALUES("10003587","峨眉乡","711399","10000388","3","E");
INSERT INTO cmf_region_letter VALUES("10003588","中坜区","711414","10000389","3","Z");
INSERT INTO cmf_region_letter VALUES("10003589","平镇区","711415","10000389","3","P");
INSERT INTO cmf_region_letter VALUES("10003590","杨梅区","711417","10000389","3","Y");
INSERT INTO cmf_region_letter VALUES("10003591","新屋区","711418","10000389","3","X");
INSERT INTO cmf_region_letter VALUES("10003592","观音区","711419","10000389","3","G");
INSERT INTO cmf_region_letter VALUES("10003593","桃园区","711420","10000389","3","T");
INSERT INTO cmf_region_letter VALUES("10003594","龟山区","711421","10000389","3","G");
INSERT INTO cmf_region_letter VALUES("10003595","八德区","711422","10000389","3","B");
INSERT INTO cmf_region_letter VALUES("10003596","大溪区","711423","10000389","3","D");
INSERT INTO cmf_region_letter VALUES("10003597","大园区","711425","10000389","3","D");
INSERT INTO cmf_region_letter VALUES("10003598","芦竹区","711426","10000389","3","L");
INSERT INTO cmf_region_letter VALUES("10003599","中坜市","711487","10000389","3","Z");
INSERT INTO cmf_region_letter VALUES("10003600","平镇市","711488","10000389","3","P");
INSERT INTO cmf_region_letter VALUES("10003601","龙潭乡","711489","10000389","3","L");
INSERT INTO cmf_region_letter VALUES("10003602","杨梅市","711490","10000389","3","Y");
INSERT INTO cmf_region_letter VALUES("10003603","新屋乡","711491","10000389","3","X");
INSERT INTO cmf_region_letter VALUES("10003604","观音乡","711492","10000389","3","G");
INSERT INTO cmf_region_letter VALUES("10003605","桃园市","711493","10000389","3","T");
INSERT INTO cmf_region_letter VALUES("10003606","龟山乡","711494","10000389","3","G");
INSERT INTO cmf_region_letter VALUES("10003607","八德市","711495","10000389","3","B");
INSERT INTO cmf_region_letter VALUES("10003608","大溪镇","711496","10000389","3","D");
INSERT INTO cmf_region_letter VALUES("10003609","复兴乡","711497","10000389","3","F");
INSERT INTO cmf_region_letter VALUES("10003610","大园乡","711498","10000389","3","D");
INSERT INTO cmf_region_letter VALUES("10003611","芦竹乡","711499","10000389","3","L");
INSERT INTO cmf_region_letter VALUES("10003612","头份市","711520","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003613","竹南镇","711582","10000390","3","Z");
INSERT INTO cmf_region_letter VALUES("10003614","头份镇","711583","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003615","三湾乡","711584","10000390","3","S");
INSERT INTO cmf_region_letter VALUES("10003616","南庄乡","711585","10000390","3","N");
INSERT INTO cmf_region_letter VALUES("10003617","狮潭乡","711586","10000390","3","S");
INSERT INTO cmf_region_letter VALUES("10003618","后龙镇","711587","10000390","3","H");
INSERT INTO cmf_region_letter VALUES("10003619","通霄镇","711588","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003620","苑里镇","711589","10000390","3","Y");
INSERT INTO cmf_region_letter VALUES("10003621","苗栗市","711590","10000390","3","M");
INSERT INTO cmf_region_letter VALUES("10003622","造桥乡","711591","10000390","3","Z");
INSERT INTO cmf_region_letter VALUES("10003623","头屋乡","711592","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003624","公馆乡","711593","10000390","3","G");
INSERT INTO cmf_region_letter VALUES("10003625","大湖乡","711594","10000390","3","D");
INSERT INTO cmf_region_letter VALUES("10003626","泰安乡","711595","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003627","铜锣乡","711596","10000390","3","T");
INSERT INTO cmf_region_letter VALUES("10003628","三义乡","711597","10000390","3","S");
INSERT INTO cmf_region_letter VALUES("10003629","西湖乡","711598","10000390","3","X");
INSERT INTO cmf_region_letter VALUES("10003630","卓兰镇","711599","10000390","3","Z");
INSERT INTO cmf_region_letter VALUES("10003631","员林市","711736","10000391","3","Y");
INSERT INTO cmf_region_letter VALUES("10003632","彰化市","711774","10000391","3","Z");
INSERT INTO cmf_region_letter VALUES("10003633","芬园乡","711775","10000391","3","F");
INSERT INTO cmf_region_letter VALUES("10003634","花坛乡","711776","10000391","3","H");
INSERT INTO cmf_region_letter VALUES("10003635","秀水乡","711777","10000391","3","X");
INSERT INTO cmf_region_letter VALUES("10003636","鹿港镇","711778","10000391","3","L");
INSERT INTO cmf_region_letter VALUES("10003637","福兴乡","711779","10000391","3","F");
INSERT INTO cmf_region_letter VALUES("10003638","线西乡","711780","10000391","3","X");
INSERT INTO cmf_region_letter VALUES("10003639","和美镇","711781","10000391","3","H");
INSERT INTO cmf_region_letter VALUES("10003640","伸港乡","711782","10000391","3","S");
INSERT INTO cmf_region_letter VALUES("10003641","员林镇","711783","10000391","3","Y");
INSERT INTO cmf_region_letter VALUES("10003642","社头乡","711784","10000391","3","S");
INSERT INTO cmf_region_letter VALUES("10003643","永靖乡","711785","10000391","3","Y");
INSERT INTO cmf_region_letter VALUES("10003644","埔心乡","711786","10000391","3","B");
INSERT INTO cmf_region_letter VALUES("10003645","溪湖镇","711787","10000391","3","X");
INSERT INTO cmf_region_letter VALUES("10003646","大村乡","711788","10000391","3","D");
INSERT INTO cmf_region_letter VALUES("10003647","埔盐乡","711789","10000391","3","B");
INSERT INTO cmf_region_letter VALUES("10003648","田中镇","711790","10000391","3","T");
INSERT INTO cmf_region_letter VALUES("10003649","北斗镇","711791","10000391","3","B");
INSERT INTO cmf_region_letter VALUES("10003650","田尾乡","711792","10000391","3","T");
INSERT INTO cmf_region_letter VALUES("10003651","埤头乡","711793","10000391","3","P");
INSERT INTO cmf_region_letter VALUES("10003652","溪州乡","711794","10000391","3","X");
INSERT INTO cmf_region_letter VALUES("10003653","竹塘乡","711795","10000391","3","Z");
INSERT INTO cmf_region_letter VALUES("10003654","二林镇","711796","10000391","3","E");
INSERT INTO cmf_region_letter VALUES("10003655","大城乡","711797","10000391","3","D");
INSERT INTO cmf_region_letter VALUES("10003656","芳苑乡","711798","10000391","3","F");
INSERT INTO cmf_region_letter VALUES("10003657","二水乡","711799","10000391","3","E");
INSERT INTO cmf_region_letter VALUES("10003658","番路乡","711982","10000392","3","F");
INSERT INTO cmf_region_letter VALUES("10003659","梅山乡","711983","10000392","3","M");
INSERT INTO cmf_region_letter VALUES("10003660","竹崎乡","711984","10000392","3","Z");
INSERT INTO cmf_region_letter VALUES("10003661","阿里山乡","711985","10000392","3","A");
INSERT INTO cmf_region_letter VALUES("10003662","中埔乡","711986","10000392","3","Z");
INSERT INTO cmf_region_letter VALUES("10003663","大埔乡","711987","10000392","3","D");
INSERT INTO cmf_region_letter VALUES("10003664","水上乡","711988","10000392","3","S");
INSERT INTO cmf_region_letter VALUES("10003665","鹿草乡","711989","10000392","3","L");
INSERT INTO cmf_region_letter VALUES("10003666","太保市","711990","10000392","3","T");
INSERT INTO cmf_region_letter VALUES("10003667","朴子市","711991","10000392","3","P");
INSERT INTO cmf_region_letter VALUES("10003668","东石乡","711992","10000392","3","D");
INSERT INTO cmf_region_letter VALUES("10003669","六脚乡","711993","10000392","3","L");
INSERT INTO cmf_region_letter VALUES("10003670","新港乡","711994","10000392","3","X");
INSERT INTO cmf_region_letter VALUES("10003671","民雄乡","711995","10000392","3","M");
INSERT INTO cmf_region_letter VALUES("10003672","大林镇","711996","10000392","3","D");
INSERT INTO cmf_region_letter VALUES("10003673","溪口乡","711997","10000392","3","X");
INSERT INTO cmf_region_letter VALUES("10003674","义竹乡","711998","10000392","3","Y");
INSERT INTO cmf_region_letter VALUES("10003675","布袋镇","711999","10000392","3","B");
INSERT INTO cmf_region_letter VALUES("10003676","斗南镇","712180","10000393","3","D");
INSERT INTO cmf_region_letter VALUES("10003677","大埤乡","712181","10000393","3","D");
INSERT INTO cmf_region_letter VALUES("10003678","虎尾镇","712182","10000393","3","H");
INSERT INTO cmf_region_letter VALUES("10003679","土库镇","712183","10000393","3","T");
INSERT INTO cmf_region_letter VALUES("10003680","褒忠乡","712184","10000393","3","B");
INSERT INTO cmf_region_letter VALUES("10003681","东势乡","712185","10000393","3","D");
INSERT INTO cmf_region_letter VALUES("10003682","台西乡","712186","10000393","3","T");
INSERT INTO cmf_region_letter VALUES("10003683","仑背乡","712187","10000393","3","L");
INSERT INTO cmf_region_letter VALUES("10003684","麦寮乡","712188","10000393","3","M");
INSERT INTO cmf_region_letter VALUES("10003685","斗六市","712189","10000393","3","D");
INSERT INTO cmf_region_letter VALUES("10003686","林内乡","712190","10000393","3","L");
INSERT INTO cmf_region_letter VALUES("10003687","古坑乡","712191","10000393","3","G");
INSERT INTO cmf_region_letter VALUES("10003688","莿桐乡","712192","10000393","3","C");
INSERT INTO cmf_region_letter VALUES("10003689","西螺镇","712193","10000393","3","X");
INSERT INTO cmf_region_letter VALUES("10003690","二仑乡","712194","10000393","3","E");
INSERT INTO cmf_region_letter VALUES("10003691","北港镇","712195","10000393","3","B");
INSERT INTO cmf_region_letter VALUES("10003692","水林乡","712196","10000393","3","S");
INSERT INTO cmf_region_letter VALUES("10003693","口湖乡","712197","10000393","3","K");
INSERT INTO cmf_region_letter VALUES("10003694","四湖乡","712198","10000393","3","S");
INSERT INTO cmf_region_letter VALUES("10003695","元长乡","712199","10000393","3","Y");
INSERT INTO cmf_region_letter VALUES("10003696","崁顶乡","712451","10000394","3","K");
INSERT INTO cmf_region_letter VALUES("10003697","屏东市","712467","10000394","3","P");
INSERT INTO cmf_region_letter VALUES("10003698","三地门乡","712468","10000394","3","S");
INSERT INTO cmf_region_letter VALUES("10003699","雾台乡","712469","10000394","3","W");
INSERT INTO cmf_region_letter VALUES("10003700","玛家乡","712470","10000394","3","M");
INSERT INTO cmf_region_letter VALUES("10003701","九如乡","712471","10000394","3","J");
INSERT INTO cmf_region_letter VALUES("10003702","里港乡","712472","10000394","3","L");
INSERT INTO cmf_region_letter VALUES("10003703","高树乡","712473","10000394","3","G");
INSERT INTO cmf_region_letter VALUES("10003704","盐埔乡","712474","10000394","3","Y");
INSERT INTO cmf_region_letter VALUES("10003705","长治乡","712475","10000394","3","C");
INSERT INTO cmf_region_letter VALUES("10003706","麟洛乡","712476","10000394","3","L");
INSERT INTO cmf_region_letter VALUES("10003707","竹田乡","712477","10000394","3","Z");
INSERT INTO cmf_region_letter VALUES("10003708","内埔乡","712478","10000394","3","N");
INSERT INTO cmf_region_letter VALUES("10003709","万丹乡","712479","10000394","3","W");
INSERT INTO cmf_region_letter VALUES("10003710","潮州镇","712480","10000394","3","C");
INSERT INTO cmf_region_letter VALUES("10003711","泰武乡","712481","10000394","3","T");
INSERT INTO cmf_region_letter VALUES("10003712","来义乡","712482","10000394","3","L");
INSERT INTO cmf_region_letter VALUES("10003713","万峦乡","712483","10000394","3","W");
INSERT INTO cmf_region_letter VALUES("10003714","莰顶乡","712484","10000394","3","K");
INSERT INTO cmf_region_letter VALUES("10003715","新埤乡","712485","10000394","3","X");
INSERT INTO cmf_region_letter VALUES("10003716","南州乡","712486","10000394","3","N");
INSERT INTO cmf_region_letter VALUES("10003717","林边乡","712487","10000394","3","L");
INSERT INTO cmf_region_letter VALUES("10003718","东港镇","712488","10000394","3","D");
INSERT INTO cmf_region_letter VALUES("10003719","琉球乡","712489","10000394","3","L");
INSERT INTO cmf_region_letter VALUES("10003720","佳冬乡","712490","10000394","3","J");
INSERT INTO cmf_region_letter VALUES("10003721","新园乡","712491","10000394","3","X");
INSERT INTO cmf_region_letter VALUES("10003722","枋寮乡","712492","10000394","3","F");
INSERT INTO cmf_region_letter VALUES("10003723","枋山乡","712493","10000394","3","F");
INSERT INTO cmf_region_letter VALUES("10003724","春日乡","712494","10000394","3","C");
INSERT INTO cmf_region_letter VALUES("10003725","狮子乡","712495","10000394","3","S");
INSERT INTO cmf_region_letter VALUES("10003726","车城乡","712496","10000394","3","C");
INSERT INTO cmf_region_letter VALUES("10003727","牡丹乡","712497","10000394","3","M");
INSERT INTO cmf_region_letter VALUES("10003728","恒春镇","712498","10000394","3","H");
INSERT INTO cmf_region_letter VALUES("10003729","满州乡","712499","10000394","3","M");
INSERT INTO cmf_region_letter VALUES("10003730","台东市","712584","10000395","3","T");
INSERT INTO cmf_region_letter VALUES("10003731","绿岛乡","712585","10000395","3","L");
INSERT INTO cmf_region_letter VALUES("10003732","兰屿乡","712586","10000395","3","L");
INSERT INTO cmf_region_letter VALUES("10003733","延平乡","712587","10000395","3","Y");
INSERT INTO cmf_region_letter VALUES("10003734","卑南乡","712588","10000395","3","B");
INSERT INTO cmf_region_letter VALUES("10003735","鹿野乡","712589","10000395","3","L");
INSERT INTO cmf_region_letter VALUES("10003736","关山镇","712590","10000395","3","G");
INSERT INTO cmf_region_letter VALUES("10003737","海端乡","712591","10000395","3","H");
INSERT INTO cmf_region_letter VALUES("10003738","池上乡","712592","10000395","3","C");
INSERT INTO cmf_region_letter VALUES("10003739","东河乡","712593","10000395","3","D");
INSERT INTO cmf_region_letter VALUES("10003740","成功镇","712594","10000395","3","C");
INSERT INTO cmf_region_letter VALUES("10003741","长滨乡","712595","10000395","3","C");
INSERT INTO cmf_region_letter VALUES("10003742","金峰乡","712596","10000395","3","J");
INSERT INTO cmf_region_letter VALUES("10003743","大武乡","712597","10000395","3","D");
INSERT INTO cmf_region_letter VALUES("10003744","达仁乡","712598","10000395","3","D");
INSERT INTO cmf_region_letter VALUES("10003745","太麻里乡","712599","10000395","3","T");
INSERT INTO cmf_region_letter VALUES("10003746","花莲市","712686","10000396","3","H");
INSERT INTO cmf_region_letter VALUES("10003747","新城乡","712687","10000396","3","X");
INSERT INTO cmf_region_letter VALUES("10003748","太鲁阁","712688","10000396","3","T");
INSERT INTO cmf_region_letter VALUES("10003749","秀林乡","712689","10000396","3","X");
INSERT INTO cmf_region_letter VALUES("10003750","吉安乡","712690","10000396","3","J");
INSERT INTO cmf_region_letter VALUES("10003751","寿丰乡","712691","10000396","3","S");
INSERT INTO cmf_region_letter VALUES("10003752","凤林镇","712692","10000396","3","F");
INSERT INTO cmf_region_letter VALUES("10003753","光复乡","712693","10000396","3","G");
INSERT INTO cmf_region_letter VALUES("10003754","丰滨乡","712694","10000396","3","F");
INSERT INTO cmf_region_letter VALUES("10003755","瑞穗乡","712695","10000396","3","R");
INSERT INTO cmf_region_letter VALUES("10003756","万荣乡","712696","10000396","3","W");
INSERT INTO cmf_region_letter VALUES("10003757","玉里镇","712697","10000396","3","Y");
INSERT INTO cmf_region_letter VALUES("10003758","卓溪乡","712698","10000396","3","Z");
INSERT INTO cmf_region_letter VALUES("10003759","富里乡","712699","10000396","3","F");
INSERT INTO cmf_region_letter VALUES("10003760","马公市","712794","10000397","3","M");
INSERT INTO cmf_region_letter VALUES("10003761","西屿乡","712795","10000397","3","X");
INSERT INTO cmf_region_letter VALUES("10003762","望安乡","712796","10000397","3","W");
INSERT INTO cmf_region_letter VALUES("10003763","七美乡","712797","10000397","3","Q");
INSERT INTO cmf_region_letter VALUES("10003764","白沙乡","712798","10000397","3","B");
INSERT INTO cmf_region_letter VALUES("10003765","湖西乡","712799","10000397","3","H");
INSERT INTO cmf_region_letter VALUES("10003766","南竿乡","712896","10000398","3","N");
INSERT INTO cmf_region_letter VALUES("10003767","北竿乡","712897","10000398","3","B");
INSERT INTO cmf_region_letter VALUES("10003768","东引乡","712898","10000398","3","D");
INSERT INTO cmf_region_letter VALUES("10003769","莒光乡","712899","10000398","3","J");
INSERT INTO cmf_region_letter VALUES("10003770","中西区","810101","10000399","3","Z");
INSERT INTO cmf_region_letter VALUES("10003771","湾仔区","810102","10000399","3","W");
INSERT INTO cmf_region_letter VALUES("10003772","东区","810103","10000399","3","D");
INSERT INTO cmf_region_letter VALUES("10003773","南区","810104","10000399","3","N");
INSERT INTO cmf_region_letter VALUES("10003774","九龙城区","810201","10000400","3","J");
INSERT INTO cmf_region_letter VALUES("10003775","油尖旺区","810202","10000400","3","Y");
INSERT INTO cmf_region_letter VALUES("10003776","深水埗区","810203","10000400","3","S");
INSERT INTO cmf_region_letter VALUES("10003777","黄大仙区","810204","10000400","3","H");
INSERT INTO cmf_region_letter VALUES("10003778","观塘区","810205","10000400","3","G");
INSERT INTO cmf_region_letter VALUES("10003779","北区","810301","10000401","3","B");
INSERT INTO cmf_region_letter VALUES("10003780","大埔区","810302","10000401","3","D");
INSERT INTO cmf_region_letter VALUES("10003781","沙田区","810303","10000401","3","S");
INSERT INTO cmf_region_letter VALUES("10003782","西贡区","810304","10000401","3","X");
INSERT INTO cmf_region_letter VALUES("10003783","元朗区","810305","10000401","3","Y");
INSERT INTO cmf_region_letter VALUES("10003784","屯门区","810306","10000401","3","T");
INSERT INTO cmf_region_letter VALUES("10003785","荃湾区","810307","10000401","3","Q");
INSERT INTO cmf_region_letter VALUES("10003786","葵青区","810308","10000401","3","K");
INSERT INTO cmf_region_letter VALUES("10003787","离岛区","810309","10000401","3","L");
INSERT INTO cmf_region_letter VALUES("10003788","澳门半岛","820101","10000402","3","A");
INSERT INTO cmf_region_letter VALUES("10003789","离岛","820201","10000403","3","L");



DROP TABLE cmf_role;

CREATE TABLE `cmf_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父角色ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;0:禁用;1:正常',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `list_order` float NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

INSERT INTO cmf_role VALUES("1","0","1","1329633709","1329633709","0","超级管理员","拥有网站最高管理员权限！");
INSERT INTO cmf_role VALUES("2","0","1","1329633709","1329633709","0","普通管理员","权限由最高管理员分配！");
INSERT INTO cmf_role VALUES("3","0","1","0","0","0","测试管理员","测试");



DROP TABLE cmf_role_user;

CREATE TABLE `cmf_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色 id',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='用户角色对应表';

INSERT INTO cmf_role_user VALUES("12","2","2");
INSERT INTO cmf_role_user VALUES("16","3","5");



DROP TABLE cmf_route;

CREATE TABLE `cmf_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态;1:启用,0:不启用',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'URL规则类型;1:用户自定义;2:别名添加',
  `full_url` varchar(255) NOT NULL DEFAULT '' COMMENT '完整url',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '实际显示的url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='url路由表';




DROP TABLE cmf_shop;

CREATE TABLE `cmf_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `class_id` int(11) DEFAULT NULL COMMENT '分类id',
  `shop_type` tinyint(4) DEFAULT NULL COMMENT '类型:1全屋整装,2装修建材,3智能电器,5家具软装 ',
  `name` varchar(50) DEFAULT NULL COMMENT '店铺名字',
  `logo_image` varchar(200) DEFAULT NULL COMMENT 'logo',
  `images` text COMMENT '轮播图',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `time` varchar(80) DEFAULT NULL COMMENT '营业时间',
  `address` varchar(300) DEFAULT NULL COMMENT '地址信息',
  `lng` varchar(30) DEFAULT NULL COMMENT '经度',
  `lat` varchar(30) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(50) DEFAULT NULL COMMENT '经纬度',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(50) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(50) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(50) DEFAULT NULL COMMENT '区code',
  `list_order` int(11) DEFAULT '0' COMMENT '人气',
  `is_recommend` tinyint(2) DEFAULT '1' COMMENT '推荐:1是,2否',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='店铺管理';




DROP TABLE cmf_shop_address;

CREATE TABLE `cmf_shop_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(255) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(255) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(255) DEFAULT NULL COMMENT '区code',
  `address` varchar(120) DEFAULT NULL COMMENT '详细地址',
  `username` varchar(30) DEFAULT NULL COMMENT '名字',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `is_default` tinyint(2) DEFAULT '2' COMMENT '是否默认:1默认,2不默认',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1正常',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='地址管理';

INSERT INTO cmf_shop_address VALUES("1","1","","","","河南省","郑州市","金水区","","","","详细地址测试","测试人员","18888888888","1","1","","","0");



DROP TABLE cmf_shop_cart;

CREATE TABLE `cmf_shop_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '商品类型:paid=有偿共享,show=种质展示,discount=限时折扣,full=满减活动,new=新品预售,goods=普通商品',
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `count` int(11) DEFAULT NULL COMMENT '下单数量',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格id',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku_name',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购物车';




DROP TABLE cmf_shop_comment;

CREATE TABLE `cmf_shop_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `order_detail_id` int(11) DEFAULT NULL COMMENT '订单详情',
  `content` text COMMENT '评论内容',
  `images` text COMMENT '图片',
  `star` varchar(255) DEFAULT '5' COMMENT '星级',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '是否显示:1显示,2隐藏',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品评价';




DROP TABLE cmf_shop_coupon;

CREATE TABLE `cmf_shop_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) DEFAULT '1' COMMENT '优惠券类型:1时间段,2按天',
  `coupon_type` tinyint(4) DEFAULT '1' COMMENT '优惠券类型:1满减券,2折扣券',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` varchar(20) DEFAULT NULL COMMENT '满额',
  `amount` varchar(20) DEFAULT NULL COMMENT '面额',
  `discount` varchar(20) DEFAULT NULL COMMENT '折扣',
  `count` int(11) DEFAULT NULL COMMENT '数量',
  `select_count` int(11) DEFAULT '0' COMMENT '领取数量',
  `limit` int(11) DEFAULT '1' COMMENT '限领取数',
  `status` tinyint(4) DEFAULT '2' COMMENT '状态:1显示,2隐藏',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `content` text COMMENT '内容',
  `day` varchar(50) DEFAULT '7' COMMENT '有效期',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='优惠券';

INSERT INTO cmf_shop_coupon VALUES("1","1","1","满10减5","10","5","","","0","1","2","1753372800","2132668799","","365","1000","1753346891","1753410063","0");
INSERT INTO cmf_shop_coupon VALUES("2","2","1","满100减50","100","50","","","0","1","2","0","0","","350","1000","1753346908","","0");
INSERT INTO cmf_shop_coupon VALUES("3","1","2","95折券","","","95","","0","1","2","1753372800","1782835199","","","1000","1753408364","1753409814","0");



DROP TABLE cmf_shop_coupon_user;

CREATE TABLE `cmf_shop_coupon_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) DEFAULT NULL COMMENT '时间类型:1时间段,按天',
  `coupon_type` tinyint(4) DEFAULT NULL COMMENT '优惠券类型:1满减券,2折扣券',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `coupon_id` int(11) NOT NULL COMMENT '优惠券id',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1正常',
  `used` tinyint(4) DEFAULT '1' COMMENT '状态:1未使用,2已使用,3已过期',
  `name` varchar(32) DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` varchar(20) DEFAULT '0' COMMENT '满n金额',
  `amount` varchar(20) DEFAULT '0' COMMENT '金额',
  `discount` varchar(20) DEFAULT NULL COMMENT '折扣',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `code` varchar(32) DEFAULT NULL COMMENT 'code码',
  `qr_image` varchar(100) DEFAULT NULL COMMENT '二维码',
  `order_num` varchar(32) DEFAULT NULL COMMENT '关联订单号',
  `is_send` tinyint(4) DEFAULT '1' COMMENT '是否发放:1赠送的',
  `use_time` bigint(20) DEFAULT NULL COMMENT '使用时间',
  `verification_user_id` int(11) DEFAULT NULL COMMENT '核销人',
  `verification_name` varchar(255) DEFAULT NULL,
  `create_time` bigint(20) DEFAULT NULL COMMENT '领取时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='优惠券领取记录';

INSERT INTO cmf_shop_coupon_user VALUES("1","2","1","1","2","1","1","满100减50","100","50","","1753352741","1783592741","YtnK5jZlO","","","1","","","","1753352741","","0");
INSERT INTO cmf_shop_coupon_user VALUES("2","2","1","1","2","1","1","满100减50","100","50","","1753352742","1783592742","YLqDjMP9c","","","1","","","","1753352742","","0");
INSERT INTO cmf_shop_coupon_user VALUES("3","2","1","1","2","1","1","满100减50","100","50","","1753352742","1783592742","YVMm95g8t","","","1","","","","1753352742","","0");
INSERT INTO cmf_shop_coupon_user VALUES("4","2","1","1","2","1","1","满100减50","100","50","","1753352743","1783592743","YFijaj54A","","","1","","","","1753352743","","0");
INSERT INTO cmf_shop_coupon_user VALUES("5","2","1","1","2","1","1","满100减50","100","50","","1753352743","1783592743","YFJ6w13Ks","","","1","","","","1753352743","","0");



DROP TABLE cmf_shop_goods;

CREATE TABLE `cmf_shop_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT 'goods' COMMENT '商品类型:goods=普通商品,customized=定制商品',
  `class_id` int(11) DEFAULT NULL,
  `class_two_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `goods_name` varchar(60) DEFAULT NULL COMMENT '商品名称',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `line_price` decimal(10,2) DEFAULT NULL COMMENT '划线价',
  `image` varchar(255) DEFAULT NULL COMMENT '封面',
  `images` text COMMENT '图集',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态',
  `sell_count` int(11) DEFAULT '0' COMMENT '售出数量',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `tag` varchar(255) DEFAULT NULL COMMENT '标签',
  `is_index` tinyint(2) DEFAULT '2' COMMENT '首页推荐:1是,2否',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '是否显示:1是,2否',
  `is_hot` tinyint(4) DEFAULT '2' COMMENT '热门:1是,2否',
  `list_order` int(11) DEFAULT '1000' COMMENT '排序',
  `content` text COMMENT '图文详情',
  `code` varchar(255) DEFAULT NULL COMMENT '编号',
  `qr_image` varchar(255) DEFAULT NULL COMMENT '二维码信息',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `is_attribute` varchar(255) DEFAULT NULL COMMENT '规格类型',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COMMENT='商品管理';

INSERT INTO cmf_shop_goods VALUES("49","goods","14","15","","戴尔2025款","80.00","90.00","xcxkf00000000001/admin/20250723/87f1efa5e3d24276273ac4bdd983105f.jpeg","xcxkf00000000001/admin/20250723/725db02d7c51bc76803bb302b123acc4.jpeg,xcxkf00000000001/admin/20250723/806e28d8a59dbd463bef54c788b4df06.jpg,xcxkf00000000001/admin/20250723/2fe200aa408939fd2cf1fa39e2a5e44d.jpg,xcxkf00000000001/admin/20250723/ab548885c56a001337c1d901fae8290d.jpeg","1","0","700000","相应快/运行快/样式新","2","1","2","1000","&lt;p&gt;场内车次黑&lt;/p&gt;","202549","https://oss.ausite.cn/xcxkf00000000001/code/c76363c13b0b7897d7452bbafe20fc46.jpg","1753241712","1753241712","0","0");
INSERT INTO cmf_shop_goods VALUES("50","goods","13","19","","小米16","800.00","1800.00","xcxkf00000000001/admin/20250723/f288d8143f4d0916a8242a51718b6bd1.jpeg","xcxkf00000000001/admin/20250723/8c8311a8069d7740a6c2dbbf1a89f5c7.jpg,xcxkf00000000001/admin/20250723/95401f125df0eb36bdfb8c30459d1f71.jpg,xcxkf00000000001/admin/20250723/f17694139aecf466729efdbeff9fe18d.jpeg","1","0","810000","ios系统/电池大/屏幕大","2","1","2","1000","&lt;p&gt;三打发大水&lt;/p&gt;","202550","https://oss.ausite.cn/xcxkf00000000001/code/6e31b371f9f4d383c803be88476e4188.jpg","1753241845","1753241845","0","1");



DROP TABLE cmf_shop_goods_attr;

CREATE TABLE `cmf_shop_goods_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `attr_name` varchar(32) NOT NULL COMMENT '属性',
  `list_order` int(11) NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) DEFAULT '1' COMMENT '0删除 1正常',
  `create_time` bigint(11) DEFAULT NULL,
  `update_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='属性表';




DROP TABLE cmf_shop_goods_attr_value;

CREATE TABLE `cmf_shop_goods_attr_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `attr_id` int(11) NOT NULL COMMENT '属性id',
  `attr_value_name` varchar(32) NOT NULL COMMENT '属性值',
  `list_order` int(11) NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) DEFAULT '1' COMMENT '0删除 1正常',
  `create_time` bigint(11) DEFAULT NULL,
  `update_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='属性值表';




DROP TABLE cmf_shop_goods_class;

CREATE TABLE `cmf_shop_goods_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL COMMENT '商品类型:goods=普通商品,point=积分商品',
  `pid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `is_index` tinyint(4) DEFAULT '2' COMMENT '首页推荐:1是,2否',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '显示:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COMMENT='分类管理';

INSERT INTO cmf_shop_goods_class VALUES("13","goods","0","手机","","2","1","1000","1753241373","","0");
INSERT INTO cmf_shop_goods_class VALUES("14","goods","0","电脑","","2","1","1000","1753241377","","0");
INSERT INTO cmf_shop_goods_class VALUES("15","goods","14","戴尔","","2","1","1000","1753241384","","0");
INSERT INTO cmf_shop_goods_class VALUES("16","goods","14","华硕","","2","1","1000","1753241392","","0");
INSERT INTO cmf_shop_goods_class VALUES("17","goods","13","苹果","","2","1","1000","1753241397","","0");
INSERT INTO cmf_shop_goods_class VALUES("18","goods","13","华为","","2","1","1000","1753241404","","0");
INSERT INTO cmf_shop_goods_class VALUES("19","goods","13","小米","","2","1","1000","1753241408","","0");



DROP TABLE cmf_shop_goods_sku;

CREATE TABLE `cmf_shop_goods_sku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `sku_name` varchar(30) DEFAULT NULL COMMENT 'sku',
  `code` varchar(255) DEFAULT NULL COMMENT '编码',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `line_price` decimal(10,2) DEFAULT NULL COMMENT '划线价',
  `sell_count` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '1' COMMENT '0不显示 1正常',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL,
  `delete_time` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品sku';




DROP TABLE cmf_shop_goods_sku_attr;

CREATE TABLE `cmf_shop_goods_sku_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `sku_id` int(11) NOT NULL COMMENT '规格id',
  `attr_id` int(11) NOT NULL COMMENT '属性id',
  `attr_value_id` int(11) NOT NULL COMMENT '属性值id',
  `status` tinyint(4) DEFAULT '1' COMMENT '0删除',
  `create_time` bigint(11) DEFAULT NULL,
  `update_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




DROP TABLE cmf_shop_order;

CREATE TABLE `cmf_shop_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT NULL COMMENT '商品类型:goods=普通商品,customized=定制商品',
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1待付款,2已付款,4已发货,6已收货,8已完成,10已取消,12退款申请,14退款不通过,16退款通过,20待生成价格',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `pay_num` varchar(255) DEFAULT NULL COMMENT '支付单号',
  `address_id` int(11) DEFAULT '0' COMMENT '地址id',
  `openid` varchar(255) DEFAULT NULL COMMENT '身份标识 openid',
  `username` varchar(255) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `county` varchar(255) DEFAULT NULL COMMENT '区',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '实际支付金额',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '余额支付金额',
  `goods_amount` decimal(10,2) DEFAULT NULL COMMENT '商品金额',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '原始 总金额 = 商品金额+优惠金额+运费金额',
  `coupon_id` int(11) DEFAULT '0' COMMENT '优惠券id',
  `coupon_amount` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
  `point` decimal(10,2) DEFAULT '0.00' COMMENT '使用积分',
  `point_balance` decimal(10,2) DEFAULT '0.00' COMMENT '积分已抵扣金额',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费',
  `give_point` decimal(10,2) DEFAULT NULL COMMENT '赠送积分',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付,5组合支付(微信+余额),6免费兑换',
  `remark` varchar(300) DEFAULT '' COMMENT '备注',
  `cav_qr_code` varchar(200) DEFAULT NULL COMMENT '核销二维码',
  `cav_code` varchar(40) DEFAULT NULL COMMENT '核销码',
  `exp_num` varchar(60) DEFAULT NULL COMMENT '快递单号',
  `exp_name` varchar(60) DEFAULT NULL COMMENT '快递名称',
  `catr_ids` varchar(255) DEFAULT NULL COMMENT '购物车下单',
  `goods_ids` varchar(255) DEFAULT NULL COMMENT '商品id',
  `goods_name` varchar(2555) DEFAULT NULL COMMENT '商品名字',
  `admin_remark` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  `is_comment` tinyint(4) DEFAULT '2' COMMENT '是否已评价:1是,2否',
  `comment_time` bigint(20) DEFAULT NULL COMMENT '评价时间',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `pay_time` bigint(20) DEFAULT '0' COMMENT '支付时间',
  `send_time` bigint(20) DEFAULT NULL COMMENT '发货时间',
  `take_delivery_time` bigint(20) DEFAULT NULL COMMENT '收货时间',
  `accomplish_time` bigint(20) DEFAULT NULL COMMENT '完成时间',
  `auto_cancel_time` bigint(20) DEFAULT NULL COMMENT '自动取消时间',
  `auto_accomplish_time` bigint(20) DEFAULT NULL COMMENT '自动完成时间',
  `auto_verification_time` bigint(20) DEFAULT NULL COMMENT '自动核销时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`,`status`,`order_num`) USING BTREE,
  KEY `username` (`username`,`phone`) USING BTREE,
  KEY `goods_name` (`goods_name`(768)) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单管理';




DROP TABLE cmf_shop_order_detail;

CREATE TABLE `cmf_shop_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL COMMENT '店铺',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '规格名字',
  `count` int(11) DEFAULT NULL COMMENT '购买数量',
  `is_vip` tinyint(4) DEFAULT '0' COMMENT '是否是会员:0否,1是',
  `goods_price` decimal(10,2) DEFAULT NULL COMMENT '价格/单价',
  `vip_price` decimal(10,2) DEFAULT '0.00' COMMENT '会员价/单价   同步到普通单价里面,方便展示',
  `vip_amount` decimal(10,2) DEFAULT '0.00' COMMENT '会员价/合计   同步到普通合计里面,方便展示',
  `coupon_amount` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
  `point` decimal(10,2) DEFAULT '0.00' COMMENT '使用积分',
  `point_balance` decimal(10,2) DEFAULT '0.00' COMMENT '积分已抵扣金额',
  `full_amount` decimal(10,2) DEFAULT '0.00' COMMENT '折扣金额',
  `give_point` decimal(10,2) DEFAULT NULL COMMENT '赠送积分',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '合计',
  `max_refund_amount` decimal(10,2) DEFAULT '0.00' COMMENT '最多退款金额',
  `image` varchar(255) DEFAULT NULL COMMENT '展示图',
  `status` tinyint(4) DEFAULT '0' COMMENT '退款状态:0未提交,1审核中,2已通过,3已驳回',
  `refund_time` bigint(20) DEFAULT NULL COMMENT '退款时间',
  `order_num` varchar(255) DEFAULT '0' COMMENT '订单单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `order_num` (`order_num`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单详情';




DROP TABLE cmf_shop_order_refund;

CREATE TABLE `cmf_shop_order_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1售后中, 2售后完成,3已拒绝,4已取消',
  `type` tinyint(20) DEFAULT '1' COMMENT '售后类型:1退货退款,2换货',
  `refund_why` varchar(300) DEFAULT NULL COMMENT '换货原因',
  `order_num` varchar(120) DEFAULT NULL COMMENT '退款订单号',
  `pay_num` varchar(120) DEFAULT NULL COMMENT '支付单号',
  `detail_id` int(11) DEFAULT NULL COMMENT '详情id',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '退款金额',
  `order_amount` decimal(10,2) DEFAULT NULL COMMENT '订单总支付金额',
  `sku_id` int(11) DEFAULT NULL COMMENT '更换规格id',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '更换规格',
  `count` int(11) DEFAULT '1' COMMENT '退货数量',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `goods_price` decimal(8,2) DEFAULT NULL COMMENT '价格/单价',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `exp_name` varchar(60) DEFAULT NULL COMMENT '快递名称',
  `exp_num` varchar(60) DEFAULT NULL COMMENT '快递单号',
  `refund_num` varchar(255) DEFAULT NULL COMMENT '退款订单号',
  `content` text COMMENT '说明',
  `images` text COMMENT '图集',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款管理';




DROP TABLE cmf_shop_stock;

CREATE TABLE `cmf_shop_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operate_type` varchar(20) DEFAULT NULL COMMENT '操作类型:shop_goods,point_goods',
  `type` tinyint(4) DEFAULT '1' COMMENT '1增加销量  2减少销量',
  `goods_id` int(11) DEFAULT NULL,
  `sku_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `order_num` varchar(120) DEFAULT NULL,
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存记录';




DROP TABLE cmf_slide;

CREATE TABLE `cmf_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示,0不显示',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片表';

INSERT INTO cmf_slide VALUES("1","1","0","首页轮播图","首页轮播图[请勿删除]");



DROP TABLE cmf_slide_item;

CREATE TABLE `cmf_slide_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide_id` int(11) NOT NULL DEFAULT '0' COMMENT '幻灯片id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片名称',
  `image` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片图片',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片链接',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '幻灯片描述',
  `content` text CHARACTER SET utf8 COMMENT '幻灯片内容',
  `more` text COMMENT '扩展信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `slide_id` (`slide_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片子项表';

INSERT INTO cmf_slide_item VALUES("1","1","1","1000","1","dz000/admin/20220928/f6eb31a4707d3e8705bce2402f331592.jpg","/pages/user/index","navigateTo","9999","","");
INSERT INTO cmf_slide_item VALUES("2","1","1","10","测试啊","dzkf00000000001/admin/20250311/2d72a549ecdc21ce4823201d27453ae3.jpg","/pages/index/index","switchTab","778899","","");



DROP TABLE cmf_theme;

CREATE TABLE `cmf_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后升级时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '模板状态,1:正在使用;0:未使用',
  `is_compiled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为已编译模板',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '主题目录名，用于主题的维一标识',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '主题名称',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '主题版本号',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '主题作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '支持语言',
  `keywords` varchar(50) NOT NULL DEFAULT '' COMMENT '主题关键字',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '主题描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='轮播图';

INSERT INTO cmf_theme VALUES("1","0","0","0","0","default","default","1.0.0","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","zh-cn","ThinkCMF默认模板","ThinkCMF默认模板");



DROP TABLE cmf_theme_file;

CREATE TABLE `cmf_theme_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_public` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否公共的模板文件',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模板文件名',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作',
  `file` varchar(50) NOT NULL DEFAULT '' COMMENT '模板文件，相对于模板根目录，如Portal/index.html',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '模板文件描述',
  `more` text COMMENT '模板更多配置,用户自己后台设置的',
  `config_more` text COMMENT '模板更多配置,来源模板的配置文件',
  `draft_more` text COMMENT '模板更多配置,用户临时保存的配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='轮播图,图片';

INSERT INTO cmf_theme_file VALUES("1","0","5","default","首页","demo/Index/index","demo/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");
INSERT INTO cmf_theme_file VALUES("2","0","5","default","首页","portal/Index/index","portal/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");



DROP TABLE cmf_user;

CREATE TABLE `cmf_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(3) unsigned DEFAULT '1' COMMENT '用户类型;1:admin;2:会员',
  `sex` tinyint(2) DEFAULT '0' COMMENT '性别;0:保密,1:男,2:女',
  `birthday` int(11) DEFAULT '0' COMMENT '生日',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `score` int(11) DEFAULT '0' COMMENT '用户积分',
  `coin` int(10) unsigned DEFAULT '0' COMMENT '金币',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '余额',
  `user_status` tinyint(3) unsigned DEFAULT '1' COMMENT '用户状态;0:禁用,1:正常,2:未验证',
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `user_pass` varchar(64) DEFAULT '' COMMENT '登录密码;cmf_password加密',
  `user_nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户昵称',
  `user_email` varchar(100) DEFAULT '' COMMENT '用户登录邮箱',
  `user_url` varchar(100) DEFAULT '' COMMENT '用户个人网址',
  `avatar` varchar(255) DEFAULT '' COMMENT '用户头像',
  `signature` varchar(255) DEFAULT '' COMMENT '个性签名',
  `last_login_ip` varchar(15) DEFAULT '' COMMENT '最后登录ip',
  `user_activation_key` varchar(60) DEFAULT '' COMMENT '激活码',
  `mobile` varchar(20) DEFAULT '' COMMENT '中国手机不带国家代码，国际手机号格式为：国家代码-手机号',
  `more` text COMMENT '扩展属性',
  `is_contract` tinyint(4) DEFAULT '2' COMMENT '查看合同:1是,2否',
  `create_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `update_time` bigint(20) DEFAULT NULL,
  `delete_time` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_login` (`user_login`) USING BTREE,
  KEY `user_nickname` (`user_nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_user VALUES("1","1","0","0","1754102068","0","0","0.00","1","admin","###7a83c4a197d689babb621303f7f65c07","admin","admin@gmail.com","","","","115.57.221.122","","","","2","1660558068","","0");
INSERT INTO cmf_user VALUES("2","1","0","0","1735353352","0","0","0.00","1","test1","###c312d5fbef62b46c9ef089b8a8dff5c6","","","","","","123.14.174.35","","15801055988","","2","0","1735354271","0");
INSERT INTO cmf_user VALUES("5","1","0","0","1735354321","0","0","0.00","0","test555","###69bad127654ba4ed702e0acc9e6d5cb7","","","","","","123.14.174.35","","18888854541","","0","1735353788","1743387406","0");



DROP TABLE cmf_user_login_attempt;

CREATE TABLE `cmf_user_login_attempt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试次数',
  `attempt_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试登录时间',
  `locked_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户 ip',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '用户账号,手机号,邮箱或用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户登录尝试表';




DROP TABLE cmf_user_token;

CREATE TABLE `cmf_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `token` varchar(64) NOT NULL DEFAULT '' COMMENT 'token',
  `device_type` varchar(10) NOT NULL DEFAULT '' COMMENT '设备类型;mobile,android,iphone,ipad,web,pc,mac,wxapp',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='用户客户端登录 token 表';

INSERT INTO cmf_user_token VALUES("1","1","1755332022","1739780022","21a141d229b251c404dbebbcf3334aa910dbe0b7d68eb339b8df8f96de00ed84","web");
INSERT INTO cmf_user_token VALUES("2","5","1750906298","1735354298","03f8880a016368367a36f27bb950566695adbe47a2cab470bf15950269bf0e13","web");



DROP TABLE cmf_verification_code;

CREATE TABLE `cmf_verification_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天已经发送成功的次数',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后发送成功时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证码过期时间',
  `code` varchar(8) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '最后发送成功的验证码',
  `account` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '手机号或者邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机邮箱数字验证码表';




DROP TABLE cmf_wechat_menu;

CREATE TABLE `cmf_wechat_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0' COMMENT '父级id',
  `name` varchar(20) DEFAULT NULL COMMENT '菜单名称',
  `type` varchar(32) DEFAULT NULL COMMENT '按钮类型 click，view，media_id，article_id，miniprogram',
  `key` varchar(64) DEFAULT NULL COMMENT 'click类型的key值',
  `url` varchar(256) DEFAULT NULL COMMENT '网页 链接，用户点击菜单可打开链接，不超过1024字节。 type为miniprogram时，不支持小程序的老版本客户端将打开本url。',
  `media_id` varchar(1024) DEFAULT NULL COMMENT '调用新增永久素材接口返回的合法media_id',
  `appid` varchar(64) DEFAULT NULL COMMENT '小程序的appid',
  `pagepath` varchar(64) DEFAULT NULL COMMENT '小程序的页面路径',
  `article_id` varchar(64) DEFAULT NULL COMMENT '发布后获得的合法 article_id',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1显示,2隐藏',
  `list_order` int(11) DEFAULT '100',
  `thumb` varchar(255) DEFAULT NULL,
  `reply_content` varchar(1024) DEFAULT NULL COMMENT '回复内容',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO cmf_wechat_menu VALUES("1","0","按钮1","","","","","","","","1","100","100","","","1743924149","0");
INSERT INTO cmf_wechat_menu VALUES("2","0","按钮2","click","about","","","","","","1","200","1","","0","1743924149","0");
INSERT INTO cmf_wechat_menu VALUES("3","0","按钮3","","","","","","","","1","300","100","","","1743924149","0");
INSERT INTO cmf_wechat_menu VALUES("8","3","测试网址","view","miniprogram","www.baidu.com","","","","","1","100","","","1743924042","1743924223","0");
INSERT INTO cmf_wechat_menu VALUES("14","1","测试","","miniprogram","","","","","","1","100","","","1743925200","","0");
INSERT INTO cmf_wechat_menu VALUES("15","1","测试2","click","1","","","","","","1","100","","222","1743925214","","0");
INSERT INTO cmf_wechat_menu VALUES("16","1","测试3","view","miniprogram","www.bai","","","","","1","100","","","1743925226","","0");
INSERT INTO cmf_wechat_menu VALUES("17","1","测试4","miniprogram","miniprogram","","","1","1","","1","100","","","1743925234","1743926432","0");



