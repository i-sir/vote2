DROP TABLE cmf_admin_menu;

CREATE TABLE `cmf_admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父菜单id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '菜单类型;1:有界面可访问菜单,2:无界面可访问菜单,0:只作为菜单',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;1:显示,0:不显示',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '应用名',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action` varchar(30) NOT NULL DEFAULT '' COMMENT '操作名称',
  `param` varchar(50) NOT NULL DEFAULT '' COMMENT '额外参数',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单名称',
  `icon` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `controller` (`controller`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单表';

INSERT INTO cmf_admin_menu VALUES("1","0","0","1","10000","admin","Plugin","default","","插件中心","cloud","插件中心","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("2","1","1","0","1000","admin","Hook","index","","钩子管理","","钩子管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("3","2","1","0","1000","admin","Hook","plugins","","钩子插件管理","","钩子插件管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("4","2","2","0","1000","admin","Hook","pluginListOrder","","钩子插件排序","","钩子插件排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("5","2","1","0","1000","admin","Hook","sync","","同步钩子","","同步钩子","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("6","0","0","1","100","admin","Setting","default","","设置","cogs","系统设置入口","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("7","6","1","0","1000","admin","Link","index","","友情链接","","友情链接管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("8","7","1","0","1000","admin","Link","add","","添加友情链接","","添加友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("9","7","2","0","1000","admin","Link","addPost","","添加友情链接提交保存","","添加友情链接提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("10","7","1","0","1000","admin","Link","edit","","编辑友情链接","","编辑友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("11","7","2","0","1000","admin","Link","editPost","","编辑友情链接提交保存","","编辑友情链接提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("12","7","2","0","1000","admin","Link","delete","","删除友情链接","","删除友情链接","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("13","7","2","0","1000","admin","Link","listOrder","","友情链接排序","","友情链接排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("14","7","2","0","1000","admin","Link","toggle","","友情链接显示隐藏","","友情链接显示隐藏","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("15","6","1","0","1000","admin","Mailer","index","","邮箱配置","","邮箱配置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("16","15","2","0","1000","admin","Mailer","indexPost","","邮箱配置提交保存","","邮箱配置提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("17","15","1","0","1000","admin","Mailer","template","","邮件模板","","邮件模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("18","15","2","0","1000","admin","Mailer","templatePost","","邮件模板提交","","邮件模板提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("19","15","1","0","1000","admin","Mailer","test","","邮件发送测试","","邮件发送测试","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("20","6","1","0","1000","admin","Menu","index","","后台菜单","","后台菜单管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("21","20","1","0","1000","admin","Menu","lists","","所有菜单","","后台所有菜单列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("22","20","1","0","1000","admin","Menu","add","","后台菜单添加","","后台菜单添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("23","20","2","0","1000","admin","Menu","addPost","","后台菜单添加提交保存","","后台菜单添加提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("24","20","1","0","1000","admin","Menu","edit","","后台菜单编辑","","后台菜单编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("25","20","2","0","1000","admin","Menu","editPost","","后台菜单编辑提交保存","","后台菜单编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("26","20","2","0","1000","admin","Menu","delete","","后台菜单删除","","后台菜单删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("27","20","2","0","1000","admin","Menu","listOrder","","后台菜单排序","","后台菜单排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("28","20","1","0","1000","admin","Menu","getActions","","导入新后台菜单","","导入新后台菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("29","6","1","0","1000","admin","Nav","index","","导航管理","","导航管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("30","29","1","0","1000","admin","Nav","add","","添加导航","","添加导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("31","29","2","0","1000","admin","Nav","addPost","","添加导航提交保存","","添加导航提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("32","29","1","0","1000","admin","Nav","edit","","编辑导航","","编辑导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("33","29","2","0","1000","admin","Nav","editPost","","编辑导航提交保存","","编辑导航提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("34","29","2","0","1000","admin","Nav","delete","","删除导航","","删除导航","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("35","29","1","0","1000","admin","NavMenu","index","","导航菜单","","导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("36","35","1","0","1000","admin","NavMenu","add","","添加导航菜单","","添加导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("37","35","2","0","1000","admin","NavMenu","addPost","","添加导航菜单提交保存","","添加导航菜单提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("38","35","1","0","1000","admin","NavMenu","edit","","编辑导航菜单","","编辑导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("39","35","2","0","1000","admin","NavMenu","editPost","","编辑导航菜单提交保存","","编辑导航菜单提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("40","35","2","0","1000","admin","NavMenu","delete","","删除导航菜单","","删除导航菜单","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("41","35","2","0","1000","admin","NavMenu","listOrder","","导航菜单排序","","导航菜单排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("42","1","1","1","1000","admin","Plugin","index","","插件列表","","插件列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("43","42","2","0","1000","admin","Plugin","toggle","","插件启用禁用","","插件启用禁用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("44","42","1","0","1000","admin","Plugin","setting","","插件设置","","插件设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("45","42","2","0","1000","admin","Plugin","settingPost","","插件设置提交","","插件设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("46","42","2","0","1000","admin","Plugin","install","","插件安装","","插件安装","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("47","42","2","0","1000","admin","Plugin","update","","插件更新","","插件更新","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("48","42","2","0","1000","admin","Plugin","uninstall","","卸载插件","","卸载插件","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("49","0","0","1","9800","admin","User","default","","管理组","users","管理组","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("50","49","1","1","1000","admin","Rbac","index","","角色管理","","角色管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("51","50","1","0","1000","admin","Rbac","roleAdd","","添加角色","","添加角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("52","50","2","0","1000","admin","Rbac","roleAddPost","","添加角色提交","","添加角色提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("53","50","1","0","1000","admin","Rbac","roleEdit","","编辑角色","","编辑角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("54","50","2","0","1000","admin","Rbac","roleEditPost","","编辑角色提交","","编辑角色提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("55","50","2","0","1000","admin","Rbac","roleDelete","","删除角色","","删除角色","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("56","50","1","0","1000","admin","Rbac","authorize","","设置角色权限","","设置角色权限","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("57","50","2","0","1000","admin","Rbac","authorizePost","","角色授权提交","","角色授权提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("58","199","1","0","10000","admin","RecycleBin","index","","回收站","","回收站","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("59","58","2","0","1000","admin","RecycleBin","restore","","回收站还原","","回收站还原","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("60","58","2","0","1000","admin","RecycleBin","delete","","回收站彻底删除","","回收站彻底删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("61","6","1","0","1000","admin","Route","index","","URL美化","","URL规则管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("62","61","1","0","1000","admin","Route","add","","添加路由规则","","添加路由规则","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("63","61","2","0","1000","admin","Route","addPost","","添加路由规则提交","","添加路由规则提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("64","61","1","0","1000","admin","Route","edit","","路由规则编辑","","路由规则编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("65","61","2","0","1000","admin","Route","editPost","","路由规则编辑提交","","路由规则编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("66","61","2","0","1000","admin","Route","delete","","路由规则删除","","路由规则删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("67","61","2","0","1000","admin","Route","ban","","路由规则禁用","","路由规则禁用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("68","61","2","0","1000","admin","Route","open","","路由规则启用","","路由规则启用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("69","61","2","0","1000","admin","Route","listOrder","","路由规则排序","","路由规则排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("70","61","1","0","1000","admin","Route","select","","选择URL","","选择URL","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("71","6","1","0","1000","admin","Setting","site","","网站信息","","网站信息","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("72","71","2","0","1000","admin","Setting","sitePost","","网站信息设置提交","","网站信息设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("73","199","1","0","1000","admin","Setting","password","","密码修改","","密码修改","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("74","73","2","0","1000","admin","Setting","passwordPost","","密码修改提交","","密码修改提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("75","6","1","1","30","admin","Setting","upload","","上传设置","","上传设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("76","75","2","0","1000","admin","Setting","uploadPost","","上传设置提交","","上传设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("77","199","1","0","1000","admin","Setting","clearCache","","清除缓存","","清除缓存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("78","6","1","1","20","admin","Slide","index","","幻灯片管理","","幻灯片管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("79","78","1","0","1000","admin","Slide","add","","添加幻灯片","","添加幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("80","78","2","0","1000","admin","Slide","addPost","","添加幻灯片提交","","添加幻灯片提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("81","78","1","0","1000","admin","Slide","edit","","编辑幻灯片","","编辑幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("82","78","2","0","1000","admin","Slide","editPost","","编辑幻灯片提交","","编辑幻灯片提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("83","78","2","0","1000","admin","Slide","delete","","删除幻灯片","","删除幻灯片","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("84","78","1","0","1000","admin","SlideItem","index","","幻灯片页面列表","","幻灯片页面列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("85","84","1","0","1000","admin","SlideItem","add","","幻灯片页面添加","","幻灯片页面添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("86","84","2","0","1000","admin","SlideItem","addPost","","幻灯片页面添加提交","","幻灯片页面添加提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("87","84","1","0","1000","admin","SlideItem","edit","","幻灯片页面编辑","","幻灯片页面编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("88","84","2","0","1000","admin","SlideItem","editPost","","幻灯片页面编辑提交","","幻灯片页面编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("89","84","2","0","1000","admin","SlideItem","delete","","幻灯片页面删除","","幻灯片页面删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("90","84","2","0","1000","admin","SlideItem","ban","","幻灯片页面隐藏","","幻灯片页面隐藏","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("91","84","2","0","1000","admin","SlideItem","cancelBan","","幻灯片页面显示","","幻灯片页面显示","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("92","84","2","0","1000","admin","SlideItem","listOrder","","幻灯片页面排序","","幻灯片页面排序","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("93","6","1","1","40","admin","Storage","index","","文件存储","","文件存储","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("94","93","2","0","1000","admin","Storage","settingPost","","文件存储设置提交","","文件存储设置提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("95","6","1","0","1000","admin","Theme","index","","模板管理","","模板管理","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("96","95","1","0","1000","admin","Theme","install","","安装模板","","安装模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("97","95","2","0","1000","admin","Theme","uninstall","","卸载模板","","卸载模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("98","95","2","0","1000","admin","Theme","installTheme","","模板安装","","模板安装","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("99","95","2","0","1000","admin","Theme","update","","模板更新","","模板更新","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("100","95","2","0","1000","admin","Theme","active","","启用模板","","启用模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("101","95","1","0","1000","admin","Theme","files","","模板文件列表","","启用模板","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("102","95","1","0","1000","admin","Theme","fileSetting","","模板文件设置","","模板文件设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("103","95","1","0","1000","admin","Theme","fileArrayData","","模板文件数组数据列表","","模板文件数组数据列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("104","95","2","0","1000","admin","Theme","fileArrayDataEdit","","模板文件数组数据添加编辑","","模板文件数组数据添加编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("105","95","2","0","1000","admin","Theme","fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","","模板文件数组数据添加编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("106","95","2","0","1000","admin","Theme","fileArrayDataDelete","","模板文件数组数据删除","","模板文件数组数据删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("107","95","2","0","1000","admin","Theme","settingPost","","模板文件编辑提交保存","","模板文件编辑提交保存","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("108","95","1","0","1000","admin","Theme","dataSource","","模板文件设置数据源","","模板文件设置数据源","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("109","95","1","0","1000","admin","Theme","design","","模板设计","","模板设计","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("112","111","1","0","1000","admin","User","add","","管理员添加","","管理员添加","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("113","111","2","0","1000","admin","User","addPost","","管理员添加提交","","管理员添加提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("114","111","1","0","1000","admin","User","edit","","管理员编辑","","管理员编辑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("115","111","2","0","1000","admin","User","editPost","","管理员编辑提交","","管理员编辑提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("116","111","1","0","1000","admin","User","userInfo","","个人信息","","管理员个人信息修改","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("117","111","2","0","1000","admin","User","userInfoPost","","管理员个人信息修改提交","","管理员个人信息修改提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("118","111","2","0","1000","admin","User","delete","","管理员删除","","管理员删除","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("119","111","2","0","1000","admin","User","ban","","停用管理员","","停用管理员","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("120","111","2","0","1000","admin","User","cancelBan","","启用管理员","","启用管理员","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("121","199","1","0","1000","user","AdminAsset","index","","资源管理","file","资源管理列表","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("122","121","2","0","1000","user","AdminAsset","delete","","删除文件","","删除文件","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("123","110","0","1","10000","user","AdminIndex","default1","","用户组","","用户组","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("124","123","1","1","10000","user","AdminIndex","index","","本站用户","","本站用户","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("125","124","2","0","10000","user","AdminIndex","ban","","本站用户拉黑","","本站用户拉黑","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("126","124","2","0","10000","user","AdminIndex","cancelBan","","本站用户启用","","本站用户启用","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("127","123","1","1","10000","user","AdminOauth","index","","第三方用户","","第三方用户","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("128","127","2","0","10000","user","AdminOauth","delete","","删除第三方用户绑定","","删除第三方用户绑定","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("130","129","1","0","1000","user","AdminUserAction","edit","","编辑用户操作","","编辑用户操作","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("131","129","2","0","1000","user","AdminUserAction","editPost","","编辑用户操作提交","","编辑用户操作提交","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("132","129","1","0","1000","user","AdminUserAction","sync","","同步用户操作","","同步用户操作","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("162","58","2","0","1000","admin","RecycleBin","clear","","清空回收站","","一键清空回收站","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("163","1","1","1","1000","plugin/Swagger","AdminIndex","index","","Swagger","","Swagger","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("164","6","1","1","10","plugin/Configs","AdminIndex","index","","系统参数设置","","系统参数设置","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("167","0","1","1","1000","admin","member","default","","用户管理","user-o","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("168","167","1","1","1000","admin","member","index","","用户管理","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("169","1","1","1","1000","/plugin/form","AdminIndex","setting","","生成CURD","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("179","0","1","1","9000","admin","dingdan","index","","订单管理","reorder","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("180","179","1","1","1000","admin","shop_order","index","","订单管理","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("183","182","1","0","10000","admin","Shop","edit","","编辑","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("184","182","1","0","10000","admin","Shop","add","","添加","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("185","182","1","0","10000","admin","Shop","find","","查看","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("186","182","1","0","10000","admin","Shop","delete","","删除","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("198","6","1","1","10000","plugin/weipay","admin_index","index","","小程序设置","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("199","0","2","0","11000","admin","moren","index","","子权限","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("217","49","1","1","10000","admin","AdminUser","index","","管理员","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("218","217","1","0","10000","admin","AdminUser","edit","","编辑","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("219","217","1","0","10000","admin","AdminUser","add","","添加","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("220","217","1","0","10000","admin","AdminUser","delete","","删除","","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("231","0","1","1","9300","admin","member","log_all","","资金变动记录","rmb","","1740995591","1740995591","0");
INSERT INTO cmf_admin_menu VALUES("232","0","1","1","9200","admin","withdrawal","index","","提现管理","cc","","1740995591","1740995591","0");



CREATE TABLE `cmf_asset` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `file_size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小,单位B',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:可用,0:不可用',
  `download_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `file_key` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件惟一码',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `file_path` varchar(100) NOT NULL DEFAULT '' COMMENT '文件路径,相对于upload目录,可以为url',
  `file_md5` varchar(32) NOT NULL DEFAULT '' COMMENT '文件md5值',
  `file_sha1` varchar(40) NOT NULL DEFAULT '',
  `suffix` varchar(10) NOT NULL DEFAULT '' COMMENT '文件后缀名,不包括点',
  `more` text COMMENT '其它详细信息,JSON格式',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='资源表';

DROP TABLE cmf_auth_access;

CREATE TABLE `cmf_auth_access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL COMMENT '角色',
  `rule_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类,请加应用前缀,如admin_',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `rule_name` (`rule_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COMMENT='权限授权表';

INSERT INTO cmf_auth_access VALUES("135","2","admin/member/default","admin_url");
INSERT INTO cmf_auth_access VALUES("136","2","admin/member/index","admin_url");
INSERT INTO cmf_auth_access VALUES("137","2","admin/plugin/default","admin_url");
INSERT INTO cmf_auth_access VALUES("138","2","admin/hook/index","admin_url");
INSERT INTO cmf_auth_access VALUES("139","2","admin/hook/plugins","admin_url");
INSERT INTO cmf_auth_access VALUES("140","2","admin/hook/pluginlistorder","admin_url");
INSERT INTO cmf_auth_access VALUES("141","2","admin/hook/sync","admin_url");
INSERT INTO cmf_auth_access VALUES("142","2","admin/plugin/index","admin_url");
INSERT INTO cmf_auth_access VALUES("143","2","admin/plugin/toggle","admin_url");
INSERT INTO cmf_auth_access VALUES("144","2","admin/plugin/setting","admin_url");
INSERT INTO cmf_auth_access VALUES("145","2","admin/plugin/settingpost","admin_url");
INSERT INTO cmf_auth_access VALUES("146","2","admin/plugin/install","admin_url");
INSERT INTO cmf_auth_access VALUES("147","2","admin/plugin/update","admin_url");
INSERT INTO cmf_auth_access VALUES("148","2","admin/plugin/uninstall","admin_url");
INSERT INTO cmf_auth_access VALUES("149","2","plugin/swagger/adminindex/index","admin_url");
INSERT INTO cmf_auth_access VALUES("150","2","/plugin/form/adminindex/setting","admin_url");



DROP TABLE cmf_auth_rule;

CREATE TABLE `cmf_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `app` varchar(40) NOT NULL DEFAULT '' COMMENT '规则所属app',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '权限规则分类，请加应用前缀,如admin_',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识,全小写',
  `param` varchar(100) NOT NULL DEFAULT '' COMMENT '额外url参数',
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '规则描述',
  `condition` varchar(200) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `module` (`app`,`status`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COMMENT='权限规则表';

INSERT INTO cmf_auth_rule VALUES("1","1","admin","admin_url","admin/Hook/index","","钩子管理","");
INSERT INTO cmf_auth_rule VALUES("2","1","admin","admin_url","admin/Hook/plugins","","钩子插件管理","");
INSERT INTO cmf_auth_rule VALUES("3","1","admin","admin_url","admin/Hook/pluginListOrder","","钩子插件排序","");
INSERT INTO cmf_auth_rule VALUES("4","1","admin","admin_url","admin/Hook/sync","","同步钩子","");
INSERT INTO cmf_auth_rule VALUES("5","1","admin","admin_url","admin/Link/index","","友情链接","");
INSERT INTO cmf_auth_rule VALUES("6","1","admin","admin_url","admin/Link/add","","添加友情链接","");
INSERT INTO cmf_auth_rule VALUES("7","1","admin","admin_url","admin/Link/addPost","","添加友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("8","1","admin","admin_url","admin/Link/edit","","编辑友情链接","");
INSERT INTO cmf_auth_rule VALUES("9","1","admin","admin_url","admin/Link/editPost","","编辑友情链接提交保存","");
INSERT INTO cmf_auth_rule VALUES("10","1","admin","admin_url","admin/Link/delete","","删除友情链接","");
INSERT INTO cmf_auth_rule VALUES("11","1","admin","admin_url","admin/Link/listOrder","","友情链接排序","");
INSERT INTO cmf_auth_rule VALUES("12","1","admin","admin_url","admin/Link/toggle","","友情链接显示隐藏","");
INSERT INTO cmf_auth_rule VALUES("13","1","admin","admin_url","admin/Mailer/index","","邮箱配置","");
INSERT INTO cmf_auth_rule VALUES("14","1","admin","admin_url","admin/Mailer/indexPost","","邮箱配置提交保存","");
INSERT INTO cmf_auth_rule VALUES("15","1","admin","admin_url","admin/Mailer/template","","邮件模板","");
INSERT INTO cmf_auth_rule VALUES("16","1","admin","admin_url","admin/Mailer/templatePost","","邮件模板提交","");
INSERT INTO cmf_auth_rule VALUES("17","1","admin","admin_url","admin/Mailer/test","","邮件发送测试","");
INSERT INTO cmf_auth_rule VALUES("18","1","admin","admin_url","admin/Menu/index","","后台菜单","");
INSERT INTO cmf_auth_rule VALUES("19","1","admin","admin_url","admin/Menu/lists","","所有菜单","");
INSERT INTO cmf_auth_rule VALUES("20","1","admin","admin_url","admin/Menu/add","","后台菜单添加","");
INSERT INTO cmf_auth_rule VALUES("21","1","admin","admin_url","admin/Menu/addPost","","后台菜单添加提交保存","");
INSERT INTO cmf_auth_rule VALUES("22","1","admin","admin_url","admin/Menu/edit","","后台菜单编辑","");
INSERT INTO cmf_auth_rule VALUES("23","1","admin","admin_url","admin/Menu/editPost","","后台菜单编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("24","1","admin","admin_url","admin/Menu/delete","","后台菜单删除","");
INSERT INTO cmf_auth_rule VALUES("25","1","admin","admin_url","admin/Menu/listOrder","","后台菜单排序","");
INSERT INTO cmf_auth_rule VALUES("26","1","admin","admin_url","admin/Menu/getActions","","导入新后台菜单","");
INSERT INTO cmf_auth_rule VALUES("27","1","admin","admin_url","admin/Nav/index","","导航管理","");
INSERT INTO cmf_auth_rule VALUES("28","1","admin","admin_url","admin/Nav/add","","添加导航","");
INSERT INTO cmf_auth_rule VALUES("29","1","admin","admin_url","admin/Nav/addPost","","添加导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("30","1","admin","admin_url","admin/Nav/edit","","编辑导航","");
INSERT INTO cmf_auth_rule VALUES("31","1","admin","admin_url","admin/Nav/editPost","","编辑导航提交保存","");
INSERT INTO cmf_auth_rule VALUES("32","1","admin","admin_url","admin/Nav/delete","","删除导航","");
INSERT INTO cmf_auth_rule VALUES("33","1","admin","admin_url","admin/NavMenu/index","","导航菜单","");
INSERT INTO cmf_auth_rule VALUES("34","1","admin","admin_url","admin/NavMenu/add","","添加导航菜单","");
INSERT INTO cmf_auth_rule VALUES("35","1","admin","admin_url","admin/NavMenu/addPost","","添加导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("36","1","admin","admin_url","admin/NavMenu/edit","","编辑导航菜单","");
INSERT INTO cmf_auth_rule VALUES("37","1","admin","admin_url","admin/NavMenu/editPost","","编辑导航菜单提交保存","");
INSERT INTO cmf_auth_rule VALUES("38","1","admin","admin_url","admin/NavMenu/delete","","删除导航菜单","");
INSERT INTO cmf_auth_rule VALUES("39","1","admin","admin_url","admin/NavMenu/listOrder","","导航菜单排序","");
INSERT INTO cmf_auth_rule VALUES("40","1","admin","admin_url","admin/Plugin/default","","插件中心","");
INSERT INTO cmf_auth_rule VALUES("41","1","admin","admin_url","admin/Plugin/index","","插件列表","");
INSERT INTO cmf_auth_rule VALUES("42","1","admin","admin_url","admin/Plugin/toggle","","插件启用禁用","");
INSERT INTO cmf_auth_rule VALUES("43","1","admin","admin_url","admin/Plugin/setting","","插件设置","");
INSERT INTO cmf_auth_rule VALUES("44","1","admin","admin_url","admin/Plugin/settingPost","","插件设置提交","");
INSERT INTO cmf_auth_rule VALUES("45","1","admin","admin_url","admin/Plugin/install","","插件安装","");
INSERT INTO cmf_auth_rule VALUES("46","1","admin","admin_url","admin/Plugin/update","","插件更新","");
INSERT INTO cmf_auth_rule VALUES("47","1","admin","admin_url","admin/Plugin/uninstall","","卸载插件","");
INSERT INTO cmf_auth_rule VALUES("48","1","admin","admin_url","admin/Rbac/index","","角色管理","");
INSERT INTO cmf_auth_rule VALUES("49","1","admin","admin_url","admin/Rbac/roleAdd","","添加角色","");
INSERT INTO cmf_auth_rule VALUES("50","1","admin","admin_url","admin/Rbac/roleAddPost","","添加角色提交","");
INSERT INTO cmf_auth_rule VALUES("51","1","admin","admin_url","admin/Rbac/roleEdit","","编辑角色","");
INSERT INTO cmf_auth_rule VALUES("52","1","admin","admin_url","admin/Rbac/roleEditPost","","编辑角色提交","");
INSERT INTO cmf_auth_rule VALUES("53","1","admin","admin_url","admin/Rbac/roleDelete","","删除角色","");
INSERT INTO cmf_auth_rule VALUES("54","1","admin","admin_url","admin/Rbac/authorize","","设置角色权限","");
INSERT INTO cmf_auth_rule VALUES("55","1","admin","admin_url","admin/Rbac/authorizePost","","角色授权提交","");
INSERT INTO cmf_auth_rule VALUES("56","1","admin","admin_url","admin/RecycleBin/index","","回收站","");
INSERT INTO cmf_auth_rule VALUES("57","1","admin","admin_url","admin/RecycleBin/restore","","回收站还原","");
INSERT INTO cmf_auth_rule VALUES("58","1","admin","admin_url","admin/RecycleBin/delete","","回收站彻底删除","");
INSERT INTO cmf_auth_rule VALUES("59","1","admin","admin_url","admin/Route/index","","URL美化","");
INSERT INTO cmf_auth_rule VALUES("60","1","admin","admin_url","admin/Route/add","","添加路由规则","");
INSERT INTO cmf_auth_rule VALUES("61","1","admin","admin_url","admin/Route/addPost","","添加路由规则提交","");
INSERT INTO cmf_auth_rule VALUES("62","1","admin","admin_url","admin/Route/edit","","路由规则编辑","");
INSERT INTO cmf_auth_rule VALUES("63","1","admin","admin_url","admin/Route/editPost","","路由规则编辑提交","");
INSERT INTO cmf_auth_rule VALUES("64","1","admin","admin_url","admin/Route/delete","","路由规则删除","");
INSERT INTO cmf_auth_rule VALUES("65","1","admin","admin_url","admin/Route/ban","","路由规则禁用","");
INSERT INTO cmf_auth_rule VALUES("66","1","admin","admin_url","admin/Route/open","","路由规则启用","");
INSERT INTO cmf_auth_rule VALUES("67","1","admin","admin_url","admin/Route/listOrder","","路由规则排序","");
INSERT INTO cmf_auth_rule VALUES("68","1","admin","admin_url","admin/Route/select","","选择URL","");
INSERT INTO cmf_auth_rule VALUES("69","1","admin","admin_url","admin/Setting/default","","设置","");
INSERT INTO cmf_auth_rule VALUES("70","1","admin","admin_url","admin/Setting/site","","网站信息","");
INSERT INTO cmf_auth_rule VALUES("71","1","admin","admin_url","admin/Setting/sitePost","","网站信息设置提交","");
INSERT INTO cmf_auth_rule VALUES("72","1","admin","admin_url","admin/Setting/password","","密码修改","");
INSERT INTO cmf_auth_rule VALUES("73","1","admin","admin_url","admin/Setting/passwordPost","","密码修改提交","");
INSERT INTO cmf_auth_rule VALUES("74","1","admin","admin_url","admin/Setting/upload","","上传设置","");
INSERT INTO cmf_auth_rule VALUES("75","1","admin","admin_url","admin/Setting/uploadPost","","上传设置提交","");
INSERT INTO cmf_auth_rule VALUES("76","1","admin","admin_url","admin/Setting/clearCache","","清除缓存","");
INSERT INTO cmf_auth_rule VALUES("77","1","admin","admin_url","admin/Slide/index","","幻灯片管理","");
INSERT INTO cmf_auth_rule VALUES("78","1","admin","admin_url","admin/Slide/add","","添加幻灯片","");
INSERT INTO cmf_auth_rule VALUES("79","1","admin","admin_url","admin/Slide/addPost","","添加幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("80","1","admin","admin_url","admin/Slide/edit","","编辑幻灯片","");
INSERT INTO cmf_auth_rule VALUES("81","1","admin","admin_url","admin/Slide/editPost","","编辑幻灯片提交","");
INSERT INTO cmf_auth_rule VALUES("82","1","admin","admin_url","admin/Slide/delete","","删除幻灯片","");
INSERT INTO cmf_auth_rule VALUES("83","1","admin","admin_url","admin/SlideItem/index","","幻灯片页面列表","");
INSERT INTO cmf_auth_rule VALUES("84","1","admin","admin_url","admin/SlideItem/add","","幻灯片页面添加","");
INSERT INTO cmf_auth_rule VALUES("85","1","admin","admin_url","admin/SlideItem/addPost","","幻灯片页面添加提交","");
INSERT INTO cmf_auth_rule VALUES("86","1","admin","admin_url","admin/SlideItem/edit","","幻灯片页面编辑","");
INSERT INTO cmf_auth_rule VALUES("87","1","admin","admin_url","admin/SlideItem/editPost","","幻灯片页面编辑提交","");
INSERT INTO cmf_auth_rule VALUES("88","1","admin","admin_url","admin/SlideItem/delete","","幻灯片页面删除","");
INSERT INTO cmf_auth_rule VALUES("89","1","admin","admin_url","admin/SlideItem/ban","","幻灯片页面隐藏","");
INSERT INTO cmf_auth_rule VALUES("90","1","admin","admin_url","admin/SlideItem/cancelBan","","幻灯片页面显示","");
INSERT INTO cmf_auth_rule VALUES("91","1","admin","admin_url","admin/SlideItem/listOrder","","幻灯片页面排序","");
INSERT INTO cmf_auth_rule VALUES("92","1","admin","admin_url","admin/Storage/index","","文件存储","");
INSERT INTO cmf_auth_rule VALUES("93","1","admin","admin_url","admin/Storage/settingPost","","文件存储设置提交","");
INSERT INTO cmf_auth_rule VALUES("94","1","admin","admin_url","admin/Theme/index","","模板管理","");
INSERT INTO cmf_auth_rule VALUES("95","1","admin","admin_url","admin/Theme/install","","安装模板","");
INSERT INTO cmf_auth_rule VALUES("96","1","admin","admin_url","admin/Theme/uninstall","","卸载模板","");
INSERT INTO cmf_auth_rule VALUES("97","1","admin","admin_url","admin/Theme/installTheme","","模板安装","");
INSERT INTO cmf_auth_rule VALUES("98","1","admin","admin_url","admin/Theme/update","","模板更新","");
INSERT INTO cmf_auth_rule VALUES("99","1","admin","admin_url","admin/Theme/active","","启用模板","");
INSERT INTO cmf_auth_rule VALUES("100","1","admin","admin_url","admin/Theme/files","","模板文件列表","");
INSERT INTO cmf_auth_rule VALUES("101","1","admin","admin_url","admin/Theme/fileSetting","","模板文件设置","");
INSERT INTO cmf_auth_rule VALUES("102","1","admin","admin_url","admin/Theme/fileArrayData","","模板文件数组数据列表","");
INSERT INTO cmf_auth_rule VALUES("103","1","admin","admin_url","admin/Theme/fileArrayDataEdit","","模板文件数组数据添加编辑","");
INSERT INTO cmf_auth_rule VALUES("104","1","admin","admin_url","admin/Theme/fileArrayDataEditPost","","模板文件数组数据添加编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("105","1","admin","admin_url","admin/Theme/fileArrayDataDelete","","模板文件数组数据删除","");
INSERT INTO cmf_auth_rule VALUES("106","1","admin","admin_url","admin/Theme/settingPost","","模板文件编辑提交保存","");
INSERT INTO cmf_auth_rule VALUES("107","1","admin","admin_url","admin/Theme/dataSource","","模板文件设置数据源","");
INSERT INTO cmf_auth_rule VALUES("108","1","admin","admin_url","admin/Theme/design","","模板设计","");
INSERT INTO cmf_auth_rule VALUES("109","1","admin","admin_url","admin/User/default","","管理组","");
INSERT INTO cmf_auth_rule VALUES("110","1","admin","admin_url","admin/User/index","","管理员","");
INSERT INTO cmf_auth_rule VALUES("111","1","admin","admin_url","admin/User/add","","管理员添加","");
INSERT INTO cmf_auth_rule VALUES("112","1","admin","admin_url","admin/User/addPost","","管理员添加提交","");
INSERT INTO cmf_auth_rule VALUES("113","1","admin","admin_url","admin/User/edit","","管理员编辑","");
INSERT INTO cmf_auth_rule VALUES("114","1","admin","admin_url","admin/User/editPost","","管理员编辑提交","");
INSERT INTO cmf_auth_rule VALUES("115","1","admin","admin_url","admin/User/userInfo","","个人信息","");
INSERT INTO cmf_auth_rule VALUES("116","1","admin","admin_url","admin/User/userInfoPost","","管理员个人信息修改提交","");
INSERT INTO cmf_auth_rule VALUES("117","1","admin","admin_url","admin/User/delete","","管理员删除","");
INSERT INTO cmf_auth_rule VALUES("118","1","admin","admin_url","admin/User/ban","","停用管理员","");
INSERT INTO cmf_auth_rule VALUES("119","1","admin","admin_url","admin/User/cancelBan","","启用管理员","");
INSERT INTO cmf_auth_rule VALUES("120","1","user","admin_url","user/AdminAsset/index","","资源管理","");
INSERT INTO cmf_auth_rule VALUES("121","1","user","admin_url","user/AdminAsset/delete","","删除文件","");
INSERT INTO cmf_auth_rule VALUES("122","1","user","admin_url","user/AdminIndex/default","","管理员","");
INSERT INTO cmf_auth_rule VALUES("123","1","user","admin_url","user/AdminIndex/default1","","用户组","");
INSERT INTO cmf_auth_rule VALUES("124","1","user","admin_url","user/AdminIndex/index","","本站用户","");
INSERT INTO cmf_auth_rule VALUES("125","1","user","admin_url","user/AdminIndex/ban","","本站用户拉黑","");
INSERT INTO cmf_auth_rule VALUES("126","1","user","admin_url","user/AdminIndex/cancelBan","","本站用户启用","");
INSERT INTO cmf_auth_rule VALUES("127","1","user","admin_url","user/AdminOauth/index","","第三方用户","");
INSERT INTO cmf_auth_rule VALUES("128","1","user","admin_url","user/AdminOauth/delete","","删除第三方用户绑定","");
INSERT INTO cmf_auth_rule VALUES("129","1","user","admin_url","user/AdminUserAction/index","","用户操作管理","");
INSERT INTO cmf_auth_rule VALUES("130","1","user","admin_url","user/AdminUserAction/edit","","编辑用户操作","");
INSERT INTO cmf_auth_rule VALUES("131","1","user","admin_url","user/AdminUserAction/editPost","","编辑用户操作提交","");
INSERT INTO cmf_auth_rule VALUES("132","1","user","admin_url","user/AdminUserAction/sync","","同步用户操作","");
INSERT INTO cmf_auth_rule VALUES("133","1","admin","admin_url","admin/AppInfo/index","","应用设置","");
INSERT INTO cmf_auth_rule VALUES("162","1","admin","admin_url","admin/RecycleBin/clear","","清空回收站","");
INSERT INTO cmf_auth_rule VALUES("163","1","plugin/Swagger","plugin_url","plugin/Swagger/AdminIndex/index","","Swagger","");
INSERT INTO cmf_auth_rule VALUES("164","1","plugin/Configs","plugin_url","plugin/Configs/AdminIndex/index","","系统参数设置","");
INSERT INTO cmf_auth_rule VALUES("166","1","plugin/AdminJournal","admin_url","plugin/AdminJournal/AdminIndex/index","","操作日志","");
INSERT INTO cmf_auth_rule VALUES("167","1","admin","admin_url","admin/member/default","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("168","1","admin","admin_url","admin/member/index","","用户管理","");
INSERT INTO cmf_auth_rule VALUES("169","1","/plugin/form","admin_url","/plugin/form/AdminIndex/setting","","生成CURD","");
INSERT INTO cmf_auth_rule VALUES("177","1","admin","admin_url","admin/dingdan/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("178","1","admin","admin_url","admin/shop_order/index","","订单管理","");
INSERT INTO cmf_auth_rule VALUES("179","1","admin","admin_url","admin/Shop/index","","店铺管理","");
INSERT INTO cmf_auth_rule VALUES("180","1","admin","admin_url","admin/Shop/edit","","店铺管理-编辑","");
INSERT INTO cmf_auth_rule VALUES("181","1","admin","admin_url","admin/Shop/add","","店铺管理-添加","");
INSERT INTO cmf_auth_rule VALUES("182","1","admin","admin_url","admin/Shop/find","","店铺管理-查看","");
INSERT INTO cmf_auth_rule VALUES("183","1","admin","admin_url","admin/Shop/delete","","店铺管理-删除","");
INSERT INTO cmf_auth_rule VALUES("184","1","admin","admin_url","admin/FormTest/index","","测试生成crud","");
INSERT INTO cmf_auth_rule VALUES("185","1","admin","admin_url","admin/FormTest/edit","","测试生成crud-编辑","");
INSERT INTO cmf_auth_rule VALUES("186","1","admin","admin_url","admin/FormTest/add","","测试生成crud-添加","");
INSERT INTO cmf_auth_rule VALUES("187","1","admin","admin_url","admin/FormTest/find","","测试生成crud-查看","");
INSERT INTO cmf_auth_rule VALUES("188","1","admin","admin_url","admin/FormTest/delete","","测试生成crud-删除","");
INSERT INTO cmf_auth_rule VALUES("189","1","admin","admin_url","admin/FormTest/recommend_post","","测试生成crud-推荐","");
INSERT INTO cmf_auth_rule VALUES("190","1","admin","admin_url","admin/FormTest/list_order_post","","测试生成crud-排序","");
INSERT INTO cmf_auth_rule VALUES("191","1","admin","admin_url","admin/test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("192","1","plugin/weipay","admin_url","plugin/weipay/admin_index/index","","小程序设置","");
INSERT INTO cmf_auth_rule VALUES("193","1","admin","admin_url","admin/moren/index","","子权限","");
INSERT INTO cmf_auth_rule VALUES("194","1","admin","admin_url","admin/member/log_all","","资金变动记录","");
INSERT INTO cmf_auth_rule VALUES("195","1","admin","admin_url","admin/withdrawal/index","","提现管理","");
INSERT INTO cmf_auth_rule VALUES("196","1","admin","admin_url","admin/base_test/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("197","1","admin","admin_url","admin/BaseTest/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("198","1","admin","admin_url","admin/BaseTest/edit","","测试-编辑","");
INSERT INTO cmf_auth_rule VALUES("199","1","admin","admin_url","admin/BaseTest/add","","测试-添加","");
INSERT INTO cmf_auth_rule VALUES("200","1","admin","admin_url","admin/BaseTest/find","","测试-查看","");
INSERT INTO cmf_auth_rule VALUES("201","1","admin","admin_url","admin/BaseTest/delete","","测试-删除","");
INSERT INTO cmf_auth_rule VALUES("202","1","admin","admin_url","admin/ct/index","","测试","");
INSERT INTO cmf_auth_rule VALUES("203","1","admin","admin_url","admin/rere/idnf","","测试","");
INSERT INTO cmf_auth_rule VALUES("204","1","a","admin_url","a/a/a","","测试","");
INSERT INTO cmf_auth_rule VALUES("205","1","a","admin_url","a/a/a1","","a","");



CREATE TABLE `cmf_base_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '1后台  2前端',
  `log` longtext COMMENT '操作地址参数',
  `admin_id` int(11) DEFAULT NULL COMMENT '登录人',
  `admin_name` varchar(200) DEFAULT NULL COMMENT '昵称',
  `openid` varchar(255) DEFAULT NULL COMMENT '登录标识',
  `ip` varchar(200) DEFAULT NULL COMMENT 'IP地址',
  `menu_name` text COMMENT '地址栏',
  `param` longtext COMMENT '参数值',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `date` varchar(200) DEFAULT NULL COMMENT '日期',
  `visit_url` text COMMENT '域名+参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员日志';

DROP TABLE cmf_base_asset_log;

CREATE TABLE `cmf_base_asset_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单单号',
  `operate_type` varchar(255) DEFAULT 'balance' COMMENT '操作类型:balance余额,point积分',
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `change_type` tinyint(6) DEFAULT NULL COMMENT '变动类型:1=收入,2=支出',
  `order_type` int(11) DEFAULT '0' COMMENT '订单类型 ',
  `price` decimal(10,2) DEFAULT NULL COMMENT '变动金额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后',
  `content` varchar(50) DEFAULT NULL COMMENT '变动说明',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `order_id` int(11) DEFAULT '0' COMMENT '订单ID',
  `child_id` int(11) DEFAULT NULL COMMENT '子级id',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户资产变动记录';




DROP TABLE cmf_base_config;

CREATE TABLE `cmf_base_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'group_id只',
  `is_menu` tinyint(4) DEFAULT '2' COMMENT '是否菜单1:线上显示,本地都显示,2所有不显示,3本地显示,线上不显示',
  `menu_name` varchar(255) DEFAULT NULL COMMENT '菜单名字',
  `key` bigint(20) DEFAULT NULL COMMENT 'group_id值',
  `group_id` bigint(20) DEFAULT NULL COMMENT '分组ID',
  `name` varchar(100) DEFAULT NULL COMMENT '参数名',
  `value` text COMMENT '参数值,序列化数据',
  `label` varchar(100) DEFAULT NULL COMMENT '参数说明',
  `uridata` varchar(100) DEFAULT NULL COMMENT '附加数据',
  `data` varchar(2555) DEFAULT NULL COMMENT '数据源',
  `type` varchar(100) DEFAULT 'text' COMMENT '设置类型 ',
  `about` varchar(100) DEFAULT NULL COMMENT '备注注释',
  `list_order` bigint(20) DEFAULT NULL COMMENT '排序',
  `status` tinyint(100) DEFAULT '1' COMMENT '0不显示',
  `scatter` varchar(100) DEFAULT NULL COMMENT '隔断,打散数据 /',
  `data_type` varchar(50) DEFAULT NULL COMMENT '数据类型',
  `is_label` tinyint(4) DEFAULT '0' COMMENT '组件数据格式:0否,1是',
  `is_edit` tinyint(4) DEFAULT '0' COMMENT '禁止编辑:0否,1是',
  `is_show` tinyint(4) DEFAULT '1' COMMENT '显示:0否,1是',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

INSERT INTO cmf_base_config VALUES("1","1","系统配置","100","0","system_configuration","","系统配置","","s:0:\"\";","text","","100","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("2","3","私有配置","999999","0","private_configuration","","私有配置","","s:0:\"\";","text","","999999","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("100","2","","0","100","app_logo","s:59:\"kf222/default/20240426/53e5c8df35ec4817f5065b53da6ee458.jpg\";","应用LOGO","","s:0:\"\";","img","","1","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("101","2","","0","100","app_name","s:25:\"公众号/小程序模板\";","应用名称","","s:0:\"\";","","","2","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("102","2","","0","999999","domain_name","s:26:\"https://lscs001.jscxkf.net\";","域名","","s:0:\"\";","text","","100","1","","string","0","0","1");
INSERT INTO cmf_base_config VALUES("103","2","","0","999999","app_expiration_time","s:0:\"\";","应用到期时间","","s:0:\"\";","date","开发应用到期时间","300","1","","","0","0","0");
INSERT INTO cmf_base_config VALUES("104","2","","0","999999","project_name","s:19:\"公众号/小程序\";","项目名字","","s:0:\"\";","","本地项目名","300","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("105","2","","0","999999","copyright","s:42:\"技术支持：微巨宝科技有限公司\";","版权","","s:0:\"\";","","登录页版权","400","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("106","2","","0","999999","local_domain_name","s:16:\"http://lscs.ikun\";","本地域名","","s:0:\"\";","","","200","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("107","2","","0","999999","log_file_days","s:2:\"10\";","日志文件保留天数","","s:0:\"\";","number","日志文件保留天数","500","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("136","2","","0","200","program_code","s:69:\"dzkf00000000001/default/20241016/ae73672e549f1ef3ceba9fe1593e5d07.jpg\";","程序码二维码","","s:0:\"\";","img","","200","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("137","3","程序配置","200","0","program_configuration","","程序配置","","s:0:\"\";","","","999998","1","","","0","0","0");
INSERT INTO cmf_base_config VALUES("139","2","","0","200","program_information","s:22:\"***小程序-旺旺名\";","程序信息","","s:0:\"\";","","程序基础信息","100","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("141","2","","0","999999","order_automatic_cancellation_time","s:2:\"15\";","订单自动取消时","","s:0:\"\";","number","单位/分钟","600","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("142","2","","0","999999","order_auto_completion_time","s:2:\"10\";","订单发货后自动完成时间","","s:0:\"\";","number","单位/天","700","1","","","0","0","1");
INSERT INTO cmf_base_config VALUES("143","2","","0","999999","tencent_map_key","s:35:\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\";","腾讯地图key","","s:0:\"\";","","用于地图转经纬度,经纬度转地址,腾讯地图key","800","1","","","0","0","1");



DROP TABLE cmf_base_express;

CREATE TABLE `cmf_base_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(12) DEFAULT NULL COMMENT '快递名称',
  `abbr` varchar(10) DEFAULT NULL COMMENT '微信快递code',
  `kd_hundred_code` varchar(255) DEFAULT NULL COMMENT '快递100code',
  `kd_bird_code` varchar(255) DEFAULT NULL COMMENT '快递鸟code',
  `status` tinyint(4) DEFAULT '1' COMMENT '2删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='快递表';

INSERT INTO cmf_base_express VALUES("1","安能物流","ANE","annengwuliu","ANE","1");
INSERT INTO cmf_base_express VALUES("2","百世快递","BEST","huitongkuaidi","HTKY","1");
INSERT INTO cmf_base_express VALUES("3","德邦快递","DB","debangkuaidi","DBL","1");
INSERT INTO cmf_base_express VALUES("4","中国邮政速递物流","EMS","youzhengguonei","YZPY","1");
INSERT INTO cmf_base_express VALUES("6","京东快递","JDL","jd","JD","1");
INSERT INTO cmf_base_express VALUES("7","极兔快递","JTSD","jtexpress","JTSD","1");
INSERT INTO cmf_base_express VALUES("9","顺丰速运","SF","shunfeng","SF","1");
INSERT INTO cmf_base_express VALUES("10","申通快递","STO","shentong","STO","1");
INSERT INTO cmf_base_express VALUES("12","圆通速递","YTO","yuantong","YTO","1");
INSERT INTO cmf_base_express VALUES("13","韵达快递","YUNDA","yunda","YD","1");
INSERT INTO cmf_base_express VALUES("14","中通快递","ZTO","zhongtong","ZTO","1");



DROP TABLE cmf_base_form_model;

CREATE TABLE `cmf_base_form_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json_params` text COLLATE utf8_unicode_ci,
  `type` tinyint(2) DEFAULT '1' COMMENT '1提交数据  2访问域名',
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='生成curt';

INSERT INTO cmf_base_form_model VALUES("1","a:33:{s:10:\"table_name\";s:9:\"form_test\";s:10:\"model_name\";s:8:\"FormTest\";s:4:\"tags\";s:16:\"测试生成crud\";s:7:\"keyword\";a:8:{s:9:\"order_num\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"b_image\";s:2:\"on\";s:8:\"b_images\";s:2:\"on\";s:9:\"a_content\";s:2:\"on\";s:9:\"b_content\";s:2:\"on\";s:6:\"status\";s:2:\"on\";s:12:\"is_recommend\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:13:\"api_checkAuth\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:16:\"测试生成crud\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("2","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("3","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("4","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:form_test  -------  控制器(tags):测试生成crud");
INSERT INTO cmf_base_form_model VALUES("5","a:26:{s:10:\"table_name\";s:17:\"shop_order_detail\";s:10:\"model_name\";s:15:\"ShopOrderDetail\";s:4:\"tags\";s:12:\"订单详情\";s:7:\"keyword\";a:6:{s:8:\"goods_id\";s:2:\"on\";s:6:\"sku_id\";s:2:\"on\";s:10:\"goods_name\";s:2:\"on\";s:8:\"sku_name\";s:2:\"on\";s:5:\"count\";s:2:\"on\";s:11:\"goods_price\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:12:\"订单详情\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("6","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:shop_order_detail  -------  控制器(tags):订单详情");
INSERT INTO cmf_base_form_model VALUES("7","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:shop_order_detail  -------  控制器(tags):订单详情");
INSERT INTO cmf_base_form_model VALUES("8","a:32:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("9","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("10","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("11","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("12","a:26:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:5:\"token\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("13","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("14","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("15","a:30:{s:10:\"table_name\";s:4:\"test\";s:10:\"model_name\";s:4:\"Test\";s:4:\"tags\";s:4:\"test\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:5:\"token\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("16","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("17","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("18","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("19","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:test  -------  控制器(tags):test");
INSERT INTO cmf_base_form_model VALUES("20","a:26:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("21","http://w.site/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("22","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("23","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("24","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("25","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("26","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("27","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("28","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("29","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("30","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("31","a:32:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("32","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("33","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("34","a:31:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("35","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("36","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("37","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("38","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("39","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("40","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("41","a:32:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:14:\"index_delete_s\";s:2:\"on\";s:15:\"index_recommend\";s:2:\"on\";s:16:\"index_list_order\";s:2:\"on\";s:11:\"index_enter\";s:2:\"on\";s:9:\"index_out\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("42","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("43","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("44","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:7:\"require\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:10:\"\' . id . \'\";s:0:\"\";s:12:\"\' . name . \'\";s:18:\"名字不能为空\";s:13:\"\' . image . \'\";s:0:\"\";s:15:\"\' . a_image . \'\";s:0:\"\";s:14:\"\' . images . \'\";s:0:\"\";s:16:\"\' . a_images . \'\";s:0:\"\";s:12:\"\' . file . \'\";s:0:\"\";s:14:\"\' . a_file . \'\";s:0:\"\";s:13:\"\' . video . \'\";s:0:\"\";s:15:\"\' . a_video . \'\";s:0:\"\";s:12:\"\' . type . \'\";s:0:\"\";s:15:\"\' . content . \'\";s:0:\"\";s:17:\"\' . introduce . \'\";s:0:\"\";s:16:\"\' . pay_type . \'\";s:0:\"\";s:14:\"\' . refuse . \'\";s:0:\"\";s:13:\"\' . reply . \'\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("45","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:9:\"不为空\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("46","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:6:\"侧耳\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("47","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("48","a:27:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("49","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:7:\"require\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:19:\"名字不能为空!\";s:5:\"image\";s:15:\"图片请选择\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("50","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("51","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("52","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("53","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("54","a:28:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:4:\"null\";s:5:\"image\";s:4:\"null\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:5:\"image\";s:0:\"\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("55","a:29:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:7:\"require\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:19:\"名字不能为空!\";s:5:\"image\";s:19:\"图片不能为空!\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("56","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("57","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("58","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("59","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("60","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("61","a:30:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:7:\"require\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:19:\"名字不能为空!\";s:5:\"image\";s:19:\"图片不能为空!\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:0:\"\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("62","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("63","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("64","a:30:{s:10:\"table_name\";s:9:\"base_test\";s:10:\"model_name\";s:8:\"BaseTest\";s:4:\"tags\";s:9:\"base_test\";s:7:\"keyword\";a:1:{s:4:\"name\";s:2:\"on\";}s:17:\"checkbox_validate\";a:16:{s:2:\"id\";s:2:\"on\";s:4:\"name\";s:2:\"on\";s:5:\"image\";s:2:\"on\";s:7:\"a_image\";s:2:\"on\";s:6:\"images\";s:2:\"on\";s:8:\"a_images\";s:2:\"on\";s:4:\"file\";s:2:\"on\";s:6:\"a_file\";s:2:\"on\";s:5:\"video\";s:2:\"on\";s:7:\"a_video\";s:2:\"on\";s:4:\"type\";s:2:\"on\";s:7:\"content\";s:2:\"on\";s:9:\"introduce\";s:2:\"on\";s:8:\"pay_type\";s:2:\"on\";s:6:\"refuse\";s:2:\"on\";s:5:\"reply\";s:2:\"on\";}s:8:\"validate\";a:16:{s:2:\"id\";s:4:\"null\";s:4:\"name\";s:7:\"require\";s:5:\"image\";s:7:\"require\";s:7:\"a_image\";s:4:\"null\";s:6:\"images\";s:4:\"null\";s:8:\"a_images\";s:4:\"null\";s:4:\"file\";s:4:\"null\";s:6:\"a_file\";s:4:\"null\";s:5:\"video\";s:4:\"null\";s:7:\"a_video\";s:4:\"null\";s:4:\"type\";s:4:\"null\";s:7:\"content\";s:4:\"null\";s:9:\"introduce\";s:4:\"null\";s:8:\"pay_type\";s:4:\"null\";s:6:\"refuse\";s:4:\"null\";s:5:\"reply\";s:4:\"null\";}s:13:\"validate_text\";a:16:{s:2:\"id\";s:0:\"\";s:4:\"name\";s:19:\"名字不能为空!\";s:5:\"image\";s:19:\"图片不能为空!\";s:7:\"a_image\";s:0:\"\";s:6:\"images\";s:0:\"\";s:8:\"a_images\";s:0:\"\";s:4:\"file\";s:0:\"\";s:6:\"a_file\";s:0:\"\";s:5:\"video\";s:0:\"\";s:7:\"a_video\";s:0:\"\";s:4:\"type\";s:0:\"\";s:7:\"content\";s:0:\"\";s:9:\"introduce\";s:0:\"\";s:8:\"pay_type\";s:0:\"\";s:6:\"refuse\";s:0:\"\";s:5:\"reply\";s:0:\"\";}s:14:\"api_controller\";s:2:\"on\";s:12:\"api_paginate\";s:2:\"on\";s:10:\"api_openid\";s:6:\"openid\";s:16:\"admin_controller\";s:2:\"on\";s:14:\"admin_paginate\";s:2:\"on\";s:10:\"admin_view\";s:2:\"on\";s:10:\"admin_menu\";s:2:\"on\";s:9:\"index_add\";s:2:\"on\";s:10:\"index_edit\";s:2:\"on\";s:10:\"index_find\";s:2:\"on\";s:12:\"index_delete\";s:2:\"on\";s:9:\"parent_id\";s:0:\"\";s:4:\"name\";s:6:\"测试\";s:3:\"app\";s:5:\"admin\";s:6:\"action\";s:5:\"index\";s:5:\"param\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"remark\";s:0:\"\";s:6:\"status\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:7:\"_plugin\";s:4:\"form\";s:11:\"_controller\";s:10:\"AdminIndex\";s:7:\"_action\";s:11:\"settingPost\";}","1","");
INSERT INTO cmf_base_form_model VALUES("65","http://lscs.ikun/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");
INSERT INTO cmf_base_form_model VALUES("66","https://lscs001.jscxkf.net/plugin/form/AdminIndex/settingPost","2","表名:base_test  -------  控制器(tags):base_test");



DROP TABLE cmf_base_leave;

CREATE TABLE `cmf_base_leave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `username` varchar(255) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `content` varchar(2555) DEFAULT NULL COMMENT '留言内容',
  `images` text COMMENT '图集',
  `reply_content` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT '0' COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投诉建议';




DROP TABLE cmf_base_order_pay;

CREATE TABLE `cmf_base_order_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL COMMENT '关联订单id',
  `openid` varchar(255) DEFAULT NULL COMMENT 'openid',
  `order_type` int(5) DEFAULT '1' COMMENT '订单类型:',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付',
  `order_num` varchar(255) DEFAULT NULL COMMENT '关联订单号',
  `pay_num` varchar(255) DEFAULT NULL COMMENT '发起支付单号',
  `trade_num` varchar(255) DEFAULT NULL COMMENT '第三方返回单号',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `notify` text COMMENT '回调信息',
  `status` int(2) DEFAULT '1' COMMENT '支付状态:1未支付,2已支付',
  `pay_time` bigint(20) DEFAULT NULL COMMENT '支付时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='支付管理';

INSERT INTO cmf_base_order_pay VALUES("1","","","1","0","240508609700658392","31024050860970112603927","","0.00","","1","0","1715160970","0","0");
INSERT INTO cmf_base_order_pay VALUES("2","","","1","1","2407039409479192025407","31024070394094793940704","","0.01","","1","","1719994094","","0");
INSERT INTO cmf_base_order_pay VALUES("3","","","1","1","2407039412127888334409","31024070394121280912055","","0.01","","1","","1719994121","","0");
INSERT INTO cmf_base_order_pay VALUES("4","","","1","1","2407039412239917041783","31024070394122401004018","","0.01","","1","","1719994122","","0");
INSERT INTO cmf_base_order_pay VALUES("5","","","1","1","2407039412325082355093","31024070394123252743316","","0.01","","1","","1719994123","","0");
INSERT INTO cmf_base_order_pay VALUES("6","","","1","1","2407039412396916192002","31024070394123971140129","","0.01","","1","","1719994123","","0");
INSERT INTO cmf_base_order_pay VALUES("7","","","1","1","2407039412725289652572","31024070394127254981746","","0.01","","1","","1719994127","","0");
INSERT INTO cmf_base_order_pay VALUES("8","","","1","1","2407039414803170067535","31024070394148033586767","","0.01","","1","","1719994148","","0");
INSERT INTO cmf_base_order_pay VALUES("9","","","1","1","2407039414897335091781","31024070394148975378756","","0.01","","1","","1719994148","","0");
INSERT INTO cmf_base_order_pay VALUES("10","","","1","1","2407039455164451848133","31024070394551646483109","","0.01","","1","","1719994551","","0");
INSERT INTO cmf_base_order_pay VALUES("11","","","1","1","2407039455406511393314","31024070394554067017298","","0.01","","1","","1719994554","","0");
INSERT INTO cmf_base_order_pay VALUES("12","","","1","1","2407039470629075443774","31024070394706292689417","","0.01","","1","","1719994706","","0");
INSERT INTO cmf_base_order_pay VALUES("13","","","1","1","2407039509023785184582","31024070395090239837236","","0.01","","1","","1719995090","","0");
INSERT INTO cmf_base_order_pay VALUES("14","","","1","1","2407039509961503896333","31024070395099616995084","","0.01","","1","","1719995099","","0");
INSERT INTO cmf_base_order_pay VALUES("15","","","1","1","2407039510746982854494","31024070395107471836687","","0.01","","1","","1719995107","","0");
INSERT INTO cmf_base_order_pay VALUES("16","","","1","1","2407039514252680384637","31024070395142528799141","","0.01","","1","","1719995142","","0");
INSERT INTO cmf_base_order_pay VALUES("17","","","1","1","2407039514414642945026","31024070395144148467143","","0.01","","1","","1719995144","","0");
INSERT INTO cmf_base_order_pay VALUES("18","","","1","1","2407039515611068350519","31024070395156112602058","","0.01","","1","","1719995156","","0");
INSERT INTO cmf_base_order_pay VALUES("19","","","1","1","2407039519030014244300","31024070395190302155660","","0.01","","1","","1719995190","","0");
INSERT INTO cmf_base_order_pay VALUES("20","","","1","1","2407039519199700883809","31024070395191999007047","","0.01","","1","","1719995191","","0");
INSERT INTO cmf_base_order_pay VALUES("21","","","1","1","2407039520505382242462","31024070395205055849654","","0.01","","1","","1719995205","","0");
INSERT INTO cmf_base_order_pay VALUES("22","","","1","1","2407039521206280708856","31024070395212064740245","","0.01","","1","","1719995212","","0");
INSERT INTO cmf_base_order_pay VALUES("23","","","1","1","2407039521902201205117","31024070395219024136783","","0.01","","1","","1719995219","","0");
INSERT INTO cmf_base_order_pay VALUES("24","","","1","1","2407039530673552089695","31024070395306737521595","","0.01","","1","","1719995306","","0");
INSERT INTO cmf_base_order_pay VALUES("25","","","1","1","2407039531463830132279","31024070395314640201390","","0.01","","1","","1719995314","","0");
INSERT INTO cmf_base_order_pay VALUES("26","","","1","1","2407039547694793644178","31024070395476949865386","","0.01","","1","","1719995476","","0");
INSERT INTO cmf_base_order_pay VALUES("27","","","1","1","2407039549721031216111","31024070395497212263976","","0.01","","1","","1719995497","","0");
INSERT INTO cmf_base_order_pay VALUES("28","","","1","1","2407039550432606957428","31024070395504327926136","","0.01","","1","","1719995504","","0");
INSERT INTO cmf_base_order_pay VALUES("29","","","1","1","2407039555828692941317","31024070395558288970794","","0.01","","1","","1719995558","","0");
INSERT INTO cmf_base_order_pay VALUES("30","","","1","1","2407039556342573069662","31024070395563427709367","","0.01","","1","","1719995563","","0");
INSERT INTO cmf_base_order_pay VALUES("31","","","1","1","2407039556765905672834","31024070395567661180788","","0.01","","1","","1719995567","","0");
INSERT INTO cmf_base_order_pay VALUES("32","","","1","1","2407039556905436149503","31024070395569056423300","","0.01","","1","","1719995569","","0");
INSERT INTO cmf_base_order_pay VALUES("33","","","1","1","2407039577459313796364","31024070395774595062620","","0.01","","1","","1719995774","","0");



CREATE TABLE `cmf_base_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `a_image` varchar(255) DEFAULT NULL,
  `images` text,
  `a_images` text,
  `file` varchar(255) DEFAULT NULL,
  `a_file` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `a_video` varchar(255) DEFAULT NULL,
  `is_index` tinyint(4) DEFAULT '1' COMMENT '首页推荐:1是,2否',
  `type` tinyint(4) DEFAULT '1' COMMENT '类型:1普通商品,2抢购商品,3拼团商品',
  `is_pay` tinyint(4) DEFAULT '1' COMMENT '支付:1是,2否',
  `content` text,
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信,2余额,3支付宝',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态:1审核中,2已通过,3已拒绝',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `pass_time` bigint(20) DEFAULT NULL COMMENT '通过时间',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `reply` varchar(255) DEFAULT NULL COMMENT '回复内容',
  `reply_time` bigint(20) DEFAULT NULL COMMENT '回复时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `is_recommend` tinyint(4) DEFAULT '2' COMMENT '推荐:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

DROP TABLE cmf_base_withdrawal;

CREATE TABLE `cmf_base_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户信息',
  `identity_type` varchar(255) DEFAULT 'member' COMMENT '身份类型',
  `type` tinyint(2) DEFAULT '1' COMMENT '提现类型:1支付宝,2微信,3银行卡',
  `openid` varchar(120) DEFAULT NULL COMMENT 'openid',
  `wx_openid` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL COMMENT '提现金额',
  `charges` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `rmb` decimal(10,2) DEFAULT NULL COMMENT '需打款金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1待审核,2已审核,3已拒绝',
  `refuse` varchar(50) DEFAULT '' COMMENT '拒绝原因',
  `order_num` varchar(100) DEFAULT NULL COMMENT '订单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `ali_username` varchar(25) DEFAULT NULL,
  `ali_account` varchar(25) DEFAULT NULL,
  `wx_image` varchar(255) DEFAULT NULL,
  `opening_bank` varchar(255) DEFAULT NULL,
  `bank_username` varchar(25) DEFAULT NULL,
  `bank_account` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='会员提现申请';

INSERT INTO cmf_base_withdrawal VALUES("25","1","member","2","1","1","200.00","0.00","200.00","1","","250219345467983743","1739934546","","0","","","https://oss.ausite.cn/kf222/default/20240426/53e5c8df35ec4817f5065b53da6ee458.jpg","","","");
INSERT INTO cmf_base_withdrawal VALUES("26","1","member","1","1","1","200.00","0.00","200.00","1","","250219345711619409","1739934571","","0","张三","1888888","https://oss.ausite.cn/kf222/default/20240426/53e5c8df35ec4817f5065b53da6ee458.jpg","郑州银行","刘测试","88888888888");
INSERT INTO cmf_base_withdrawal VALUES("27","1","member","3","1","1","200.00","0.00","200.00","1","","250219345747629237","1739934574","","0","张三","1888888","https://oss.ausite.cn/kf222/default/20240426/53e5c8df35ec4817f5065b53da6ee458.jpg","郑州银行","刘测试","88888888888");



DROP TABLE cmf_comment;

CREATE TABLE `cmf_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '被回复的评论id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发表评论的用户id',
  `to_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被评论的用户id',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论内容 id',
  `like_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `dislike_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '不喜欢数',
  `floor` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '楼层数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论时间',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:已审核,0:未审核',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '评论类型；1实名评论',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '评论内容所在表，不带表前缀',
  `full_name` varchar(50) NOT NULL DEFAULT '' COMMENT '评论者昵称',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '评论者邮箱',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '层级关系',
  `url` text COMMENT '原文地址',
  `content` text CHARACTER SET utf8mb4 COMMENT '评论内容',
  `more` text CHARACTER SET utf8mb4 COMMENT '扩展属性',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `table_id_status` (`table_name`,`object_id`,`status`) USING BTREE,
  KEY `object_id` (`object_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='评论表';




DROP TABLE cmf_hook;

CREATE TABLE `cmf_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '钩子类型(1:系统钩子;2:应用钩子;3:模板钩子;4:后台模板钩子)',
  `once` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否只允许一个插件运行(0:多个;1:一个)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子',
  `app` varchar(15) NOT NULL DEFAULT '' COMMENT '应用名(只有应用钩子才用)',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子表';

INSERT INTO cmf_hook VALUES("2","1","0","应用开始","app_begin","cmf","应用开始");
INSERT INTO cmf_hook VALUES("3","1","0","模块初始化","module_init","cmf","模块初始化");
INSERT INTO cmf_hook VALUES("4","1","0","控制器开始","action_begin","cmf","控制器开始");
INSERT INTO cmf_hook VALUES("5","1","0","视图输出过滤","view_filter","cmf","视图输出过滤");
INSERT INTO cmf_hook VALUES("6","1","0","应用结束","app_end","cmf","应用结束");
INSERT INTO cmf_hook VALUES("7","1","0","日志write方法","log_write","cmf","日志write方法");
INSERT INTO cmf_hook VALUES("8","1","0","输出结束","response_end","cmf","输出结束");
INSERT INTO cmf_hook VALUES("9","1","0","后台控制器初始化","admin_init","cmf","后台控制器初始化");
INSERT INTO cmf_hook VALUES("10","1","0","前台控制器初始化","home_init","cmf","前台控制器初始化");
INSERT INTO cmf_hook VALUES("11","1","1","发送手机验证码","send_mobile_verification_code","cmf","发送手机验证码");
INSERT INTO cmf_hook VALUES("12","3","0","模板 body标签开始","body_start","","模板 body标签开始");
INSERT INTO cmf_hook VALUES("13","3","0","模板 head标签结束前","before_head_end","","模板 head标签结束前");
INSERT INTO cmf_hook VALUES("14","3","0","模板底部开始","footer_start","","模板底部开始");
INSERT INTO cmf_hook VALUES("15","3","0","模板底部开始之前","before_footer","","模板底部开始之前");
INSERT INTO cmf_hook VALUES("16","3","0","模板底部结束之前","before_footer_end","","模板底部结束之前");
INSERT INTO cmf_hook VALUES("17","3","0","模板 body 标签结束之前","before_body_end","","模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("18","3","0","模板左边栏开始","left_sidebar_start","","模板左边栏开始");
INSERT INTO cmf_hook VALUES("19","3","0","模板左边栏结束之前","before_left_sidebar_end","","模板左边栏结束之前");
INSERT INTO cmf_hook VALUES("20","3","0","模板右边栏开始","right_sidebar_start","","模板右边栏开始");
INSERT INTO cmf_hook VALUES("21","3","0","模板右边栏结束之前","before_right_sidebar_end","","模板右边栏结束之前");
INSERT INTO cmf_hook VALUES("22","3","1","评论区","comment","","评论区");
INSERT INTO cmf_hook VALUES("23","3","1","留言区","guestbook","","留言区");
INSERT INTO cmf_hook VALUES("24","2","0","后台首页仪表盘","admin_dashboard","admin","后台首页仪表盘");
INSERT INTO cmf_hook VALUES("25","4","0","后台模板 head标签结束前","admin_before_head_end","","后台模板 head标签结束前");
INSERT INTO cmf_hook VALUES("26","4","0","后台模板 body 标签结束之前","admin_before_body_end","","后台模板 body 标签结束之前");
INSERT INTO cmf_hook VALUES("27","2","0","后台登录页面","admin_login","admin","后台登录页面");
INSERT INTO cmf_hook VALUES("28","1","1","前台模板切换","switch_theme","cmf","前台模板切换");
INSERT INTO cmf_hook VALUES("29","3","0","主要内容之后","after_content","","主要内容之后");
INSERT INTO cmf_hook VALUES("32","2","1","获取上传界面","fetch_upload_view","user","获取上传界面");
INSERT INTO cmf_hook VALUES("33","3","0","主要内容之前","before_content","cmf","主要内容之前");
INSERT INTO cmf_hook VALUES("34","1","0","日志写入完成","log_write_done","cmf","日志写入完成");
INSERT INTO cmf_hook VALUES("35","1","1","后台模板切换","switch_admin_theme","cmf","后台模板切换");
INSERT INTO cmf_hook VALUES("36","1","1","验证码图片","captcha_image","cmf","验证码图片");
INSERT INTO cmf_hook VALUES("37","2","1","后台模板设计界面","admin_theme_design_view","admin","后台模板设计界面");
INSERT INTO cmf_hook VALUES("38","2","1","后台设置网站信息界面","admin_setting_site_view","admin","后台设置网站信息界面");
INSERT INTO cmf_hook VALUES("39","2","1","后台清除缓存界面","admin_setting_clear_cache_view","admin","后台清除缓存界面");
INSERT INTO cmf_hook VALUES("40","2","1","后台导航管理界面","admin_nav_index_view","admin","后台导航管理界面");
INSERT INTO cmf_hook VALUES("41","2","1","后台友情链接管理界面","admin_link_index_view","admin","后台友情链接管理界面");
INSERT INTO cmf_hook VALUES("42","2","1","后台幻灯片管理界面","admin_slide_index_view","admin","后台幻灯片管理界面");
INSERT INTO cmf_hook VALUES("43","2","1","后台管理员列表界面","admin_user_index_view","admin","后台管理员列表界面");
INSERT INTO cmf_hook VALUES("44","2","1","后台角色管理界面","admin_rbac_index_view","admin","后台角色管理界面");
INSERT INTO cmf_hook VALUES("49","2","1","用户管理本站用户列表界面","user_admin_index_view","user","用户管理本站用户列表界面");
INSERT INTO cmf_hook VALUES("50","2","1","资源管理列表界面","user_admin_asset_index_view","user","资源管理列表界面");
INSERT INTO cmf_hook VALUES("51","2","1","用户管理第三方用户列表界面","user_admin_oauth_index_view","user","用户管理第三方用户列表界面");
INSERT INTO cmf_hook VALUES("52","2","1","后台首页界面","admin_index_index_view","admin","后台首页界面");
INSERT INTO cmf_hook VALUES("53","2","1","后台回收站界面","admin_recycle_bin_index_view","admin","后台回收站界面");
INSERT INTO cmf_hook VALUES("54","2","1","后台菜单管理界面","admin_menu_index_view","admin","后台菜单管理界面");
INSERT INTO cmf_hook VALUES("55","2","1","后台自定义登录是否开启钩子","admin_custom_login_open","admin","后台自定义登录是否开启钩子");
INSERT INTO cmf_hook VALUES("64","2","1","后台幻灯片页面列表界面","admin_slide_item_index_view","admin","后台幻灯片页面列表界面");
INSERT INTO cmf_hook VALUES("65","2","1","后台幻灯片页面添加界面","admin_slide_item_add_view","admin","后台幻灯片页面添加界面");
INSERT INTO cmf_hook VALUES("66","2","1","后台幻灯片页面编辑界面","admin_slide_item_edit_view","admin","后台幻灯片页面编辑界面");
INSERT INTO cmf_hook VALUES("67","2","1","后台管理员添加界面","admin_user_add_view","admin","后台管理员添加界面");
INSERT INTO cmf_hook VALUES("68","2","1","后台管理员编辑界面","admin_user_edit_view","admin","后台管理员编辑界面");
INSERT INTO cmf_hook VALUES("69","2","1","后台角色添加界面","admin_rbac_role_add_view","admin","后台角色添加界面");
INSERT INTO cmf_hook VALUES("70","2","1","后台角色编辑界面","admin_rbac_role_edit_view","admin","后台角色编辑界面");
INSERT INTO cmf_hook VALUES("71","2","1","后台角色授权界面","admin_rbac_authorize_view","admin","后台角色授权界面");



DROP TABLE cmf_hook_plugin;

CREATE TABLE `cmf_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `hook` varchar(50) NOT NULL DEFAULT '' COMMENT '钩子名',
  `plugin` varchar(50) NOT NULL DEFAULT '' COMMENT '插件',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='系统钩子插件表';

INSERT INTO cmf_hook_plugin VALUES("2","10000","1","app_begin","Configs");
INSERT INTO cmf_hook_plugin VALUES("3","10000","1","fetch_upload_view","Oss");
INSERT INTO cmf_hook_plugin VALUES("4","10000","1","admin_init","AdminJournal");
INSERT INTO cmf_hook_plugin VALUES("5","10000","1","admin_login","FengiyLogin");



DROP TABLE cmf_member;

CREATE TABLE `cmf_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(200) DEFAULT NULL COMMENT '头像',
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `pass` varchar(100) DEFAULT NULL COMMENT '密码',
  `balance` decimal(11,2) DEFAULT '0.00' COMMENT '余额',
  `point` decimal(11,2) DEFAULT '0.00' COMMENT '积分',
  `ip` varchar(255) DEFAULT NULL COMMENT '登录ip地址',
  `login_time` bigint(20) DEFAULT NULL COMMENT '最后登录时间',
  `login_city` varchar(255) DEFAULT NULL COMMENT '登录城市',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `pid` int(11) DEFAULT NULL COMMENT '上级',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_member VALUES("1","CTRL","https://oss.ausite.cn/dz000/default/20230602/8fb025339dcafcb3e2f9e34f862e1976.png","1","1888","1","0.00","0.00","","1685676913","","1685676913","1740965414","0","1111","0");



DROP TABLE cmf_member_gzh;

CREATE TABLE `cmf_member_gzh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(80) DEFAULT NULL COMMENT 'openid',
  `unionid` varchar(255) DEFAULT NULL COMMENT 'unionId',
  `ext` text CHARACTER SET utf8 COMMENT '扩展信息',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号用户';




DROP TABLE cmf_option;

CREATE TABLE `cmf_option` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `autoload` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '是否自动加载;1:自动加载;0:不自动加载',
  `option_name` varchar(64) NOT NULL DEFAULT '' COMMENT '配置名',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `option_name` (`option_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='全站配置表';

INSERT INTO cmf_option VALUES("1","1","site_info","{\"site_name\":\"微巨宝定制后台模板\",\"site_seo_title\":\"微巨宝定制后台模板\",\"site_seo_keywords\":\"\",\"site_seo_description\":\"\"}");
INSERT INTO cmf_option VALUES("2","1","set_config","{\"app_name\":\"公众号\\/小程序模板\",\"app_logo\":\"kf222\\/default\\/20240426\\/53e5c8df35ec4817f5065b53da6ee458.jpg\",\"user_agreement\":\"&lt;p&gt;用户协议&lt;\\/p&gt;\",\"privacy_agreement\":\"&lt;p&gt;&lt;span style=&quot;color: rgba(0, 0, 0, 0.85); font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, &amp;quot;PingFang SC&amp;quot;, Tahoma, Arial, sans-serif; font-size: 14px; font-weight: 700; text-align: right; background-color: rgb(255, 255, 255);&quot;&gt;隐私协议&lt;\\/span&gt;&lt;\\/p&gt;\",\"group_id\":\"100\",\"app_logo_1\":\"https:\\/\\/oss.ausite.cn\\/dz000\\/default\\/20230217\\/2680011108c19b50228c124d86749b7d.jpg?watermark\",\"_plugin\":\"configs\",\"_controller\":\"admin_index\",\"_action\":\"details\",\"test\":\"的是范德萨范德萨\",\"domain_name\":\"https:\\/\\/lscs001.jscxkf.net\",\"s\":[\"sdfwe\",\"sfwaweew\"],\"f\":[\"fawefewfawefwe\"],\"debug_mode\":\"1\",\"app_expiration_time\":\"2042-02-28 00:00\",\"listorder\":{\"100\":\"1\",\"101\":\"2\",\"108\":\"100\"},\"label\":{\"101\":\"应用名称\"},\"name\":{\"101\":\"app_name\"},\"about\":{\"101\":\"\"},\"project_name\":\"公众号\\/小程序\",\"copyright\":\"技术支持：微巨宝科技有限公司\",\"local_domain_name\":\"http:\\/\\/lscs.ikun\",\"number_of_days_for_log_files\":\"\",\"log_file_days\":\"10\",\"list_order\":{\"100\":\"1\",\"101\":\"2\"},\"video\":\"dzkf00000000001\\/default\\/20240624\\/c2dcc94117717aaad3d7d9664c2affcb.mp4\",\"file2\":\"dzkf00000000001\\/default\\/20240624\\/2cec82e71890d9b59a689e8a869c544e.docx\",\"video2\":\"dzkf00000000001\\/default\\/20240624\\/ab75196b4f0f699eb563758d59e662ca.mp4\",\"file333\":\"dzkf00000000001\\/default\\/20240624\\/9fff193bb6acaead8c8523bea7a76ad6.pdf\",\"program_code\":\"dzkf00000000001\\/default\\/20241016\\/ae73672e549f1ef3ceba9fe1593e5d07.jpg\",\"program_information\":\"***小程序-旺旺名\",\"is_show\":\"1\",\"show\":{\"app_logo\":\"on\",\"app_name\":\"on\"},\"order_automatic_cancellation_time\":\"15\",\"order_auto_completion_time\":\"10\",\"tencent_map_key\":\"GGVBZ-DUV6J-N33FQ-FX3AE-HTJ56-N6FDP\",\"cescesges\":[\"2\",\"3\",\"4\"],\"testing_and_testing\":\"额外各位各位e4545\"}");
INSERT INTO cmf_option VALUES("3","1","storage","{\"storages\":{\"Oss\":{\"name\":\"阿里云OSS存储\",\"driver\":\"\\\\plugins\\\\oss\\\\lib\\\\Oss\"}},\"type\":\"Oss\"}");
INSERT INTO cmf_option VALUES("4","1","weipay","{\"wx_mp_app_id\":\"\",\"wx_mini_app_id\":\"\",\"wx_mp_app_secret\":\"\",\"wx_mini_app_secret\":\"\",\"wx_token\":\"\",\"wx_encodingaeskey\":\"\",\"wx_app_id\":\"\",\"wx_mch_id\":\"\",\"wx_v2_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_v3_mch_secret_key\":\"Qwertyuiopasdfghjklzxcvbnm123456\",\"wx_mch_secret_cert\":\"\",\"wx_mch_public_cert_path\":\"\",\"wx_notify_url\":\"\\/api\\/wxapp\\/notify\\/wxPayNotify\",\"ali_app_id\":\"\",\"ali_app_secret_cert\":\"\",\"ali_app_public_cert_path\":\"\",\"ali_alipay_public_cert_path\":\"\",\"ali_alipay_root_cert_path\":\"\",\"ali_notify_url\":\"\",\"ali_return_url\":\"\",\"wx_system_type\":\"wx_mini\"}");
INSERT INTO cmf_option VALUES("5","1","upload_setting","{\"max_files\":\"20\",\"chunk_size\":\"512\",\"file_types\":{\"image\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"jpg,jpeg,png,gif,bmp4,mp3\"},\"video\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp4,avi,wmv,rm,rmvb,mkv\"},\"audio\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"mp3,wma,wav\"},\"file\":{\"upload_max_filesize\":\"15360\",\"extensions\":\"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,pem\"}}}");



DROP TABLE cmf_plugin;

CREATE TABLE `cmf_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '插件类型;1:网站;8:微信',
  `has_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理,0:没有;1:有',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态;1:开启;0:禁用',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '插件安装时间',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件标识名,英文字母(惟一)',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件名称',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `hooks` varchar(255) NOT NULL DEFAULT '' COMMENT '实现的钩子;以“,”分隔',
  `author` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '插件作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '插件版本号',
  `description` varchar(255) NOT NULL COMMENT '插件描述',
  `config` text COMMENT '插件配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='插件表';

INSERT INTO cmf_plugin VALUES("1","1","1","1","1660558216","Weipay","APP信息&支付信息","","","wjb","","1.0.0","微信小程序&公众号&支付宝支付信息","[]");
INSERT INTO cmf_plugin VALUES("2","1","1","1","1660558220","Swagger","Swagger","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","1.0.0","Swagger","[]");
INSERT INTO cmf_plugin VALUES("4","1","1","1","1660723183","Configs","系统参数设置","","","lampzww","","1.0","config读取配置参数扩展","[]");
INSERT INTO cmf_plugin VALUES("6","1","0","1","1660723194","Oss","OSS上传","","","zsl","","1.0.0","OSS上传","{\"accessKey\":\"LTAI5t9uSAQt9GiYcZ7X34Xe\",\"secretKey\":\"4zgCseVv6ufMsAu2oP1BoK5SFoGOi3\",\"protocol\":\"https\",\"domain\":\"oss.ausite.cn\",\"bucket\":\"twjbdzoss\",\"style_separator\":\"?\",\"dir\":\"dzkf00000000001\"}");
INSERT INTO cmf_plugin VALUES("8","1","1","1","1660723805","Form","表单生成","http://demo.thinkcmf.com","","idcpj","http://www.thinkcmf.com","1.1","表单生成","{\"custom_config\":\"0\",\"text\":\"hello,ThinkCMF!\",\"password\":\"\",\"number\":\"1.0\",\"select\":\"1\",\"checkbox\":1,\"radio\":\"1\",\"radio2\":\"1\",\"textarea\":\"\\u8fd9\\u91cc\\u662f\\u4f60\\u8981\\u586b\\u5199\\u7684\\u5185\\u5bb9\",\"date\":\"2017-05-20\",\"datetime\":\"2017-05-20\",\"color\":\"#103633\",\"image\":\"\",\"file\":\"\",\"location\":\"\"}");
INSERT INTO cmf_plugin VALUES("9","1","1","1","1662171892","AdminJournal","操作日志","https://www.wzxaini9.cn/","","Powerless","https://www.wzxaini9.cn/","1.2.0","后台操作日志","[]");
INSERT INTO cmf_plugin VALUES("10","1","0","1","1670382358","FengiyLogin","微巨宝自定义登录页","","","Fengiy","","1.0","支持大背景/轮播图/Logo/名称自定义","{\"b_bg\":\"\",\"b_bg_illus\":\"\"}");
INSERT INTO cmf_plugin VALUES("11","1","1","1","1718330446","LoginTime","登陆状态时长控制","http://www.songzhenjiang.cn","","Tangchao","http://www.songzhenjiang.cn","1.0","登陆状态时长控制","[]");



DROP TABLE cmf_recycle_bin;

CREATE TABLE `cmf_recycle_bin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT '0' COMMENT '删除内容 id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `table_name` varchar(60) DEFAULT '' COMMENT '删除内容所在表名',
  `name` varchar(255) DEFAULT '' COMMENT '删除内容名称',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' 回收站';




DROP TABLE cmf_role;

CREATE TABLE `cmf_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父角色ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态;0:禁用;1:正常',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `list_order` float NOT NULL DEFAULT '0' COMMENT '排序',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

INSERT INTO cmf_role VALUES("1","0","1","1329633709","1329633709","0","超级管理员","拥有网站最高管理员权限！");
INSERT INTO cmf_role VALUES("2","0","1","1329633709","1329633709","0","普通管理员","权限由最高管理员分配！");
INSERT INTO cmf_role VALUES("3","0","1","0","0","0","测试管理员","测试");



DROP TABLE cmf_role_user;

CREATE TABLE `cmf_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '角色 id',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `role_id` (`role_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='用户角色对应表';

INSERT INTO cmf_role_user VALUES("12","2","2");
INSERT INTO cmf_role_user VALUES("15","2","5");



DROP TABLE cmf_route;

CREATE TABLE `cmf_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态;1:启用,0:不启用',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'URL规则类型;1:用户自定义;2:别名添加',
  `full_url` varchar(255) NOT NULL DEFAULT '' COMMENT '完整url',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '实际显示的url',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='url路由表';




DROP TABLE cmf_shop;

CREATE TABLE `cmf_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `class_id` int(11) DEFAULT NULL COMMENT '分类id',
  `shop_type` tinyint(4) DEFAULT NULL COMMENT '类型:1全屋整装,2装修建材,3智能电器,5家具软装 ',
  `name` varchar(50) DEFAULT NULL COMMENT '店铺名字',
  `logo_image` varchar(200) DEFAULT NULL COMMENT 'logo',
  `images` text COMMENT '轮播图',
  `introduce` varchar(255) DEFAULT NULL COMMENT '介绍',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `time` varchar(80) DEFAULT NULL COMMENT '营业时间',
  `address` varchar(300) DEFAULT NULL COMMENT '地址信息',
  `lng` varchar(30) DEFAULT NULL COMMENT '经度',
  `lat` varchar(30) DEFAULT NULL COMMENT '纬度',
  `lnglat` varchar(50) DEFAULT NULL COMMENT '经纬度',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(50) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(50) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(50) DEFAULT NULL COMMENT '区code',
  `list_order` int(11) DEFAULT '0' COMMENT '人气',
  `is_recommend` tinyint(2) DEFAULT '1' COMMENT '推荐:1是,2否',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='店铺管理';




DROP TABLE cmf_shop_address;

CREATE TABLE `cmf_shop_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `province_id` varchar(50) DEFAULT NULL COMMENT '省id',
  `city_id` varchar(50) DEFAULT NULL COMMENT '市id',
  `county_id` varchar(50) DEFAULT NULL COMMENT '区id',
  `province` varchar(50) DEFAULT NULL COMMENT '省name',
  `city` varchar(50) DEFAULT NULL COMMENT '市name',
  `county` varchar(50) DEFAULT NULL COMMENT '区name',
  `province_code` varchar(255) DEFAULT NULL COMMENT '省code',
  `city_code` varchar(255) DEFAULT NULL COMMENT '市code',
  `county_code` varchar(255) DEFAULT NULL COMMENT '区code',
  `address` varchar(120) DEFAULT NULL COMMENT '详细地址',
  `username` varchar(30) DEFAULT NULL COMMENT '名字',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `is_default` tinyint(2) DEFAULT '2' COMMENT '是否默认:1默认,2不默认',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1正常',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='地址管理';

INSERT INTO cmf_shop_address VALUES("1","1","","","","省","市","区","","","","地址","姓名","17633940000","1","1","1649127128","1649127128","0");



DROP TABLE cmf_shop_cart;

CREATE TABLE `cmf_shop_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `count` int(11) DEFAULT NULL COMMENT '下单数量',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格id',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku_name',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='购物车';




DROP TABLE cmf_shop_comment;

CREATE TABLE `cmf_shop_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `order_detail_id` int(11) DEFAULT NULL COMMENT '订单详情',
  `content` text COMMENT '评论内容',
  `images` text COMMENT '图片',
  `is_show` tinyint(2) DEFAULT '1' COMMENT '是否显示:1显示,2隐藏',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价';




DROP TABLE cmf_shop_coupon;

CREATE TABLE `cmf_shop_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) DEFAULT '1' COMMENT '优惠券类型:1时间段,2按分钟',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` float DEFAULT NULL COMMENT '满额',
  `amount` float DEFAULT NULL COMMENT '面额',
  `count` int(11) DEFAULT NULL COMMENT '数量',
  `select_count` int(11) DEFAULT '0' COMMENT '领取数量',
  `limit` int(11) DEFAULT '1' COMMENT '限领取数',
  `status` tinyint(4) DEFAULT '2' COMMENT '状态:1显示,2隐藏',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `content` text COMMENT '内容',
  `indate` varchar(50) DEFAULT '7' COMMENT '有效期',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='优惠券';




DROP TABLE cmf_shop_coupon_user;

CREATE TABLE `cmf_shop_coupon_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `verification_user_id` int(11) DEFAULT NULL COMMENT '核销人',
  `verification_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `coupon_id` int(11) NOT NULL COMMENT '优惠券id',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1正常',
  `used` tinyint(4) DEFAULT '1' COMMENT '状态:1未使用,2已使用,3已过期',
  `name` varchar(32) DEFAULT NULL COMMENT '优惠券名称',
  `full_amount` float DEFAULT '0' COMMENT '满n金额',
  `amount` float DEFAULT '0' COMMENT '金额',
  `start_time` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `end_time` bigint(20) DEFAULT NULL COMMENT '结束时间',
  `code` varchar(32) DEFAULT NULL COMMENT 'code码',
  `qr_image` varchar(100) DEFAULT NULL COMMENT '二维码',
  `order_num` varchar(32) DEFAULT NULL COMMENT '关联订单号',
  `is_send` tinyint(4) DEFAULT '1' COMMENT '是否发放:1赠送的',
  `type` tinyint(4) DEFAULT NULL COMMENT '时间类型:1时间段,2按分钟',
  `use_time` bigint(20) DEFAULT NULL COMMENT '使用时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '领取时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='优惠券领取记录';




DROP TABLE cmf_shop_goods;

CREATE TABLE `cmf_shop_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '商品类型:1抢购,2限购',
  `class_id` int(11) DEFAULT NULL COMMENT '分类',
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `goods_name` varchar(60) DEFAULT NULL COMMENT '商品名称',
  `image` varchar(255) DEFAULT NULL COMMENT '封面',
  `images` text COMMENT '图集',
  `content` text COMMENT '详情',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `status` tinyint(2) DEFAULT '1' COMMENT '是否展示:1展示,2隐藏',
  `sell_count` int(11) DEFAULT '0' COMMENT '售出数量',
  `stock` int(11) DEFAULT '0',
  `is_index` tinyint(2) DEFAULT '2' COMMENT '首页推荐:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  `line_price` decimal(10,2) DEFAULT NULL COMMENT '划线价',
  `quota` int(11) DEFAULT NULL COMMENT '限购数量',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='商品管理';




DROP TABLE cmf_shop_goods_class;

CREATE TABLE `cmf_shop_goods_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `is_index` tinyint(4) DEFAULT '2' COMMENT '首页推荐:1是,2否',
  `list_order` int(11) DEFAULT '1000',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='分类管理';




DROP TABLE cmf_shop_goods_sku;

CREATE TABLE `cmf_shop_goods_sku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL COMMENT '商品id',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `sku_name` varchar(30) DEFAULT NULL COMMENT 'sku',
  `code` varchar(255) DEFAULT NULL COMMENT '编码',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `price` decimal(8,2) DEFAULT '0.00' COMMENT '价格',
  `line_price` decimal(10,2) DEFAULT NULL COMMENT '划线价',
  `status` tinyint(4) DEFAULT '1' COMMENT '0不显示 1正常',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL,
  `delete_time` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1039 DEFAULT CHARSET=utf8mb4 COMMENT='商品sku';




DROP TABLE cmf_shop_order;

CREATE TABLE `cmf_shop_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '订单类型:1抢购,2限购',
  `shop_id` int(11) DEFAULT NULL COMMENT '门店id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `status` tinyint(8) DEFAULT '1' COMMENT '状态:1待付款,2已付款,4已发货,6已收货,8已完成,10已取消,12退款申请,14退款不通过,16退款通过',
  `order_num` varchar(255) DEFAULT NULL COMMENT '订单号',
  `pay_num` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0' COMMENT '地址id',
  `openid` varchar(255) DEFAULT NULL COMMENT '身份标识 openid',
  `username` varchar(255) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `county` varchar(255) DEFAULT NULL COMMENT '区',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `amount` decimal(8,2) DEFAULT NULL COMMENT '实际支付金额',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '余额支付金额',
  `goods_amount` decimal(8,2) DEFAULT NULL COMMENT '商品金额',
  `total_amount` decimal(8,2) DEFAULT NULL COMMENT '原始 总金额 = 商品金额+优惠金额+运费金额',
  `coupon_id` int(11) DEFAULT '0' COMMENT '优惠券id',
  `coupon_amount` decimal(8,2) DEFAULT '0.00' COMMENT '优惠金额',
  `freight_amount` decimal(10,2) DEFAULT NULL COMMENT '运费',
  `pay_type` tinyint(4) DEFAULT '1' COMMENT '支付类型:1微信支付,2余额支付,3积分支付,4支付宝支付,5组合支付(微信+余额)',
  `remark` varchar(300) DEFAULT '' COMMENT '备注',
  `cav_qr_code` varchar(200) DEFAULT NULL COMMENT '核销二维码',
  `cav_code` varchar(40) DEFAULT NULL COMMENT '核销码',
  `exp_num` varchar(60) DEFAULT NULL COMMENT '快递单号',
  `exp_name` varchar(60) DEFAULT NULL COMMENT '快递名称',
  `cancel_time` bigint(20) DEFAULT NULL COMMENT '取消时间',
  `pay_time` bigint(20) DEFAULT '0' COMMENT '支付时间',
  `send_time` bigint(20) DEFAULT NULL COMMENT '发货时间',
  `take_delivery_time` bigint(20) DEFAULT NULL COMMENT '收货时间',
  `accomplish_time` bigint(20) DEFAULT NULL COMMENT '完成时间',
  `auto_cancel_time` bigint(20) DEFAULT NULL COMMENT '自动取消时间',
  `auto_accomplish_time` bigint(20) DEFAULT NULL COMMENT '自动完成时间',
  `auto_verification_time` bigint(20) DEFAULT NULL COMMENT '自动核销时间',
  `catr_ids` varchar(255) DEFAULT NULL COMMENT '购物车下单',
  `goods_name` varchar(2555) DEFAULT NULL COMMENT '商品名字',
  `admin_remark` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  `create_time` bigint(20) DEFAULT NULL COMMENT '下单时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dindex` (`user_id`,`order_num`(191)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COMMENT='订单管理';

INSERT INTO cmf_shop_order VALUES("1","1","0","1","1","2023112146145782","","0","","测试","18582300163","河南省","郑州市","金水区","测试地址","0.01","0.00","0.00","0.00","0","0.00","0.00","1","用户备注测试","111","11","","","0","0","0","0","0","0","0","0","","测试商品","测试测试色差","1696491848","1696494111","0");
INSERT INTO cmf_shop_order VALUES("2","1","118","254","43","HOZ6Q1IKqX","","282","qMDEiapyR2","Saito Rena","28-867-2789","U6HLoMFF2j","Chengdu","N4uuatxHWY","602 NO.6, YuShuang Road, ChengHua Distric","348.43","0.00","124.97","250.83","216","71.80","95.02","11","Zj6KFB2Coq","GR4VaLRlm6","iXTznXo4DK","o37mpoydwe","Saito Rena","888","752","327","83","139","810","234","102","l5IpfIi3RL","Saito Rena","M1ymaEG2KT","504","76","0");
INSERT INTO cmf_shop_order VALUES("3","18","925","922","43","7hMtUTSgIt","","399","QyPPBDUP2Y","Yuen Kar Yan","80-7557-2364","ze8JQkN4uw","Sapporo","nd2MyuJu4x","13-3-17 Toyohira 3 Jo, Toyohira Ward","684.86","0.00","347.92","20.29","283","589.16","24.06","3","L8bhB7ODoW","sKmDQnxJXn","8LFaqcBeer","KAsEfI8CEu","Yuen Kar Yan","5","732","368","175","907","294","453","548","XjZiFCmaHR","Yuen Kar Yan","w61CRYevvr","36","749","0");
INSERT INTO cmf_shop_order VALUES("4","41","52","355","106","bC2EC5jOn5","","303","XUr4gxnb6c","Maruyama Rena","80-5800-9540","Ld1HAmfMx5","Nara","Xy142j0H2P","3-9-1 Gakuenminami","543.92","0.00","3.20","994.80","492","170.31","417.24","112","TyOqsqh98E","X2qHSaXvvw","TQQpZNihsl","tD1R3q6Z5Z","Maruyama Rena","960","956","881","789","397","228","927","209","GznnCP8di7","Maruyama Rena","moEFe2dbnA","54","955","0");
INSERT INTO cmf_shop_order VALUES("5","126","294","226","53","3rjUuA4xTz","","89","P7BZOjYmT9","Jiang Yuning","838-163-7533","Ih9U2vg1Wv","Albany","R9KvYuTokZ","753 Central Avenue","85.52","0.00","787.73","989.94","709","955.25","800.29","89","6DdIjbze7X","GmUf33qU1l","h47VgVWpPi","FeofYiodrn","Jiang Yuning","124","496","947","541","183","771","605","417","XfKn5fEdfI","Jiang Yuning","zXs6Np3JNo","638","541","0");
INSERT INTO cmf_shop_order VALUES("6","18","270","208","106","sqxY5V6Boq","","570","AE9Q2DEodc","Inoue Yota","(151) 989 1247","xdRSSLADt0","Liverpool","ty89jZli0X","667 Earle Rd","207.90","0.00","395.79","891.69","312","146.78","732.45","8","T5B9Y8LeEN","zPQhDPTiW9","Ifeh54QuNF","LSgFC6MwHg","Inoue Yota","528","689","567","607","198","674","857","800","rJPv29g6nt","Inoue Yota","UprVjfrk7b","208","791","0");
INSERT INTO cmf_shop_order VALUES("7","121","680","460","66","inGIBHQJNs","","565","mtPLAE1SJO","Sato Ryota","28-2360-0898","oA74R53nCB","Chengdu","MylCEBh6DA","No.24, Dongsan Road, Erxianqiao, Chenghua District","517.01","0.00","232.65","834.84","819","360.13","897.64","112","Ple3Ps9sfY","ElknIszhkW","6G6JcbObo3","FneNPf7h8g","Sato Ryota","580","146","594","957","679","204","790","166","dM0DimhyYM","Sato Ryota","34a4eM7unE","507","385","0");
INSERT INTO cmf_shop_order VALUES("8","33","131","902","77","E17lXUY2jX","","720","afEBnd35bx","Qin Yunxi","7037 015849","A95dInVBpM","Liverpool","joUsiydH29","623 Hanover St","261.94","0.00","722.75","436.84","153","926.21","447.72","79","m9ttTWyKAi","xbmy4psmro","BoLYvFjMEi","Fp2XJsJXbo","Qin Yunxi","417","574","179","939","275","955","611","220","EJNEx8E9cF","Qin Yunxi","kpTyMNQIGW","706","832","0");
INSERT INTO cmf_shop_order VALUES("9","17","524","295","36","Ivfu7TTFOm","","395","tSmFKGiUKW","Nakano Ryota","(20) 7385 5586","UAkzj6bF6V","London","ZVvhpA8J8j","221 Pollen Street","665.87","0.00","65.15","216.46","358","463.57","111.15","26","w5l7Hp09fG","oTJErCS2yW","LplxPF14QD","h8QozyL7wj","Nakano Ryota","606","988","856","735","609","832","15","56","sK3Jk9SGkZ","Nakano Ryota","26JPtkrXQs","924","70","0");
INSERT INTO cmf_shop_order VALUES("10","101","664","318","54","qZAaPOGt4c","","130","gFp3QHwoXe","Cheng Ka Fai","(1223) 28 1642","0cGk7qWltR","Cambridge","0ID9SC9ag1","546 Silver St, Newnham","823.88","0.00","836.88","427.90","770","113.38","586.61","70","8Nt8357oHf","RWOUfXUf7p","zA5CETPx4K","mHO2jogygm","Cheng Ka Fai","114","419","130","492","924","649","563","156","WigotguCIT","Cheng Ka Fai","6rKZc5VriA","469","299","0");
INSERT INTO cmf_shop_order VALUES("11","76","623","536","11","zzo4y7en9A","","118","d9Y3gBQb19","Yung Fu Shing","755-335-1286","dcJM3uxqHg","Shenzhen","ftLyaj3Yn8","118 W Ring Rd, Buji Town, Longgang","799.24","0.00","788.94","984.96","31","395.79","190.22","90","hmIULZnqLR","TWIkKNlS2z","eLESq2DSmU","JXe1pvE7cj","Yung Fu Shing","579","811","320","459","686","391","742","195","y4bK2MAgN6","Yung Fu Shing","CMjizuH6iP","900","366","0");
INSERT INTO cmf_shop_order VALUES("12","73","824","970","35","AeAg1sLwE9","","331","8s5wzbYOwF","Fujita Yuna","11-690-9309","uRQpjQsjkm","Sapporo","xmZeWXajTg","6-1-3, Miyanomori 4 Jō, Chuo Ward","255.57","0.00","875.98","501.30","793","575.99","830.15","62","R16nQRS23y","icPkOIeue3","HKAe03oZrO","gCbQtpbxbO","Fujita Yuna","18","532","371","428","815","663","694","225","9lrKzetllk","Fujita Yuna","2PazC6oXrq","479","582","0");
INSERT INTO cmf_shop_order VALUES("13","52","566","535","22","Aikw2H9PIV","","941","DfojK8MzEz","Zhou Zhiyuan","151-1500-8510","LSsYhMN1gB","Guangzhou","MQsjKyh7hV","675 Jiangnan West Road, Haizhu District","438.31","0.00","525.85","276.83","656","783.70","890.78","4","kbjT9aErI2","QMxjuuwFO1","91LWU0huI1","QYxZZ2F2ki","Zhou Zhiyuan","871","690","907","897","690","382","38","110","2qUF7qZ8dH","Zhou Zhiyuan","QhQ2U6IENN","869","531","0");
INSERT INTO cmf_shop_order VALUES("14","68","599","572","108","XaqcQecmn6","","643","2qSUkQt6q5","Cynthia Ortiz","(151) 326 7624","wUtPOwV6wj","Liverpool","RNk1dwCNoB","765 39 William IV St, Charing Cross","503.70","0.00","544.56","758.37","225","240.20","285.56","25","vBA4whV2L2","9Drxqfidk9","5L6O1rbZgk","tKwzFGtRoG","Cynthia Ortiz","796","975","1000","887","94","42","595","233","J8uoEcdOWC","Cynthia Ortiz","mzTHjh2XcP","527","554","0");
INSERT INTO cmf_shop_order VALUES("15","63","59","851","109","GF7bDL7OWi","","360","x5P133kCo8","Nakamori Momoe","5625 032174","xdzkOdMVSD","Birmingham","cyjyTnQMbE","597 Stephenson Street","521.91","0.00","758.60","857.95","854","251.37","437.03","120","5Go16MLIAC","FTio7nHZj7","hrZtifRv2P","2AYUPZ6lGm","Nakamori Momoe","815","975","894","820","265","675","515","19","8mcbdTElqe","Nakamori Momoe","AazyJ2iybu","11","561","0");
INSERT INTO cmf_shop_order VALUES("16","74","28","578","37","qvIF6zuKoo","","411","g1WqKpooTQ","Wei Jialun","(1223) 79 2416","njkgqervy7","Cambridge","TFemVDLAOq","469 Whitehouse Lane, Huntingdon Rd","712.06","0.00","991.75","745.79","929","903.09","92.07","40","absUvr4cMn","ffZVerRQcV","fWqL48I6bt","UVgBpmyU2r","Wei Jialun","428","604","372","720","30","921","128","612","5cXkKgdn4r","Wei Jialun","jbiTneddFP","237","359","0");
INSERT INTO cmf_shop_order VALUES("17","104","427","234","97","lECdojaQmf","","285","mHNgLjQUq1","Mike Jimenez","838-968-8879","3BQLkPCive","Albany","ksdTbnH4xQ","771 Broadway","354.91","0.00","850.31","600.54","829","454.57","560.38","97","HmObMXmTv7","IXkQshZKfC","T7R12ne7O7","Afzey7c2v7","Mike Jimenez","363","364","873","226","47","104","212","777","EwfGiWWuaX","Mike Jimenez","di39P7IgT4","25","331","0");
INSERT INTO cmf_shop_order VALUES("18","70","993","941","10","vmegBQtbaC","","493","lzvyLfngSG","Florence Wright","(1223) 28 6399","gE5o0VJTcR","Cambridge","xOpLDRMsAb","555 The Pavilion, Lammas Field, Driftway","429.10","0.00","991.48","201.99","494","48.41","250.68","53","5Ol17mtz3W","gVLBKra29b","6jsXngJjPj","3TBRNlIewk","Florence Wright","523","488","494","621","106","479","331","786","iFrOWGDvGK","Florence Wright","yQyh46SfJT","754","818","0");
INSERT INTO cmf_shop_order VALUES("19","14","806","929","14","WQAlKd0oTM","","660","N2rFaiyrjh","Fung Ming Sze","312-334-7028","7arDTci2SE","Chicago","NYM25C6Llm","156 Pedway","221.42","0.00","70.28","703.93","611","385.43","277.16","37","joZeEFLYAJ","U1AiA042a9","dxCkSBy5Xe","cjx6bqVWTu","Fung Ming Sze","779","609","547","566","843","674","117","301","6qFSCKoiXW","Fung Ming Sze","udt4DCcBBl","750","169","0");
INSERT INTO cmf_shop_order VALUES("20","127","916","903","105","az9CfHmoed","","84","9sjw6f1sDV","Roy Vasquez","718-020-1626","vqJE9SGhEh","Brooklyn","wFNYZmlmq8","498 Nostrand Ave","877.58","0.00","242.44","877.22","268","353.43","258.52","7","PABKp4SeFX","vE0nDCnDwg","1tKaBbuAiE","ErpDjqtVgI","Roy Vasquez","122","109","531","959","839","870","147","945","DhxUiW7ER3","Roy Vasquez","BeKk5NKFcs","404","84","0");
INSERT INTO cmf_shop_order VALUES("21","37","640","838","115","4BJaorwPe5","","890","IhBtONR7Uv","Ng Wing Sze","5708 050735","MWpkLRnInh","Birmingham","DSdhgQKzWB","123 Stephenson Street","921.40","0.00","29.23","678.51","878","585.88","438.60","53","EcTayHRxyc","GJpi1GyDEg","oOun0qRdpq","4NI3tr0P0f","Ng Wing Sze","546","743","498","200","427","439","739","464","bsjV0IosgH","Ng Wing Sze","PLJ4ftfIHu","300","872","0");
INSERT INTO cmf_shop_order VALUES("22","88","705","58","113","U5HtlJ46YP","","186","AUjP9KbzPH","Sato Aoi","80-0916-3514","4G3umacZUQ","Nagoya","MxQp3qXixi","16 3-803 Kusunokiajima, Kita Ward","915.33","0.00","430.00","778.95","756","490.96","524.96","101","suqkU6X672","grLpEuuOS9","Hxy6WiUtZp","vQZzRm9bdd","Sato Aoi","962","774","464","357","83","620","645","124","uw0xfHMfCj","Sato Aoi","3mVLuUvyUt","529","404","0");
INSERT INTO cmf_shop_order VALUES("23","26","79","737","58","ScPI9SP9LP","","248","og5dMv7cGY","Kam Chun Yu","718-231-2349","X3n7XZBOj6","Brooklyn","JDRzy44nYI","777 Columbia St","385.59","0.00","182.20","801.75","988","972.14","968.63","118","OstQ5nSPJn","Qa8RFJszEJ","FTVVTaHgHQ","MAveFO0LYx","Kam Chun Yu","337","435","170","208","906","692","775","4","zxvtjskYjW","Kam Chun Yu","RzERyyLCsr","881","42","0");
INSERT INTO cmf_shop_order VALUES("24","9","781","593","30","ped20747Mv","","714","WaMdjlW1AN","Janet Roberts","130-9598-7515","qFo9zp3QIT","Dongguan","JFLb2bo29l","907 Huanqu South Street 2nd Alley","472.83","0.00","841.42","704.70","451","333.46","900.82","119","UttupeyIb6","9q74sJVDtS","ez3SyHwgRM","n9Np8XfHTT","Janet Roberts","302","476","687","646","573","847","248","987","cVLDgBWmI9","Janet Roberts","C9AHYtJzjE","306","976","0");
INSERT INTO cmf_shop_order VALUES("25","18","150","330","111","GX3h09PdAo","","611","yXDX9RTflq","Kathryn Patterson","10-9943-4613","2YKQw5vCCe","Beijing","wrdbsV1YTx","957 68 Qinghe Middle St, Haidian District","294.21","0.00","238.44","275.70","214","458.75","462.71","36","bbevyikEQN","nP6YnR9fWk","uHK6zSaARc","kCDbnWHwaO","Kathryn Patterson","131","973","51","691","345","21","473","799","45CfohNBDy","Kathryn Patterson","yDHeHXOWna","729","856","0");
INSERT INTO cmf_shop_order VALUES("26","58","323","441","89","odUsbbPYgY","","903","kgEgJAPc2i","Wei Zhiyuan","838-243-5168","Kqgfol5sUF","Albany","G2NbvuEfBf","948 Lark Street","951.78","0.00","136.04","447.10","421","989.58","878.10","46","ZkU6a5ZrYY","7PYQOP5JW1","rYZ0TELIyk","WA1ytbw2ec","Wei Zhiyuan","651","123","518","679","995","506","755","836","BnGXFvET19","Wei Zhiyuan","TkxlNNSSDR","26","109","0");
INSERT INTO cmf_shop_order VALUES("27","38","564","402","97","cM2VdmkV6A","","525","QoWIUx4VGm","Rhonda Perry","838-845-2964","MWui18BnHp","Albany","rdlS3L97fg","647 Broadway","456.21","0.00","917.06","768.16","354","691.66","13.29","80","xYR473l5jM","xltJG8aRa5","p54zukc0IY","hnqfCp2eLu","Rhonda Perry","313","388","319","631","535","682","936","291","9idoAq0Y2r","Rhonda Perry","MpECeUW5n8","975","795","0");
INSERT INTO cmf_shop_order VALUES("28","15","796","833","68","KC6nssWxfi","","250","i2l7W8Z1gu","Kong Ching Wan","718-530-7514","ZGLZ2Z7XFd","Brooklyn","7JikPeJ8ho","56 Columbia St","421.75","0.00","238.03","550.42","956","250.44","126.36","40","PnnJxO9v43","jTNJlAbVhV","14gFMwziv9","OxzhZwJSkp","Kong Ching Wan","99","626","562","20","371","651","957","745","h9TNk44Voy","Kong Ching Wan","LKiKfXOCHY","90","804","0");
INSERT INTO cmf_shop_order VALUES("29","105","723","250","21","qNxxFLUFrT","","336","MoFfg8OJoA","Kwok Chun Yu","70-3702-4089","UPSKPLMZPK","Nagoya","SdKf1Zm6zv","3-19-18 Shimizu, Kita Ward","483.33","0.00","10.08","696.61","313","982.62","450.15","86","6yXXyoRrek","zImja5VrDV","o4wUtEHLOJ","SL3VvzzOnt","Kwok Chun Yu","71","238","991","261","438","323","65","437","Txdj4nQzyH","Kwok Chun Yu","GE1obyKM0D","608","863","0");
INSERT INTO cmf_shop_order VALUES("30","26","897","135","90","7LaG2533EY","","529","RBcwnSgyKt","Jiang Xiuying","755-0334-9735","n90Qd2BGyj","Shenzhen","IwyenBI1iG","853 W Ring Rd, Buji Town, Longgang","330.69","0.00","866.60","642.53","204","304.12","369.13","49","N1jQw8qtqo","8lcrT2cDfd","uNoSxqTJO0","r6Sn2fL83Q","Jiang Xiuying","191","984","220","892","494","179","822","425","QV6iCrahR6","Jiang Xiuying","sEbWB1Wl2o","473","125","0");
INSERT INTO cmf_shop_order VALUES("31","39","137","434","74","XV2pmPIxhb","","957","EQgHLV1ZvX","Tse Chung Yin","20-679-5143","KuMxntAGws","Guangzhou","Q80Sp2wcKA","785 Tianhe Road, Tianhe District","382.33","0.00","156.01","501.14","151","510.91","797.68","38","MrgXblhl00","vh4udlK9JI","6zfeStQ4WX","OC79YeBhBb","Tse Chung Yin","553","695","378","666","546","942","665","36","mxQAzVY2Rq","Tse Chung Yin","PrjSGfdmSm","952","589","0");
INSERT INTO cmf_shop_order VALUES("32","91","837","687","44","AoTGl8PzEL","","348","CGajBDGXZp","Allen Wells","(1223) 50 0270","es4ja4vY7Z","Cambridge","XtOscqJpjZ","696 Whitehouse Lane, Huntingdon Rd","856.93","0.00","982.22","736.92","70","925.87","252.22","12","s97y1bBT5i","1BJD5CPorA","uhnegC50G1","r94mhPB9gT","Allen Wells","866","902","181","564","377","197","504","511","peu35v6XZb","Allen Wells","kWIWRQfvz4","930","911","0");
INSERT INTO cmf_shop_order VALUES("33","127","689","179","68","d2sLNeEyM4","","298","KDH2Tm40BQ","Cheng Wing Fat","20-6696-2809","kbYX4RBMKY","Guangzhou","JfbtVPaFcL","371 Tianhe Road, Tianhe District","488.49","0.00","449.31","3.53","368","468.31","507.51","103","tWOSVofybx","WUYvvPjM0k","S0bslr0mAX","ygiD5r8FCN","Cheng Wing Fat","289","156","232","6","534","460","760","740","qlGnPdm0dq","Cheng Wing Fat","lj3zlIWTcF","329","984","0");
INSERT INTO cmf_shop_order VALUES("34","97","195","129","9","y9iZH6pS8f","","293","Mr3xy1tseY","Zou Yuning","769-905-3866","r1L3w9CBl6","Dongguan","viXpHXTHnr","714 Huanqu South Street 2nd Alley","499.50","0.00","840.15","445.61","461","809.07","329.06","114","bfG0PkLh3q","EhPXGcJVvG","ZAwWkGY4uN","9kgLFFL4DE","Zou Yuning","234","91","699","494","378","475","942","83","kLyeZGwpE1","Zou Yuning","5Jg1WHiYhl","978","883","0");
INSERT INTO cmf_shop_order VALUES("35","68","353","227","55","tbCDJN1siC","","811","ojuqjAt30x","Liao Wing Suen","755-411-4073","Vl08EFpf5U","Shenzhen","LG7X7qGa4a","41 Xue Yuan Yi Xiang, Longgang","310.59","0.00","576.76","125.09","669","302.81","115.10","40","A2DDgxTV6h","svRwMimX39","89ktpsTBLb","YSGyLQOQWE","Liao Wing Suen","920","737","382","408","73","817","437","717","zAqEID5Yr9","Liao Wing Suen","V4SmPDfaZH","699","163","0");
INSERT INTO cmf_shop_order VALUES("36","45","234","23","31","C4sRx122ED","","695","edeFbjx6NT","Lau Wai Han","160-4035-5762","iJmXp0XGu9","Shenzhen","stDJEBX6aT","668 Qingshuihe 1st Rd, Luohu District","535.05","0.00","91.31","690.58","151","550.68","73.28","57","BZinK7m04l","s4Lzt0lM53","8qnuA5Hhsg","mIE9OhWzzS","Lau Wai Han","578","737","53","345","206","930","556","74","8sjRYe7tPt","Lau Wai Han","VCHjkrn1Ql","311","574","0");
INSERT INTO cmf_shop_order VALUES("37","92","377","152","11","oRuaBqmTWe","","634","rF28cOjwim","Wei Rui","20-2611-0062","e5RLgAnntc","Guangzhou","qbDg3v6TzT","822 Xiaoping E Rd, Baiyun ","763.21","0.00","808.39","106.16","524","624.15","31.13","50","EC6Ubbwhw3","0n82fsdt8m","RYzqEyKIvJ","9uIhhJECLS","Wei Rui","99","332","349","950","836","533","266","112","0hzsIukPxF","Wei Rui","QEPOTZZB9J","734","397","0");
INSERT INTO cmf_shop_order VALUES("38","93","816","75","21","4b5Q4m083W","","618","gMuyLuS4Bg","Hasegawa Akina","80-0042-5543","8C31AxPgic","Nagoya","TZbU5GelYw","17 1-1715 Sekohigashi, Moriyama Ward","998.20","0.00","662.58","611.45","173","733.08","739.41","37","c4NaNQafcT","CJO7NTqVSB","p5prEoPAms","dswnvACabo","Hasegawa Akina","853","195","693","348","406","210","65","695","uPHHfS38Gg","Hasegawa Akina","bUU54b9DWs","513","725","0");
INSERT INTO cmf_shop_order VALUES("39","31","622","506","17","eZ9cyKSDCc","","743","G0yYqPLM4m","Morita Airi","80-5489-6218","PrXPnnKXoo","Osaka","jytCeOaioW","3-27-5 Higashitanabe, Higashisumiyoshi Ward","41.93","0.00","579.71","241.81","744","856.76","382.90","123","pRW8rzaTFE","sHkeZkg8pb","L4GPHfxDN1","ytMkd7WljI","Morita Airi","958","352","808","658","431","750","422","285","SbOhbRqA41","Morita Airi","YPU7vfkU3M","890","89","0");
INSERT INTO cmf_shop_order VALUES("40","67","23","530","83","QYB5oy4CMt","","752","PxEr4pCfn8","Matsuda Momoka","755-259-8708","nml28iVL4G","Shenzhen","AO3y6QEgg9","675 Qingshuihe 1st Rd, Luohu District","82.09","0.00","482.79","504.66","472","66.93","582.23","59","7jcU5Y4JqK","BXeHkkIyzt","QCZF0RiDH7","2GjqNtmgCq","Matsuda Momoka","403","146","903","764","430","152","415","356","fPCbm2fvNZ","Matsuda Momoka","pUeE4iTFuz","501","195","0");
INSERT INTO cmf_shop_order VALUES("41","86","647","676","6","HCI7wA25b6","","952","oWUPGfyHX3","Jiang Ziyi","3-7421-7422","wcUGIKdHl5","Tokyo","elZlvlshoB","3-15-6 Ginza, Chuo-ku","264.05","0.00","508.50","461.19","699","133.22","950.13","19","suZtCtNIsU","GtDCfdltPO","c0pczBhfPP","FWGeAl8kaS","Jiang Ziyi","186","62","696","194","599","942","825","831","ruFmlDT394","Jiang Ziyi","gjHYCQrdRY","863","666","0");
INSERT INTO cmf_shop_order VALUES("42","13","961","501","73","rAVS4fngnt","","26","XON9yDvzjN","Tina Wilson","755-0333-6696","fXzFEqimul","Shenzhen","zLxz5aLAaY","114 Jingtian East 1st St, Futian District","286.62","0.00","420.51","54.24","547","681.47","946.14","36","JUY3ufrAk3","37RYYPT44H","4qMMfTRr9O","9tIf3Dl8FL","Tina Wilson","879","14","282","701","32","520","671","581","nhk8UUJc0c","Tina Wilson","9POQjENxTa","966","679","0");
INSERT INTO cmf_shop_order VALUES("43","62","144","135","96","EztcgbpcoV","","730","9yRdCpgRFh","Clifford Medina","172-5184-0223","8QEhR4SyC5","Shanghai","oahu5EjZr3","241 Hongqiao Rd., Xu Hui District","995.97","0.00","60.72","756.99","829","695.24","577.51","96","MtXZf96n2z","bjo3YfqOCJ","FBSvSfzVUK","6W1G3zsRN5","Clifford Medina","476","26","323","783","681","419","686","110","6lIoO5eXcC","Clifford Medina","LagBZOUw7x","363","438","0");
INSERT INTO cmf_shop_order VALUES("44","17","53","451","65","IVzahrsDIQ","","664","FHxV4ODQuR","Harry Ramirez","5017 992248","hxLQAgQ8lK","Birmingham","yBpiTNnZME","745 New Street","677.22","0.00","424.47","554.35","275","280.56","760.86","80","FMnHbyakUi","uGfw7Y7mYW","dZq22MWdj4","xUDQlFQDuX","Harry Ramirez","911","601","432","63","989","134","912","686","Rc7DmgvN5E","Harry Ramirez","MRZw4R4B84","537","191","0");
INSERT INTO cmf_shop_order VALUES("45","40","331","2","16","mIfjHDZuIB","","745","z3I8ertn36","Wang Xiaoming","21-931-0731","xi78SitgUm","Shanghai","0vN8U84InV","804 Jianxiang Rd, Pudong","234.54","0.00","960.99","897.24","621","564.32","862.40","8","Ik13x7yal7","gKY0mZE5ff","qYScneJQ0h","4CMpOro1LC","Wang Xiaoming","787","243","700","819","882","957","821","498","O3VCeBTzjl","Wang Xiaoming","eylzYxY17k","550","524","0");
INSERT INTO cmf_shop_order VALUES("46","65","561","695","73","kIpqAKJlK0","","234","H9AEkF1wwH","Yue Ka Ming","3-3745-5708","IlvVoU29RB","Tokyo","XaKopViuFg","2-3-12 Yoyogi, Shibuya-ku","861.12","0.00","328.84","932.69","837","171.22","219.41","60","JQZy6CXNIP","UlDGRUo3Hq","3U4Kt9uPDT","SECvJOEdpN","Yue Ka Ming","444","675","991","429","725","422","133","435","FnF1ZxDrCh","Yue Ka Ming","sYiUnFiIcq","736","768","0");
INSERT INTO cmf_shop_order VALUES("47","124","864","411","115","1fdf4TuvT9","","345","1E1uA5b2jZ","Koo Kwok Wing","(1223) 38 7303","OxJikgvior","Cambridge","L4VP548cV1","629 Whitehouse Lane, Huntingdon Rd","7.83","0.00","329.73","719.72","536","639.33","696.40","31","iwlIvzMUt3","36Cww4VJUF","tivIOavgfl","ymvtS9057u","Koo Kwok Wing","965","628","263","525","300","777","604","974","uSYSynfWjc","Koo Kwok Wing","9nk53GLQsu","844","987","0");
INSERT INTO cmf_shop_order VALUES("48","17","420","482","41","iwbOEactSn","","415","oULDaUWoFa","Wada Hikaru","11-236-2447","NS9eS7RgEX","Sapporo","mIiULk3jQU","13-3-1 Toyohira 3 Jo, Toyohira Ward","292.08","0.00","195.53","215.39","545","458.20","436.04","99","Ism64Wr5wP","Kz11nmUrvS","vKk5H41Yi2","dvGDlpL8GJ","Wada Hikaru","164","989","984","688","435","107","764","244","xyGJyjpl6w","Wada Hikaru","payhUvQnyX","212","687","0");
INSERT INTO cmf_shop_order VALUES("49","104","70","646","87","4GjYUWxMZ5","","116","Cp3RwboofR","Deng Yunxi","179-4330-9670","lIbdovvdYk","Guangzhou","tmBUvYJF9u","504 Jiangnan West Road, Haizhu District","868.74","0.00","82.55","6.11","857","380.55","603.40","7","NB6JbCWrxP","M1ELNf8vD1","LVQZOJVt9T","jXBTqBiG2x","Deng Yunxi","676","214","305","672","523","969","729","331","quLCD9DaI9","Deng Yunxi","epvQ5UIsOm","296","178","0");
INSERT INTO cmf_shop_order VALUES("50","127","748","727","58","Exdib6UIwm","","565","MVXqrAZtru","Julie Sanders","52-401-1381","uf2IPf0XS2","Nagoya","I8GHkfHFFU","11 3-803 Kusunokiajima, Kita Ward","90.49","0.00","224.11","865.66","911","921.09","539.27","4","aWpiUwNHUY","IQqEOKKU41","49N588qakB","wcbbQcQH8p","Julie Sanders","766","205","757","286","403","476","358","685","MIa6Vi5qqa","Julie Sanders","frWoLUXuKL","877","250","0");
INSERT INTO cmf_shop_order VALUES("51","36","135","508","93","zGgtgigHIx","","217","wJwetGdx0b","Eugene Jones","718-725-6469","0NuMCSPg17","Brooklyn","5LlXGLUnri","241 1st Ave","663.30","0.00","782.40","634.49","777","511.01","376.79","82","bcicsGZRlp","XXIojjzInx","gLz3oantzE","yJ5IHnCqd0","Eugene Jones","78","352","364","816","4","123","909","287","nAbNco7S4l","Eugene Jones","FPZjj2Lh0C","481","991","0");
INSERT INTO cmf_shop_order VALUES("52","112","896","12","125","5s0dn0iSbU","","426","3azm4isnNg","Jeffrey Martinez","168-2594-9912","oQS3a6aZzr","Beijing","lhHxm9QO9m","898 FuXingMenNei Street, XiCheng District","274.52","0.00","59.36","830.05","79","797.93","614.42","62","ClugsOUs3r","H0bLLN3c3n","f5gg0lhW6W","LkbbbB58zC","Jeffrey Martinez","350","673","916","354","437","527","538","480","WQhj2S8rtv","Jeffrey Martinez","oHkoYMk9sf","712","556","0");
INSERT INTO cmf_shop_order VALUES("53","118","929","601","2","WG6DuLGMJO","","764","Bg6X1jrPJk","Carolyn Howard","74-564-2768","au9JhNFvjb","Nara","vvHm0yawPu","1-7-2 Saidaiji Akodacho","825.24","0.00","830.98","775.54","425","198.59","180.59","61","pa2aW9dTWL","c71KJRJRkP","5cVi7eVhUF","StOAPvC41M","Carolyn Howard","662","380","227","962","61","103","798","859","kHjpRuCELS","Carolyn Howard","9fonVZoefc888","960","1740392309","0");
INSERT INTO cmf_shop_order VALUES("54","109","500","748","20","6nFLGwm0d9","","270","jK2MeSnaiq","Zhou Xiuying","74-976-8870","a9xO0zRv8U","Nara","lYBzIDHlGz","1-7-6 Saidaiji Akodacho","206.19","0.00","396.51","77.49","263","886.65","604.24","85","naZVhwIDVJ","XZ58QxVWc2","DqcweigYB6","5U8URPr0r7","Zhou Xiuying","271","248","267","836","444","215","804","865","lAs0ujehgH","Zhou Xiuying","Y897eo4Nkp","448","47","0");
INSERT INTO cmf_shop_order VALUES("55","4","289","251","89","oMmJXOD1yQ","","467","vvnwjWQU2e","Shannon Garcia","7849 607506","oQYKJsF58S","Manchester","Ib566qBhCg","428 Spring Gardens","872.54","0.00","584.10","934.52","666","349.24","938.27","111","7hgz9LwNIQ","fJdycodCTH","hTzEcRQrDw","sbjcxXWCJ5","Shannon Garcia","468","931","117","742","7","445","437","82","DwfH42G5jR","Shannon Garcia","NAIcNqFPfb","546","685","0");
INSERT INTO cmf_shop_order VALUES("56","16","614","792","104","i2GDTPXwUf","","104","Bl38gYpMWK","Yue Yu Ling","718-895-1627","dwhc0fli3U","Brooklyn","AVS3HPBfyF","544 Nostrand Ave","480.59","0.00","771.26","252.64","88","313.22","373.36","99","Nxrlnej7V0","5SmzxYT4j8","H6paY2NOpj","cQ4aq5anMs","Yue Yu Ling","791","777","406","112","555","691","884","65","EhUVoZDEmd","Yue Yu Ling","m3gsLoO5wk","240","496","0");
INSERT INTO cmf_shop_order VALUES("57","30","74","14","78","lVfJ85shrx","","831","URmfC44f21","Lai Wai Man","213-697-3314","OqpfICQ0S8","Los Angeles","zFvtjxrmMI","630 Grape Street","952.47","0.00","686.48","660.14","282","333.05","242.20","34","zNbt3bFtq4","emExFXNC3A","9RMsQBrxU3","V8EA5py3su","Lai Wai Man","440","880","504","605","433","827","238","524","q5brKlrvRT","Lai Wai Man","tZwROjbZtw","549","96","0");
INSERT INTO cmf_shop_order VALUES("58","119","758","734","32","map73dlMw4","","976","x8spRv9nYU","Takeda Ikki","3-0327-4733","UUheD4Qiri","Tokyo","vTly7Ax4Zg","1-5-1, Higashi-Shimbashi, Minato-ku","721.43","0.00","358.03","925.47","734","202.59","846.24","99","0uzqseEVwh","SIkyUwVAUl","Rjve6Wv9d6","63S8irLoe7","Takeda Ikki","671","343","964","909","700","746","21","976","VqWy8maJaE","Takeda Ikki","W0LXB93Fpl","358","989","0");
INSERT INTO cmf_shop_order VALUES("59","6","800","121","101","72ZyONxzZR","","796","a0y1n4FKaL","Fang Lu","10-4088-2020","GVTqTJheFW","Beijing","FV1uoA9Qyp","759 028 County Rd, Yanqing District","657.86","0.00","517.33","72.29","10","200.88","800.25","27","qRNaISgXA0","1P4RGvZOpW","QIDvbjZPrc","pbZDkzjkVB","Fang Lu","858","409","276","259","190","168","405","263","2KkQVaA4kI","Fang Lu","wyRweUzIwk","731","767","0");
INSERT INTO cmf_shop_order VALUES("60","23","617","815","87","YShrz2Gu2D","","413","uNy5VH8jVw","Choi Tak Wah","(1223) 14 4831","fAw4LlKwtR","Cambridge","lGu0GGizWr","918 Whitehouse Lane, Huntingdon Rd","235.38","0.00","836.65","774.16","40","786.71","510.81","113","FeTrIBsYYR","EnFDNZbUsG","vwvk56qrRK","vvL7ZfPr1B","Choi Tak Wah","449","362","674","634","155","174","803","964","2oybVTSVVI","Choi Tak Wah","oZmWDApgoe","780","96","0");
INSERT INTO cmf_shop_order VALUES("61","33","319","576","0","iGIyGsIwio","","102","h2kDWE4VaG","Takeuchi Hina","80-9416-6132","ZZiIm3KtHI","Sapporo","ZfueU2oU4O","13-3-7 Toyohira 3 Jo, Toyohira Ward","579.84","0.00","488.71","954.20","97","656.73","359.14","54","xSchvQVKG8","Z05xMVvg1M","0v4rUtj6MR","XuC6z6wRT3","Takeuchi Hina","693","379","356","727","589","494","420","891","LWv157ycqV","Takeuchi Hina","0PvWrlAxzU","635","71","0");
INSERT INTO cmf_shop_order VALUES("62","125","945","100","96","wKG5nS0IqK","","234","LY3n2cY3l1","Phillip Diaz","70-5056-0762","SGfea6Mk2O","Sapporo","RZvvCrwNXf","5-19-4 Shinei 4 Jo, Kiyota Ward","623.39","0.00","135.26","774.18","973","348.41","447.73","5","B4xnYqF1jp","aRnr1fJJ1V","bZkDOUJoEt","KsGWgwEE5P","Phillip Diaz","645","9","228","575","819","842","681","175","sqfEonfsEm","Phillip Diaz","7U8usLt5WU","188","187","0");
INSERT INTO cmf_shop_order VALUES("63","123","395","837","72","8H0TZFTmAo","","587","R0rdWpK7Q1","Edward Griffin","10-2853-3034","uDohXYYTEW","Beijing","qkxYuSADqe","851 East Wangfujing Street, Dongcheng District ","455.08","0.00","31.40","951.28","616","463.07","667.60","99","lgkUlqQyHt","ZJqbZzGxSr","nQ7RJoCbeg","q5SogqZLEf","Edward Griffin","166","144","458","455","684","916","407","892","v0tk3YtvMk","Edward Griffin","X7nNi2mLTE","412","529","0");
INSERT INTO cmf_shop_order VALUES("64","78","953","500","35","S3kPENzcOv","","426","1xBAwzCL5V","Hsuan Fat","156-2995-1478","vdHpzXNtWr","Beijing","CxroywRsQo","750 West Chang\'an Avenue, Xicheng District","500.51","0.00","357.38","908.41","173","724.36","201.29","111","L6Lc7GyE6Y","IumHVMmFNv","hwZAEc7a4K","GIkjhBhk8F","Hsuan Fat","381","258","880","509","614","570","525","373","gIkJGtXDKU","Hsuan Fat","d5e3GUFkvp","690","697","0");
INSERT INTO cmf_shop_order VALUES("65","37","636","637","20","nFcsFN4hun","","715","MMrFDIhIua","Leonard Reed","148-6049-1663","yl8bmqSCeL","Chengdu","YVVnlwHaRC","No.536, Dongsan Road, Erxianqiao, Chenghua District","571.47","0.00","803.73","401.50","993","481.60","308.87","106","8ekgNgirVV","tIN0LbpBFb","QNHwgthzG0","8FBkKtcuq6","Leonard Reed","231","451","798","951","716","663","415","298","TxbgjKWqYf","Leonard Reed","rO2mb9Eeqf","767","905","0");
INSERT INTO cmf_shop_order VALUES("66","49","400","404","108","Ax9dGw14kL","","305","XMcUmZLwF2","Arimura Momoe","718-630-0520","XI25zTq6M7","Brooklyn","QBy33tDGu5","509 Columbia St","59.63","0.00","507.86","229.55","310","903.64","894.26","17","SJTmxEVD7o","DfEGqBudGQ","dosRmUO8K7","zErBWcpspl","Arimura Momoe","840","96","830","963","699","489","833","351","RgtDX01e3a","Arimura Momoe","4gAeOj2PpS","820","759","0");
INSERT INTO cmf_shop_order VALUES("67","123","650","245","39","gIbQHtlS0k","","541","RT0uFz1Ar7","Tammy Wells","90-0308-2494","2Eug27iMPB","Sapporo","rEgq5kawxP","2-1-19 Kaminopporo 1 Jo, Atsubetsu Ward","70.50","0.00","874.90","334.43","81","420.44","905.92","60","fOSCpzqHcf","BlkiPe6GWi","06R1ELFOiT","Lfs7eJwrFX","Tammy Wells","915","317","253","714","238","467","777","43","J71IRoRyMX","Tammy Wells","BepK3lhLB4","234","667","0");
INSERT INTO cmf_shop_order VALUES("68","71","725","760","119","wXaAPPe6CA","","863","5IA8UttvBr","Yuen Ka Ming","70-3492-2251","UY8uHYmZOt","Nara","QlWnpMlc6f","1-7-1 Saidaiji Akodacho","995.11","0.00","733.86","25.32","548","952.31","968.91","10","ftJhxvEGlD","mQ02E6jUuc","2FSQJibFbX","O2Ks0yaubC","Yuen Ka Ming","956","425","520","493","343","776","81","388","ZC7k9yX7Km","Yuen Ka Ming","vxrDP2aReS","65","513","0");
INSERT INTO cmf_shop_order VALUES("69","22","794","191","97","nkyq857Azk","","410","NllSkZYXSV","Chen Yuning","10-697-8404","QuI8YKzkau","Beijing","2efb6EmyO3","112 Dong Zhi Men, Dongcheng District","524.25","0.00","600.08","89.99","392","14.92","84.20","105","jmluIx7ULq","wC4Cm6Rqm4","HvqDKAyInu","AZ46OPzr4z","Chen Yuning","733","529","787","876","301","469","882","227","S2oPCfzL9h","Chen Yuning","COrZ4m3Hui","981","722","0");
INSERT INTO cmf_shop_order VALUES("70","125","653","295","78","9S1YYTaY4Y","","690","ytAorkqd2c","Man Ka Keung","(1865) 70 2068","ysfkcPoJ0b","Oxford","G5IVSHRbh2","505 Little Clarendon St","992.82","0.00","292.82","319.68","80","849.82","936.77","64","th4pRW5wsY","vg2mLtbLb6","1rWQaMVxsA","ynBlfrVTmD","Man Ka Keung","2","484","58","148","179","749","108","329","O38AJyYKI4","Man Ka Keung","e06lZOCWxf","650","575","0");
INSERT INTO cmf_shop_order VALUES("71","61","93","174","0","vRqJx1SO2v","","429","q3yEJGkntk","Tong Sau Man","838-690-3692","Drm7Zw6Jqu","Albany","Tg6E2VElRs","330 State Street","466.94","0.00","861.01","772.19","198","390.32","584.73","105","5kFhhwE2To","gUKExHY3iv","PAfTVMLBas","JtKBnXGFui","Tong Sau Man","976","479","189","829","143","863","860","774","kzaIc5LSp7","Tong Sau Man","99KKXLTpXk","293","298","0");
INSERT INTO cmf_shop_order VALUES("72","112","587","152","31","CRiPcQJczi","","442","MNBqLXhvsL","Cui Shihan","11-703-4953","WvlpKEqWzp","Sapporo","fmoCBiJSfx","5-19-10 Shinei 4 Jo, Kiyota Ward","435.13","0.00","805.57","578.84","704","288.69","538.12","22","ZSrDokCy3J","OZnbqdweKa","NTKuP3gpSP","pXX15V16De","Cui Shihan","104","749","952","661","489","670","621","400","8MpOK0ZM08","Cui Shihan","dIb97wYxIm","343","742","0");
INSERT INTO cmf_shop_order VALUES("73","114","74","618","89","eTAvlGNyt5","","753","c2W7mhTUEt","Craig Rose","718-492-8265","n2neXS8arx","Brooklyn","T9ZNoaogjW","718 Nostrand Ave","370.66","0.00","952.40","568.40","644","878.19","737.07","21","vtsgmEU7mt","WKiPLq4adD","AaN4U8h2m0","h5eB5s357N","Craig Rose","133","45","730","62","915","83","387","640","6NKQSF7CX8","Craig Rose","YpMfLpD1Ut","385","131","0");
INSERT INTO cmf_shop_order VALUES("74","39","813","655","97","ySxWVKc5ad","","62","IjuwsPeHYW","Charles Morales","(151) 384 4882","UHxLHnkdYn","Liverpool","p9WlL7AJbi","825 Aigburth Rd, Aigburth","406.38","0.00","637.87","318.82","616","143.57","39.80","9","kW4B810YCG","9WenoJ7348","6Frf5FP1Ue","szMC9k7rSR","Charles Morales","694","498","911","146","67","620","662","380","wd4z7Jr8PJ","Charles Morales","KGA4gI7heM","201","480","0");
INSERT INTO cmf_shop_order VALUES("75","89","75","477","18","DAnZQxMWw2","","985","CX0z3WczKt","Siu Yun Fat","213-052-8267","najKRJyzmT","Los Angeles","xOJZrirTKc","720 Figueroa Street","260.33","0.00","399.72","166.28","673","768.92","982.33","67","aAHlo9pu1s","ubq3mJ8Siv","6hc69Pnwaq","VsXwR9Dk5L","Siu Yun Fat","669","950","202","403","103","548","250","705","c9wiW1xFni","Siu Yun Fat","JL23O2JhEz","164","799","0");
INSERT INTO cmf_shop_order VALUES("76","21","578","340","100","LLT8yNXKEz","","293","IVbhha2tm9","So Wing Sze","192-6014-4286","NqrV4OmmOR","Shenzhen","h1CNR7PtTs","15 Shennan Ave, Futian District","6.70","0.00","455.83","140.32","134","606.09","943.98","63","xpmYDa0Osp","00JmrzN1I6","rOkKEWJx7y","rGg3SEalXW","So Wing Sze","856","904","983","878","473","561","92","164","khLPEngL4G","So Wing Sze","dIUTOcma4a","638","124","0");
INSERT INTO cmf_shop_order VALUES("77","83","788","556","92","udLqT06lDF","","914","xnsI4gwmiQ","Du Jialun","(151) 484 9212","hAAnKU7gIf","Liverpool","OLwtPwbybG","970 Redfern St","448.60","0.00","55.83","657.73","978","302.36","509.77","27","xSdefJN2sE","80K3LzBA8f","CRwq1KCi3B","p3SF318fsb","Du Jialun","417","417","495","789","86","161","646","536","Jzz4yeM87q","Du Jialun","oNiViKHukr","496","835","0");
INSERT INTO cmf_shop_order VALUES("78","68","610","297","108","PVBKe0Y2yi","","838","ARuRPrFqjp","Kobayashi Sakura","7992 546743","8fNZ4wfHQR","Liverpool","sxWOijWRwm","286 Aigburth Rd, Aigburth","679.01","0.00","325.36","699.37","896","106.75","997.41","89","qfTJq36pPy","qOmZ8nqzf2","9Kn6allDWx","oQCqZnHrTj","Kobayashi Sakura","146","745","274","577","820","457","50","138","RzrdTwAzEm","Kobayashi Sakura","JycYIv7Bz9","955","970","0");
INSERT INTO cmf_shop_order VALUES("79","124","932","639","12","xgDscFpj5x","","561","jJGAODBCZj","Sakurai Ryota","330-371-1609","GLixwGneRc","Akron","KNIq8pdjHW","943 Collier Road","424.57","0.00","439.85","386.17","31","117.18","509.90","118","mIXci8RI4u","8HLcGVh0Ky","XeZXaXq3DT","ii9eAase74","Sakurai Ryota","117","314","616","11","904","833","717","167","k1XnDkx7Ik","Sakurai Ryota","MW4ZdI7LyS","849","42","0");
INSERT INTO cmf_shop_order VALUES("80","64","478","129","81","EafALWGOwX","","919","r9vksWmzZq","Chu Siu Wai","52-957-7066","7Ajja7BCyJ","Nagoya","nq3OUs3HGQ","7 4-20 Kawagishicho, Mizuho Ward","58.89","0.00","405.11","545.69","605","422.87","951.06","25","9Q172glbmn","tTODQ45byS","P0y2TD84sQ","ZPwLzFhwIe","Chu Siu Wai","306","586","103","77","447","815","124","76","bf5gqFnnvS","Chu Siu Wai","eGq0WuN4QF","14","97","0");
INSERT INTO cmf_shop_order VALUES("81","65","961","718","95","Bs3VG7SJIZ","","770","MlPLllgDpv","Dale Gutierrez","80-1406-5660","MvDt1f6Kcr","Nara","Dlfe2qzQk1","11 1-1 Honjocho, Yamatokoriyama","401.19","0.00","749.59","725.63","605","202.76","904.97","19","TMsiwhsJhH","FvAQZjccOV","OYakxYgxbA","uFFdizcEGD","Dale Gutierrez","620","28","67","442","517","722","144","62","YSe7NM3XWy","Dale Gutierrez","ywN7ElXmeb","857","788","0");
INSERT INTO cmf_shop_order VALUES("82","64","505","928","72","nfaxuNvK2k","","815","h6MDH99u8Q","Yeow Ka Ling","5577 100302","JPzHbHocKF","Oxford","Nig7091hoD","891 Elms Rd, Botley","925.60","0.00","358.54","138.74","306","433.72","787.10","123","LiiKer9SAQ","h8ZAHxmi43","jnaoJfBb2P","UfhrVDVYjn","Yeow Ka Ling","122","378","785","972","334","735","728","123","NefGLpJB6M","Yeow Ka Ling","ZqPwyPrhBh","180","919","0");
INSERT INTO cmf_shop_order VALUES("83","117","764","863","32","RhumaduEXn","","57","0WdZoPpmn0","Catherine Hamilton","20-4319-2787","lhoudSlkSS","Guangzhou","oqzezl0utJ","692 Jiangnan West Road, Haizhu District","753.78","0.00","468.81","180.51","808","842.78","241.20","38","ZW8HDtATQN","RZ4cLPA6Ph","ByVspF1GGY","2c2FeDDuF8","Catherine Hamilton","96","939","499","634","28","646","315","537","hGpPaJdMqI","Catherine Hamilton","AAJWtwcWIA","912","970","0");
INSERT INTO cmf_shop_order VALUES("84","66","12","467","9","4L7Vk4Vf68","","287","5OzXjN9Lhc","Matsuda Yuto","188-7663-7476","RDe5b63Cu7","Beijing","3toUh90naL","520 Sanlitun Road, Chaoyang District","469.61","0.00","770.60","929.40","591","138.47","886.28","64","U8NByfwZvl","TSUWKNEqwf","LK0IvNoyyn","QMjn0w8Dyu","Matsuda Yuto","256","674","775","722","826","69","485","321","7pZZNtLasG","Matsuda Yuto","I6D0Sx8cTn","877","149","0");
INSERT INTO cmf_shop_order VALUES("85","32","862","691","80","17Pnp4VZrU","","343","RvFUqJWn9W","Jacqueline Turner","28-961-5050","hQtHPCI9Pk","Chengdu","kMOWhwjnqx","988 NO.6, YuShuang Road, ChengHua Distric","250.48","0.00","671.07","630.47","269","761.59","765.44","51","YEDdiSmHKD","7WXew4GM46","gJti6AAwd7","mqmqtXtOiA","Jacqueline Turner","329","777","354","299","694","744","579","49","W339lFisKX","Jacqueline Turner","OY8d3VZqQS","445","208","0");
INSERT INTO cmf_shop_order VALUES("86","70","394","948","46","WO5OTGw9PS","","7","yNRSvr2GMP","Yoshida Yuna","312-919-5137","Br5ZIRP1TN","Chicago","m8KTeYqgxI","993 Pedway","198.40","0.00","331.65","298.92","71","425.30","145.14","66","p49CO7ALaa","DmJtTKnQ3t","iY4phLZRlk","qKQhtCczEP","Yoshida Yuna","304","778","748","657","777","970","704","488","sujriyJJ2Y","Yoshida Yuna","N8ezGEjxoj","700","496","0");
INSERT INTO cmf_shop_order VALUES("87","11","176","899","97","kd12PwFMie","","78","anKxv0s48F","Feng Lan","718-875-1319","eSsAXDdgK8","Brooklyn","o3V8k3R1cD","182 1st Ave","250.38","0.00","630.91","399.98","34","877.23","123.94","8","QdvEZmlIz6","lidu8TQO2s","o0E00Vt8m2","qci7SfQa3r","Feng Lan","651","645","592","169","490","458","408","925","14UmvaPYxb","Feng Lan","EKPpaTw28t","196","365","0");
INSERT INTO cmf_shop_order VALUES("88","103","824","919","89","2idldUTpQV","","33","zcmoxL2e1C","Kwong Ka Fai","330-375-1557","ZUWjKj0PoO","Akron","vi75z6fLak","481 Ridgewood Road","751.09","0.00","728.87","451.22","728","112.72","594.24","127","uFLtvaBi0K","Nd4s8V7DxR","x4LXhGVmKa","8u5jfCa5S0","Kwong Ka Fai","685","450","403","676","765","950","188","297","DtxdI6mAsu","Kwong Ka Fai","2VuBPjgBSC","212","273","0");
INSERT INTO cmf_shop_order VALUES("89","119","869","318","35","9IyMvI0VEn","","41","R55ihDA9hv","Mao Xiuying","213-816-6348","W8EF5tmNmw","Los Angeles","bdL08yH52B","423 S Broadway","662.72","0.00","946.42","302.26","738","138.73","141.36","64","MP99DvuTCn","F4wC3OPzmu","2qhnDecylZ","Dt3qyqJrH9","Mao Xiuying","651","983","315","616","542","554","335","313","xWKyt64yR2","Mao Xiuying","0qreqvpMvT","510","157","0");
INSERT INTO cmf_shop_order VALUES("90","36","672","346","13","g9iWeVxFBY","","190","YLQMiXmKbJ","Fujita Momoka","5941 890579","mHiqoGjunV","Birmingham","XdX0xmpTnD","795 Cannon Street","732.63","0.00","127.49","824.94","741","272.40","84.72","87","ouMYVHd1xL","kgAcGkYmwk","nK6H4FYaTE","97WoKp7WOg","Fujita Momoka","546","660","497","960","819","794","567","16","C8Ty7jJrpQ","Fujita Momoka","lkjN6qKO5G","690","347","0");
INSERT INTO cmf_shop_order VALUES("91","7","629","302","64","88nqqo1dPK","","110","679bzsvmSU","Tony Gutierrez","7481 440182","SWI8e7JZv5","Manchester","0ZCSoHxVpS","971 New Wakefield St","609.03","0.00","832.76","741.24","573","197.76","656.48","76","a8TbtGGHIv","EzY3SwucYj","IAj40VPrRI","0ssXCWkn5V","Tony Gutierrez","196","173","808","205","857","75","264","183","YK6IMsavMX","Tony Gutierrez","Dht9O7wRFd","121","857","0");
INSERT INTO cmf_shop_order VALUES("92","100","621","535","121","OziSK5ZTyG","","987","huiwSnoBkG","Sherry Morales","52-266-8524","ealIonXBRP","Nagoya","mvcxOuQshc","2-5-7 Chitose, Atsuta Ward","122.39","0.00","787.50","272.39","86","413.66","215.06","120","qua1MzRn7L","kWq8XoJDvd","x5TuDdyHaR","QTfZUl2Hmr","Sherry Morales","940","616","377","474","63","324","786","584","tBvNJQfMRA","Sherry Morales","bpXncIRKHB","249","87","0");
INSERT INTO cmf_shop_order VALUES("93","119","754","525","44","GvaesLX4NL","","60","JjetzEPBOv","To Chi Ming","11-275-6096","f6uSYGZ2a5","Sapporo","tvEmCVsuyO","13-3-18 Toyohira 3 Jo, Toyohira Ward","103.77","0.00","27.28","275.95","140","351.46","308.63","21","j8dIjILVNr","7StUjvk3G6","VM11IDJtPI","d2uBYVAjmj","To Chi Ming","228","600","146","896","342","947","664","221","tMzzKGEPfa","To Chi Ming","RPRs5V5VAE","822","235","0");
INSERT INTO cmf_shop_order VALUES("94","35","787","853","76","opgkveaxBy","","272","PoQyZ9CoZZ","Bonnie Collins","212-714-4404","Jmj2vq7F9V","New York","4J0hSHNTKD","46 Bank Street","663.18","0.00","249.11","817.10","304","860.50","147.24","46","sJ1vHQarJy","DeMml2d6M8","4FxiovIMV4","nCPx9ah6Ce","Bonnie Collins","749","833","467","553","415","774","831","166","WdpnobZDH4","Bonnie Collins","hH0I16k7CN","985","590","0");
INSERT INTO cmf_shop_order VALUES("95","33","143","907","35","g98CrTYAgc","","696","9UsRxhbSGD","Imai Ren","7616 886191","DY98YV9oWv","Manchester","iauLzfT69k","142 Portland St","260.05","0.00","961.46","593.82","14","839.66","598.18","118","2eGWTNYkMe","1nKELBhSBW","etFvEA3mIi","ComYtt3IqL","Imai Ren","905","499","227","530","723","321","979","383","F2ZpytVUeG","Imai Ren","5sRdSzTpTM","338","765","0");
INSERT INTO cmf_shop_order VALUES("96","107","821","894","59","pf4DiWWcrS","","95","EB50zlFi4d","Ono Daisuke","5410 134568","gsziVI2xip","London","f6fwEc2HMO","433 Hanover Street","749.38","0.00","158.88","238.35","325","911.86","799.21","16","I6XotnzobG","m6ypxf5B1A","QxR99AU656","W6ByGmfH0k","Ono Daisuke","843","250","355","360","788","932","18","630","usISfHHm6g","Ono Daisuke","PmAcMp53xj","1","424","0");
INSERT INTO cmf_shop_order VALUES("97","108","437","448","26","qISeKeUTe2","","838","q6bmSXqKtQ","Beverly Spencer","212-825-4898","MCa7pjC9NV","New York","zlV2NBEVVP","225 Fifth Avenue","272.69","0.00","81.93","946.63","104","786.78","80.76","40","ycbSTgoF9X","fSPFi6hgIm","ecNMzOCJ1N","jqqPapnynn","Beverly Spencer","205","775","323","819","292","234","978","26","RtGdtmPbhZ","Beverly Spencer","GFZdOC3O2d","554","548","0");
INSERT INTO cmf_shop_order VALUES("98","29","862","377","8","znVd2nzraV","","983","GD2c8LJj4Z","Shen Zitao","70-8816-7926","Oe2iSFOsTw","Sapporo","wmwTkgTw7n","13-3-20 Toyohira 3 Jo, Toyohira Ward","80.41","0.00","276.23","717.87","221","980.12","99.32","53","s8juRLMt2L","lyFz3R8qbg","YfBXp5cFfj","Tdcks1YrTQ","Shen Zitao","292","285","730","585","641","954","932","967","iEMBZ1UmyY","Shen Zitao","R80SHvMOBj","673","278","0");
INSERT INTO cmf_shop_order VALUES("99","92","316","894","84","jbU4PgMk1z","","218","zBavGzi8tQ","Jimmy Thompson","312-041-2551","AQhnoL7Yvt","Chicago","amLsf7UCK7","69 Rush Street","974.65","0.00","778.50","918.16","451","488.98","624.58","80","jBVHItqhwr","JhopV5rTYU","4AxJukm5fB","gU948DIOfa","Jimmy Thompson","208","843","564","830","632","230","513","659","DTPIQOn2Kk","Jimmy Thompson","eX5F2h7dif","439","227","0");
INSERT INTO cmf_shop_order VALUES("100","21","411","720","101","FIF0ZN1BNi","","738","NrouhEVSq5","Jia Xiaoming","5589 363049","aaghJZ060u","Leicester","A5U7G3Njuu","570 Narborough Rd","687.50","0.00","924.32","622.36","432","403.88","421.70","81","NnVZHms7aa","nZweUhfQLK","R8JexgO8XE","nqRSSelZOo","Jia Xiaoming","576","507","743","354","43","410","510","577","Mh0cu0OBNv","Jia Xiaoming","SaboMVnaa8","449","719","0");
INSERT INTO cmf_shop_order VALUES("101","99","30","59","91","aGxgNQy98C","","350","A4VfKuTqzA","Ma Kar Yan","70-9600-8024","v58ht3u3e9","Sapporo","Au7nKOJEBQ","6-1-12, Miyanomori 4 Jō, Chuo Ward","636.41","0.00","566.78","285.72","792","345.59","374.56","2","os9AYH86Ou","CfMzTu0kmO","wYiMJ4Ttt5","TsmFt13UBw","Ma Kar Yan","131","896","637","920","137","185","561","308","7Y2QkAEIVg","Ma Kar Yan","Wx3DeNAafG","313","456","0");



DROP TABLE cmf_shop_order_detail;

CREATE TABLE `cmf_shop_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) DEFAULT NULL COMMENT '店铺',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `goods_id` int(11) DEFAULT NULL COMMENT '商品',
  `sku_id` int(11) DEFAULT NULL COMMENT '规格',
  `goods_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '规格名字',
  `count` int(11) DEFAULT NULL COMMENT '购买数量',
  `is_vip` tinyint(4) DEFAULT '0' COMMENT '是否是会员:0否,1是',
  `goods_price` decimal(8,2) DEFAULT NULL COMMENT '价格/单价',
  `vip_price` decimal(8,2) DEFAULT '0.00' COMMENT '会员价/单价   同步到普通单价里面,方便展示',
  `vip_amount` decimal(8,2) DEFAULT '0.00' COMMENT '会员价/合计   同步到普通合计里面,方便展示',
  `coupon_amount` decimal(8,2) DEFAULT '0.00' COMMENT '优惠金额',
  `total_amount` decimal(8,2) DEFAULT NULL COMMENT '合计',
  `image` varchar(255) DEFAULT NULL COMMENT '展示图',
  `status` tinyint(4) DEFAULT NULL COMMENT '退款状态:0未提交,1审核中,2已通过,3已驳回',
  `order_num` varchar(255) DEFAULT '0' COMMENT '订单单号',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='订单详情';

INSERT INTO cmf_shop_order_detail VALUES("1","0","1","1","1","测试","测试测试","1","0","0.01","0.00","0.00","0.00","0.00","https://oss.ausite.cn/dz000/default/20230628/820c42f489d2cc76e078959c44fc5776.png","0","1","1696491848","0","0");



DROP TABLE cmf_shop_order_refund;

CREATE TABLE `cmf_shop_order_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) DEFAULT '1' COMMENT '订单类型:1抢购,2限购',
  `user_id` int(11) DEFAULT NULL COMMENT '用户',
  `refund_why` varchar(300) DEFAULT NULL COMMENT '退款原因',
  `order_num` varchar(120) DEFAULT NULL COMMENT '退款订单号',
  `amount` decimal(8,2) DEFAULT NULL COMMENT '退款金额',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态:1审核中, 2已通过,3已驳回,4已取消',
  `refuse` varchar(255) DEFAULT NULL COMMENT '拒绝理由',
  `refund_num` varchar(255) DEFAULT NULL COMMENT '退款订单号',
  `content` text COMMENT '说明',
  `images` text COMMENT '图集',
  `refuse_time` bigint(20) DEFAULT NULL COMMENT '拒绝时间',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `delete_time` bigint(20) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款管理';




DROP TABLE cmf_slide;

CREATE TABLE `cmf_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示,0不显示',
  `delete_time` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '删除时间',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片分类',
  `remark` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '分类备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片表';

INSERT INTO cmf_slide VALUES("1","1","0","首页轮播图","首页轮播图[请勿删除]");



DROP TABLE cmf_slide_item;

CREATE TABLE `cmf_slide_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide_id` int(11) NOT NULL DEFAULT '0' COMMENT '幻灯片id',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '状态,1:显示;0:隐藏',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '幻灯片名称',
  `image` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片图片',
  `url` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '幻灯片链接',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '友情链接打开方式',
  `description` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '幻灯片描述',
  `content` text CHARACTER SET utf8 COMMENT '幻灯片内容',
  `more` text COMMENT '扩展信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `slide_id` (`slide_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='幻灯片子项表';

INSERT INTO cmf_slide_item VALUES("1","1","1","1000","1","dz000/admin/20220928/f6eb31a4707d3e8705bce2402f331592.jpg","","_blank","","","");



DROP TABLE cmf_theme;

CREATE TABLE `cmf_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后升级时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '模板状态,1:正在使用;0:未使用',
  `is_compiled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否为已编译模板',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '主题目录名，用于主题的维一标识',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '主题名称',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '主题版本号',
  `demo_url` varchar(50) NOT NULL DEFAULT '' COMMENT '演示地址，带协议',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `author` varchar(20) NOT NULL DEFAULT '' COMMENT '主题作者',
  `author_url` varchar(50) NOT NULL DEFAULT '' COMMENT '作者网站链接',
  `lang` varchar(10) NOT NULL DEFAULT '' COMMENT '支持语言',
  `keywords` varchar(50) NOT NULL DEFAULT '' COMMENT '主题关键字',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '主题描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='轮播图';

INSERT INTO cmf_theme VALUES("1","0","0","0","0","default","default","1.0.0","http://demo.thinkcmf.com","","ThinkCMF","http://www.thinkcmf.com","zh-cn","ThinkCMF默认模板","ThinkCMF默认模板");



DROP TABLE cmf_theme_file;

CREATE TABLE `cmf_theme_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_public` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否公共的模板文件',
  `list_order` float NOT NULL DEFAULT '10000' COMMENT '排序',
  `theme` varchar(20) NOT NULL DEFAULT '' COMMENT '模板名称',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '模板文件名',
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作',
  `file` varchar(50) NOT NULL DEFAULT '' COMMENT '模板文件，相对于模板根目录，如Portal/index.html',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT '模板文件描述',
  `more` text COMMENT '模板更多配置,用户自己后台设置的',
  `config_more` text COMMENT '模板更多配置,来源模板的配置文件',
  `draft_more` text COMMENT '模板更多配置,用户临时保存的配置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='轮播图,图片';

INSERT INTO cmf_theme_file VALUES("1","0","5","default","首页","demo/Index/index","demo/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");
INSERT INTO cmf_theme_file VALUES("2","0","5","default","首页","portal/Index/index","portal/index","首页模板文件","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","{\"vars\":{\"top_slide\":{\"title\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"admin\\/Slide\\/index\",\"multi\":false},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"tip\":\"\\u9876\\u90e8\\u5e7b\\u706f\\u7247\",\"rule\":{\"require\":true}}},\"widgets\":{\"features\":{\"title\":\"\\u5feb\\u901f\\u4e86\\u89e3ThinkCMF\",\"display\":\"1\",\"vars\":{\"sub_title\":{\"title\":\"\\u526f\\u6807\\u9898\",\"value\":\"Quickly understand the ThinkCMF\",\"type\":\"text\",\"placeholder\":\"\\u8bf7\\u8f93\\u5165\\u526f\\u6807\\u9898\",\"tip\":\"\",\"rule\":{\"require\":true}},\"features\":{\"title\":\"\\u7279\\u6027\\u4ecb\\u7ecd\",\"value\":[{\"title\":\"MVC\\u5206\\u5c42\\u6a21\\u5f0f\",\"icon\":\"bars\",\"content\":\"\\u4f7f\\u7528MVC\\u5e94\\u7528\\u7a0b\\u5e8f\\u88ab\\u5206\\u6210\\u4e09\\u4e2a\\u6838\\u5fc3\\u90e8\\u4ef6\\uff1a\\u6a21\\u578b\\uff08M\\uff09\\u3001\\u89c6\\u56fe\\uff08V\\uff09\\u3001\\u63a7\\u5236\\u5668\\uff08C\\uff09\\uff0c\\u4ed6\\u4e0d\\u662f\\u4e00\\u4e2a\\u65b0\\u7684\\u6982\\u5ff5\\uff0c\\u53ea\\u662fThinkCMF\\u5c06\\u5176\\u53d1\\u6325\\u5230\\u4e86\\u6781\\u81f4\\u3002\"},{\"title\":\"\\u7528\\u6237\\u7ba1\\u7406\",\"icon\":\"group\",\"content\":\"ThinkCMF\\u5185\\u7f6e\\u4e86\\u7075\\u6d3b\\u7684\\u7528\\u6237\\u7ba1\\u7406\\u65b9\\u5f0f\\uff0c\\u5e76\\u53ef\\u76f4\\u63a5\\u4e0e\\u7b2c\\u4e09\\u65b9\\u7ad9\\u70b9\\u8fdb\\u884c\\u4e92\\u8054\\u4e92\\u901a\\uff0c\\u5982\\u679c\\u4f60\\u613f\\u610f\\u751a\\u81f3\\u53ef\\u4ee5\\u5bf9\\u5355\\u4e2a\\u7528\\u6237\\u6216\\u7fa4\\u4f53\\u7528\\u6237\\u7684\\u884c\\u4e3a\\u8fdb\\u884c\\u8bb0\\u5f55\\u53ca\\u5206\\u4eab\\uff0c\\u4e3a\\u60a8\\u7684\\u8fd0\\u8425\\u51b3\\u7b56\\u63d0\\u4f9b\\u6709\\u6548\\u53c2\\u8003\\u6570\\u636e\\u3002\"},{\"title\":\"\\u4e91\\u7aef\\u90e8\\u7f72\",\"icon\":\"cloud\",\"content\":\"\\u901a\\u8fc7\\u9a71\\u52a8\\u7684\\u65b9\\u5f0f\\u53ef\\u4ee5\\u8f7b\\u677e\\u652f\\u6301\\u4e91\\u5e73\\u53f0\\u7684\\u90e8\\u7f72\\uff0c\\u8ba9\\u4f60\\u7684\\u7f51\\u7ad9\\u65e0\\u7f1d\\u8fc1\\u79fb\\uff0c\\u5185\\u7f6e\\u5df2\\u7ecf\\u652f\\u6301SAE\\u3001BAE\\uff0c\\u6b63\\u5f0f\\u7248\\u5c06\\u5bf9\\u4e91\\u7aef\\u90e8\\u7f72\\u8fdb\\u884c\\u8fdb\\u4e00\\u6b65\\u4f18\\u5316\\u3002\"},{\"title\":\"\\u5b89\\u5168\\u7b56\\u7565\",\"icon\":\"heart\",\"content\":\"\\u63d0\\u4f9b\\u7684\\u7a33\\u5065\\u7684\\u5b89\\u5168\\u7b56\\u7565\\uff0c\\u5305\\u62ec\\u5907\\u4efd\\u6062\\u590d\\uff0c\\u5bb9\\u9519\\uff0c\\u9632\\u6cbb\\u6076\\u610f\\u653b\\u51fb\\u767b\\u9646\\uff0c\\u7f51\\u9875\\u9632\\u7be1\\u6539\\u7b49\\u591a\\u9879\\u5b89\\u5168\\u7ba1\\u7406\\u529f\\u80fd\\uff0c\\u4fdd\\u8bc1\\u7cfb\\u7edf\\u5b89\\u5168\\uff0c\\u53ef\\u9760\\uff0c\\u7a33\\u5b9a\\u7684\\u8fd0\\u884c\\u3002\"},{\"title\":\"\\u5e94\\u7528\\u6a21\\u5757\\u5316\",\"icon\":\"cubes\",\"content\":\"\\u63d0\\u51fa\\u5168\\u65b0\\u7684\\u5e94\\u7528\\u6a21\\u5f0f\\u8fdb\\u884c\\u6269\\u5c55\\uff0c\\u4e0d\\u7ba1\\u662f\\u4f60\\u5f00\\u53d1\\u4e00\\u4e2a\\u5c0f\\u529f\\u80fd\\u8fd8\\u662f\\u4e00\\u4e2a\\u5168\\u65b0\\u7684\\u7ad9\\u70b9\\uff0c\\u5728ThinkCMF\\u4e2d\\u4f60\\u53ea\\u662f\\u589e\\u52a0\\u4e86\\u4e00\\u4e2aAPP\\uff0c\\u6bcf\\u4e2a\\u72ec\\u7acb\\u8fd0\\u884c\\u4e92\\u4e0d\\u5f71\\u54cd\\uff0c\\u4fbf\\u4e8e\\u7075\\u6d3b\\u6269\\u5c55\\u548c\\u4e8c\\u6b21\\u5f00\\u53d1\\u3002\"},{\"title\":\"\\u514d\\u8d39\\u5f00\\u6e90\",\"icon\":\"certificate\",\"content\":\"\\u4ee3\\u7801\\u9075\\u5faaApache2\\u5f00\\u6e90\\u534f\\u8bae\\uff0c\\u514d\\u8d39\\u4f7f\\u7528\\uff0c\\u5bf9\\u5546\\u4e1a\\u7528\\u6237\\u4e5f\\u65e0\\u4efb\\u4f55\\u9650\\u5236\\u3002\"}],\"type\":\"array\",\"item\":{\"title\":{\"title\":\"\\u6807\\u9898\",\"value\":\"\",\"type\":\"text\",\"rule\":{\"require\":true}},\"icon\":{\"title\":\"\\u56fe\\u6807\",\"value\":\"\",\"type\":\"text\"},\"content\":{\"title\":\"\\u63cf\\u8ff0\",\"value\":\"\",\"type\":\"textarea\"}},\"tip\":\"\"}}},\"last_news\":{\"title\":\"\\u6700\\u65b0\\u8d44\\u8baf\",\"display\":\"1\",\"vars\":{\"last_news_category_id\":{\"title\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\",\"value\":\"\",\"type\":\"text\",\"dataSource\":{\"api\":\"portal\\/Category\\/index\",\"multi\":true},\"placeholder\":\"\\u8bf7\\u9009\\u62e9\\u5206\\u7c7b\",\"tip\":\"\",\"rule\":{\"require\":true}}}}}}","");



DROP TABLE cmf_user;

CREATE TABLE `cmf_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(3) unsigned DEFAULT '1' COMMENT '用户类型;1:admin;2:会员',
  `sex` tinyint(2) DEFAULT '0' COMMENT '性别;0:保密,1:男,2:女',
  `birthday` int(11) DEFAULT '0' COMMENT '生日',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `score` int(11) DEFAULT '0' COMMENT '用户积分',
  `coin` int(10) unsigned DEFAULT '0' COMMENT '金币',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '余额',
  `user_status` tinyint(3) unsigned DEFAULT '1' COMMENT '用户状态;0:禁用,1:正常,2:未验证',
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `user_pass` varchar(64) DEFAULT '' COMMENT '登录密码;cmf_password加密',
  `user_nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户昵称',
  `user_email` varchar(100) DEFAULT '' COMMENT '用户登录邮箱',
  `user_url` varchar(100) DEFAULT '' COMMENT '用户个人网址',
  `avatar` varchar(255) DEFAULT '' COMMENT '用户头像',
  `signature` varchar(255) DEFAULT '' COMMENT '个性签名',
  `last_login_ip` varchar(15) DEFAULT '' COMMENT '最后登录ip',
  `user_activation_key` varchar(60) DEFAULT '' COMMENT '激活码',
  `mobile` varchar(20) DEFAULT '' COMMENT '中国手机不带国家代码，国际手机号格式为：国家代码-手机号',
  `more` text COMMENT '扩展属性',
  `is_contract` tinyint(4) DEFAULT '2' COMMENT '查看合同:1是,2否',
  `create_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `update_time` bigint(20) DEFAULT NULL,
  `delete_time` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_login` (`user_login`) USING BTREE,
  KEY `user_nickname` (`user_nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO cmf_user VALUES("1","1","0","0","1740965375","0","0","0.00","1","admin","###7a83c4a197d689babb621303f7f65c07","admin","admin@gmail.com","","","","123.14.175.1","","","","2","1660558068","","0");
INSERT INTO cmf_user VALUES("2","1","0","0","1735353352","0","0","0.00","1","test1","###c312d5fbef62b46c9ef089b8a8dff5c6","","","","","","123.14.174.35","","15801055988","","2","0","1735354271","0");
INSERT INTO cmf_user VALUES("5","1","0","0","1735354321","0","0","0.00","0","test555","###69bad127654ba4ed702e0acc9e6d5cb7","","","","","","123.14.174.35","","18888854541","","0","1735353788","1735354331","0");



DROP TABLE cmf_user_login_attempt;

CREATE TABLE `cmf_user_login_attempt` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试次数',
  `attempt_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '尝试登录时间',
  `locked_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '锁定时间',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户 ip',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '用户账号,手机号,邮箱或用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户登录尝试表';




DROP TABLE cmf_user_token;

CREATE TABLE `cmf_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户id',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 过期时间',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `token` varchar(64) NOT NULL DEFAULT '' COMMENT 'token',
  `device_type` varchar(10) NOT NULL DEFAULT '' COMMENT '设备类型;mobile,android,iphone,ipad,web,pc,mac,wxapp',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='用户客户端登录 token 表';

INSERT INTO cmf_user_token VALUES("1","1","1755332022","1739780022","21a141d229b251c404dbebbcf3334aa910dbe0b7d68eb339b8df8f96de00ed84","web");
INSERT INTO cmf_user_token VALUES("2","5","1750906298","1735354298","03f8880a016368367a36f27bb950566695adbe47a2cab470bf15950269bf0e13","web");



DROP TABLE cmf_verification_code;

CREATE TABLE `cmf_verification_code` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '当天已经发送成功的次数',
  `send_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后发送成功时间',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证码过期时间',
  `code` varchar(8) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '最后发送成功的验证码',
  `account` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '手机号或者邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='手机邮箱数字验证码表';




